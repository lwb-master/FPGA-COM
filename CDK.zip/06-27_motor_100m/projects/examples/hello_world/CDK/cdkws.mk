.PHONY: clean All Project_Title Project_Build Project_PostBuild

All: Project_Title Project_Build Project_PostBuild

Project_Title:
	@echo "----------Building project:[ wujian100_open-hello_world - BuildSet ]----------"

Project_Build:
	@make -r -f wujian100_open-hello_world.mk -j 32 -C  ./ 

Project_PostBuild:
	@echo Executing Post Build commands ...
	@export CDKPath="D:/C-Sky/CDK" CDK_VERSION="V2.24.11" CPU="RV32EMC" ProjectName="wujian100_open-hello_world" ProjectPath="C:/Users/ThinkStation/Desktop/colorprinter0412/06-27_motor_100m/projects/examples/hello_world/CDK/" && "C:/Users/ThinkStation/Desktop/colorprinter0412/06-27_motor_100m/projects/examples/hello_world/CDK/../../../../utilities//aft_build.sh"
	@echo Done


clean:
	@echo "----------Cleaning project:[ wujian100_open-hello_world - BuildSet ]----------"

