
.//Obj/wujian100_open-hello_world.elf:     file format elf32-littleriscv


Disassembly of section .text:

00000000 <Reset_Handler>:
       0:	20000197          	auipc	gp,0x20000
       4:	4e818193          	addi	gp,gp,1256 # 200004e8 <g_system_clock>
       8:	00000517          	auipc	a0,0x0
       c:	1b850513          	addi	a0,a0,440 # 1c0 <Default_Handler>
      10:	00356513          	ori	a0,a0,3
      14:	30551073          	csrw	mtvec,a0
      18:	b1818513          	addi	a0,gp,-1256 # 20000000 <__Vectors>
      1c:	30751073          	csrw	mtvt,a0
      20:	20001117          	auipc	sp,0x20001
      24:	58810113          	addi	sp,sp,1416 # 200015a8 <g_top_irqstack>
      28:	00007517          	auipc	a0,0x7
      2c:	b9850513          	addi	a0,a0,-1128 # 6bc0 <__ctor_end__>
      30:	b1818593          	addi	a1,gp,-1256 # 20000000 <__Vectors>
      34:	02418613          	addi	a2,gp,36 # 2000050c <pgpio_pin_handle>
      38:	00c5fa63          	bgeu	a1,a2,4c <Reset_Handler+0x4c>
    la      a0, __erodata
    la      a1, __data_start__
    la      a2, __data_end__
    bgeu    a1, a2, 2f
1:
    lw      t0, (a0)
      3c:	00052283          	lw	t0,0(a0)
    sw      t0, (a1)
      40:	0055a023          	sw	t0,0(a1)
      44:	0511                	addi	a0,a0,4
      46:	0591                	addi	a1,a1,4
      48:	fec5eae3          	bltu	a1,a2,3c <Reset_Handler+0x3c>
      4c:	02418513          	addi	a0,gp,36 # 2000050c <pgpio_pin_handle>
      50:	20002597          	auipc	a1,0x20002
      54:	d4458593          	addi	a1,a1,-700 # 20001d94 <__bss_end__>
      58:	00b57763          	bgeu	a0,a1,66 <Reset_Handler+0x66>
      5c:	00052023          	sw	zero,0(a0)
    la      a0, __bss_start__
    la      a1, __bss_end__
    bgeu    a0, a1, 2f
1:
    sw      zero, (a0)
    addi    a0, a0, 4
      60:	0511                	addi	a0,a0,4
    bltu    a0, a1, 1b
      62:	feb56de3          	bltu	a0,a1,5c <Reset_Handler+0x5c>
2:

#ifndef __NO_SYSTEM_INIT
    jal     SystemInit
      66:	272030ef          	jal	32d8 <SystemInit>
      6a:	130020ef          	jal	219a <board_init>
      6e:	584030ef          	jal	35f2 <main>

00000072 <__exit>:
      72:	a001                	j	72 <__exit>
	...

00000080 <Default_IRQHandler>:
      80:	7179                	addi	sp,sp,-48
    .global Default_IRQHandler
    .weak   Default_IRQHandler
    .type   Default_IRQHandler, %function
Default_IRQHandler:
    addi    sp, sp, -48
    sw      t0, 4(sp)
      82:	c216                	sw	t0,4(sp)
    sw      t1, 8(sp)
      84:	c41a                	sw	t1,8(sp)
    csrr    t0, mepc
      86:	341022f3          	csrr	t0,mepc
    csrr    t1, mcause
      8a:	34202373          	csrr	t1,mcause
    sw      t1, 40(sp)
      8e:	d41a                	sw	t1,40(sp)
    sw      t0, 44(sp)
      90:	d616                	sw	t0,44(sp)
    csrs    mstatus, 8
      92:	30046073          	csrsi	mstatus,8

    sw      ra, 0(sp)
      96:	c006                	sw	ra,0(sp)
    sw      t2, 12(sp)
      98:	c61e                	sw	t2,12(sp)
    sw      a0, 16(sp)
      9a:	c82a                	sw	a0,16(sp)
    sw      a1, 20(sp)
      9c:	ca2e                	sw	a1,20(sp)
    sw      a2, 24(sp)
      9e:	cc32                	sw	a2,24(sp)
      a0:	ce36                	sw	a3,28(sp)
      a2:	d03a                	sw	a4,32(sp)
      a4:	d23e                	sw	a5,36(sp)
      a6:	3ff37313          	andi	t1,t1,1023
    sw      a3, 28(sp)
    sw      a4, 32(sp)
    sw      a5, 36(sp)

    andi    t1, t1, 0x3FF
    slli    t1, t1, 2
      aa:	030a                	slli	t1,t1,0x2

    la      t0, g_irqvector
      ac:	20002297          	auipc	t0,0x20002
      b0:	ad428293          	addi	t0,t0,-1324 # 20001b80 <g_irqvector>
    add     t0, t0, t1
      b4:	929a                	add	t0,t0,t1
    lw      t2, (t0)
      b6:	0002a383          	lw	t2,0(t0)
    jalr    t2
      ba:	9382                	jalr	t2

    csrc    mstatus, 8
      bc:	30047073          	csrci	mstatus,8

    lw      a1, 40(sp)
      c0:	55a2                	lw	a1,40(sp)
    andi    a0, a1, 0x3FF
      c2:	3ff5f513          	andi	a0,a1,1023

    /* clear pending */
    li      a2, 0xE000E100
      c6:	e000e637          	lui	a2,0xe000e
      ca:	10060613          	addi	a2,a2,256 # e000e100 <__heap_end+0xbffde100>
    add     a2, a2, a0
      ce:	962a                	add	a2,a2,a0
    lb      a3, 0(a2)
      d0:	00060683          	lb	a3,0(a2)
    li      a4, 1
      d4:	4705                	li	a4,1
    not     a4, a4
      d6:	fff74713          	not	a4,a4
    and     a5, a4, a3
      da:	00d777b3          	and	a5,a4,a3
    sb      a5, 0(a2)
      de:	00f60023          	sb	a5,0(a2)

    li      t0, MSTATUS_PRV1
      e2:	6289                	lui	t0,0x2
      e4:	88028293          	addi	t0,t0,-1920 # 1880 <__muldf3+0x2ee>
    csrs    mstatus, t0
      e8:	3002a073          	csrs	mstatus,t0
    csrw    mcause, a1
      ec:	34259073          	csrw	mcause,a1
    lw      t0, 44(sp)
      f0:	52b2                	lw	t0,44(sp)
    csrw    mepc, t0
      f2:	34129073          	csrw	mepc,t0
    lw      ra, 0(sp)
      f6:	4082                	lw	ra,0(sp)
    lw      t0, 4(sp)
      f8:	4292                	lw	t0,4(sp)
    lw      t1, 8(sp)
      fa:	4322                	lw	t1,8(sp)
    lw      t2, 12(sp)
      fc:	43b2                	lw	t2,12(sp)
    lw      a0, 16(sp)
      fe:	4542                	lw	a0,16(sp)
    lw      a1, 20(sp)
     100:	45d2                	lw	a1,20(sp)
    lw      a2, 24(sp)
     102:	4662                	lw	a2,24(sp)
    lw      a3, 28(sp)
     104:	46f2                	lw	a3,28(sp)
    lw      a4, 32(sp)
     106:	5702                	lw	a4,32(sp)
    lw      a5, 36(sp)
     108:	5792                	lw	a5,36(sp)

    addi    sp, sp, 48
     10a:	6145                	addi	sp,sp,48
    mret
     10c:	30200073          	mret

00000110 <trap>:
    .align  2
    .global trap
    .type   trap, %function
trap:
    /* Check for interrupt */
    addi    sp, sp, -4
     110:	1171                	addi	sp,sp,-4
    sw      t0, 0x0(sp)
     112:	c016                	sw	t0,0(sp)
    csrr    t0, mcause
     114:	342022f3          	csrr	t0,mcause

    blt     t0, x0, .Lirq
     118:	0602c463          	bltz	t0,180 <trap+0x70>

    addi    sp, sp, 4
     11c:	0111                	addi	sp,sp,4

    la      t0, g_trap_sp
     11e:	20001297          	auipc	t0,0x20001
     122:	68a28293          	addi	t0,t0,1674 # 200017a8 <g_trap_sp>
    addi    t0, t0, -68
     126:	fbc28293          	addi	t0,t0,-68
    sw      x1, 0(t0)
     12a:	0012a023          	sw	ra,0(t0)
    sw      x2, 4(t0)
     12e:	0022a223          	sw	sp,4(t0)
    sw      x3, 8(t0)
     132:	0032a423          	sw	gp,8(t0)
    sw      x4, 12(t0)
     136:	0042a623          	sw	tp,12(t0)
    sw      x6, 20(t0)
     13a:	0062aa23          	sw	t1,20(t0)
    sw      x7, 24(t0)
     13e:	0072ac23          	sw	t2,24(t0)
    sw      x8, 28(t0)
     142:	0082ae23          	sw	s0,28(t0)
    sw      x9, 32(t0)
     146:	0292a023          	sw	s1,32(t0)
    sw      x10, 36(t0)
     14a:	02a2a223          	sw	a0,36(t0)
    sw      x11, 40(t0)
     14e:	02b2a423          	sw	a1,40(t0)
    sw      x12, 44(t0)
     152:	02c2a623          	sw	a2,44(t0)
    sw      x13, 48(t0)
     156:	02d2a823          	sw	a3,48(t0)
    sw      x14, 52(t0)
     15a:	02e2aa23          	sw	a4,52(t0)
    sw      x15, 56(t0)
     15e:	02f2ac23          	sw	a5,56(t0)
    csrr    a0, mepc
     162:	34102573          	csrr	a0,mepc
    sw      a0, 60(t0)
     166:	02a2ae23          	sw	a0,60(t0)
    csrr    a0, mstatus
     16a:	30002573          	csrr	a0,mstatus
    sw      a0, 64(t0)
     16e:	04a2a023          	sw	a0,64(t0)

    mv      a0, t0
     172:	8516                	mv	a0,t0
    lw      t0, -4(sp)
     174:	ffc12283          	lw	t0,-4(sp)
    mv      sp, a0
     178:	812a                	mv	sp,a0
    sw      t0, 16(sp)
     17a:	c816                	sw	t0,16(sp)

    jal     trap_c
     17c:	1ba030ef          	jal	3336 <trap_c>


.Lirq:
    lw      t0, 0x0(sp)
     180:	4282                	lw	t0,0(sp)
    addi    sp, sp, 4
     182:	0111                	addi	sp,sp,4
    j       Default_IRQHandler
     184:	efdff06f          	j	80 <Default_IRQHandler>
     188:	00000013          	nop
     18c:	00000013          	nop
     190:	00000013          	nop
     194:	00000013          	nop
     198:	00000013          	nop
     19c:	00000013          	nop
     1a0:	00000013          	nop
     1a4:	00000013          	nop
     1a8:	00000013          	nop
     1ac:	00000013          	nop
     1b0:	00000013          	nop
     1b4:	00000013          	nop
     1b8:	00000013          	nop
     1bc:	00000013          	nop

000001c0 <Default_Handler>:
    .align  6
    .weak   Default_Handler
    .global Default_Handler
    .type   Default_Handler, %function
Default_Handler:
    j      trap
     1c0:	bf81                	j	110 <trap>
	...

000001f6 <__udivdi3>:
     1f6:	832a                	mv	t1,a0
     1f8:	82ae                	mv	t0,a1
     1fa:	20069263          	bnez	a3,3fe <__udivdi3+0x208>
     1fe:	872a                	mv	a4,a0
     200:	87b2                	mv	a5,a2
     202:	00006517          	auipc	a0,0x6
     206:	c6a50513          	addi	a0,a0,-918 # 5e6c <__clz_tab>
     20a:	0ac5fe63          	bgeu	a1,a2,2c6 <__udivdi3+0xd0>
     20e:	66c1                	lui	a3,0x10
     210:	0ad67463          	bgeu	a2,a3,2b8 <__udivdi3+0xc2>
     214:	10063693          	sltiu	a3,a2,256
     218:	0016b693          	seqz	a3,a3
     21c:	068e                	slli	a3,a3,0x3
     21e:	00d653b3          	srl	t2,a2,a3
     222:	951e                	add	a0,a0,t2
     224:	00054503          	lbu	a0,0(a0)
     228:	02000393          	li	t2,32
     22c:	96aa                	add	a3,a3,a0
     22e:	40d38533          	sub	a0,t2,a3
     232:	00d38b63          	beq	t2,a3,248 <__udivdi3+0x52>
     236:	00a295b3          	sll	a1,t0,a0
     23a:	00d356b3          	srl	a3,t1,a3
     23e:	00a617b3          	sll	a5,a2,a0
     242:	8dd5                	or	a1,a1,a3
     244:	00a31733          	sll	a4,t1,a0
     248:	0107d313          	srli	t1,a5,0x10
     24c:	0265d3b3          	divu	t2,a1,t1
     250:	01079613          	slli	a2,a5,0x10
     254:	8241                	srli	a2,a2,0x10
     256:	01075693          	srli	a3,a4,0x10
     25a:	0265f5b3          	remu	a1,a1,t1
     25e:	851e                	mv	a0,t2
     260:	027602b3          	mul	t0,a2,t2
     264:	05c2                	slli	a1,a1,0x10
     266:	8ecd                	or	a3,a3,a1
     268:	0056fc63          	bgeu	a3,t0,280 <__udivdi3+0x8a>
     26c:	96be                	add	a3,a3,a5
     26e:	fff38513          	addi	a0,t2,-1
     272:	00f6e763          	bltu	a3,a5,280 <__udivdi3+0x8a>
     276:	0056f563          	bgeu	a3,t0,280 <__udivdi3+0x8a>
     27a:	ffe38513          	addi	a0,t2,-2
     27e:	96be                	add	a3,a3,a5
     280:	405686b3          	sub	a3,a3,t0
     284:	0266d5b3          	divu	a1,a3,t1
     288:	0742                	slli	a4,a4,0x10
     28a:	8341                	srli	a4,a4,0x10
     28c:	0266f6b3          	remu	a3,a3,t1
     290:	02b60633          	mul	a2,a2,a1
     294:	06c2                	slli	a3,a3,0x10
     296:	8f55                	or	a4,a4,a3
     298:	86ae                	mv	a3,a1
     29a:	00c77b63          	bgeu	a4,a2,2b0 <__udivdi3+0xba>
     29e:	973e                	add	a4,a4,a5
     2a0:	fff58693          	addi	a3,a1,-1
     2a4:	00f76663          	bltu	a4,a5,2b0 <__udivdi3+0xba>
     2a8:	00c77463          	bgeu	a4,a2,2b0 <__udivdi3+0xba>
     2ac:	ffe58693          	addi	a3,a1,-2
     2b0:	0542                	slli	a0,a0,0x10
     2b2:	8d55                	or	a0,a0,a3
     2b4:	4581                	li	a1,0
     2b6:	8082                	ret
     2b8:	010003b7          	lui	t2,0x1000
     2bc:	46e1                	li	a3,24
     2be:	f67670e3          	bgeu	a2,t2,21e <__udivdi3+0x28>
     2c2:	46c1                	li	a3,16
     2c4:	bfa9                	j	21e <__udivdi3+0x28>
     2c6:	4681                	li	a3,0
     2c8:	ca09                	beqz	a2,2da <__udivdi3+0xe4>
     2ca:	66c1                	lui	a3,0x10
     2cc:	08d67d63          	bgeu	a2,a3,366 <__udivdi3+0x170>
     2d0:	10063693          	sltiu	a3,a2,256
     2d4:	0016b693          	seqz	a3,a3
     2d8:	068e                	slli	a3,a3,0x3
     2da:	00d655b3          	srl	a1,a2,a3
     2de:	952e                	add	a0,a0,a1
     2e0:	00054583          	lbu	a1,0(a0)
     2e4:	96ae                	add	a3,a3,a1
     2e6:	02000593          	li	a1,32
     2ea:	40d58533          	sub	a0,a1,a3
     2ee:	08d59363          	bne	a1,a3,374 <__udivdi3+0x17e>
     2f2:	40c28633          	sub	a2,t0,a2
     2f6:	4585                	li	a1,1
     2f8:	0107d313          	srli	t1,a5,0x10
     2fc:	026653b3          	divu	t2,a2,t1
     300:	01079693          	slli	a3,a5,0x10
     304:	82c1                	srli	a3,a3,0x10
     306:	01075513          	srli	a0,a4,0x10
     30a:	02667633          	remu	a2,a2,t1
     30e:	027682b3          	mul	t0,a3,t2
     312:	0642                	slli	a2,a2,0x10
     314:	8e49                	or	a2,a2,a0
     316:	851e                	mv	a0,t2
     318:	00567c63          	bgeu	a2,t0,330 <__udivdi3+0x13a>
     31c:	963e                	add	a2,a2,a5
     31e:	fff38513          	addi	a0,t2,-1 # ffffff <__ctor_end__+0xff943f>
     322:	00f66763          	bltu	a2,a5,330 <__udivdi3+0x13a>
     326:	00567563          	bgeu	a2,t0,330 <__udivdi3+0x13a>
     32a:	ffe38513          	addi	a0,t2,-2
     32e:	963e                	add	a2,a2,a5
     330:	40560633          	sub	a2,a2,t0
     334:	026652b3          	divu	t0,a2,t1
     338:	0742                	slli	a4,a4,0x10
     33a:	8341                	srli	a4,a4,0x10
     33c:	02667633          	remu	a2,a2,t1
     340:	025686b3          	mul	a3,a3,t0
     344:	0642                	slli	a2,a2,0x10
     346:	8f51                	or	a4,a4,a2
     348:	8616                	mv	a2,t0
     34a:	00d77b63          	bgeu	a4,a3,360 <__udivdi3+0x16a>
     34e:	973e                	add	a4,a4,a5
     350:	fff28613          	addi	a2,t0,-1
     354:	00f76663          	bltu	a4,a5,360 <__udivdi3+0x16a>
     358:	00d77463          	bgeu	a4,a3,360 <__udivdi3+0x16a>
     35c:	ffe28613          	addi	a2,t0,-2
     360:	0542                	slli	a0,a0,0x10
     362:	8d51                	or	a0,a0,a2
     364:	8082                	ret
     366:	010005b7          	lui	a1,0x1000
     36a:	46e1                	li	a3,24
     36c:	f6b677e3          	bgeu	a2,a1,2da <__udivdi3+0xe4>
     370:	46c1                	li	a3,16
     372:	b7a5                	j	2da <__udivdi3+0xe4>
     374:	00d2d5b3          	srl	a1,t0,a3
     378:	00a617b3          	sll	a5,a2,a0
     37c:	00a292b3          	sll	t0,t0,a0
     380:	00d356b3          	srl	a3,t1,a3
     384:	0056e633          	or	a2,a3,t0
     388:	0107d293          	srli	t0,a5,0x10
     38c:	0255d3b3          	divu	t2,a1,t0
     390:	00a31733          	sll	a4,t1,a0
     394:	01079513          	slli	a0,a5,0x10
     398:	8141                	srli	a0,a0,0x10
     39a:	01065693          	srli	a3,a2,0x10
     39e:	0255f5b3          	remu	a1,a1,t0
     3a2:	02750333          	mul	t1,a0,t2
     3a6:	05c2                	slli	a1,a1,0x10
     3a8:	8ecd                	or	a3,a3,a1
     3aa:	859e                	mv	a1,t2
     3ac:	0066fc63          	bgeu	a3,t1,3c4 <__udivdi3+0x1ce>
     3b0:	96be                	add	a3,a3,a5
     3b2:	fff38593          	addi	a1,t2,-1
     3b6:	00f6e763          	bltu	a3,a5,3c4 <__udivdi3+0x1ce>
     3ba:	0066f563          	bgeu	a3,t1,3c4 <__udivdi3+0x1ce>
     3be:	ffe38593          	addi	a1,t2,-2
     3c2:	96be                	add	a3,a3,a5
     3c4:	406686b3          	sub	a3,a3,t1
     3c8:	0256d333          	divu	t1,a3,t0
     3cc:	0642                	slli	a2,a2,0x10
     3ce:	8241                	srli	a2,a2,0x10
     3d0:	0256f6b3          	remu	a3,a3,t0
     3d4:	02650533          	mul	a0,a0,t1
     3d8:	06c2                	slli	a3,a3,0x10
     3da:	8e55                	or	a2,a2,a3
     3dc:	869a                	mv	a3,t1
     3de:	00a67c63          	bgeu	a2,a0,3f6 <__udivdi3+0x200>
     3e2:	963e                	add	a2,a2,a5
     3e4:	fff30693          	addi	a3,t1,-1
     3e8:	00f66763          	bltu	a2,a5,3f6 <__udivdi3+0x200>
     3ec:	00a67563          	bgeu	a2,a0,3f6 <__udivdi3+0x200>
     3f0:	ffe30693          	addi	a3,t1,-2
     3f4:	963e                	add	a2,a2,a5
     3f6:	05c2                	slli	a1,a1,0x10
     3f8:	8e09                	sub	a2,a2,a0
     3fa:	8dd5                	or	a1,a1,a3
     3fc:	bdf5                	j	2f8 <__udivdi3+0x102>
     3fe:	14d5e663          	bltu	a1,a3,54a <__udivdi3+0x354>
     402:	67c1                	lui	a5,0x10
     404:	02f6ff63          	bgeu	a3,a5,442 <__udivdi3+0x24c>
     408:	1006b713          	sltiu	a4,a3,256
     40c:	00173713          	seqz	a4,a4
     410:	070e                	slli	a4,a4,0x3
     412:	00e6d5b3          	srl	a1,a3,a4
     416:	00006797          	auipc	a5,0x6
     41a:	a5678793          	addi	a5,a5,-1450 # 5e6c <__clz_tab>
     41e:	97ae                	add	a5,a5,a1
     420:	0007c783          	lbu	a5,0(a5)
     424:	97ba                	add	a5,a5,a4
     426:	02000713          	li	a4,32
     42a:	40f705b3          	sub	a1,a4,a5
     42e:	02f71163          	bne	a4,a5,450 <__udivdi3+0x25a>
     432:	4505                	li	a0,1
     434:	1056ee63          	bltu	a3,t0,550 <__udivdi3+0x35a>
     438:	00c33533          	sltu	a0,t1,a2
     43c:	00153513          	seqz	a0,a0
     440:	8082                	ret
     442:	010007b7          	lui	a5,0x1000
     446:	4761                	li	a4,24
     448:	fcf6f5e3          	bgeu	a3,a5,412 <__udivdi3+0x21c>
     44c:	4741                	li	a4,16
     44e:	b7d1                	j	412 <__udivdi3+0x21c>
     450:	00b69733          	sll	a4,a3,a1
     454:	00f656b3          	srl	a3,a2,a5
     458:	8ed9                	or	a3,a3,a4
     45a:	1161                	addi	sp,sp,-8
     45c:	00f2d733          	srl	a4,t0,a5
     460:	c222                	sw	s0,4(sp)
     462:	0106d413          	srli	s0,a3,0x10
     466:	c026                	sw	s1,0(sp)
     468:	028754b3          	divu	s1,a4,s0
     46c:	00b292b3          	sll	t0,t0,a1
     470:	00f357b3          	srl	a5,t1,a5
     474:	0057e7b3          	or	a5,a5,t0
     478:	01069293          	slli	t0,a3,0x10
     47c:	0102d293          	srli	t0,t0,0x10
     480:	00b61633          	sll	a2,a2,a1
     484:	02877733          	remu	a4,a4,s0
     488:	029283b3          	mul	t2,t0,s1
     48c:	01071513          	slli	a0,a4,0x10
     490:	0107d713          	srli	a4,a5,0x10
     494:	8f49                	or	a4,a4,a0
     496:	8526                	mv	a0,s1
     498:	00777c63          	bgeu	a4,t2,4b0 <__udivdi3+0x2ba>
     49c:	9736                	add	a4,a4,a3
     49e:	fff48513          	addi	a0,s1,-1
     4a2:	00d76763          	bltu	a4,a3,4b0 <__udivdi3+0x2ba>
     4a6:	00777563          	bgeu	a4,t2,4b0 <__udivdi3+0x2ba>
     4aa:	ffe48513          	addi	a0,s1,-2
     4ae:	9736                	add	a4,a4,a3
     4b0:	40770733          	sub	a4,a4,t2
     4b4:	028753b3          	divu	t2,a4,s0
     4b8:	07c2                	slli	a5,a5,0x10
     4ba:	83c1                	srli	a5,a5,0x10
     4bc:	02877733          	remu	a4,a4,s0
     4c0:	027282b3          	mul	t0,t0,t2
     4c4:	0742                	slli	a4,a4,0x10
     4c6:	8fd9                	or	a5,a5,a4
     4c8:	871e                	mv	a4,t2
     4ca:	0057fc63          	bgeu	a5,t0,4e2 <__udivdi3+0x2ec>
     4ce:	97b6                	add	a5,a5,a3
     4d0:	fff38713          	addi	a4,t2,-1
     4d4:	00d7e763          	bltu	a5,a3,4e2 <__udivdi3+0x2ec>
     4d8:	0057f563          	bgeu	a5,t0,4e2 <__udivdi3+0x2ec>
     4dc:	ffe38713          	addi	a4,t2,-2
     4e0:	97b6                	add	a5,a5,a3
     4e2:	0542                	slli	a0,a0,0x10
     4e4:	8d59                	or	a0,a0,a4
     4e6:	01071693          	slli	a3,a4,0x10
     4ea:	01061413          	slli	s0,a2,0x10
     4ee:	82c1                	srli	a3,a3,0x10
     4f0:	01055393          	srli	t2,a0,0x10
     4f4:	8041                	srli	s0,s0,0x10
     4f6:	8241                	srli	a2,a2,0x10
     4f8:	405787b3          	sub	a5,a5,t0
     4fc:	028682b3          	mul	t0,a3,s0
     500:	02838433          	mul	s0,t2,s0
     504:	0102d713          	srli	a4,t0,0x10
     508:	02c686b3          	mul	a3,a3,a2
     50c:	96a2                	add	a3,a3,s0
     50e:	9736                	add	a4,a4,a3
     510:	02c383b3          	mul	t2,t2,a2
     514:	00877463          	bgeu	a4,s0,51c <__udivdi3+0x326>
     518:	66c1                	lui	a3,0x10
     51a:	93b6                	add	t2,t2,a3
     51c:	01075693          	srli	a3,a4,0x10
     520:	969e                	add	a3,a3,t2
     522:	00d7ee63          	bltu	a5,a3,53e <__udivdi3+0x348>
     526:	00d79d63          	bne	a5,a3,540 <__udivdi3+0x34a>
     52a:	02c2                	slli	t0,t0,0x10
     52c:	0742                	slli	a4,a4,0x10
     52e:	0102d293          	srli	t0,t0,0x10
     532:	00b31333          	sll	t1,t1,a1
     536:	9716                	add	a4,a4,t0
     538:	4581                	li	a1,0
     53a:	00e37463          	bgeu	t1,a4,542 <__udivdi3+0x34c>
     53e:	157d                	addi	a0,a0,-1
     540:	4581                	li	a1,0
     542:	4412                	lw	s0,4(sp)
     544:	4482                	lw	s1,0(sp)
     546:	0121                	addi	sp,sp,8
     548:	8082                	ret
     54a:	4581                	li	a1,0
     54c:	4501                	li	a0,0
     54e:	8082                	ret
     550:	8082                	ret

00000552 <__umoddi3>:
     552:	872e                	mv	a4,a1
     554:	87aa                	mv	a5,a0
     556:	1c069463          	bnez	a3,71e <__umoddi3+0x1cc>
     55a:	8332                	mv	t1,a2
     55c:	00006297          	auipc	t0,0x6
     560:	91028293          	addi	t0,t0,-1776 # 5e6c <__clz_tab>
     564:	0ac5f863          	bgeu	a1,a2,614 <__umoddi3+0xc2>
     568:	66c1                	lui	a3,0x10
     56a:	08d67e63          	bgeu	a2,a3,606 <__umoddi3+0xb4>
     56e:	10063693          	sltiu	a3,a2,256
     572:	0016b693          	seqz	a3,a3
     576:	068e                	slli	a3,a3,0x3
     578:	00d653b3          	srl	t2,a2,a3
     57c:	929e                	add	t0,t0,t2
     57e:	0002c283          	lbu	t0,0(t0)
     582:	02000393          	li	t2,32
     586:	92b6                	add	t0,t0,a3
     588:	405386b3          	sub	a3,t2,t0
     58c:	00538c63          	beq	t2,t0,5a4 <__umoddi3+0x52>
     590:	00d715b3          	sll	a1,a4,a3
     594:	005552b3          	srl	t0,a0,t0
     598:	00d61333          	sll	t1,a2,a3
     59c:	00b2e5b3          	or	a1,t0,a1
     5a0:	00d517b3          	sll	a5,a0,a3
     5a4:	01035613          	srli	a2,t1,0x10
     5a8:	02c5d733          	divu	a4,a1,a2
     5ac:	01031513          	slli	a0,t1,0x10
     5b0:	8141                	srli	a0,a0,0x10
     5b2:	02c5f5b3          	remu	a1,a1,a2
     5b6:	02a70733          	mul	a4,a4,a0
     5ba:	01059293          	slli	t0,a1,0x10
     5be:	0107d593          	srli	a1,a5,0x10
     5c2:	0055e5b3          	or	a1,a1,t0
     5c6:	00e5f863          	bgeu	a1,a4,5d6 <__umoddi3+0x84>
     5ca:	959a                	add	a1,a1,t1
     5cc:	0065e563          	bltu	a1,t1,5d6 <__umoddi3+0x84>
     5d0:	00e5f363          	bgeu	a1,a4,5d6 <__umoddi3+0x84>
     5d4:	959a                	add	a1,a1,t1
     5d6:	8d99                	sub	a1,a1,a4
     5d8:	02c5d733          	divu	a4,a1,a2
     5dc:	07c2                	slli	a5,a5,0x10
     5de:	83c1                	srli	a5,a5,0x10
     5e0:	02c5f5b3          	remu	a1,a1,a2
     5e4:	02a70733          	mul	a4,a4,a0
     5e8:	05c2                	slli	a1,a1,0x10
     5ea:	8fcd                	or	a5,a5,a1
     5ec:	00e7f863          	bgeu	a5,a4,5fc <__umoddi3+0xaa>
     5f0:	979a                	add	a5,a5,t1
     5f2:	0067e563          	bltu	a5,t1,5fc <__umoddi3+0xaa>
     5f6:	00e7f363          	bgeu	a5,a4,5fc <__umoddi3+0xaa>
     5fa:	979a                	add	a5,a5,t1
     5fc:	8f99                	sub	a5,a5,a4
     5fe:	00d7d533          	srl	a0,a5,a3
     602:	4581                	li	a1,0
     604:	8082                	ret
     606:	010003b7          	lui	t2,0x1000
     60a:	46e1                	li	a3,24
     60c:	f67676e3          	bgeu	a2,t2,578 <__umoddi3+0x26>
     610:	46c1                	li	a3,16
     612:	b79d                	j	578 <__umoddi3+0x26>
     614:	4681                	li	a3,0
     616:	ca09                	beqz	a2,628 <__umoddi3+0xd6>
     618:	66c1                	lui	a3,0x10
     61a:	08d67163          	bgeu	a2,a3,69c <__umoddi3+0x14a>
     61e:	10063693          	sltiu	a3,a2,256
     622:	0016b693          	seqz	a3,a3
     626:	068e                	slli	a3,a3,0x3
     628:	00d655b3          	srl	a1,a2,a3
     62c:	9596                	add	a1,a1,t0
     62e:	0005c583          	lbu	a1,0(a1) # 1000000 <__ctor_end__+0xff9440>
     632:	02000293          	li	t0,32
     636:	95b6                	add	a1,a1,a3
     638:	40b286b3          	sub	a3,t0,a1
     63c:	06b29763          	bne	t0,a1,6aa <__umoddi3+0x158>
     640:	8f11                	sub	a4,a4,a2
     642:	01035613          	srli	a2,t1,0x10
     646:	02c75533          	divu	a0,a4,a2
     64a:	01031593          	slli	a1,t1,0x10
     64e:	81c1                	srli	a1,a1,0x10
     650:	0107d293          	srli	t0,a5,0x10
     654:	02c77733          	remu	a4,a4,a2
     658:	02b50533          	mul	a0,a0,a1
     65c:	0742                	slli	a4,a4,0x10
     65e:	00e2e733          	or	a4,t0,a4
     662:	00a77863          	bgeu	a4,a0,672 <__umoddi3+0x120>
     666:	971a                	add	a4,a4,t1
     668:	00676563          	bltu	a4,t1,672 <__umoddi3+0x120>
     66c:	00a77363          	bgeu	a4,a0,672 <__umoddi3+0x120>
     670:	971a                	add	a4,a4,t1
     672:	8f09                	sub	a4,a4,a0
     674:	02c75533          	divu	a0,a4,a2
     678:	07c2                	slli	a5,a5,0x10
     67a:	83c1                	srli	a5,a5,0x10
     67c:	02c77733          	remu	a4,a4,a2
     680:	02b505b3          	mul	a1,a0,a1
     684:	0742                	slli	a4,a4,0x10
     686:	8fd9                	or	a5,a5,a4
     688:	00b7f863          	bgeu	a5,a1,698 <__umoddi3+0x146>
     68c:	979a                	add	a5,a5,t1
     68e:	0067e563          	bltu	a5,t1,698 <__umoddi3+0x146>
     692:	00b7f363          	bgeu	a5,a1,698 <__umoddi3+0x146>
     696:	979a                	add	a5,a5,t1
     698:	8f8d                	sub	a5,a5,a1
     69a:	b795                	j	5fe <__umoddi3+0xac>
     69c:	010005b7          	lui	a1,0x1000
     6a0:	46e1                	li	a3,24
     6a2:	f8b673e3          	bgeu	a2,a1,628 <__umoddi3+0xd6>
     6a6:	46c1                	li	a3,16
     6a8:	b741                	j	628 <__umoddi3+0xd6>
     6aa:	00d61333          	sll	t1,a2,a3
     6ae:	00d717b3          	sll	a5,a4,a3
     6b2:	00b75633          	srl	a2,a4,a1
     6b6:	00b55733          	srl	a4,a0,a1
     6ba:	8f5d                	or	a4,a4,a5
     6bc:	00d517b3          	sll	a5,a0,a3
     6c0:	01035513          	srli	a0,t1,0x10
     6c4:	02a655b3          	divu	a1,a2,a0
     6c8:	01031293          	slli	t0,t1,0x10
     6cc:	0102d293          	srli	t0,t0,0x10
     6d0:	02a67633          	remu	a2,a2,a0
     6d4:	025585b3          	mul	a1,a1,t0
     6d8:	01061393          	slli	t2,a2,0x10
     6dc:	01075613          	srli	a2,a4,0x10
     6e0:	00766633          	or	a2,a2,t2
     6e4:	00b67863          	bgeu	a2,a1,6f4 <__umoddi3+0x1a2>
     6e8:	961a                	add	a2,a2,t1
     6ea:	00666563          	bltu	a2,t1,6f4 <__umoddi3+0x1a2>
     6ee:	00b67363          	bgeu	a2,a1,6f4 <__umoddi3+0x1a2>
     6f2:	961a                	add	a2,a2,t1
     6f4:	8e0d                	sub	a2,a2,a1
     6f6:	02a655b3          	divu	a1,a2,a0
     6fa:	0742                	slli	a4,a4,0x10
     6fc:	8341                	srli	a4,a4,0x10
     6fe:	02a67633          	remu	a2,a2,a0
     702:	025585b3          	mul	a1,a1,t0
     706:	0642                	slli	a2,a2,0x10
     708:	8f51                	or	a4,a4,a2
     70a:	00b77863          	bgeu	a4,a1,71a <__umoddi3+0x1c8>
     70e:	971a                	add	a4,a4,t1
     710:	00676563          	bltu	a4,t1,71a <__umoddi3+0x1c8>
     714:	00b77363          	bgeu	a4,a1,71a <__umoddi3+0x1c8>
     718:	971a                	add	a4,a4,t1
     71a:	8f0d                	sub	a4,a4,a1
     71c:	b71d                	j	642 <__umoddi3+0xf0>
     71e:	00d5f363          	bgeu	a1,a3,724 <__umoddi3+0x1d2>
     722:	8082                	ret
     724:	6341                	lui	t1,0x10
     726:	0466f663          	bgeu	a3,t1,772 <__umoddi3+0x220>
     72a:	1006b293          	sltiu	t0,a3,256
     72e:	0012b293          	seqz	t0,t0
     732:	028e                	slli	t0,t0,0x3
     734:	0056d3b3          	srl	t2,a3,t0
     738:	00005317          	auipc	t1,0x5
     73c:	73430313          	addi	t1,t1,1844 # 5e6c <__clz_tab>
     740:	931e                	add	t1,t1,t2
     742:	00034303          	lbu	t1,0(t1)
     746:	02000393          	li	t2,32
     74a:	9316                	add	t1,t1,t0
     74c:	406382b3          	sub	t0,t2,t1
     750:	02639863          	bne	t2,t1,780 <__umoddi3+0x22e>
     754:	00e6e463          	bltu	a3,a4,75c <__umoddi3+0x20a>
     758:	00c56b63          	bltu	a0,a2,76e <__umoddi3+0x21c>
     75c:	40c50633          	sub	a2,a0,a2
     760:	40d706b3          	sub	a3,a4,a3
     764:	00c535b3          	sltu	a1,a0,a2
     768:	87b2                	mv	a5,a2
     76a:	40b685b3          	sub	a1,a3,a1
     76e:	853e                	mv	a0,a5
     770:	8082                	ret
     772:	01000337          	lui	t1,0x1000
     776:	42e1                	li	t0,24
     778:	fa66fee3          	bgeu	a3,t1,734 <__umoddi3+0x1e2>
     77c:	42c1                	li	t0,16
     77e:	bf5d                	j	734 <__umoddi3+0x1e2>
     780:	005697b3          	sll	a5,a3,t0
     784:	006656b3          	srl	a3,a2,t1
     788:	8edd                	or	a3,a3,a5
     78a:	1151                	addi	sp,sp,-12
     78c:	006757b3          	srl	a5,a4,t1
     790:	0106d393          	srli	t2,a3,0x10
     794:	c226                	sw	s1,4(sp)
     796:	0277d4b3          	divu	s1,a5,t2
     79a:	00571733          	sll	a4,a4,t0
     79e:	006555b3          	srl	a1,a0,t1
     7a2:	8dd9                	or	a1,a1,a4
     7a4:	01069713          	slli	a4,a3,0x10
     7a8:	8341                	srli	a4,a4,0x10
     7aa:	c422                	sw	s0,8(sp)
     7ac:	c03a                	sw	a4,0(sp)
     7ae:	00561633          	sll	a2,a2,t0
     7b2:	00551533          	sll	a0,a0,t0
     7b6:	0277f7b3          	remu	a5,a5,t2
     7ba:	02970433          	mul	s0,a4,s1
     7be:	07c2                	slli	a5,a5,0x10
     7c0:	0105d713          	srli	a4,a1,0x10
     7c4:	8fd9                	or	a5,a5,a4
     7c6:	8726                	mv	a4,s1
     7c8:	0087fc63          	bgeu	a5,s0,7e0 <__umoddi3+0x28e>
     7cc:	97b6                	add	a5,a5,a3
     7ce:	fff48713          	addi	a4,s1,-1
     7d2:	00d7e763          	bltu	a5,a3,7e0 <__umoddi3+0x28e>
     7d6:	0087f563          	bgeu	a5,s0,7e0 <__umoddi3+0x28e>
     7da:	ffe48713          	addi	a4,s1,-2
     7de:	97b6                	add	a5,a5,a3
     7e0:	8f81                	sub	a5,a5,s0
     7e2:	0277d433          	divu	s0,a5,t2
     7e6:	01069493          	slli	s1,a3,0x10
     7ea:	80c1                	srli	s1,s1,0x10
     7ec:	05c2                	slli	a1,a1,0x10
     7ee:	81c1                	srli	a1,a1,0x10
     7f0:	0277f7b3          	remu	a5,a5,t2
     7f4:	028484b3          	mul	s1,s1,s0
     7f8:	07c2                	slli	a5,a5,0x10
     7fa:	8ddd                	or	a1,a1,a5
     7fc:	87a2                	mv	a5,s0
     7fe:	0095fc63          	bgeu	a1,s1,816 <__umoddi3+0x2c4>
     802:	95b6                	add	a1,a1,a3
     804:	fff40793          	addi	a5,s0,-1
     808:	00d5e763          	bltu	a1,a3,816 <__umoddi3+0x2c4>
     80c:	0095f563          	bgeu	a1,s1,816 <__umoddi3+0x2c4>
     810:	ffe40793          	addi	a5,s0,-2
     814:	95b6                	add	a1,a1,a3
     816:	0742                	slli	a4,a4,0x10
     818:	8f5d                	or	a4,a4,a5
     81a:	01061413          	slli	s0,a2,0x10
     81e:	07c2                	slli	a5,a5,0x10
     820:	83c1                	srli	a5,a5,0x10
     822:	8341                	srli	a4,a4,0x10
     824:	8041                	srli	s0,s0,0x10
     826:	8d85                	sub	a1,a1,s1
     828:	01065493          	srli	s1,a2,0x10
     82c:	028783b3          	mul	t2,a5,s0
     830:	02870433          	mul	s0,a4,s0
     834:	029787b3          	mul	a5,a5,s1
     838:	02970733          	mul	a4,a4,s1
     83c:	008784b3          	add	s1,a5,s0
     840:	0103d793          	srli	a5,t2,0x10
     844:	97a6                	add	a5,a5,s1
     846:	0087f463          	bgeu	a5,s0,84e <__umoddi3+0x2fc>
     84a:	6441                	lui	s0,0x10
     84c:	9722                	add	a4,a4,s0
     84e:	0107d413          	srli	s0,a5,0x10
     852:	03c2                	slli	t2,t2,0x10
     854:	07c2                	slli	a5,a5,0x10
     856:	0103d393          	srli	t2,t2,0x10
     85a:	9722                	add	a4,a4,s0
     85c:	979e                	add	a5,a5,t2
     85e:	00e5e663          	bltu	a1,a4,86a <__umoddi3+0x318>
     862:	00e59b63          	bne	a1,a4,878 <__umoddi3+0x326>
     866:	00f57963          	bgeu	a0,a5,878 <__umoddi3+0x326>
     86a:	40c78633          	sub	a2,a5,a2
     86e:	00c7b3b3          	sltu	t2,a5,a2
     872:	969e                	add	a3,a3,t2
     874:	87b2                	mv	a5,a2
     876:	8f15                	sub	a4,a4,a3
     878:	40f507b3          	sub	a5,a0,a5
     87c:	00f53533          	sltu	a0,a0,a5
     880:	4422                	lw	s0,8(sp)
     882:	8d99                	sub	a1,a1,a4
     884:	8d89                	sub	a1,a1,a0
     886:	00659333          	sll	t1,a1,t1
     88a:	0057d7b3          	srl	a5,a5,t0
     88e:	4492                	lw	s1,4(sp)
     890:	00f36533          	or	a0,t1,a5
     894:	0055d5b3          	srl	a1,a1,t0
     898:	0131                	addi	sp,sp,12
     89a:	8082                	ret

0000089c <__adddf3>:
     89c:	00100337          	lui	t1,0x100
     8a0:	137d                	addi	t1,t1,-1 # fffff <__ctor_end__+0xf943f>
     8a2:	00b372b3          	and	t0,t1,a1
     8a6:	1131                	addi	sp,sp,-20
     8a8:	0145d713          	srli	a4,a1,0x14
     8ac:	01d55793          	srli	a5,a0,0x1d
     8b0:	c622                	sw	s0,12(sp)
     8b2:	c426                	sw	s1,8(sp)
     8b4:	01f5d413          	srli	s0,a1,0x1f
     8b8:	7ff77493          	andi	s1,a4,2047
     8bc:	00d375b3          	and	a1,t1,a3
     8c0:	00329713          	slli	a4,t0,0x3
     8c4:	0146d313          	srli	t1,a3,0x14
     8c8:	058e                	slli	a1,a1,0x3
     8ca:	8fd9                	or	a5,a5,a4
     8cc:	7ff37313          	andi	t1,t1,2047
     8d0:	01d65713          	srli	a4,a2,0x1d
     8d4:	c806                	sw	ra,16(sp)
     8d6:	82fd                	srli	a3,a3,0x1f
     8d8:	8f4d                	or	a4,a4,a1
     8da:	050e                	slli	a0,a0,0x3
     8dc:	060e                	slli	a2,a2,0x3
     8de:	406485b3          	sub	a1,s1,t1
     8e2:	7ff00293          	li	t0,2047
     8e6:	26d41563          	bne	s0,a3,b50 <__adddf3+0x2b4>
     8ea:	10b05b63          	blez	a1,a00 <__adddf3+0x164>
     8ee:	06031563          	bnez	t1,958 <__adddf3+0xbc>
     8f2:	00c766b3          	or	a3,a4,a2
     8f6:	ce99                	beqz	a3,914 <__adddf3+0x78>
     8f8:	fff48593          	addi	a1,s1,-1
     8fc:	e991                	bnez	a1,910 <__adddf3+0x74>
     8fe:	962a                	add	a2,a2,a0
     900:	00a636b3          	sltu	a3,a2,a0
     904:	973e                	add	a4,a4,a5
     906:	8532                	mv	a0,a2
     908:	00d707b3          	add	a5,a4,a3
     90c:	4485                	li	s1,1
     90e:	a849                	j	9a0 <__adddf3+0x104>
     910:	04549963          	bne	s1,t0,962 <__adddf3+0xc6>
     914:	01d79693          	slli	a3,a5,0x1d
     918:	810d                	srli	a0,a0,0x3
     91a:	7ff00713          	li	a4,2047
     91e:	8ec9                	or	a3,a3,a0
     920:	838d                	srli	a5,a5,0x3
     922:	00e49963          	bne	s1,a4,934 <__adddf3+0x98>
     926:	8edd                	or	a3,a3,a5
     928:	4781                	li	a5,0
     92a:	c689                	beqz	a3,934 <__adddf3+0x98>
     92c:	000807b7          	lui	a5,0x80
     930:	4681                	li	a3,0
     932:	4401                	li	s0,0
     934:	01449713          	slli	a4,s1,0x14
     938:	7ff00637          	lui	a2,0x7ff00
     93c:	07b2                	slli	a5,a5,0xc
     93e:	8f71                	and	a4,a4,a2
     940:	83b1                	srli	a5,a5,0xc
     942:	047e                	slli	s0,s0,0x1f
     944:	8fd9                	or	a5,a5,a4
     946:	40c2                	lw	ra,16(sp)
     948:	0087e733          	or	a4,a5,s0
     94c:	4432                	lw	s0,12(sp)
     94e:	44a2                	lw	s1,8(sp)
     950:	8536                	mv	a0,a3
     952:	85ba                	mv	a1,a4
     954:	0151                	addi	sp,sp,20
     956:	8082                	ret
     958:	fa548ee3          	beq	s1,t0,914 <__adddf3+0x78>
     95c:	008006b7          	lui	a3,0x800
     960:	8f55                	or	a4,a4,a3
     962:	03800693          	li	a3,56
     966:	08b6c863          	blt	a3,a1,9f6 <__adddf3+0x15a>
     96a:	46fd                	li	a3,31
     96c:	02000293          	li	t0,32
     970:	04b6ce63          	blt	a3,a1,9cc <__adddf3+0x130>
     974:	40b282b3          	sub	t0,t0,a1
     978:	005716b3          	sll	a3,a4,t0
     97c:	00b65333          	srl	t1,a2,a1
     980:	005612b3          	sll	t0,a2,t0
     984:	0066e6b3          	or	a3,a3,t1
     988:	005032b3          	snez	t0,t0
     98c:	0056e6b3          	or	a3,a3,t0
     990:	00b755b3          	srl	a1,a4,a1
     994:	9536                	add	a0,a0,a3
     996:	95be                	add	a1,a1,a5
     998:	00d536b3          	sltu	a3,a0,a3
     99c:	00d587b3          	add	a5,a1,a3
     9a0:	00879713          	slli	a4,a5,0x8
     9a4:	16075a63          	bgez	a4,b18 <__adddf3+0x27c>
     9a8:	0485                	addi	s1,s1,1
     9aa:	7ff00713          	li	a4,2047
     9ae:	4ae48063          	beq	s1,a4,e4e <__adddf3+0x5b2>
     9b2:	ff800737          	lui	a4,0xff800
     9b6:	177d                	addi	a4,a4,-1 # ff7fffff <__heap_end+0xdf7cffff>
     9b8:	8ff9                	and	a5,a5,a4
     9ba:	00155713          	srli	a4,a0,0x1
     9be:	8905                	andi	a0,a0,1
     9c0:	8f49                	or	a4,a4,a0
     9c2:	01f79513          	slli	a0,a5,0x1f
     9c6:	8d59                	or	a0,a0,a4
     9c8:	8385                	srli	a5,a5,0x1
     9ca:	a2b9                	j	b18 <__adddf3+0x27c>
     9cc:	fe058693          	addi	a3,a1,-32 # ffffe0 <__ctor_end__+0xff9420>
     9d0:	00d756b3          	srl	a3,a4,a3
     9d4:	4301                	li	t1,0
     9d6:	00558863          	beq	a1,t0,9e6 <__adddf3+0x14a>
     9da:	04000313          	li	t1,64
     9de:	40b30333          	sub	t1,t1,a1
     9e2:	00671333          	sll	t1,a4,t1
     9e6:	00c36333          	or	t1,t1,a2
     9ea:	00603333          	snez	t1,t1
     9ee:	0066e6b3          	or	a3,a3,t1
     9f2:	4581                	li	a1,0
     9f4:	b745                	j	994 <__adddf3+0xf8>
     9f6:	00c766b3          	or	a3,a4,a2
     9fa:	00d036b3          	snez	a3,a3
     9fe:	bfd5                	j	9f2 <__adddf3+0x156>
     a00:	c1d5                	beqz	a1,aa4 <__adddf3+0x208>
     a02:	409306b3          	sub	a3,t1,s1
     a06:	ec91                	bnez	s1,a22 <__adddf3+0x186>
     a08:	00a7e5b3          	or	a1,a5,a0
     a0c:	c599                	beqz	a1,a1a <__adddf3+0x17e>
     a0e:	fff68593          	addi	a1,a3,-1 # 7fffff <__ctor_end__+0x7f943f>
     a12:	ee0586e3          	beqz	a1,8fe <__adddf3+0x62>
     a16:	00569c63          	bne	a3,t0,a2e <__adddf3+0x192>
     a1a:	87ba                	mv	a5,a4
     a1c:	8532                	mv	a0,a2
     a1e:	84b6                	mv	s1,a3
     a20:	bdd5                	j	914 <__adddf3+0x78>
     a22:	42530963          	beq	t1,t0,e54 <__adddf3+0x5b8>
     a26:	008005b7          	lui	a1,0x800
     a2a:	8fcd                	or	a5,a5,a1
     a2c:	85b6                	mv	a1,a3
     a2e:	03800693          	li	a3,56
     a32:	06b6c463          	blt	a3,a1,a9a <__adddf3+0x1fe>
     a36:	46fd                	li	a3,31
     a38:	02000393          	li	t2,32
     a3c:	02b6ca63          	blt	a3,a1,a70 <__adddf3+0x1d4>
     a40:	40b383b3          	sub	t2,t2,a1
     a44:	007796b3          	sll	a3,a5,t2
     a48:	00b552b3          	srl	t0,a0,a1
     a4c:	007513b3          	sll	t2,a0,t2
     a50:	0056e6b3          	or	a3,a3,t0
     a54:	007033b3          	snez	t2,t2
     a58:	0076e6b3          	or	a3,a3,t2
     a5c:	00b7d7b3          	srl	a5,a5,a1
     a60:	00c68533          	add	a0,a3,a2
     a64:	97ba                	add	a5,a5,a4
     a66:	00d536b3          	sltu	a3,a0,a3
     a6a:	97b6                	add	a5,a5,a3
     a6c:	849a                	mv	s1,t1
     a6e:	bf0d                	j	9a0 <__adddf3+0x104>
     a70:	fe058693          	addi	a3,a1,-32 # 7fffe0 <__ctor_end__+0x7f9420>
     a74:	00d7d6b3          	srl	a3,a5,a3
     a78:	4281                	li	t0,0
     a7a:	00758863          	beq	a1,t2,a8a <__adddf3+0x1ee>
     a7e:	04000293          	li	t0,64
     a82:	40b282b3          	sub	t0,t0,a1
     a86:	005792b3          	sll	t0,a5,t0
     a8a:	00a2e2b3          	or	t0,t0,a0
     a8e:	005032b3          	snez	t0,t0
     a92:	0056e6b3          	or	a3,a3,t0
     a96:	4781                	li	a5,0
     a98:	b7e1                	j	a60 <__adddf3+0x1c4>
     a9a:	00a7e6b3          	or	a3,a5,a0
     a9e:	00d036b3          	snez	a3,a3
     aa2:	bfd5                	j	a96 <__adddf3+0x1fa>
     aa4:	00148693          	addi	a3,s1,1
     aa8:	7fe6f593          	andi	a1,a3,2046
     aac:	e9a1                	bnez	a1,afc <__adddf3+0x260>
     aae:	00a7e6b3          	or	a3,a5,a0
     ab2:	e895                	bnez	s1,ae6 <__adddf3+0x24a>
     ab4:	38068463          	beqz	a3,e3c <__adddf3+0x5a0>
     ab8:	00c766b3          	or	a3,a4,a2
     abc:	38068263          	beqz	a3,e40 <__adddf3+0x5a4>
     ac0:	00c506b3          	add	a3,a0,a2
     ac4:	973e                	add	a4,a4,a5
     ac6:	00a6b533          	sltu	a0,a3,a0
     aca:	00a707b3          	add	a5,a4,a0
     ace:	00879713          	slli	a4,a5,0x8
     ad2:	8636                	mv	a2,a3
     ad4:	24075563          	bgez	a4,d1e <__adddf3+0x482>
     ad8:	ff800737          	lui	a4,0xff800
     adc:	177d                	addi	a4,a4,-1 # ff7fffff <__heap_end+0xdf7cffff>
     ade:	8ff9                	and	a5,a5,a4
     ae0:	8536                	mv	a0,a3
     ae2:	4485                	li	s1,1
     ae4:	bd05                	j	914 <__adddf3+0x78>
     ae6:	34068f63          	beqz	a3,e44 <__adddf3+0x5a8>
     aea:	8f51                	or	a4,a4,a2
     aec:	8496                	mv	s1,t0
     aee:	e20703e3          	beqz	a4,914 <__adddf3+0x78>
     af2:	4401                	li	s0,0
     af4:	004007b7          	lui	a5,0x400
     af8:	4501                	li	a0,0
     afa:	bd29                	j	914 <__adddf3+0x78>
     afc:	34568863          	beq	a3,t0,e4c <__adddf3+0x5b0>
     b00:	962a                	add	a2,a2,a0
     b02:	00a63533          	sltu	a0,a2,a0
     b06:	973e                	add	a4,a4,a5
     b08:	972a                	add	a4,a4,a0
     b0a:	01f71513          	slli	a0,a4,0x1f
     b0e:	8205                	srli	a2,a2,0x1
     b10:	8d51                	or	a0,a0,a2
     b12:	00175793          	srli	a5,a4,0x1
     b16:	84b6                	mv	s1,a3
     b18:	00757713          	andi	a4,a0,7
     b1c:	cf01                	beqz	a4,b34 <__adddf3+0x298>
     b1e:	00f57713          	andi	a4,a0,15
     b22:	4691                	li	a3,4
     b24:	00d70863          	beq	a4,a3,b34 <__adddf3+0x298>
     b28:	00d50733          	add	a4,a0,a3
     b2c:	00a736b3          	sltu	a3,a4,a0
     b30:	97b6                	add	a5,a5,a3
     b32:	853a                	mv	a0,a4
     b34:	00879713          	slli	a4,a5,0x8
     b38:	dc075ee3          	bgez	a4,914 <__adddf3+0x78>
     b3c:	0485                	addi	s1,s1,1
     b3e:	7ff00713          	li	a4,2047
     b42:	30e48663          	beq	s1,a4,e4e <__adddf3+0x5b2>
     b46:	ff800737          	lui	a4,0xff800
     b4a:	177d                	addi	a4,a4,-1 # ff7fffff <__heap_end+0xdf7cffff>
     b4c:	8ff9                	and	a5,a5,a4
     b4e:	b3d9                	j	914 <__adddf3+0x78>
     b50:	0cb05463          	blez	a1,c18 <__adddf3+0x37c>
     b54:	08031263          	bnez	t1,bd8 <__adddf3+0x33c>
     b58:	00c766b3          	or	a3,a4,a2
     b5c:	da068ce3          	beqz	a3,914 <__adddf3+0x78>
     b60:	fff48593          	addi	a1,s1,-1
     b64:	ed81                	bnez	a1,b7c <__adddf3+0x2e0>
     b66:	40c50633          	sub	a2,a0,a2
     b6a:	00c536b3          	sltu	a3,a0,a2
     b6e:	40e78733          	sub	a4,a5,a4
     b72:	8532                	mv	a0,a2
     b74:	40d707b3          	sub	a5,a4,a3
     b78:	4485                	li	s1,1
     b7a:	a0a9                	j	bc4 <__adddf3+0x328>
     b7c:	d8548ce3          	beq	s1,t0,914 <__adddf3+0x78>
     b80:	03800693          	li	a3,56
     b84:	08b6c563          	blt	a3,a1,c0e <__adddf3+0x372>
     b88:	46fd                	li	a3,31
     b8a:	02000293          	li	t0,32
     b8e:	04b6cb63          	blt	a3,a1,be4 <__adddf3+0x348>
     b92:	40b282b3          	sub	t0,t0,a1
     b96:	005716b3          	sll	a3,a4,t0
     b9a:	00b65333          	srl	t1,a2,a1
     b9e:	005612b3          	sll	t0,a2,t0
     ba2:	0066e6b3          	or	a3,a3,t1
     ba6:	005032b3          	snez	t0,t0
     baa:	0056e6b3          	or	a3,a3,t0
     bae:	00b755b3          	srl	a1,a4,a1
     bb2:	40d506b3          	sub	a3,a0,a3
     bb6:	00d53733          	sltu	a4,a0,a3
     bba:	40b785b3          	sub	a1,a5,a1
     bbe:	8536                	mv	a0,a3
     bc0:	40e587b3          	sub	a5,a1,a4
     bc4:	00879713          	slli	a4,a5,0x8
     bc8:	f40758e3          	bgez	a4,b18 <__adddf3+0x27c>
     bcc:	008005b7          	lui	a1,0x800
     bd0:	15fd                	addi	a1,a1,-1 # 7fffff <__ctor_end__+0x7f943f>
     bd2:	8dfd                	and	a1,a1,a5
     bd4:	832a                	mv	t1,a0
     bd6:	a26d                	j	d80 <__adddf3+0x4e4>
     bd8:	d2548ee3          	beq	s1,t0,914 <__adddf3+0x78>
     bdc:	008006b7          	lui	a3,0x800
     be0:	8f55                	or	a4,a4,a3
     be2:	bf79                	j	b80 <__adddf3+0x2e4>
     be4:	fe058693          	addi	a3,a1,-32
     be8:	00d756b3          	srl	a3,a4,a3
     bec:	4301                	li	t1,0
     bee:	00558863          	beq	a1,t0,bfe <__adddf3+0x362>
     bf2:	04000313          	li	t1,64
     bf6:	40b30333          	sub	t1,t1,a1
     bfa:	00671333          	sll	t1,a4,t1
     bfe:	00c36333          	or	t1,t1,a2
     c02:	00603333          	snez	t1,t1
     c06:	0066e6b3          	or	a3,a3,t1
     c0a:	4581                	li	a1,0
     c0c:	b75d                	j	bb2 <__adddf3+0x316>
     c0e:	00c766b3          	or	a3,a4,a2
     c12:	00d036b3          	snez	a3,a3
     c16:	bfd5                	j	c0a <__adddf3+0x36e>
     c18:	cdc5                	beqz	a1,cd0 <__adddf3+0x434>
     c1a:	409303b3          	sub	t2,t1,s1
     c1e:	e49d                	bnez	s1,c4c <__adddf3+0x3b0>
     c20:	00a7e5b3          	or	a1,a5,a0
     c24:	cd99                	beqz	a1,c42 <__adddf3+0x3a6>
     c26:	fff38593          	addi	a1,t2,-1 # ffffff <__ctor_end__+0xff943f>
     c2a:	e991                	bnez	a1,c3e <__adddf3+0x3a2>
     c2c:	40a60533          	sub	a0,a2,a0
     c30:	8f1d                	sub	a4,a4,a5
     c32:	00a637b3          	sltu	a5,a2,a0
     c36:	40f707b3          	sub	a5,a4,a5
     c3a:	8436                	mv	s0,a3
     c3c:	bf35                	j	b78 <__adddf3+0x2dc>
     c3e:	00539d63          	bne	t2,t0,c58 <__adddf3+0x3bc>
     c42:	8436                	mv	s0,a3
     c44:	87ba                	mv	a5,a4
     c46:	8532                	mv	a0,a2
     c48:	849e                	mv	s1,t2
     c4a:	b1e9                	j	914 <__adddf3+0x78>
     c4c:	20530363          	beq	t1,t0,e52 <__adddf3+0x5b6>
     c50:	008005b7          	lui	a1,0x800
     c54:	8fcd                	or	a5,a5,a1
     c56:	859e                	mv	a1,t2
     c58:	03800293          	li	t0,56
     c5c:	06b2c663          	blt	t0,a1,cc8 <__adddf3+0x42c>
     c60:	42fd                	li	t0,31
     c62:	02000413          	li	s0,32
     c66:	02b2cc63          	blt	t0,a1,c9e <__adddf3+0x402>
     c6a:	8c0d                	sub	s0,s0,a1
     c6c:	00b553b3          	srl	t2,a0,a1
     c70:	008792b3          	sll	t0,a5,s0
     c74:	00851433          	sll	s0,a0,s0
     c78:	0072e2b3          	or	t0,t0,t2
     c7c:	00803433          	snez	s0,s0
     c80:	0082e533          	or	a0,t0,s0
     c84:	00b7d5b3          	srl	a1,a5,a1
     c88:	40a60533          	sub	a0,a2,a0
     c8c:	40b705b3          	sub	a1,a4,a1
     c90:	00a637b3          	sltu	a5,a2,a0
     c94:	40f587b3          	sub	a5,a1,a5
     c98:	849a                	mv	s1,t1
     c9a:	8436                	mv	s0,a3
     c9c:	b725                	j	bc4 <__adddf3+0x328>
     c9e:	fe058293          	addi	t0,a1,-32 # 7fffe0 <__ctor_end__+0x7f9420>
     ca2:	0057d2b3          	srl	t0,a5,t0
     ca6:	4381                	li	t2,0
     ca8:	00858863          	beq	a1,s0,cb8 <__adddf3+0x41c>
     cac:	04000393          	li	t2,64
     cb0:	40b383b3          	sub	t2,t2,a1
     cb4:	007793b3          	sll	t2,a5,t2
     cb8:	00a3e3b3          	or	t2,t2,a0
     cbc:	007033b3          	snez	t2,t2
     cc0:	0072e533          	or	a0,t0,t2
     cc4:	4581                	li	a1,0
     cc6:	b7c9                	j	c88 <__adddf3+0x3ec>
     cc8:	8d5d                	or	a0,a0,a5
     cca:	00a03533          	snez	a0,a0
     cce:	bfdd                	j	cc4 <__adddf3+0x428>
     cd0:	00148593          	addi	a1,s1,1
     cd4:	7fe5f593          	andi	a1,a1,2046
     cd8:	edb5                	bnez	a1,d54 <__adddf3+0x4b8>
     cda:	00a7e333          	or	t1,a5,a0
     cde:	00c765b3          	or	a1,a4,a2
     ce2:	e8b9                	bnez	s1,d38 <__adddf3+0x49c>
     ce4:	00031663          	bnez	t1,cf0 <__adddf3+0x454>
     ce8:	87ba                	mv	a5,a4
     cea:	e98d                	bnez	a1,d1c <__adddf3+0x480>
     cec:	4401                	li	s0,0
     cee:	a285                	j	e4e <__adddf3+0x5b2>
     cf0:	14058863          	beqz	a1,e40 <__adddf3+0x5a4>
     cf4:	40c50333          	sub	t1,a0,a2
     cf8:	006532b3          	sltu	t0,a0,t1
     cfc:	40e785b3          	sub	a1,a5,a4
     d00:	405585b3          	sub	a1,a1,t0
     d04:	00859293          	slli	t0,a1,0x8
     d08:	0202d163          	bgez	t0,d2a <__adddf3+0x48e>
     d0c:	40a60533          	sub	a0,a2,a0
     d10:	00a635b3          	sltu	a1,a2,a0
     d14:	8f1d                	sub	a4,a4,a5
     d16:	862a                	mv	a2,a0
     d18:	40b707b3          	sub	a5,a4,a1
     d1c:	8436                	mv	s0,a3
     d1e:	00c7e533          	or	a0,a5,a2
     d22:	c161                	beqz	a0,de2 <__adddf3+0x546>
     d24:	8532                	mv	a0,a2
     d26:	4481                	li	s1,0
     d28:	bbc5                	j	b18 <__adddf3+0x27c>
     d2a:	00b36533          	or	a0,t1,a1
     d2e:	12050763          	beqz	a0,e5c <__adddf3+0x5c0>
     d32:	87ae                	mv	a5,a1
     d34:	861a                	mv	a2,t1
     d36:	b7e5                	j	d1e <__adddf3+0x482>
     d38:	00031a63          	bnez	t1,d4c <__adddf3+0x4b0>
     d3c:	8436                	mv	s0,a3
     d3e:	10059363          	bnez	a1,e44 <__adddf3+0x5a8>
     d42:	4401                	li	s0,0
     d44:	004007b7          	lui	a5,0x400
     d48:	4501                	li	a0,0
     d4a:	a8fd                	j	e48 <__adddf3+0x5ac>
     d4c:	8496                	mv	s1,t0
     d4e:	bc0583e3          	beqz	a1,914 <__adddf3+0x78>
     d52:	b345                	j	af2 <__adddf3+0x256>
     d54:	40c502b3          	sub	t0,a0,a2
     d58:	005533b3          	sltu	t2,a0,t0
     d5c:	40e785b3          	sub	a1,a5,a4
     d60:	407585b3          	sub	a1,a1,t2
     d64:	00859393          	slli	t2,a1,0x8
     d68:	8316                	mv	t1,t0
     d6a:	0603d863          	bgez	t2,dda <__adddf3+0x53e>
     d6e:	40a60533          	sub	a0,a2,a0
     d72:	8f1d                	sub	a4,a4,a5
     d74:	00a63633          	sltu	a2,a2,a0
     d78:	832a                	mv	t1,a0
     d7a:	40c705b3          	sub	a1,a4,a2
     d7e:	8436                	mv	s0,a3
     d80:	c5a5                	beqz	a1,de8 <__adddf3+0x54c>
     d82:	852e                	mv	a0,a1
     d84:	c21a                	sw	t1,4(sp)
     d86:	c02e                	sw	a1,0(sp)
     d88:	32a010ef          	jal	20b2 <__clzsi2>
     d8c:	4582                	lw	a1,0(sp)
     d8e:	4312                	lw	t1,4(sp)
     d90:	ff850693          	addi	a3,a0,-8
     d94:	02000793          	li	a5,32
     d98:	8f95                	sub	a5,a5,a3
     d9a:	00d595b3          	sll	a1,a1,a3
     d9e:	00f357b3          	srl	a5,t1,a5
     da2:	8fcd                	or	a5,a5,a1
     da4:	00d315b3          	sll	a1,t1,a3
     da8:	0896c363          	blt	a3,s1,e2e <__adddf3+0x592>
     dac:	8e85                	sub	a3,a3,s1
     dae:	00168313          	addi	t1,a3,1 # 800001 <__ctor_end__+0x7f9441>
     db2:	477d                	li	a4,31
     db4:	02000513          	li	a0,32
     db8:	04674963          	blt	a4,t1,e0a <__adddf3+0x56e>
     dbc:	40650533          	sub	a0,a0,t1
     dc0:	00a79633          	sll	a2,a5,a0
     dc4:	0065d733          	srl	a4,a1,t1
     dc8:	00a59533          	sll	a0,a1,a0
     dcc:	8e59                	or	a2,a2,a4
     dce:	00a03533          	snez	a0,a0
     dd2:	8e49                	or	a2,a2,a0
     dd4:	0067d7b3          	srl	a5,a5,t1
     dd8:	b799                	j	d1e <__adddf3+0x482>
     dda:	00b2e533          	or	a0,t0,a1
     dde:	f14d                	bnez	a0,d80 <__adddf3+0x4e4>
     de0:	4401                	li	s0,0
     de2:	4781                	li	a5,0
     de4:	4481                	li	s1,0
     de6:	b63d                	j	914 <__adddf3+0x78>
     de8:	851a                	mv	a0,t1
     dea:	c22e                	sw	a1,4(sp)
     dec:	c01a                	sw	t1,0(sp)
     dee:	2c4010ef          	jal	20b2 <__clzsi2>
     df2:	01850693          	addi	a3,a0,24
     df6:	47fd                	li	a5,31
     df8:	4302                	lw	t1,0(sp)
     dfa:	4592                	lw	a1,4(sp)
     dfc:	f8d7dce3          	bge	a5,a3,d94 <__adddf3+0x4f8>
     e00:	ff850793          	addi	a5,a0,-8
     e04:	00f317b3          	sll	a5,t1,a5
     e08:	b745                	j	da8 <__adddf3+0x50c>
     e0a:	1685                	addi	a3,a3,-31
     e0c:	00d7d633          	srl	a2,a5,a3
     e10:	4701                	li	a4,0
     e12:	00a30863          	beq	t1,a0,e22 <__adddf3+0x586>
     e16:	04000713          	li	a4,64
     e1a:	40670733          	sub	a4,a4,t1
     e1e:	00e79733          	sll	a4,a5,a4
     e22:	8f4d                	or	a4,a4,a1
     e24:	00e03733          	snez	a4,a4
     e28:	8e59                	or	a2,a2,a4
     e2a:	4781                	li	a5,0
     e2c:	bdcd                	j	d1e <__adddf3+0x482>
     e2e:	ff800737          	lui	a4,0xff800
     e32:	177d                	addi	a4,a4,-1 # ff7fffff <__heap_end+0xdf7cffff>
     e34:	8c95                	sub	s1,s1,a3
     e36:	8ff9                	and	a5,a5,a4
     e38:	852e                	mv	a0,a1
     e3a:	b9f9                	j	b18 <__adddf3+0x27c>
     e3c:	87ba                	mv	a5,a4
     e3e:	b5c5                	j	d1e <__adddf3+0x482>
     e40:	862a                	mv	a2,a0
     e42:	bdf1                	j	d1e <__adddf3+0x482>
     e44:	87ba                	mv	a5,a4
     e46:	8532                	mv	a0,a2
     e48:	8496                	mv	s1,t0
     e4a:	b4e9                	j	914 <__adddf3+0x78>
     e4c:	84b6                	mv	s1,a3
     e4e:	4781                	li	a5,0
     e50:	b165                	j	af8 <__adddf3+0x25c>
     e52:	8436                	mv	s0,a3
     e54:	87ba                	mv	a5,a4
     e56:	8532                	mv	a0,a2
     e58:	849a                	mv	s1,t1
     e5a:	bc6d                	j	914 <__adddf3+0x78>
     e5c:	4401                	li	s0,0
     e5e:	4781                	li	a5,0
     e60:	bc55                	j	914 <__adddf3+0x78>

00000e62 <__divdf3>:
     e62:	fdc10113          	addi	sp,sp,-36
     e66:	872a                	mv	a4,a0
     e68:	852e                	mv	a0,a1
     e6a:	cc26                	sw	s1,24(sp)
     e6c:	82b6                	mv	t0,a3
     e6e:	00c59493          	slli	s1,a1,0xc
     e72:	01f55693          	srli	a3,a0,0x1f
     e76:	81d1                	srli	a1,a1,0x14
     e78:	d006                	sw	ra,32(sp)
     e7a:	ce22                	sw	s0,28(sp)
     e7c:	7ff5f593          	andi	a1,a1,2047
     e80:	c436                	sw	a3,8(sp)
     e82:	80b1                	srli	s1,s1,0xc
     e84:	c5c1                	beqz	a1,f0c <__divdf3+0xaa>
     e86:	7ff00693          	li	a3,2047
     e8a:	0ed58463          	beq	a1,a3,f72 <__divdf3+0x110>
     e8e:	01d75413          	srli	s0,a4,0x1d
     e92:	048e                	slli	s1,s1,0x3
     e94:	008007b7          	lui	a5,0x800
     e98:	8c45                	or	s0,s0,s1
     e9a:	8c5d                	or	s0,s0,a5
     e9c:	c0158593          	addi	a1,a1,-1023
     ea0:	00371793          	slli	a5,a4,0x3
     ea4:	4301                	li	t1,0
     ea6:	0142d693          	srli	a3,t0,0x14
     eaa:	00c29713          	slli	a4,t0,0xc
     eae:	7ff6f693          	andi	a3,a3,2047
     eb2:	00c75393          	srli	t2,a4,0xc
     eb6:	01f2d493          	srli	s1,t0,0x1f
     eba:	caf1                	beqz	a3,f8e <__divdf3+0x12c>
     ebc:	7ff00713          	li	a4,2047
     ec0:	14e68863          	beq	a3,a4,1010 <__divdf3+0x1ae>
     ec4:	00339513          	slli	a0,t2,0x3
     ec8:	01d65713          	srli	a4,a2,0x1d
     ecc:	8f49                	or	a4,a4,a0
     ece:	00800537          	lui	a0,0x800
     ed2:	00a763b3          	or	t2,a4,a0
     ed6:	c0168693          	addi	a3,a3,-1023
     eda:	00361513          	slli	a0,a2,0x3
     ede:	4701                	li	a4,0
     ee0:	4622                	lw	a2,8(sp)
     ee2:	40d586b3          	sub	a3,a1,a3
     ee6:	c036                	sw	a3,0(sp)
     ee8:	00231693          	slli	a3,t1,0x2
     eec:	8e25                	xor	a2,a2,s1
     eee:	8ed9                	or	a3,a3,a4
     ef0:	c232                	sw	a2,4(sp)
     ef2:	16fd                	addi	a3,a3,-1
     ef4:	4639                	li	a2,14
     ef6:	12d66a63          	bltu	a2,a3,102a <__divdf3+0x1c8>
     efa:	00005617          	auipc	a2,0x5
     efe:	f3660613          	addi	a2,a2,-202 # 5e30 <__srodata>
     f02:	068a                	slli	a3,a3,0x2
     f04:	96b2                	add	a3,a3,a2
     f06:	4294                	lw	a3,0(a3)
     f08:	96b2                	add	a3,a3,a2
     f0a:	8682                	jr	a3
     f0c:	00e4e433          	or	s0,s1,a4
     f10:	c43d                	beqz	s0,f7e <__divdf3+0x11c>
     f12:	c616                	sw	t0,12(sp)
     f14:	c232                	sw	a2,4(sp)
     f16:	c89d                	beqz	s1,f4c <__divdf3+0xea>
     f18:	8526                	mv	a0,s1
     f1a:	c03a                	sw	a4,0(sp)
     f1c:	196010ef          	jal	20b2 <__clzsi2>
     f20:	4702                	lw	a4,0(sp)
     f22:	4612                	lw	a2,4(sp)
     f24:	42b2                	lw	t0,12(sp)
     f26:	87aa                	mv	a5,a0
     f28:	ff550593          	addi	a1,a0,-11 # 7ffff5 <__ctor_end__+0x7f9435>
     f2c:	4475                	li	s0,29
     f2e:	ff878693          	addi	a3,a5,-8 # 7ffff8 <__ctor_end__+0x7f9438>
     f32:	8c0d                	sub	s0,s0,a1
     f34:	00d494b3          	sll	s1,s1,a3
     f38:	00875433          	srl	s0,a4,s0
     f3c:	8c45                	or	s0,s0,s1
     f3e:	00d714b3          	sll	s1,a4,a3
     f42:	c0d00593          	li	a1,-1011
     f46:	8d9d                	sub	a1,a1,a5
     f48:	87a6                	mv	a5,s1
     f4a:	bfa9                	j	ea4 <__divdf3+0x42>
     f4c:	853a                	mv	a0,a4
     f4e:	c03a                	sw	a4,0(sp)
     f50:	162010ef          	jal	20b2 <__clzsi2>
     f54:	01550593          	addi	a1,a0,21
     f58:	46f1                	li	a3,28
     f5a:	4702                	lw	a4,0(sp)
     f5c:	4612                	lw	a2,4(sp)
     f5e:	42b2                	lw	t0,12(sp)
     f60:	02050793          	addi	a5,a0,32
     f64:	fcb6d4e3          	bge	a3,a1,f2c <__divdf3+0xca>
     f68:	ff850413          	addi	s0,a0,-8
     f6c:	00871433          	sll	s0,a4,s0
     f70:	bfc9                	j	f42 <__divdf3+0xe0>
     f72:	00e4e433          	or	s0,s1,a4
     f76:	e801                	bnez	s0,f86 <__divdf3+0x124>
     f78:	4781                	li	a5,0
     f7a:	4309                	li	t1,2
     f7c:	b72d                	j	ea6 <__divdf3+0x44>
     f7e:	4781                	li	a5,0
     f80:	4581                	li	a1,0
     f82:	4305                	li	t1,1
     f84:	b70d                	j	ea6 <__divdf3+0x44>
     f86:	87ba                	mv	a5,a4
     f88:	8426                	mv	s0,s1
     f8a:	430d                	li	t1,3
     f8c:	bf29                	j	ea6 <__divdf3+0x44>
     f8e:	00c3e533          	or	a0,t2,a2
     f92:	c549                	beqz	a0,101c <__divdf3+0x1ba>
     f94:	04038663          	beqz	t2,fe0 <__divdf3+0x17e>
     f98:	851e                	mv	a0,t2
     f9a:	ca32                	sw	a2,20(sp)
     f9c:	c81a                	sw	t1,16(sp)
     f9e:	c62e                	sw	a1,12(sp)
     fa0:	c23e                	sw	a5,4(sp)
     fa2:	c01e                	sw	t2,0(sp)
     fa4:	10e010ef          	jal	20b2 <__clzsi2>
     fa8:	4382                	lw	t2,0(sp)
     faa:	4792                	lw	a5,4(sp)
     fac:	45b2                	lw	a1,12(sp)
     fae:	4342                	lw	t1,16(sp)
     fb0:	4652                	lw	a2,20(sp)
     fb2:	86aa                	mv	a3,a0
     fb4:	ff550293          	addi	t0,a0,-11
     fb8:	4775                	li	a4,29
     fba:	ff868513          	addi	a0,a3,-8
     fbe:	40570733          	sub	a4,a4,t0
     fc2:	00a393b3          	sll	t2,t2,a0
     fc6:	00e65733          	srl	a4,a2,a4
     fca:	00776733          	or	a4,a4,t2
     fce:	00a613b3          	sll	t2,a2,a0
     fd2:	c0d00613          	li	a2,-1011
     fd6:	851e                	mv	a0,t2
     fd8:	40d606b3          	sub	a3,a2,a3
     fdc:	83ba                	mv	t2,a4
     fde:	b701                	j	ede <__divdf3+0x7c>
     fe0:	8532                	mv	a0,a2
     fe2:	ca1e                	sw	t2,20(sp)
     fe4:	c81a                	sw	t1,16(sp)
     fe6:	c62e                	sw	a1,12(sp)
     fe8:	c23e                	sw	a5,4(sp)
     fea:	c032                	sw	a2,0(sp)
     fec:	0c6010ef          	jal	20b2 <__clzsi2>
     ff0:	01550293          	addi	t0,a0,21
     ff4:	4771                	li	a4,28
     ff6:	4602                	lw	a2,0(sp)
     ff8:	4792                	lw	a5,4(sp)
     ffa:	45b2                	lw	a1,12(sp)
     ffc:	4342                	lw	t1,16(sp)
     ffe:	43d2                	lw	t2,20(sp)
    1000:	02050693          	addi	a3,a0,32
    1004:	fa575ae3          	bge	a4,t0,fb8 <__divdf3+0x156>
    1008:	1561                	addi	a0,a0,-8
    100a:	00a61733          	sll	a4,a2,a0
    100e:	b7d1                	j	fd2 <__divdf3+0x170>
    1010:	00c3e533          	or	a0,t2,a2
    1014:	e901                	bnez	a0,1024 <__divdf3+0x1c2>
    1016:	4381                	li	t2,0
    1018:	4709                	li	a4,2
    101a:	b5d9                	j	ee0 <__divdf3+0x7e>
    101c:	4381                	li	t2,0
    101e:	4681                	li	a3,0
    1020:	4705                	li	a4,1
    1022:	bd7d                	j	ee0 <__divdf3+0x7e>
    1024:	8532                	mv	a0,a2
    1026:	470d                	li	a4,3
    1028:	bd65                	j	ee0 <__divdf3+0x7e>
    102a:	0083e663          	bltu	t2,s0,1036 <__divdf3+0x1d4>
    102e:	2a741d63          	bne	s0,t2,12e8 <__divdf3+0x486>
    1032:	2aa7eb63          	bltu	a5,a0,12e8 <__divdf3+0x486>
    1036:	01f41693          	slli	a3,s0,0x1f
    103a:	0017d713          	srli	a4,a5,0x1
    103e:	01f79313          	slli	t1,a5,0x1f
    1042:	8005                	srli	s0,s0,0x1
    1044:	00e6e7b3          	or	a5,a3,a4
    1048:	00839713          	slli	a4,t2,0x8
    104c:	01075493          	srli	s1,a4,0x10
    1050:	029456b3          	divu	a3,s0,s1
    1054:	01855613          	srli	a2,a0,0x18
    1058:	8e59                	or	a2,a2,a4
    105a:	01061713          	slli	a4,a2,0x10
    105e:	8341                	srli	a4,a4,0x10
    1060:	c43a                	sw	a4,8(sp)
    1062:	0107d593          	srli	a1,a5,0x10
    1066:	00851293          	slli	t0,a0,0x8
    106a:	02947433          	remu	s0,s0,s1
    106e:	02d70733          	mul	a4,a4,a3
    1072:	0442                	slli	s0,s0,0x10
    1074:	8c4d                	or	s0,s0,a1
    1076:	85b6                	mv	a1,a3
    1078:	00e47c63          	bgeu	s0,a4,1090 <__divdf3+0x22e>
    107c:	9432                	add	s0,s0,a2
    107e:	fff68593          	addi	a1,a3,-1
    1082:	00c46763          	bltu	s0,a2,1090 <__divdf3+0x22e>
    1086:	00e47563          	bgeu	s0,a4,1090 <__divdf3+0x22e>
    108a:	ffe68593          	addi	a1,a3,-2
    108e:	9432                	add	s0,s0,a2
    1090:	8c19                	sub	s0,s0,a4
    1092:	029456b3          	divu	a3,s0,s1
    1096:	01061713          	slli	a4,a2,0x10
    109a:	8341                	srli	a4,a4,0x10
    109c:	07c2                	slli	a5,a5,0x10
    109e:	83c1                	srli	a5,a5,0x10
    10a0:	02947433          	remu	s0,s0,s1
    10a4:	8536                	mv	a0,a3
    10a6:	02d70733          	mul	a4,a4,a3
    10aa:	0442                	slli	s0,s0,0x10
    10ac:	8fc1                	or	a5,a5,s0
    10ae:	00e7fc63          	bgeu	a5,a4,10c6 <__divdf3+0x264>
    10b2:	97b2                	add	a5,a5,a2
    10b4:	fff68513          	addi	a0,a3,-1
    10b8:	00c7e763          	bltu	a5,a2,10c6 <__divdf3+0x264>
    10bc:	00e7f563          	bgeu	a5,a4,10c6 <__divdf3+0x264>
    10c0:	ffe68513          	addi	a0,a3,-2
    10c4:	97b2                	add	a5,a5,a2
    10c6:	05c2                	slli	a1,a1,0x10
    10c8:	8dc9                	or	a1,a1,a0
    10ca:	8f99                	sub	a5,a5,a4
    10cc:	01029693          	slli	a3,t0,0x10
    10d0:	01059713          	slli	a4,a1,0x10
    10d4:	82c1                	srli	a3,a3,0x10
    10d6:	0102d413          	srli	s0,t0,0x10
    10da:	0105d513          	srli	a0,a1,0x10
    10de:	8341                	srli	a4,a4,0x10
    10e0:	02d703b3          	mul	t2,a4,a3
    10e4:	c436                	sw	a3,8(sp)
    10e6:	02e40733          	mul	a4,s0,a4
    10ea:	02d506b3          	mul	a3,a0,a3
    10ee:	02850533          	mul	a0,a0,s0
    10f2:	9736                	add	a4,a4,a3
    10f4:	0103d413          	srli	s0,t2,0x10
    10f8:	9722                	add	a4,a4,s0
    10fa:	00d77463          	bgeu	a4,a3,1102 <__divdf3+0x2a0>
    10fe:	66c1                	lui	a3,0x10
    1100:	9536                	add	a0,a0,a3
    1102:	03c2                	slli	t2,t2,0x10
    1104:	01075693          	srli	a3,a4,0x10
    1108:	0103d393          	srli	t2,t2,0x10
    110c:	0742                	slli	a4,a4,0x10
    110e:	971e                	add	a4,a4,t2
    1110:	96aa                	add	a3,a3,a0
    1112:	c43a                	sw	a4,8(sp)
    1114:	00d7e763          	bltu	a5,a3,1122 <__divdf3+0x2c0>
    1118:	83ae                	mv	t2,a1
    111a:	04d79263          	bne	a5,a3,115e <__divdf3+0x2fc>
    111e:	04e37063          	bgeu	t1,a4,115e <__divdf3+0x2fc>
    1122:	00530533          	add	a0,t1,t0
    1126:	00653433          	sltu	s0,a0,t1
    112a:	00c40733          	add	a4,s0,a2
    112e:	97ba                	add	a5,a5,a4
    1130:	fff58393          	addi	t2,a1,-1
    1134:	832a                	mv	t1,a0
    1136:	00f66563          	bltu	a2,a5,1140 <__divdf3+0x2de>
    113a:	02f61263          	bne	a2,a5,115e <__divdf3+0x2fc>
    113e:	e005                	bnez	s0,115e <__divdf3+0x2fc>
    1140:	00d7e763          	bltu	a5,a3,114e <__divdf3+0x2ec>
    1144:	00f69d63          	bne	a3,a5,115e <__divdf3+0x2fc>
    1148:	4722                	lw	a4,8(sp)
    114a:	00e57a63          	bgeu	a0,a4,115e <__divdf3+0x2fc>
    114e:	9516                	add	a0,a0,t0
    1150:	ffe58393          	addi	t2,a1,-2
    1154:	005535b3          	sltu	a1,a0,t0
    1158:	95b2                	add	a1,a1,a2
    115a:	832a                	mv	t1,a0
    115c:	97ae                	add	a5,a5,a1
    115e:	4722                	lw	a4,8(sp)
    1160:	40d786b3          	sub	a3,a5,a3
    1164:	557d                	li	a0,-1
    1166:	40e30733          	sub	a4,t1,a4
    116a:	00e33333          	sltu	t1,t1,a4
    116e:	406686b3          	sub	a3,a3,t1
    1172:	10d60063          	beq	a2,a3,1272 <__divdf3+0x410>
    1176:	0296d533          	divu	a0,a3,s1
    117a:	01061793          	slli	a5,a2,0x10
    117e:	83c1                	srli	a5,a5,0x10
    1180:	02a785b3          	mul	a1,a5,a0
    1184:	0296f7b3          	remu	a5,a3,s1
    1188:	01075693          	srli	a3,a4,0x10
    118c:	07c2                	slli	a5,a5,0x10
    118e:	8fd5                	or	a5,a5,a3
    1190:	86aa                	mv	a3,a0
    1192:	00b7fc63          	bgeu	a5,a1,11aa <__divdf3+0x348>
    1196:	97b2                	add	a5,a5,a2
    1198:	fff50693          	addi	a3,a0,-1
    119c:	00c7e763          	bltu	a5,a2,11aa <__divdf3+0x348>
    11a0:	00b7f563          	bgeu	a5,a1,11aa <__divdf3+0x348>
    11a4:	ffe50693          	addi	a3,a0,-2
    11a8:	97b2                	add	a5,a5,a2
    11aa:	8f8d                	sub	a5,a5,a1
    11ac:	0297d533          	divu	a0,a5,s1
    11b0:	01061593          	slli	a1,a2,0x10
    11b4:	81c1                	srli	a1,a1,0x10
    11b6:	0742                	slli	a4,a4,0x10
    11b8:	8341                	srli	a4,a4,0x10
    11ba:	0297f7b3          	remu	a5,a5,s1
    11be:	832a                	mv	t1,a0
    11c0:	02a585b3          	mul	a1,a1,a0
    11c4:	07c2                	slli	a5,a5,0x10
    11c6:	8f5d                	or	a4,a4,a5
    11c8:	00b77c63          	bgeu	a4,a1,11e0 <__divdf3+0x37e>
    11cc:	9732                	add	a4,a4,a2
    11ce:	fff50313          	addi	t1,a0,-1
    11d2:	00c76763          	bltu	a4,a2,11e0 <__divdf3+0x37e>
    11d6:	00b77563          	bgeu	a4,a1,11e0 <__divdf3+0x37e>
    11da:	ffe50313          	addi	t1,a0,-2
    11de:	9732                	add	a4,a4,a2
    11e0:	06c2                	slli	a3,a3,0x10
    11e2:	0066e6b3          	or	a3,a3,t1
    11e6:	01029413          	slli	s0,t0,0x10
    11ea:	0106d793          	srli	a5,a3,0x10
    11ee:	8041                	srli	s0,s0,0x10
    11f0:	8f0d                	sub	a4,a4,a1
    11f2:	01069513          	slli	a0,a3,0x10
    11f6:	01029593          	slli	a1,t0,0x10
    11fa:	02878333          	mul	t1,a5,s0
    11fe:	8141                	srli	a0,a0,0x10
    1200:	0102d413          	srli	s0,t0,0x10
    1204:	81c1                	srli	a1,a1,0x10
    1206:	02a585b3          	mul	a1,a1,a0
    120a:	02a40533          	mul	a0,s0,a0
    120e:	02f407b3          	mul	a5,s0,a5
    1212:	951a                	add	a0,a0,t1
    1214:	0105d413          	srli	s0,a1,0x10
    1218:	9522                	add	a0,a0,s0
    121a:	00657463          	bgeu	a0,t1,1222 <__divdf3+0x3c0>
    121e:	6341                	lui	t1,0x10
    1220:	979a                	add	a5,a5,t1
    1222:	01055313          	srli	t1,a0,0x10
    1226:	05c2                	slli	a1,a1,0x10
    1228:	0542                	slli	a0,a0,0x10
    122a:	81c1                	srli	a1,a1,0x10
    122c:	979a                	add	a5,a5,t1
    122e:	95aa                	add	a1,a1,a0
    1230:	00f76663          	bltu	a4,a5,123c <__divdf3+0x3da>
    1234:	8536                	mv	a0,a3
    1236:	02f71c63          	bne	a4,a5,126e <__divdf3+0x40c>
    123a:	cd85                	beqz	a1,1272 <__divdf3+0x410>
    123c:	9732                	add	a4,a4,a2
    123e:	fff68513          	addi	a0,a3,-1 # ffff <__ctor_end__+0x943f>
    1242:	833a                	mv	t1,a4
    1244:	02c76163          	bltu	a4,a2,1266 <__divdf3+0x404>
    1248:	00f76663          	bltu	a4,a5,1254 <__divdf3+0x3f2>
    124c:	02f71163          	bne	a4,a5,126e <__divdf3+0x40c>
    1250:	00b2fd63          	bgeu	t0,a1,126a <__divdf3+0x408>
    1254:	ffe68513          	addi	a0,a3,-2
    1258:	00129693          	slli	a3,t0,0x1
    125c:	0056b333          	sltu	t1,a3,t0
    1260:	9332                	add	t1,t1,a2
    1262:	933a                	add	t1,t1,a4
    1264:	82b6                	mv	t0,a3
    1266:	00f31463          	bne	t1,a5,126e <__divdf3+0x40c>
    126a:	00558463          	beq	a1,t0,1272 <__divdf3+0x410>
    126e:	00156513          	ori	a0,a0,1
    1272:	4782                	lw	a5,0(sp)
    1274:	3ff78793          	addi	a5,a5,1023
    1278:	0af05063          	blez	a5,1318 <__divdf3+0x4b6>
    127c:	00757713          	andi	a4,a0,7
    1280:	cf01                	beqz	a4,1298 <__divdf3+0x436>
    1282:	00f57713          	andi	a4,a0,15
    1286:	4691                	li	a3,4
    1288:	00d70863          	beq	a4,a3,1298 <__divdf3+0x436>
    128c:	00d50733          	add	a4,a0,a3
    1290:	00a736b3          	sltu	a3,a4,a0
    1294:	93b6                	add	t2,t2,a3
    1296:	853a                	mv	a0,a4
    1298:	00739713          	slli	a4,t2,0x7
    129c:	00075a63          	bgez	a4,12b0 <__divdf3+0x44e>
    12a0:	ff0007b7          	lui	a5,0xff000
    12a4:	17fd                	addi	a5,a5,-1 # feffffff <__heap_end+0xdefcffff>
    12a6:	00f3f3b3          	and	t2,t2,a5
    12aa:	4782                	lw	a5,0(sp)
    12ac:	40078793          	addi	a5,a5,1024
    12b0:	7fe00713          	li	a4,2046
    12b4:	10f74163          	blt	a4,a5,13b6 <__divdf3+0x554>
    12b8:	00355713          	srli	a4,a0,0x3
    12bc:	01d39513          	slli	a0,t2,0x1d
    12c0:	8d59                	or	a0,a0,a4
    12c2:	0033d393          	srli	t2,t2,0x3
    12c6:	4712                	lw	a4,4(sp)
    12c8:	03b2                	slli	t2,t2,0xc
    12ca:	5082                	lw	ra,32(sp)
    12cc:	4472                	lw	s0,28(sp)
    12ce:	07d2                	slli	a5,a5,0x14
    12d0:	00c3d393          	srli	t2,t2,0xc
    12d4:	0077e7b3          	or	a5,a5,t2
    12d8:	077e                	slli	a4,a4,0x1f
    12da:	00e7e6b3          	or	a3,a5,a4
    12de:	44e2                	lw	s1,24(sp)
    12e0:	85b6                	mv	a1,a3
    12e2:	02410113          	addi	sp,sp,36
    12e6:	8082                	ret
    12e8:	4702                	lw	a4,0(sp)
    12ea:	4301                	li	t1,0
    12ec:	177d                	addi	a4,a4,-1
    12ee:	c03a                	sw	a4,0(sp)
    12f0:	bba1                	j	1048 <__divdf3+0x1e6>
    12f2:	c226                	sw	s1,4(sp)
    12f4:	833a                	mv	t1,a4
    12f6:	4789                	li	a5,2
    12f8:	0af30f63          	beq	t1,a5,13b6 <__divdf3+0x554>
    12fc:	478d                	li	a5,3
    12fe:	0af30563          	beq	t1,a5,13a8 <__divdf3+0x546>
    1302:	4785                	li	a5,1
    1304:	f6f317e3          	bne	t1,a5,1272 <__divdf3+0x410>
    1308:	4381                	li	t2,0
    130a:	4501                	li	a0,0
    130c:	a0bd                	j	137a <__divdf3+0x518>
    130e:	4722                	lw	a4,8(sp)
    1310:	83a2                	mv	t2,s0
    1312:	853e                	mv	a0,a5
    1314:	c23a                	sw	a4,4(sp)
    1316:	b7c5                	j	12f6 <__divdf3+0x494>
    1318:	4685                	li	a3,1
    131a:	cb89                	beqz	a5,132c <__divdf3+0x4ca>
    131c:	8e9d                	sub	a3,a3,a5
    131e:	03800713          	li	a4,56
    1322:	fed743e3          	blt	a4,a3,1308 <__divdf3+0x4a6>
    1326:	477d                	li	a4,31
    1328:	04d74b63          	blt	a4,a3,137e <__divdf3+0x51c>
    132c:	4782                	lw	a5,0(sp)
    132e:	41e78713          	addi	a4,a5,1054
    1332:	00d557b3          	srl	a5,a0,a3
    1336:	00e51533          	sll	a0,a0,a4
    133a:	00a03533          	snez	a0,a0
    133e:	00e39733          	sll	a4,t2,a4
    1342:	8d59                	or	a0,a0,a4
    1344:	8fc9                	or	a5,a5,a0
    1346:	00d3d3b3          	srl	t2,t2,a3
    134a:	0077f713          	andi	a4,a5,7
    134e:	cf01                	beqz	a4,1366 <__divdf3+0x504>
    1350:	00f7f713          	andi	a4,a5,15
    1354:	4691                	li	a3,4
    1356:	00d70863          	beq	a4,a3,1366 <__divdf3+0x504>
    135a:	00d78733          	add	a4,a5,a3
    135e:	00f736b3          	sltu	a3,a4,a5
    1362:	93b6                	add	t2,t2,a3
    1364:	87ba                	mv	a5,a4
    1366:	00839713          	slli	a4,t2,0x8
    136a:	04074b63          	bltz	a4,13c0 <__divdf3+0x55e>
    136e:	01d39513          	slli	a0,t2,0x1d
    1372:	838d                	srli	a5,a5,0x3
    1374:	8d5d                	or	a0,a0,a5
    1376:	0033d393          	srli	t2,t2,0x3
    137a:	4781                	li	a5,0
    137c:	b7a9                	j	12c6 <__divdf3+0x464>
    137e:	5705                	li	a4,-31
    1380:	40f707b3          	sub	a5,a4,a5
    1384:	02000613          	li	a2,32
    1388:	00f3d7b3          	srl	a5,t2,a5
    138c:	4701                	li	a4,0
    138e:	00c68763          	beq	a3,a2,139c <__divdf3+0x53a>
    1392:	4702                	lw	a4,0(sp)
    1394:	43e70713          	addi	a4,a4,1086
    1398:	00e39733          	sll	a4,t2,a4
    139c:	8f49                	or	a4,a4,a0
    139e:	00e03733          	snez	a4,a4
    13a2:	8fd9                	or	a5,a5,a4
    13a4:	4381                	li	t2,0
    13a6:	b755                	j	134a <__divdf3+0x4e8>
    13a8:	000803b7          	lui	t2,0x80
    13ac:	4501                	li	a0,0
    13ae:	7ff00793          	li	a5,2047
    13b2:	c202                	sw	zero,4(sp)
    13b4:	bf09                	j	12c6 <__divdf3+0x464>
    13b6:	4381                	li	t2,0
    13b8:	4501                	li	a0,0
    13ba:	7ff00793          	li	a5,2047
    13be:	b721                	j	12c6 <__divdf3+0x464>
    13c0:	4381                	li	t2,0
    13c2:	4501                	li	a0,0
    13c4:	4785                	li	a5,1
    13c6:	b701                	j	12c6 <__divdf3+0x464>

000013c8 <__eqdf2>:
    13c8:	001007b7          	lui	a5,0x100
    13cc:	17fd                	addi	a5,a5,-1 # fffff <__ctor_end__+0xf943f>
    13ce:	1151                	addi	sp,sp,-12
    13d0:	00b7f2b3          	and	t0,a5,a1
    13d4:	0145d713          	srli	a4,a1,0x14
    13d8:	81fd                	srli	a1,a1,0x1f
    13da:	c422                	sw	s0,8(sp)
    13dc:	c226                	sw	s1,4(sp)
    13de:	832a                	mv	t1,a0
    13e0:	842a                	mv	s0,a0
    13e2:	c02e                	sw	a1,0(sp)
    13e4:	7ff77713          	andi	a4,a4,2047
    13e8:	0146d593          	srli	a1,a3,0x14
    13ec:	7ff00513          	li	a0,2047
    13f0:	8ff5                	and	a5,a5,a3
    13f2:	84b2                	mv	s1,a2
    13f4:	7ff5f593          	andi	a1,a1,2047
    13f8:	82fd                	srli	a3,a3,0x1f
    13fa:	00a71a63          	bne	a4,a0,140e <__eqdf2+0x46>
    13fe:	0062e3b3          	or	t2,t0,t1
    1402:	4505                	li	a0,1
    1404:	02039963          	bnez	t2,1436 <__eqdf2+0x6e>
    1408:	02e59763          	bne	a1,a4,1436 <__eqdf2+0x6e>
    140c:	a019                	j	1412 <__eqdf2+0x4a>
    140e:	00a59563          	bne	a1,a0,1418 <__eqdf2+0x50>
    1412:	8e5d                	or	a2,a2,a5
    1414:	4505                	li	a0,1
    1416:	e205                	bnez	a2,1436 <__eqdf2+0x6e>
    1418:	4505                	li	a0,1
    141a:	00b71e63          	bne	a4,a1,1436 <__eqdf2+0x6e>
    141e:	00f29c63          	bne	t0,a5,1436 <__eqdf2+0x6e>
    1422:	00941a63          	bne	s0,s1,1436 <__eqdf2+0x6e>
    1426:	4782                	lw	a5,0(sp)
    1428:	00d78b63          	beq	a5,a3,143e <__eqdf2+0x76>
    142c:	e709                	bnez	a4,1436 <__eqdf2+0x6e>
    142e:	0062e533          	or	a0,t0,t1
    1432:	00a03533          	snez	a0,a0
    1436:	4422                	lw	s0,8(sp)
    1438:	4492                	lw	s1,4(sp)
    143a:	0131                	addi	sp,sp,12
    143c:	8082                	ret
    143e:	4501                	li	a0,0
    1440:	bfdd                	j	1436 <__eqdf2+0x6e>

00001442 <__gedf2>:
    1442:	1161                	addi	sp,sp,-8
    1444:	0145d313          	srli	t1,a1,0x14
    1448:	001007b7          	lui	a5,0x100
    144c:	17fd                	addi	a5,a5,-1 # fffff <__ctor_end__+0xf943f>
    144e:	c222                	sw	s0,4(sp)
    1450:	c026                	sw	s1,0(sp)
    1452:	872a                	mv	a4,a0
    1454:	84aa                	mv	s1,a0
    1456:	7ff37313          	andi	t1,t1,2047
    145a:	0146d513          	srli	a0,a3,0x14
    145e:	7ff00413          	li	s0,2047
    1462:	00b7f2b3          	and	t0,a5,a1
    1466:	83b2                	mv	t2,a2
    1468:	8ff5                	and	a5,a5,a3
    146a:	81fd                	srli	a1,a1,0x1f
    146c:	7ff57513          	andi	a0,a0,2047
    1470:	82fd                	srli	a3,a3,0x1f
    1472:	00831563          	bne	t1,s0,147c <__gedf2+0x3a>
    1476:	00e2e433          	or	s0,t0,a4
    147a:	e829                	bnez	s0,14cc <__gedf2+0x8a>
    147c:	7ff00413          	li	s0,2047
    1480:	00851563          	bne	a0,s0,148a <__gedf2+0x48>
    1484:	00c7e433          	or	s0,a5,a2
    1488:	e031                	bnez	s0,14cc <__gedf2+0x8a>
    148a:	4401                	li	s0,0
    148c:	00031663          	bnez	t1,1498 <__gedf2+0x56>
    1490:	00e2e733          	or	a4,t0,a4
    1494:	00173413          	seqz	s0,a4
    1498:	ed05                	bnez	a0,14d0 <__gedf2+0x8e>
    149a:	8e5d                	or	a2,a2,a5
    149c:	c411                	beqz	s0,14a8 <__gedf2+0x66>
    149e:	c231                	beqz	a2,14e2 <__gedf2+0xa0>
    14a0:	00169513          	slli	a0,a3,0x1
    14a4:	157d                	addi	a0,a0,-1
    14a6:	a835                	j	14e2 <__gedf2+0xa0>
    14a8:	e60d                	bnez	a2,14d2 <__gedf2+0x90>
    14aa:	40b00533          	neg	a0,a1
    14ae:	a805                	j	14de <__gedf2+0x9c>
    14b0:	fea348e3          	blt	t1,a0,14a0 <__gedf2+0x5e>
    14b4:	fe57ebe3          	bltu	a5,t0,14aa <__gedf2+0x68>
    14b8:	00f29763          	bne	t0,a5,14c6 <__gedf2+0x84>
    14bc:	fe93e7e3          	bltu	t2,s1,14aa <__gedf2+0x68>
    14c0:	4501                	li	a0,0
    14c2:	0274f063          	bgeu	s1,t2,14e2 <__gedf2+0xa0>
    14c6:	00159513          	slli	a0,a1,0x1
    14ca:	bfe9                	j	14a4 <__gedf2+0x62>
    14cc:	5579                	li	a0,-2
    14ce:	a811                	j	14e2 <__gedf2+0xa0>
    14d0:	f861                	bnez	s0,14a0 <__gedf2+0x5e>
    14d2:	fcb69ce3          	bne	a3,a1,14aa <__gedf2+0x68>
    14d6:	fc655de3          	bge	a0,t1,14b0 <__gedf2+0x6e>
    14da:	40d00533          	neg	a0,a3
    14de:	00156513          	ori	a0,a0,1
    14e2:	4412                	lw	s0,4(sp)
    14e4:	4482                	lw	s1,0(sp)
    14e6:	0121                	addi	sp,sp,8
    14e8:	8082                	ret

000014ea <__ledf2>:
    14ea:	1161                	addi	sp,sp,-8
    14ec:	0145d313          	srli	t1,a1,0x14
    14f0:	001007b7          	lui	a5,0x100
    14f4:	17fd                	addi	a5,a5,-1 # fffff <__ctor_end__+0xf943f>
    14f6:	c222                	sw	s0,4(sp)
    14f8:	c026                	sw	s1,0(sp)
    14fa:	872a                	mv	a4,a0
    14fc:	84aa                	mv	s1,a0
    14fe:	7ff37313          	andi	t1,t1,2047
    1502:	0146d513          	srli	a0,a3,0x14
    1506:	7ff00413          	li	s0,2047
    150a:	00b7f2b3          	and	t0,a5,a1
    150e:	83b2                	mv	t2,a2
    1510:	8ff5                	and	a5,a5,a3
    1512:	81fd                	srli	a1,a1,0x1f
    1514:	7ff57513          	andi	a0,a0,2047
    1518:	82fd                	srli	a3,a3,0x1f
    151a:	00831563          	bne	t1,s0,1524 <__ledf2+0x3a>
    151e:	00e2e433          	or	s0,t0,a4
    1522:	e829                	bnez	s0,1574 <__ledf2+0x8a>
    1524:	7ff00413          	li	s0,2047
    1528:	00851563          	bne	a0,s0,1532 <__ledf2+0x48>
    152c:	00c7e433          	or	s0,a5,a2
    1530:	e031                	bnez	s0,1574 <__ledf2+0x8a>
    1532:	4401                	li	s0,0
    1534:	00031663          	bnez	t1,1540 <__ledf2+0x56>
    1538:	00e2e733          	or	a4,t0,a4
    153c:	00173413          	seqz	s0,a4
    1540:	ed05                	bnez	a0,1578 <__ledf2+0x8e>
    1542:	8e5d                	or	a2,a2,a5
    1544:	c411                	beqz	s0,1550 <__ledf2+0x66>
    1546:	c231                	beqz	a2,158a <__ledf2+0xa0>
    1548:	00169513          	slli	a0,a3,0x1
    154c:	157d                	addi	a0,a0,-1
    154e:	a835                	j	158a <__ledf2+0xa0>
    1550:	e60d                	bnez	a2,157a <__ledf2+0x90>
    1552:	40b00533          	neg	a0,a1
    1556:	a805                	j	1586 <__ledf2+0x9c>
    1558:	fea348e3          	blt	t1,a0,1548 <__ledf2+0x5e>
    155c:	fe57ebe3          	bltu	a5,t0,1552 <__ledf2+0x68>
    1560:	00f29763          	bne	t0,a5,156e <__ledf2+0x84>
    1564:	fe93e7e3          	bltu	t2,s1,1552 <__ledf2+0x68>
    1568:	4501                	li	a0,0
    156a:	0274f063          	bgeu	s1,t2,158a <__ledf2+0xa0>
    156e:	00159513          	slli	a0,a1,0x1
    1572:	bfe9                	j	154c <__ledf2+0x62>
    1574:	4509                	li	a0,2
    1576:	a811                	j	158a <__ledf2+0xa0>
    1578:	f861                	bnez	s0,1548 <__ledf2+0x5e>
    157a:	fcb69ce3          	bne	a3,a1,1552 <__ledf2+0x68>
    157e:	fc655de3          	bge	a0,t1,1558 <__ledf2+0x6e>
    1582:	40d00533          	neg	a0,a3
    1586:	00156513          	ori	a0,a0,1
    158a:	4412                	lw	s0,4(sp)
    158c:	4482                	lw	s1,0(sp)
    158e:	0121                	addi	sp,sp,8
    1590:	8082                	ret

00001592 <__muldf3>:
    1592:	fdc10113          	addi	sp,sp,-36
    1596:	00c59713          	slli	a4,a1,0xc
    159a:	cc26                	sw	s1,24(sp)
    159c:	84ae                	mv	s1,a1
    159e:	81d1                	srli	a1,a1,0x14
    15a0:	ce22                	sw	s0,28(sp)
    15a2:	d006                	sw	ra,32(sp)
    15a4:	7ff5f593          	andi	a1,a1,2047
    15a8:	842a                	mv	s0,a0
    15aa:	8331                	srli	a4,a4,0xc
    15ac:	80fd                	srli	s1,s1,0x1f
    15ae:	cdc9                	beqz	a1,1648 <__muldf3+0xb6>
    15b0:	7ff00793          	li	a5,2047
    15b4:	0ef58e63          	beq	a1,a5,16b0 <__muldf3+0x11e>
    15b8:	070e                	slli	a4,a4,0x3
    15ba:	01d55793          	srli	a5,a0,0x1d
    15be:	8fd9                	or	a5,a5,a4
    15c0:	00800737          	lui	a4,0x800
    15c4:	8f5d                	or	a4,a4,a5
    15c6:	c0158593          	addi	a1,a1,-1023
    15ca:	00351793          	slli	a5,a0,0x3
    15ce:	4301                	li	t1,0
    15d0:	00c69413          	slli	s0,a3,0xc
    15d4:	0146d293          	srli	t0,a3,0x14
    15d8:	82fd                	srli	a3,a3,0x1f
    15da:	7ff2f293          	andi	t0,t0,2047
    15de:	c236                	sw	a3,4(sp)
    15e0:	8031                	srli	s0,s0,0xc
    15e2:	0e028463          	beqz	t0,16ca <__muldf3+0x138>
    15e6:	7ff00693          	li	a3,2047
    15ea:	14d28f63          	beq	t0,a3,1748 <__muldf3+0x1b6>
    15ee:	040e                	slli	s0,s0,0x3
    15f0:	01d65693          	srli	a3,a2,0x1d
    15f4:	8ec1                	or	a3,a3,s0
    15f6:	00800437          	lui	s0,0x800
    15fa:	8c55                	or	s0,s0,a3
    15fc:	00361513          	slli	a0,a2,0x3
    1600:	c0128293          	addi	t0,t0,-1023
    1604:	4601                	li	a2,0
    1606:	005586b3          	add	a3,a1,t0
    160a:	c436                	sw	a3,8(sp)
    160c:	0685                	addi	a3,a3,1
    160e:	c036                	sw	a3,0(sp)
    1610:	00231693          	slli	a3,t1,0x2
    1614:	8ed1                	or	a3,a3,a2
    1616:	45a9                	li	a1,10
    1618:	16d5c363          	blt	a1,a3,177e <__muldf3+0x1ec>
    161c:	4592                	lw	a1,4(sp)
    161e:	4289                	li	t0,2
    1620:	8cad                	xor	s1,s1,a1
    1622:	4585                	li	a1,1
    1624:	12d2cf63          	blt	t0,a3,1762 <__muldf3+0x1d0>
    1628:	16fd                	addi	a3,a3,-1
    162a:	16d5e363          	bltu	a1,a3,1790 <__muldf3+0x1fe>
    162e:	8332                	mv	t1,a2
    1630:	4789                	li	a5,2
    1632:	3cf30763          	beq	t1,a5,1a00 <__muldf3+0x46e>
    1636:	478d                	li	a5,3
    1638:	3cf30063          	beq	t1,a5,19f8 <__muldf3+0x466>
    163c:	4785                	li	a5,1
    163e:	2af31763          	bne	t1,a5,18ec <__muldf3+0x35a>
    1642:	4401                	li	s0,0
    1644:	4681                	li	a3,0
    1646:	aea5                	j	19be <__muldf3+0x42c>
    1648:	00a767b3          	or	a5,a4,a0
    164c:	cba5                	beqz	a5,16bc <__muldf3+0x12a>
    164e:	c436                	sw	a3,8(sp)
    1650:	c232                	sw	a2,4(sp)
    1652:	cf0d                	beqz	a4,168c <__muldf3+0xfa>
    1654:	853a                	mv	a0,a4
    1656:	c03a                	sw	a4,0(sp)
    1658:	25b000ef          	jal	20b2 <__clzsi2>
    165c:	4702                	lw	a4,0(sp)
    165e:	4612                	lw	a2,4(sp)
    1660:	46a2                	lw	a3,8(sp)
    1662:	ff550593          	addi	a1,a0,-11
    1666:	4375                	li	t1,29
    1668:	ff850793          	addi	a5,a0,-8
    166c:	40b30333          	sub	t1,t1,a1
    1670:	00f71733          	sll	a4,a4,a5
    1674:	00645333          	srl	t1,s0,t1
    1678:	00e36333          	or	t1,t1,a4
    167c:	00f41733          	sll	a4,s0,a5
    1680:	c0d00593          	li	a1,-1011
    1684:	87ba                	mv	a5,a4
    1686:	8d89                	sub	a1,a1,a0
    1688:	871a                	mv	a4,t1
    168a:	b791                	j	15ce <__muldf3+0x3c>
    168c:	c03a                	sw	a4,0(sp)
    168e:	225000ef          	jal	20b2 <__clzsi2>
    1692:	87aa                	mv	a5,a0
    1694:	01578593          	addi	a1,a5,21
    1698:	4371                	li	t1,28
    169a:	4702                	lw	a4,0(sp)
    169c:	4612                	lw	a2,4(sp)
    169e:	46a2                	lw	a3,8(sp)
    16a0:	02050513          	addi	a0,a0,32
    16a4:	fcb351e3          	bge	t1,a1,1666 <__muldf3+0xd4>
    16a8:	17e1                	addi	a5,a5,-8
    16aa:	00f41333          	sll	t1,s0,a5
    16ae:	bfc9                	j	1680 <__muldf3+0xee>
    16b0:	00a767b3          	or	a5,a4,a0
    16b4:	eb81                	bnez	a5,16c4 <__muldf3+0x132>
    16b6:	4701                	li	a4,0
    16b8:	4309                	li	t1,2
    16ba:	bf19                	j	15d0 <__muldf3+0x3e>
    16bc:	4701                	li	a4,0
    16be:	4581                	li	a1,0
    16c0:	4305                	li	t1,1
    16c2:	b739                	j	15d0 <__muldf3+0x3e>
    16c4:	87aa                	mv	a5,a0
    16c6:	430d                	li	t1,3
    16c8:	b721                	j	15d0 <__muldf3+0x3e>
    16ca:	00c46533          	or	a0,s0,a2
    16ce:	c159                	beqz	a0,1754 <__muldf3+0x1c2>
    16d0:	c039                	beqz	s0,1716 <__muldf3+0x184>
    16d2:	8522                	mv	a0,s0
    16d4:	ca32                	sw	a2,20(sp)
    16d6:	c83a                	sw	a4,16(sp)
    16d8:	c63e                	sw	a5,12(sp)
    16da:	c42e                	sw	a1,8(sp)
    16dc:	c01a                	sw	t1,0(sp)
    16de:	1d5000ef          	jal	20b2 <__clzsi2>
    16e2:	4302                	lw	t1,0(sp)
    16e4:	45a2                	lw	a1,8(sp)
    16e6:	47b2                	lw	a5,12(sp)
    16e8:	4742                	lw	a4,16(sp)
    16ea:	4652                	lw	a2,20(sp)
    16ec:	ff550293          	addi	t0,a0,-11
    16f0:	46f5                	li	a3,29
    16f2:	ff850393          	addi	t2,a0,-8
    16f6:	405686b3          	sub	a3,a3,t0
    16fa:	00741433          	sll	s0,s0,t2
    16fe:	00d656b3          	srl	a3,a2,a3
    1702:	8ec1                	or	a3,a3,s0
    1704:	00761433          	sll	s0,a2,t2
    1708:	c0d00293          	li	t0,-1011
    170c:	40a282b3          	sub	t0,t0,a0
    1710:	8522                	mv	a0,s0
    1712:	8436                	mv	s0,a3
    1714:	bdc5                	j	1604 <__muldf3+0x72>
    1716:	8532                	mv	a0,a2
    1718:	ca3a                	sw	a4,20(sp)
    171a:	c83e                	sw	a5,16(sp)
    171c:	c62e                	sw	a1,12(sp)
    171e:	c41a                	sw	t1,8(sp)
    1720:	c032                	sw	a2,0(sp)
    1722:	191000ef          	jal	20b2 <__clzsi2>
    1726:	86aa                	mv	a3,a0
    1728:	01568293          	addi	t0,a3,21
    172c:	43f1                	li	t2,28
    172e:	4602                	lw	a2,0(sp)
    1730:	4322                	lw	t1,8(sp)
    1732:	45b2                	lw	a1,12(sp)
    1734:	47c2                	lw	a5,16(sp)
    1736:	4752                	lw	a4,20(sp)
    1738:	02050513          	addi	a0,a0,32
    173c:	fa53dae3          	bge	t2,t0,16f0 <__muldf3+0x15e>
    1740:	16e1                	addi	a3,a3,-8
    1742:	00d616b3          	sll	a3,a2,a3
    1746:	b7c9                	j	1708 <__muldf3+0x176>
    1748:	00c46533          	or	a0,s0,a2
    174c:	e901                	bnez	a0,175c <__muldf3+0x1ca>
    174e:	4401                	li	s0,0
    1750:	4609                	li	a2,2
    1752:	bd55                	j	1606 <__muldf3+0x74>
    1754:	4401                	li	s0,0
    1756:	4281                	li	t0,0
    1758:	4605                	li	a2,1
    175a:	b575                	j	1606 <__muldf3+0x74>
    175c:	8532                	mv	a0,a2
    175e:	460d                	li	a2,3
    1760:	b55d                	j	1606 <__muldf3+0x74>
    1762:	00d595b3          	sll	a1,a1,a3
    1766:	5305f693          	andi	a3,a1,1328
    176a:	e285                	bnez	a3,178a <__muldf3+0x1f8>
    176c:	2405f313          	andi	t1,a1,576
    1770:	26031e63          	bnez	t1,19ec <__muldf3+0x45a>
    1774:	0885f593          	andi	a1,a1,136
    1778:	cd81                	beqz	a1,1790 <__muldf3+0x1fe>
    177a:	4492                	lw	s1,4(sp)
    177c:	bd4d                	j	162e <__muldf3+0x9c>
    177e:	45bd                	li	a1,15
    1780:	26b68c63          	beq	a3,a1,19f8 <__muldf3+0x466>
    1784:	45ad                	li	a1,11
    1786:	feb68ae3          	beq	a3,a1,177a <__muldf3+0x1e8>
    178a:	843a                	mv	s0,a4
    178c:	853e                	mv	a0,a5
    178e:	b54d                	j	1630 <__muldf3+0x9e>
    1790:	0107d593          	srli	a1,a5,0x10
    1794:	01055693          	srli	a3,a0,0x10
    1798:	02d58633          	mul	a2,a1,a3
    179c:	07c2                	slli	a5,a5,0x10
    179e:	0542                	slli	a0,a0,0x10
    17a0:	83c1                	srli	a5,a5,0x10
    17a2:	8141                	srli	a0,a0,0x10
    17a4:	02a78333          	mul	t1,a5,a0
    17a8:	c232                	sw	a2,4(sp)
    17aa:	02a582b3          	mul	t0,a1,a0
    17ae:	01035393          	srli	t2,t1,0x10
    17b2:	02f68633          	mul	a2,a3,a5
    17b6:	9616                	add	a2,a2,t0
    17b8:	961e                	add	a2,a2,t2
    17ba:	00567763          	bgeu	a2,t0,17c8 <__muldf3+0x236>
    17be:	02d583b3          	mul	t2,a1,a3
    17c2:	62c1                	lui	t0,0x10
    17c4:	929e                	add	t0,t0,t2
    17c6:	c216                	sw	t0,4(sp)
    17c8:	0342                	slli	t1,t1,0x10
    17ca:	01065293          	srli	t0,a2,0x10
    17ce:	01035313          	srli	t1,t1,0x10
    17d2:	0642                	slli	a2,a2,0x10
    17d4:	961a                	add	a2,a2,t1
    17d6:	c832                	sw	a2,16(sp)
    17d8:	01045613          	srli	a2,s0,0x10
    17dc:	0442                	slli	s0,s0,0x10
    17de:	8041                	srli	s0,s0,0x10
    17e0:	02878333          	mul	t1,a5,s0
    17e4:	c616                	sw	t0,12(sp)
    17e6:	02f607b3          	mul	a5,a2,a5
    17ea:	01035393          	srli	t2,t1,0x10
    17ee:	028582b3          	mul	t0,a1,s0
    17f2:	9796                	add	a5,a5,t0
    17f4:	979e                	add	a5,a5,t2
    17f6:	02c585b3          	mul	a1,a1,a2
    17fa:	0057f463          	bgeu	a5,t0,1802 <__muldf3+0x270>
    17fe:	62c1                	lui	t0,0x10
    1800:	9596                	add	a1,a1,t0
    1802:	0107d293          	srli	t0,a5,0x10
    1806:	9596                	add	a1,a1,t0
    1808:	ca2e                	sw	a1,20(sp)
    180a:	0342                	slli	t1,t1,0x10
    180c:	45b2                	lw	a1,12(sp)
    180e:	01035313          	srli	t1,t1,0x10
    1812:	07c2                	slli	a5,a5,0x10
    1814:	979a                	add	a5,a5,t1
    1816:	95be                	add	a1,a1,a5
    1818:	c62e                	sw	a1,12(sp)
    181a:	01075593          	srli	a1,a4,0x10
    181e:	0742                	slli	a4,a4,0x10
    1820:	8341                	srli	a4,a4,0x10
    1822:	02a70333          	mul	t1,a4,a0
    1826:	02b682b3          	mul	t0,a3,a1
    182a:	01035393          	srli	t2,t1,0x10
    182e:	02a58533          	mul	a0,a1,a0
    1832:	02e686b3          	mul	a3,a3,a4
    1836:	96aa                	add	a3,a3,a0
    1838:	969e                	add	a3,a3,t2
    183a:	00a6f463          	bgeu	a3,a0,1842 <__muldf3+0x2b0>
    183e:	6541                	lui	a0,0x10
    1840:	92aa                	add	t0,t0,a0
    1842:	0342                	slli	t1,t1,0x10
    1844:	0106d513          	srli	a0,a3,0x10
    1848:	01035313          	srli	t1,t1,0x10
    184c:	06c2                	slli	a3,a3,0x10
    184e:	969a                	add	a3,a3,t1
    1850:	02870333          	mul	t1,a4,s0
    1854:	9516                	add	a0,a0,t0
    1856:	02858433          	mul	s0,a1,s0
    185a:	02b605b3          	mul	a1,a2,a1
    185e:	02e60633          	mul	a2,a2,a4
    1862:	01035713          	srli	a4,t1,0x10
    1866:	9622                	add	a2,a2,s0
    1868:	963a                	add	a2,a2,a4
    186a:	00867463          	bgeu	a2,s0,1872 <__muldf3+0x2e0>
    186e:	6741                	lui	a4,0x10
    1870:	95ba                	add	a1,a1,a4
    1872:	4432                	lw	s0,12(sp)
    1874:	4712                	lw	a4,4(sp)
    1876:	0342                	slli	t1,t1,0x10
    1878:	01061293          	slli	t0,a2,0x10
    187c:	9722                	add	a4,a4,s0
    187e:	4452                	lw	s0,20(sp)
    1880:	01035313          	srli	t1,t1,0x10
    1884:	9316                	add	t1,t1,t0
    1886:	008302b3          	add	t0,t1,s0
    188a:	00f737b3          	sltu	a5,a4,a5
    188e:	9796                	add	a5,a5,t0
    1890:	96ba                	add	a3,a3,a4
    1892:	0062b333          	sltu	t1,t0,t1
    1896:	0057b2b3          	sltu	t0,a5,t0
    189a:	953e                	add	a0,a0,a5
    189c:	8241                	srli	a2,a2,0x10
    189e:	00e6b733          	sltu	a4,a3,a4
    18a2:	005362b3          	or	t0,t1,t0
    18a6:	972a                	add	a4,a4,a0
    18a8:	92b2                	add	t0,t0,a2
    18aa:	4642                	lw	a2,16(sp)
    18ac:	00f537b3          	sltu	a5,a0,a5
    18b0:	00a73533          	sltu	a0,a4,a0
    18b4:	8fc9                	or	a5,a5,a0
    18b6:	00969513          	slli	a0,a3,0x9
    18ba:	9796                	add	a5,a5,t0
    18bc:	8d51                	or	a0,a0,a2
    18be:	97ae                	add	a5,a5,a1
    18c0:	00a03533          	snez	a0,a0
    18c4:	82dd                	srli	a3,a3,0x17
    18c6:	07a6                	slli	a5,a5,0x9
    18c8:	01775413          	srli	s0,a4,0x17
    18cc:	8d55                	or	a0,a0,a3
    18ce:	0726                	slli	a4,a4,0x9
    18d0:	8d59                	or	a0,a0,a4
    18d2:	00779713          	slli	a4,a5,0x7
    18d6:	8c5d                	or	s0,s0,a5
    18d8:	08075063          	bgez	a4,1958 <__muldf3+0x3c6>
    18dc:	00155793          	srli	a5,a0,0x1
    18e0:	8905                	andi	a0,a0,1
    18e2:	8fc9                	or	a5,a5,a0
    18e4:	01f41513          	slli	a0,s0,0x1f
    18e8:	8d5d                	or	a0,a0,a5
    18ea:	8005                	srli	s0,s0,0x1
    18ec:	4782                	lw	a5,0(sp)
    18ee:	3ff78793          	addi	a5,a5,1023
    18f2:	06f05663          	blez	a5,195e <__muldf3+0x3cc>
    18f6:	00757713          	andi	a4,a0,7
    18fa:	cf01                	beqz	a4,1912 <__muldf3+0x380>
    18fc:	00f57713          	andi	a4,a0,15
    1900:	4691                	li	a3,4
    1902:	00d70863          	beq	a4,a3,1912 <__muldf3+0x380>
    1906:	00d50733          	add	a4,a0,a3
    190a:	00a736b3          	sltu	a3,a4,a0
    190e:	9436                	add	s0,s0,a3
    1910:	853a                	mv	a0,a4
    1912:	00741713          	slli	a4,s0,0x7
    1916:	00075963          	bgez	a4,1928 <__muldf3+0x396>
    191a:	ff0007b7          	lui	a5,0xff000
    191e:	17fd                	addi	a5,a5,-1 # feffffff <__heap_end+0xdefcffff>
    1920:	8c7d                	and	s0,s0,a5
    1922:	4782                	lw	a5,0(sp)
    1924:	40078793          	addi	a5,a5,1024
    1928:	7fe00713          	li	a4,2046
    192c:	0cf74a63          	blt	a4,a5,1a00 <__muldf3+0x46e>
    1930:	01d41693          	slli	a3,s0,0x1d
    1934:	810d                	srli	a0,a0,0x3
    1936:	8ec9                	or	a3,a3,a0
    1938:	800d                	srli	s0,s0,0x3
    193a:	0432                	slli	s0,s0,0xc
    193c:	8031                	srli	s0,s0,0xc
    193e:	07d2                	slli	a5,a5,0x14
    1940:	5082                	lw	ra,32(sp)
    1942:	8fc1                	or	a5,a5,s0
    1944:	4472                	lw	s0,28(sp)
    1946:	04fe                	slli	s1,s1,0x1f
    1948:	0097e733          	or	a4,a5,s1
    194c:	8536                	mv	a0,a3
    194e:	44e2                	lw	s1,24(sp)
    1950:	85ba                	mv	a1,a4
    1952:	02410113          	addi	sp,sp,36
    1956:	8082                	ret
    1958:	47a2                	lw	a5,8(sp)
    195a:	c03e                	sw	a5,0(sp)
    195c:	bf41                	j	18ec <__muldf3+0x35a>
    195e:	4685                	li	a3,1
    1960:	cb89                	beqz	a5,1972 <__muldf3+0x3e0>
    1962:	8e9d                	sub	a3,a3,a5
    1964:	03800713          	li	a4,56
    1968:	ccd74de3          	blt	a4,a3,1642 <__muldf3+0xb0>
    196c:	477d                	li	a4,31
    196e:	04d74a63          	blt	a4,a3,19c2 <__muldf3+0x430>
    1972:	4782                	lw	a5,0(sp)
    1974:	41e78713          	addi	a4,a5,1054
    1978:	00d557b3          	srl	a5,a0,a3
    197c:	00e51533          	sll	a0,a0,a4
    1980:	00a03533          	snez	a0,a0
    1984:	00e41733          	sll	a4,s0,a4
    1988:	8d59                	or	a0,a0,a4
    198a:	8fc9                	or	a5,a5,a0
    198c:	00d45433          	srl	s0,s0,a3
    1990:	0077f713          	andi	a4,a5,7
    1994:	cf01                	beqz	a4,19ac <__muldf3+0x41a>
    1996:	00f7f713          	andi	a4,a5,15
    199a:	4691                	li	a3,4
    199c:	00d70863          	beq	a4,a3,19ac <__muldf3+0x41a>
    19a0:	00d78733          	add	a4,a5,a3
    19a4:	00f736b3          	sltu	a3,a4,a5
    19a8:	9436                	add	s0,s0,a3
    19aa:	87ba                	mv	a5,a4
    19ac:	00841713          	slli	a4,s0,0x8
    19b0:	04074d63          	bltz	a4,1a0a <__muldf3+0x478>
    19b4:	01d41693          	slli	a3,s0,0x1d
    19b8:	838d                	srli	a5,a5,0x3
    19ba:	8edd                	or	a3,a3,a5
    19bc:	800d                	srli	s0,s0,0x3
    19be:	4781                	li	a5,0
    19c0:	bfad                	j	193a <__muldf3+0x3a8>
    19c2:	5705                	li	a4,-31
    19c4:	40f707b3          	sub	a5,a4,a5
    19c8:	02000613          	li	a2,32
    19cc:	00f457b3          	srl	a5,s0,a5
    19d0:	4701                	li	a4,0
    19d2:	00c68763          	beq	a3,a2,19e0 <__muldf3+0x44e>
    19d6:	4702                	lw	a4,0(sp)
    19d8:	43e70713          	addi	a4,a4,1086 # 1043e <__ctor_end__+0x987e>
    19dc:	00e41733          	sll	a4,s0,a4
    19e0:	8f49                	or	a4,a4,a0
    19e2:	00e03733          	snez	a4,a4
    19e6:	8fd9                	or	a5,a5,a4
    19e8:	4401                	li	s0,0
    19ea:	b75d                	j	1990 <__muldf3+0x3fe>
    19ec:	00080437          	lui	s0,0x80
    19f0:	7ff00793          	li	a5,2047
    19f4:	4481                	li	s1,0
    19f6:	b791                	j	193a <__muldf3+0x3a8>
    19f8:	00080437          	lui	s0,0x80
    19fc:	4681                	li	a3,0
    19fe:	bfcd                	j	19f0 <__muldf3+0x45e>
    1a00:	4401                	li	s0,0
    1a02:	4681                	li	a3,0
    1a04:	7ff00793          	li	a5,2047
    1a08:	bf0d                	j	193a <__muldf3+0x3a8>
    1a0a:	4401                	li	s0,0
    1a0c:	4681                	li	a3,0
    1a0e:	4785                	li	a5,1
    1a10:	b72d                	j	193a <__muldf3+0x3a8>

00001a12 <__subdf3>:
    1a12:	00100337          	lui	t1,0x100
    1a16:	137d                	addi	t1,t1,-1 # fffff <__ctor_end__+0xf943f>
    1a18:	1131                	addi	sp,sp,-20
    1a1a:	8732                	mv	a4,a2
    1a1c:	00b37633          	and	a2,t1,a1
    1a20:	0145d793          	srli	a5,a1,0x14
    1a24:	c622                	sw	s0,12(sp)
    1a26:	01f5d413          	srli	s0,a1,0x1f
    1a2a:	00361593          	slli	a1,a2,0x3
    1a2e:	01d55613          	srli	a2,a0,0x1d
    1a32:	00d37333          	and	t1,t1,a3
    1a36:	c426                	sw	s1,8(sp)
    1a38:	7ff7f493          	andi	s1,a5,2047
    1a3c:	00b667b3          	or	a5,a2,a1
    1a40:	0146d593          	srli	a1,a3,0x14
    1a44:	00331293          	slli	t0,t1,0x3
    1a48:	c806                	sw	ra,16(sp)
    1a4a:	01d75313          	srli	t1,a4,0x1d
    1a4e:	7ff5f593          	andi	a1,a1,2047
    1a52:	7ff00613          	li	a2,2047
    1a56:	050e                	slli	a0,a0,0x3
    1a58:	82fd                	srli	a3,a3,0x1f
    1a5a:	00536333          	or	t1,t1,t0
    1a5e:	070e                	slli	a4,a4,0x3
    1a60:	00c59563          	bne	a1,a2,1a6a <__subdf3+0x58>
    1a64:	00e36633          	or	a2,t1,a4
    1a68:	e219                	bnez	a2,1a6e <__subdf3+0x5c>
    1a6a:	0016c693          	xori	a3,a3,1
    1a6e:	40b48633          	sub	a2,s1,a1
    1a72:	7ff00293          	li	t0,2047
    1a76:	26869263          	bne	a3,s0,1cda <__subdf3+0x2c8>
    1a7a:	10c05963          	blez	a2,1b8c <__subdf3+0x17a>
    1a7e:	e5ad                	bnez	a1,1ae8 <__subdf3+0xd6>
    1a80:	00e366b3          	or	a3,t1,a4
    1a84:	ce99                	beqz	a3,1aa2 <__subdf3+0x90>
    1a86:	fff48613          	addi	a2,s1,-1
    1a8a:	ea11                	bnez	a2,1a9e <__subdf3+0x8c>
    1a8c:	972a                	add	a4,a4,a0
    1a8e:	00a736b3          	sltu	a3,a4,a0
    1a92:	933e                	add	t1,t1,a5
    1a94:	853a                	mv	a0,a4
    1a96:	00d307b3          	add	a5,t1,a3
    1a9a:	4485                	li	s1,1
    1a9c:	a851                	j	1b30 <__subdf3+0x11e>
    1a9e:	04549b63          	bne	s1,t0,1af4 <__subdf3+0xe2>
    1aa2:	01d79713          	slli	a4,a5,0x1d
    1aa6:	810d                	srli	a0,a0,0x3
    1aa8:	0037d613          	srli	a2,a5,0x3
    1aac:	7ff00793          	li	a5,2047
    1ab0:	8f49                	or	a4,a4,a0
    1ab2:	00f49963          	bne	s1,a5,1ac4 <__subdf3+0xb2>
    1ab6:	8f51                	or	a4,a4,a2
    1ab8:	4601                	li	a2,0
    1aba:	c709                	beqz	a4,1ac4 <__subdf3+0xb2>
    1abc:	00080637          	lui	a2,0x80
    1ac0:	4701                	li	a4,0
    1ac2:	4401                	li	s0,0
    1ac4:	01449793          	slli	a5,s1,0x14
    1ac8:	7ff006b7          	lui	a3,0x7ff00
    1acc:	0632                	slli	a2,a2,0xc
    1ace:	8ff5                	and	a5,a5,a3
    1ad0:	8231                	srli	a2,a2,0xc
    1ad2:	047e                	slli	s0,s0,0x1f
    1ad4:	8fd1                	or	a5,a5,a2
    1ad6:	40c2                	lw	ra,16(sp)
    1ad8:	0087e6b3          	or	a3,a5,s0
    1adc:	4432                	lw	s0,12(sp)
    1ade:	44a2                	lw	s1,8(sp)
    1ae0:	853a                	mv	a0,a4
    1ae2:	85b6                	mv	a1,a3
    1ae4:	0151                	addi	sp,sp,20
    1ae6:	8082                	ret
    1ae8:	fa548de3          	beq	s1,t0,1aa2 <__subdf3+0x90>
    1aec:	008006b7          	lui	a3,0x800
    1af0:	00d36333          	or	t1,t1,a3
    1af4:	03800693          	li	a3,56
    1af8:	08c6c563          	blt	a3,a2,1b82 <__subdf3+0x170>
    1afc:	46fd                	li	a3,31
    1afe:	02000293          	li	t0,32
    1b02:	04c6cd63          	blt	a3,a2,1b5c <__subdf3+0x14a>
    1b06:	40c282b3          	sub	t0,t0,a2
    1b0a:	00c755b3          	srl	a1,a4,a2
    1b0e:	005316b3          	sll	a3,t1,t0
    1b12:	005712b3          	sll	t0,a4,t0
    1b16:	8ecd                	or	a3,a3,a1
    1b18:	005032b3          	snez	t0,t0
    1b1c:	0056e733          	or	a4,a3,t0
    1b20:	00c35633          	srl	a2,t1,a2
    1b24:	953a                	add	a0,a0,a4
    1b26:	963e                	add	a2,a2,a5
    1b28:	00e53733          	sltu	a4,a0,a4
    1b2c:	00e607b3          	add	a5,a2,a4
    1b30:	00879713          	slli	a4,a5,0x8
    1b34:	16075763          	bgez	a4,1ca2 <__subdf3+0x290>
    1b38:	0485                	addi	s1,s1,1
    1b3a:	7ff00713          	li	a4,2047
    1b3e:	48e48963          	beq	s1,a4,1fd0 <__subdf3+0x5be>
    1b42:	ff800737          	lui	a4,0xff800
    1b46:	177d                	addi	a4,a4,-1 # ff7fffff <__heap_end+0xdf7cffff>
    1b48:	8ff9                	and	a5,a5,a4
    1b4a:	00155713          	srli	a4,a0,0x1
    1b4e:	8905                	andi	a0,a0,1
    1b50:	8f49                	or	a4,a4,a0
    1b52:	01f79513          	slli	a0,a5,0x1f
    1b56:	8d59                	or	a0,a0,a4
    1b58:	8385                	srli	a5,a5,0x1
    1b5a:	a2a1                	j	1ca2 <__subdf3+0x290>
    1b5c:	fe060693          	addi	a3,a2,-32 # 7ffe0 <__ctor_end__+0x79420>
    1b60:	00d356b3          	srl	a3,t1,a3
    1b64:	4581                	li	a1,0
    1b66:	00560763          	beq	a2,t0,1b74 <__subdf3+0x162>
    1b6a:	04000593          	li	a1,64
    1b6e:	8d91                	sub	a1,a1,a2
    1b70:	00b315b3          	sll	a1,t1,a1
    1b74:	8dd9                	or	a1,a1,a4
    1b76:	00b035b3          	snez	a1,a1
    1b7a:	00b6e733          	or	a4,a3,a1
    1b7e:	4601                	li	a2,0
    1b80:	b755                	j	1b24 <__subdf3+0x112>
    1b82:	00e36733          	or	a4,t1,a4
    1b86:	00e03733          	snez	a4,a4
    1b8a:	bfd5                	j	1b7e <__subdf3+0x16c>
    1b8c:	c255                	beqz	a2,1c30 <__subdf3+0x21e>
    1b8e:	409586b3          	sub	a3,a1,s1
    1b92:	ec91                	bnez	s1,1bae <__subdf3+0x19c>
    1b94:	00a7e633          	or	a2,a5,a0
    1b98:	c619                	beqz	a2,1ba6 <__subdf3+0x194>
    1b9a:	fff68613          	addi	a2,a3,-1 # 7fffff <__ctor_end__+0x7f943f>
    1b9e:	ee0607e3          	beqz	a2,1a8c <__subdf3+0x7a>
    1ba2:	00569c63          	bne	a3,t0,1bba <__subdf3+0x1a8>
    1ba6:	879a                	mv	a5,t1
    1ba8:	853a                	mv	a0,a4
    1baa:	84b6                	mv	s1,a3
    1bac:	bddd                	j	1aa2 <__subdf3+0x90>
    1bae:	42558463          	beq	a1,t0,1fd6 <__subdf3+0x5c4>
    1bb2:	00800637          	lui	a2,0x800
    1bb6:	8fd1                	or	a5,a5,a2
    1bb8:	8636                	mv	a2,a3
    1bba:	03800693          	li	a3,56
    1bbe:	06c6c463          	blt	a3,a2,1c26 <__subdf3+0x214>
    1bc2:	46fd                	li	a3,31
    1bc4:	02000393          	li	t2,32
    1bc8:	02c6ca63          	blt	a3,a2,1bfc <__subdf3+0x1ea>
    1bcc:	40c383b3          	sub	t2,t2,a2
    1bd0:	007796b3          	sll	a3,a5,t2
    1bd4:	00c552b3          	srl	t0,a0,a2
    1bd8:	007513b3          	sll	t2,a0,t2
    1bdc:	0056e6b3          	or	a3,a3,t0
    1be0:	007033b3          	snez	t2,t2
    1be4:	0076e6b3          	or	a3,a3,t2
    1be8:	00c7d7b3          	srl	a5,a5,a2
    1bec:	00e68533          	add	a0,a3,a4
    1bf0:	979a                	add	a5,a5,t1
    1bf2:	00d536b3          	sltu	a3,a0,a3
    1bf6:	97b6                	add	a5,a5,a3
    1bf8:	84ae                	mv	s1,a1
    1bfa:	bf1d                	j	1b30 <__subdf3+0x11e>
    1bfc:	fe060693          	addi	a3,a2,-32 # 7fffe0 <__ctor_end__+0x7f9420>
    1c00:	00d7d6b3          	srl	a3,a5,a3
    1c04:	4281                	li	t0,0
    1c06:	00760863          	beq	a2,t2,1c16 <__subdf3+0x204>
    1c0a:	04000293          	li	t0,64
    1c0e:	40c282b3          	sub	t0,t0,a2
    1c12:	005792b3          	sll	t0,a5,t0
    1c16:	00a2e2b3          	or	t0,t0,a0
    1c1a:	005032b3          	snez	t0,t0
    1c1e:	0056e6b3          	or	a3,a3,t0
    1c22:	4781                	li	a5,0
    1c24:	b7e1                	j	1bec <__subdf3+0x1da>
    1c26:	00a7e6b3          	or	a3,a5,a0
    1c2a:	00d036b3          	snez	a3,a3
    1c2e:	bfd5                	j	1c22 <__subdf3+0x210>
    1c30:	00148693          	addi	a3,s1,1
    1c34:	7fe6f613          	andi	a2,a3,2046
    1c38:	e639                	bnez	a2,1c86 <__subdf3+0x274>
    1c3a:	00a7e6b3          	or	a3,a5,a0
    1c3e:	e885                	bnez	s1,1c6e <__subdf3+0x25c>
    1c40:	22068963          	beqz	a3,1e72 <__subdf3+0x460>
    1c44:	00e366b3          	or	a3,t1,a4
    1c48:	36068c63          	beqz	a3,1fc0 <__subdf3+0x5ae>
    1c4c:	972a                	add	a4,a4,a0
    1c4e:	933e                	add	t1,t1,a5
    1c50:	00a73533          	sltu	a0,a4,a0
    1c54:	932a                	add	t1,t1,a0
    1c56:	00831793          	slli	a5,t1,0x8
    1c5a:	2007dc63          	bgez	a5,1e72 <__subdf3+0x460>
    1c5e:	ff800637          	lui	a2,0xff800
    1c62:	167d                	addi	a2,a2,-1 # ff7fffff <__heap_end+0xdf7cffff>
    1c64:	00c377b3          	and	a5,t1,a2
    1c68:	853a                	mv	a0,a4
    1c6a:	4485                	li	s1,1
    1c6c:	bd1d                	j	1aa2 <__subdf3+0x90>
    1c6e:	34068c63          	beqz	a3,1fc6 <__subdf3+0x5b4>
    1c72:	00e36333          	or	t1,t1,a4
    1c76:	8496                	mv	s1,t0
    1c78:	e20305e3          	beqz	t1,1aa2 <__subdf3+0x90>
    1c7c:	4401                	li	s0,0
    1c7e:	004007b7          	lui	a5,0x400
    1c82:	4501                	li	a0,0
    1c84:	bd39                	j	1aa2 <__subdf3+0x90>
    1c86:	34568463          	beq	a3,t0,1fce <__subdf3+0x5bc>
    1c8a:	972a                	add	a4,a4,a0
    1c8c:	00a73533          	sltu	a0,a4,a0
    1c90:	933e                	add	t1,t1,a5
    1c92:	932a                	add	t1,t1,a0
    1c94:	01f31513          	slli	a0,t1,0x1f
    1c98:	8305                	srli	a4,a4,0x1
    1c9a:	8d59                	or	a0,a0,a4
    1c9c:	00135793          	srli	a5,t1,0x1
    1ca0:	84b6                	mv	s1,a3
    1ca2:	00757713          	andi	a4,a0,7
    1ca6:	cf01                	beqz	a4,1cbe <__subdf3+0x2ac>
    1ca8:	00f57713          	andi	a4,a0,15
    1cac:	4691                	li	a3,4
    1cae:	00d70863          	beq	a4,a3,1cbe <__subdf3+0x2ac>
    1cb2:	00d50733          	add	a4,a0,a3
    1cb6:	00a736b3          	sltu	a3,a4,a0
    1cba:	97b6                	add	a5,a5,a3
    1cbc:	853a                	mv	a0,a4
    1cbe:	00879713          	slli	a4,a5,0x8
    1cc2:	de0750e3          	bgez	a4,1aa2 <__subdf3+0x90>
    1cc6:	0485                	addi	s1,s1,1
    1cc8:	7ff00713          	li	a4,2047
    1ccc:	30e48263          	beq	s1,a4,1fd0 <__subdf3+0x5be>
    1cd0:	ff800737          	lui	a4,0xff800
    1cd4:	177d                	addi	a4,a4,-1 # ff7fffff <__heap_end+0xdf7cffff>
    1cd6:	8ff9                	and	a5,a5,a4
    1cd8:	b3e9                	j	1aa2 <__subdf3+0x90>
    1cda:	0cc05163          	blez	a2,1d9c <__subdf3+0x38a>
    1cde:	e1c1                	bnez	a1,1d5e <__subdf3+0x34c>
    1ce0:	00e366b3          	or	a3,t1,a4
    1ce4:	da068fe3          	beqz	a3,1aa2 <__subdf3+0x90>
    1ce8:	fff48613          	addi	a2,s1,-1
    1cec:	ee01                	bnez	a2,1d04 <__subdf3+0x2f2>
    1cee:	40e50733          	sub	a4,a0,a4
    1cf2:	00e536b3          	sltu	a3,a0,a4
    1cf6:	40678333          	sub	t1,a5,t1
    1cfa:	853a                	mv	a0,a4
    1cfc:	40d307b3          	sub	a5,t1,a3
    1d00:	4485                	li	s1,1
    1d02:	a0a1                	j	1d4a <__subdf3+0x338>
    1d04:	d8548fe3          	beq	s1,t0,1aa2 <__subdf3+0x90>
    1d08:	03800693          	li	a3,56
    1d0c:	08c6c363          	blt	a3,a2,1d92 <__subdf3+0x380>
    1d10:	46fd                	li	a3,31
    1d12:	02000293          	li	t0,32
    1d16:	04c6cb63          	blt	a3,a2,1d6c <__subdf3+0x35a>
    1d1a:	40c282b3          	sub	t0,t0,a2
    1d1e:	00c755b3          	srl	a1,a4,a2
    1d22:	005316b3          	sll	a3,t1,t0
    1d26:	005712b3          	sll	t0,a4,t0
    1d2a:	8ecd                	or	a3,a3,a1
    1d2c:	005032b3          	snez	t0,t0
    1d30:	0056e733          	or	a4,a3,t0
    1d34:	00c35633          	srl	a2,t1,a2
    1d38:	40e50733          	sub	a4,a0,a4
    1d3c:	00e536b3          	sltu	a3,a0,a4
    1d40:	40c78633          	sub	a2,a5,a2
    1d44:	853a                	mv	a0,a4
    1d46:	40d607b3          	sub	a5,a2,a3
    1d4a:	00879713          	slli	a4,a5,0x8
    1d4e:	f4075ae3          	bgez	a4,1ca2 <__subdf3+0x290>
    1d52:	008005b7          	lui	a1,0x800
    1d56:	15fd                	addi	a1,a1,-1 # 7fffff <__ctor_end__+0x7f943f>
    1d58:	8dfd                	and	a1,a1,a5
    1d5a:	862a                	mv	a2,a0
    1d5c:	a26d                	j	1f06 <__subdf3+0x4f4>
    1d5e:	d45482e3          	beq	s1,t0,1aa2 <__subdf3+0x90>
    1d62:	008006b7          	lui	a3,0x800
    1d66:	00d36333          	or	t1,t1,a3
    1d6a:	bf79                	j	1d08 <__subdf3+0x2f6>
    1d6c:	fe060693          	addi	a3,a2,-32
    1d70:	00d356b3          	srl	a3,t1,a3
    1d74:	4581                	li	a1,0
    1d76:	00560763          	beq	a2,t0,1d84 <__subdf3+0x372>
    1d7a:	04000593          	li	a1,64
    1d7e:	8d91                	sub	a1,a1,a2
    1d80:	00b315b3          	sll	a1,t1,a1
    1d84:	8dd9                	or	a1,a1,a4
    1d86:	00b035b3          	snez	a1,a1
    1d8a:	00b6e733          	or	a4,a3,a1
    1d8e:	4601                	li	a2,0
    1d90:	b765                	j	1d38 <__subdf3+0x326>
    1d92:	00e36733          	or	a4,t1,a4
    1d96:	00e03733          	snez	a4,a4
    1d9a:	bfd5                	j	1d8e <__subdf3+0x37c>
    1d9c:	ce4d                	beqz	a2,1e56 <__subdf3+0x444>
    1d9e:	409583b3          	sub	t2,a1,s1
    1da2:	e885                	bnez	s1,1dd2 <__subdf3+0x3c0>
    1da4:	00a7e633          	or	a2,a5,a0
    1da8:	c205                	beqz	a2,1dc8 <__subdf3+0x3b6>
    1daa:	fff38613          	addi	a2,t2,-1 # 7ffff <__ctor_end__+0x7943f>
    1dae:	ea19                	bnez	a2,1dc4 <__subdf3+0x3b2>
    1db0:	40a70533          	sub	a0,a4,a0
    1db4:	40f30333          	sub	t1,t1,a5
    1db8:	00a73633          	sltu	a2,a4,a0
    1dbc:	40c307b3          	sub	a5,t1,a2
    1dc0:	8436                	mv	s0,a3
    1dc2:	bf3d                	j	1d00 <__subdf3+0x2ee>
    1dc4:	00539d63          	bne	t2,t0,1dde <__subdf3+0x3cc>
    1dc8:	8436                	mv	s0,a3
    1dca:	879a                	mv	a5,t1
    1dcc:	853a                	mv	a0,a4
    1dce:	849e                	mv	s1,t2
    1dd0:	b9c9                	j	1aa2 <__subdf3+0x90>
    1dd2:	20558163          	beq	a1,t0,1fd4 <__subdf3+0x5c2>
    1dd6:	00800637          	lui	a2,0x800
    1dda:	8fd1                	or	a5,a5,a2
    1ddc:	861e                	mv	a2,t2
    1dde:	03800293          	li	t0,56
    1de2:	06c2c663          	blt	t0,a2,1e4e <__subdf3+0x43c>
    1de6:	42fd                	li	t0,31
    1de8:	02000413          	li	s0,32
    1dec:	02c2cc63          	blt	t0,a2,1e24 <__subdf3+0x412>
    1df0:	8c11                	sub	s0,s0,a2
    1df2:	00c553b3          	srl	t2,a0,a2
    1df6:	008792b3          	sll	t0,a5,s0
    1dfa:	00851433          	sll	s0,a0,s0
    1dfe:	0072e2b3          	or	t0,t0,t2
    1e02:	00803433          	snez	s0,s0
    1e06:	0082e533          	or	a0,t0,s0
    1e0a:	00c7d633          	srl	a2,a5,a2
    1e0e:	40a70533          	sub	a0,a4,a0
    1e12:	40c30633          	sub	a2,t1,a2
    1e16:	00a737b3          	sltu	a5,a4,a0
    1e1a:	40f607b3          	sub	a5,a2,a5
    1e1e:	84ae                	mv	s1,a1
    1e20:	8436                	mv	s0,a3
    1e22:	b725                	j	1d4a <__subdf3+0x338>
    1e24:	fe060293          	addi	t0,a2,-32 # 7fffe0 <__ctor_end__+0x7f9420>
    1e28:	0057d2b3          	srl	t0,a5,t0
    1e2c:	4381                	li	t2,0
    1e2e:	00860863          	beq	a2,s0,1e3e <__subdf3+0x42c>
    1e32:	04000393          	li	t2,64
    1e36:	40c383b3          	sub	t2,t2,a2
    1e3a:	007793b3          	sll	t2,a5,t2
    1e3e:	00a3e3b3          	or	t2,t2,a0
    1e42:	007033b3          	snez	t2,t2
    1e46:	0072e533          	or	a0,t0,t2
    1e4a:	4601                	li	a2,0
    1e4c:	b7c9                	j	1e0e <__subdf3+0x3fc>
    1e4e:	8d5d                	or	a0,a0,a5
    1e50:	00a03533          	snez	a0,a0
    1e54:	bfdd                	j	1e4a <__subdf3+0x438>
    1e56:	00148613          	addi	a2,s1,1
    1e5a:	7fe67613          	andi	a2,a2,2046
    1e5e:	ee2d                	bnez	a2,1ed8 <__subdf3+0x4c6>
    1e60:	00e36633          	or	a2,t1,a4
    1e64:	00a7e5b3          	or	a1,a5,a0
    1e68:	e8b9                	bnez	s1,1ebe <__subdf3+0x4ac>
    1e6a:	e999                	bnez	a1,1e80 <__subdf3+0x46e>
    1e6c:	16060963          	beqz	a2,1fde <__subdf3+0x5cc>
    1e70:	8436                	mv	s0,a3
    1e72:	00676533          	or	a0,a4,t1
    1e76:	c96d                	beqz	a0,1f68 <__subdf3+0x556>
    1e78:	879a                	mv	a5,t1
    1e7a:	853a                	mv	a0,a4
    1e7c:	4481                	li	s1,0
    1e7e:	b515                	j	1ca2 <__subdf3+0x290>
    1e80:	14060063          	beqz	a2,1fc0 <__subdf3+0x5ae>
    1e84:	40e505b3          	sub	a1,a0,a4
    1e88:	00b532b3          	sltu	t0,a0,a1
    1e8c:	40678633          	sub	a2,a5,t1
    1e90:	40560633          	sub	a2,a2,t0
    1e94:	00861293          	slli	t0,a2,0x8
    1e98:	0002dc63          	bgez	t0,1eb0 <__subdf3+0x49e>
    1e9c:	40a70533          	sub	a0,a4,a0
    1ea0:	00a73633          	sltu	a2,a4,a0
    1ea4:	40f30333          	sub	t1,t1,a5
    1ea8:	872a                	mv	a4,a0
    1eaa:	40c30333          	sub	t1,t1,a2
    1eae:	b7c9                	j	1e70 <__subdf3+0x45e>
    1eb0:	00c5e533          	or	a0,a1,a2
    1eb4:	12050763          	beqz	a0,1fe2 <__subdf3+0x5d0>
    1eb8:	8332                	mv	t1,a2
    1eba:	872e                	mv	a4,a1
    1ebc:	bf5d                	j	1e72 <__subdf3+0x460>
    1ebe:	e989                	bnez	a1,1ed0 <__subdf3+0x4be>
    1ec0:	8436                	mv	s0,a3
    1ec2:	10061263          	bnez	a2,1fc6 <__subdf3+0x5b4>
    1ec6:	4401                	li	s0,0
    1ec8:	004007b7          	lui	a5,0x400
    1ecc:	4501                	li	a0,0
    1ece:	a8f5                	j	1fca <__subdf3+0x5b8>
    1ed0:	8496                	mv	s1,t0
    1ed2:	bc0608e3          	beqz	a2,1aa2 <__subdf3+0x90>
    1ed6:	b35d                	j	1c7c <__subdf3+0x26a>
    1ed8:	40e502b3          	sub	t0,a0,a4
    1edc:	005533b3          	sltu	t2,a0,t0
    1ee0:	406785b3          	sub	a1,a5,t1
    1ee4:	407585b3          	sub	a1,a1,t2
    1ee8:	00859393          	slli	t2,a1,0x8
    1eec:	8616                	mv	a2,t0
    1eee:	0603d963          	bgez	t2,1f60 <__subdf3+0x54e>
    1ef2:	40a70533          	sub	a0,a4,a0
    1ef6:	40f30333          	sub	t1,t1,a5
    1efa:	00a73733          	sltu	a4,a4,a0
    1efe:	862a                	mv	a2,a0
    1f00:	40e305b3          	sub	a1,t1,a4
    1f04:	8436                	mv	s0,a3
    1f06:	c5a5                	beqz	a1,1f6e <__subdf3+0x55c>
    1f08:	852e                	mv	a0,a1
    1f0a:	c232                	sw	a2,4(sp)
    1f0c:	c02e                	sw	a1,0(sp)
    1f0e:	2255                	jal	20b2 <__clzsi2>
    1f10:	4582                	lw	a1,0(sp)
    1f12:	4612                	lw	a2,4(sp)
    1f14:	ff850713          	addi	a4,a0,-8 # fff8 <__ctor_end__+0x9438>
    1f18:	02000313          	li	t1,32
    1f1c:	40e30333          	sub	t1,t1,a4
    1f20:	00e595b3          	sll	a1,a1,a4
    1f24:	00665333          	srl	t1,a2,t1
    1f28:	00b36333          	or	t1,t1,a1
    1f2c:	00e615b3          	sll	a1,a2,a4
    1f30:	08974063          	blt	a4,s1,1fb0 <__subdf3+0x59e>
    1f34:	8f05                	sub	a4,a4,s1
    1f36:	00170613          	addi	a2,a4,1
    1f3a:	47fd                	li	a5,31
    1f3c:	02000693          	li	a3,32
    1f40:	04c7c763          	blt	a5,a2,1f8e <__subdf3+0x57c>
    1f44:	8e91                	sub	a3,a3,a2
    1f46:	00d31733          	sll	a4,t1,a3
    1f4a:	00c5d7b3          	srl	a5,a1,a2
    1f4e:	00d596b3          	sll	a3,a1,a3
    1f52:	8f5d                	or	a4,a4,a5
    1f54:	00d036b3          	snez	a3,a3
    1f58:	8f55                	or	a4,a4,a3
    1f5a:	00c35333          	srl	t1,t1,a2
    1f5e:	bf11                	j	1e72 <__subdf3+0x460>
    1f60:	00b2e533          	or	a0,t0,a1
    1f64:	f14d                	bnez	a0,1f06 <__subdf3+0x4f4>
    1f66:	4401                	li	s0,0
    1f68:	4781                	li	a5,0
    1f6a:	4481                	li	s1,0
    1f6c:	be1d                	j	1aa2 <__subdf3+0x90>
    1f6e:	8532                	mv	a0,a2
    1f70:	c22e                	sw	a1,4(sp)
    1f72:	c032                	sw	a2,0(sp)
    1f74:	2a3d                	jal	20b2 <__clzsi2>
    1f76:	01850713          	addi	a4,a0,24
    1f7a:	47fd                	li	a5,31
    1f7c:	4602                	lw	a2,0(sp)
    1f7e:	4592                	lw	a1,4(sp)
    1f80:	f8e7dce3          	bge	a5,a4,1f18 <__subdf3+0x506>
    1f84:	ff850313          	addi	t1,a0,-8
    1f88:	00661333          	sll	t1,a2,t1
    1f8c:	b755                	j	1f30 <__subdf3+0x51e>
    1f8e:	1705                	addi	a4,a4,-31
    1f90:	00e35733          	srl	a4,t1,a4
    1f94:	4781                	li	a5,0
    1f96:	00d60763          	beq	a2,a3,1fa4 <__subdf3+0x592>
    1f9a:	04000793          	li	a5,64
    1f9e:	8f91                	sub	a5,a5,a2
    1fa0:	00f317b3          	sll	a5,t1,a5
    1fa4:	8fcd                	or	a5,a5,a1
    1fa6:	00f037b3          	snez	a5,a5
    1faa:	8f5d                	or	a4,a4,a5
    1fac:	4301                	li	t1,0
    1fae:	b5d1                	j	1e72 <__subdf3+0x460>
    1fb0:	ff800637          	lui	a2,0xff800
    1fb4:	167d                	addi	a2,a2,-1 # ff7fffff <__heap_end+0xdf7cffff>
    1fb6:	8c99                	sub	s1,s1,a4
    1fb8:	00c377b3          	and	a5,t1,a2
    1fbc:	852e                	mv	a0,a1
    1fbe:	b1d5                	j	1ca2 <__subdf3+0x290>
    1fc0:	833e                	mv	t1,a5
    1fc2:	872a                	mv	a4,a0
    1fc4:	b57d                	j	1e72 <__subdf3+0x460>
    1fc6:	879a                	mv	a5,t1
    1fc8:	853a                	mv	a0,a4
    1fca:	8496                	mv	s1,t0
    1fcc:	bcd9                	j	1aa2 <__subdf3+0x90>
    1fce:	84b6                	mv	s1,a3
    1fd0:	4781                	li	a5,0
    1fd2:	b945                	j	1c82 <__subdf3+0x270>
    1fd4:	8436                	mv	s0,a3
    1fd6:	879a                	mv	a5,t1
    1fd8:	853a                	mv	a0,a4
    1fda:	84ae                	mv	s1,a1
    1fdc:	b4d9                	j	1aa2 <__subdf3+0x90>
    1fde:	4401                	li	s0,0
    1fe0:	bfc5                	j	1fd0 <__subdf3+0x5be>
    1fe2:	4401                	li	s0,0
    1fe4:	4781                	li	a5,0
    1fe6:	bc75                	j	1aa2 <__subdf3+0x90>

00001fe8 <__fixdfsi>:
    1fe8:	0145d713          	srli	a4,a1,0x14
    1fec:	00100637          	lui	a2,0x100
    1ff0:	86aa                	mv	a3,a0
    1ff2:	fff60793          	addi	a5,a2,-1 # fffff <__ctor_end__+0xf943f>
    1ff6:	7ff77713          	andi	a4,a4,2047
    1ffa:	3fe00513          	li	a0,1022
    1ffe:	8fed                	and	a5,a5,a1
    2000:	81fd                	srli	a1,a1,0x1f
    2002:	04e55463          	bge	a0,a4,204a <__fixdfsi+0x62>
    2006:	41d00513          	li	a0,1053
    200a:	00e55763          	bge	a0,a4,2018 <__fixdfsi+0x30>
    200e:	80000537          	lui	a0,0x80000
    2012:	157d                	addi	a0,a0,-1 # 7fffffff <__heap_end+0x5ffcffff>
    2014:	952e                	add	a0,a0,a1
    2016:	8082                	ret
    2018:	8fd1                	or	a5,a5,a2
    201a:	43300613          	li	a2,1075
    201e:	8e19                	sub	a2,a2,a4
    2020:	457d                	li	a0,31
    2022:	00c54d63          	blt	a0,a2,203c <__fixdfsi+0x54>
    2026:	bed70713          	addi	a4,a4,-1043
    202a:	00e79533          	sll	a0,a5,a4
    202e:	00c6d6b3          	srl	a3,a3,a2
    2032:	8d55                	or	a0,a0,a3
    2034:	cd81                	beqz	a1,204c <__fixdfsi+0x64>
    2036:	40a00533          	neg	a0,a0
    203a:	8082                	ret
    203c:	41300693          	li	a3,1043
    2040:	40e68733          	sub	a4,a3,a4
    2044:	00e7d533          	srl	a0,a5,a4
    2048:	b7f5                	j	2034 <__fixdfsi+0x4c>
    204a:	4501                	li	a0,0
    204c:	8082                	ret

0000204e <__floatsidf>:
    204e:	1151                	addi	sp,sp,-12
    2050:	c406                	sw	ra,8(sp)
    2052:	c222                	sw	s0,4(sp)
    2054:	c026                	sw	s1,0(sp)
    2056:	87aa                	mv	a5,a0
    2058:	c931                	beqz	a0,20ac <__floatsidf+0x5e>
    205a:	41f55713          	srai	a4,a0,0x1f
    205e:	00a744b3          	xor	s1,a4,a0
    2062:	8c99                	sub	s1,s1,a4
    2064:	01f55413          	srli	s0,a0,0x1f
    2068:	8526                	mv	a0,s1
    206a:	20a1                	jal	20b2 <__clzsi2>
    206c:	41e00793          	li	a5,1054
    2070:	4729                	li	a4,10
    2072:	8f89                	sub	a5,a5,a0
    2074:	02a74763          	blt	a4,a0,20a2 <__floatsidf+0x54>
    2078:	472d                	li	a4,11
    207a:	8f09                	sub	a4,a4,a0
    207c:	0555                	addi	a0,a0,21
    207e:	00e4d733          	srl	a4,s1,a4
    2082:	00a494b3          	sll	s1,s1,a0
    2086:	0732                	slli	a4,a4,0xc
    2088:	8331                	srli	a4,a4,0xc
    208a:	07d2                	slli	a5,a5,0x14
    208c:	047e                	slli	s0,s0,0x1f
    208e:	8fd9                	or	a5,a5,a4
    2090:	40a2                	lw	ra,8(sp)
    2092:	0087e733          	or	a4,a5,s0
    2096:	4412                	lw	s0,4(sp)
    2098:	8526                	mv	a0,s1
    209a:	85ba                	mv	a1,a4
    209c:	4482                	lw	s1,0(sp)
    209e:	0131                	addi	sp,sp,12
    20a0:	8082                	ret
    20a2:	1555                	addi	a0,a0,-11
    20a4:	00a49733          	sll	a4,s1,a0
    20a8:	4481                	li	s1,0
    20aa:	bff1                	j	2086 <__floatsidf+0x38>
    20ac:	4401                	li	s0,0
    20ae:	4701                	li	a4,0
    20b0:	bfe5                	j	20a8 <__floatsidf+0x5a>

000020b2 <__clzsi2>:
    20b2:	67c1                	lui	a5,0x10
    20b4:	02f57663          	bgeu	a0,a5,20e0 <__clzsi2+0x2e>
    20b8:	10053793          	sltiu	a5,a0,256
    20bc:	0017b793          	seqz	a5,a5
    20c0:	078e                	slli	a5,a5,0x3
    20c2:	02000713          	li	a4,32
    20c6:	8f1d                	sub	a4,a4,a5
    20c8:	00f55533          	srl	a0,a0,a5
    20cc:	00004797          	auipc	a5,0x4
    20d0:	da078793          	addi	a5,a5,-608 # 5e6c <__clz_tab>
    20d4:	97aa                	add	a5,a5,a0
    20d6:	0007c503          	lbu	a0,0(a5)
    20da:	40a70533          	sub	a0,a4,a0
    20de:	8082                	ret
    20e0:	01000737          	lui	a4,0x1000
    20e4:	47e1                	li	a5,24
    20e6:	fce57ee3          	bgeu	a0,a4,20c2 <__clzsi2+0x10>
    20ea:	47c1                	li	a5,16
    20ec:	bfd9                	j	20c2 <__clzsi2+0x10>
	...

000020f0 <memset>:
    20f0:	433d                	li	t1,15
    20f2:	872a                	mv	a4,a0
    20f4:	02c37363          	bgeu	t1,a2,211a <memset+0x2a>
    20f8:	00f77793          	andi	a5,a4,15
    20fc:	efbd                	bnez	a5,217a <memset+0x8a>
    20fe:	e5ad                	bnez	a1,2168 <memset+0x78>
    2100:	ff067693          	andi	a3,a2,-16
    2104:	8a3d                	andi	a2,a2,15
    2106:	96ba                	add	a3,a3,a4
    2108:	c30c                	sw	a1,0(a4)
    210a:	c34c                	sw	a1,4(a4)
    210c:	c70c                	sw	a1,8(a4)
    210e:	c74c                	sw	a1,12(a4)
    2110:	0741                	addi	a4,a4,16 # 1000010 <__ctor_end__+0xff9450>
    2112:	fed76be3          	bltu	a4,a3,2108 <memset+0x18>
    2116:	e211                	bnez	a2,211a <memset+0x2a>
    2118:	8082                	ret
    211a:	40c306b3          	sub	a3,t1,a2
    211e:	068a                	slli	a3,a3,0x2
    2120:	00000297          	auipc	t0,0x0
    2124:	9696                	add	a3,a3,t0
    2126:	00a68067          	jr	10(a3) # 80000a <__ctor_end__+0x7f944a>
    212a:	00b70723          	sb	a1,14(a4)
    212e:	00b706a3          	sb	a1,13(a4)
    2132:	00b70623          	sb	a1,12(a4)
    2136:	00b705a3          	sb	a1,11(a4)
    213a:	00b70523          	sb	a1,10(a4)
    213e:	00b704a3          	sb	a1,9(a4)
    2142:	00b70423          	sb	a1,8(a4)
    2146:	00b703a3          	sb	a1,7(a4)
    214a:	00b70323          	sb	a1,6(a4)
    214e:	00b702a3          	sb	a1,5(a4)
    2152:	00b70223          	sb	a1,4(a4)
    2156:	00b701a3          	sb	a1,3(a4)
    215a:	00b70123          	sb	a1,2(a4)
    215e:	00b700a3          	sb	a1,1(a4)
    2162:	00b70023          	sb	a1,0(a4)
    2166:	8082                	ret
    2168:	0ff5f593          	zext.b	a1,a1
    216c:	00859693          	slli	a3,a1,0x8
    2170:	8dd5                	or	a1,a1,a3
    2172:	01059693          	slli	a3,a1,0x10
    2176:	8dd5                	or	a1,a1,a3
    2178:	b761                	j	2100 <memset+0x10>
    217a:	00279693          	slli	a3,a5,0x2
    217e:	00000297          	auipc	t0,0x0
    2182:	9696                	add	a3,a3,t0
    2184:	8286                	mv	t0,ra
    2186:	fa8680e7          	jalr	-88(a3)
    218a:	8096                	mv	ra,t0
    218c:	17c1                	addi	a5,a5,-16
    218e:	8f1d                	sub	a4,a4,a5
    2190:	963e                	add	a2,a2,a5
    2192:	f8c374e3          	bgeu	t1,a2,211a <memset+0x2a>
    2196:	b7a5                	j	20fe <memset+0xe>
	...

0000219a <board_init>:

extern int clock_timer_init(void);
extern int clock_timer_start(void);

void board_init(void)
{
    219a:	1171                	addi	sp,sp,-4
    219c:	c006                	sw	ra,0(sp)
    int32_t ret = 0;
    /* init the console*/
    clock_timer_init();
    219e:	228010ef          	jal	33c6 <clock_timer_init>
    clock_timer_start();
    21a2:	2a4010ef          	jal	3446 <clock_timer_start>

    console_handle = csi_usart_initialize(CONSOLE_IDX, NULL);
    21a6:	4581                	li	a1,0
    21a8:	4501                	li	a0,0
    21aa:	1f9000ef          	jal	2ba2 <csi_usart_initialize>
    ret = csi_usart_config(console_handle, 115200, USART_MODE_ASYNCHRONOUS, USART_PARITY_NONE, USART_STOP_BITS_1, USART_DATA_BITS_8);

    if (ret < 0) {
        return;
    }
}
    21ae:	4082                	lw	ra,0(sp)
    console_handle = csi_usart_initialize(CONSOLE_IDX, NULL);
    21b0:	04a1a223          	sw	a0,68(gp) # 2000052c <console_handle>
    ret = csi_usart_config(console_handle, 115200, USART_MODE_ASYNCHRONOUS, USART_PARITY_NONE, USART_STOP_BITS_1, USART_DATA_BITS_8);
    21b4:	65f1                	lui	a1,0x1c
    21b6:	478d                	li	a5,3
    21b8:	4701                	li	a4,0
    21ba:	4681                	li	a3,0
    21bc:	4601                	li	a2,0
    21be:	20058593          	addi	a1,a1,512 # 1c200 <__ctor_end__+0x15640>
}
    21c2:	0111                	addi	sp,sp,4
    ret = csi_usart_config(console_handle, 115200, USART_MODE_ASYNCHRONOUS, USART_PARITY_NONE, USART_STOP_BITS_1, USART_DATA_BITS_8);
    21c4:	1e10006f          	j	2ba4 <csi_usart_config>

000021c8 <drv_irq_enable>:
  \details Enable a device-specific interrupt in the VIC interrupt controller.
  \param [in]      IRQn  External interrupt number. Value cannot be negative.
 */
__STATIC_INLINE void csi_vic_enable_irq(int32_t IRQn)
{
    CLIC->INTIE[IRQn] |= CLIC_INTIE_IE_Msk;
    21c8:	e000e7b7          	lui	a5,0xe000e
    21cc:	10078793          	addi	a5,a5,256 # e000e100 <__heap_end+0xbffde100>
    21d0:	953e                	add	a0,a0,a5
    21d2:	40054783          	lbu	a5,1024(a0)
    21d6:	0017e793          	ori	a5,a5,1
    21da:	40f50023          	sb	a5,1024(a0)
#ifdef CONFIG_SYSTEM_SECURE
    csi_vic_enable_sirq(irq_num);
#else
    csi_vic_enable_irq(irq_num);
#endif
}
    21de:	8082                	ret

000021e0 <drv_irq_register>:
  \param[in]   irq_handler IRQ Handler.
  \return      None.
*/
void drv_irq_register(uint32_t irq_num, void *irq_handler)
{
    g_irqvector[irq_num] = irq_handler;
    21e0:	200027b7          	lui	a5,0x20002
    21e4:	050a                	slli	a0,a0,0x2
    21e6:	b8078793          	addi	a5,a5,-1152 # 20001b80 <g_irqvector>
    21ea:	97aa                	add	a5,a5,a0
    21ec:	c38c                	sw	a1,0(a5)
}
    21ee:	8082                	ret

000021f0 <wj_usi_set_rxfifo_th>:

static wj_usi_priv_t usi_instance[CONFIG_USI_NUM];

void wj_usi_set_rxfifo_th(wj_usi_reg_t *addr, uint32_t length)
{
    addr->USI_INTR_CTRL &= ~USI_INTR_CTRL_TH_MODE;
    21f0:	457c                	lw	a5,76(a0)
    21f2:	7741                	lui	a4,0xffff0
    21f4:	177d                	addi	a4,a4,-1 # fffeffff <__heap_end+0xdffbffff>
    21f6:	8ff9                	and	a5,a5,a4
    21f8:	c57c                	sw	a5,76(a0)
    addr->USI_INTR_CTRL &= USI_INTR_CTRL_RXFIFO_TH;
    21fa:	457c                	lw	a5,76(a0)
    21fc:	cff7f793          	andi	a5,a5,-769
    2200:	c57c                	sw	a5,76(a0)

    if (length >= USI_RX_MAX_FIFO) {
    2202:	47bd                	li	a5,15
    2204:	00b7f963          	bgeu	a5,a1,2216 <wj_usi_set_rxfifo_th+0x26>
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_12 | USI_INTR_CTRL_TH_MODE;
    2208:	457c                	lw	a5,76(a0)
    220a:	6741                	lui	a4,0x10
    220c:	30070713          	addi	a4,a4,768 # 10300 <__ctor_end__+0x9740>
    } else if (length >= USI_RX_MAX_FIFO - 4) {
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_8 | USI_INTR_CTRL_TH_MODE;
    } else if (length >= 4) {
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_4 | USI_INTR_CTRL_TH_MODE;
    2210:	8fd9                	or	a5,a5,a4
    } else {
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_4;
    2212:	c57c                	sw	a5,76(a0)
    }
}
    2214:	8082                	ret
    } else if (length >= USI_RX_MAX_FIFO - 4) {
    2216:	47ad                	li	a5,11
    2218:	00b7f763          	bgeu	a5,a1,2226 <wj_usi_set_rxfifo_th+0x36>
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_8 | USI_INTR_CTRL_TH_MODE;
    221c:	6741                	lui	a4,0x10
    221e:	457c                	lw	a5,76(a0)
    2220:	20070713          	addi	a4,a4,512 # 10200 <__ctor_end__+0x9640>
    2224:	b7f5                	j	2210 <wj_usi_set_rxfifo_th+0x20>
    } else if (length >= 4) {
    2226:	478d                	li	a5,3
    2228:	00b7f763          	bgeu	a5,a1,2236 <wj_usi_set_rxfifo_th+0x46>
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_4 | USI_INTR_CTRL_TH_MODE;
    222c:	6741                	lui	a4,0x10
    222e:	457c                	lw	a5,76(a0)
    2230:	10070713          	addi	a4,a4,256 # 10100 <__ctor_end__+0x9540>
    2234:	bff1                	j	2210 <wj_usi_set_rxfifo_th+0x20>
        addr->USI_INTR_CTRL |= USI_INTR_CTRL_RXFIFO_TH_4;
    2236:	457c                	lw	a5,76(a0)
    2238:	1007e793          	ori	a5,a5,256
    223c:	bfd9                	j	2212 <wj_usi_set_rxfifo_th+0x22>

0000223e <wj_usi_irqhandler>:
//            CSI_DRIVER
//------------------------------------------
void wj_usi_irqhandler(int32_t idx)
{
    wj_usi_priv_t *usi_priv = &usi_instance[idx];
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usi_priv->base);
    223e:	200017b7          	lui	a5,0x20001
    2242:	00351713          	slli	a4,a0,0x3
    2246:	7b078793          	addi	a5,a5,1968 # 200017b0 <usi_instance>
    224a:	97ba                	add	a5,a5,a4
    224c:	439c                	lw	a5,0(a5)

    switch (addr->USI_MODE_SEL & 0x3) {
    224e:	4705                	li	a4,1
    2250:	43dc                	lw	a5,4(a5)
    2252:	8b8d                	andi	a5,a5,3
    2254:	00e78763          	beq	a5,a4,2262 <wj_usi_irqhandler+0x24>
    2258:	4709                	li	a4,2
    225a:	00e78563          	beq	a5,a4,2264 <wj_usi_irqhandler+0x26>
    225e:	e781                	bnez	a5,2266 <wj_usi_irqhandler+0x28>
        case USI_MODE_UART:
#ifndef  CONFIG_CHIP_PANGU
            wj_usi_usart_irqhandler(idx);
    2260:	a701                	j	2960 <wj_usi_usart_irqhandler>
#endif
            break;

        case USI_MODE_I2C:
            wj_usi_i2c_irqhandler(idx);
    2262:	a0a1                	j	22aa <wj_usi_i2c_irqhandler>
            break;

        case USI_MODE_SPI:
            wj_usi_spi_irqhandler(idx);
    2264:	acd5                	j	2558 <wj_usi_spi_irqhandler>
            break;

        default:
            return;
    }
}
    2266:	8082                	ret

00002268 <drv_usi_initialize>:

int32_t drv_usi_initialize(int32_t idx)
{
    2268:	1141                	addi	sp,sp,-16
    uint32_t base = 0u;
    uint32_t irq = 0u;

    int32_t ret = target_usi_init(idx, &base, &irq);
    226a:	0050                	addi	a2,sp,4
    226c:	858a                	mv	a1,sp
{
    226e:	c422                	sw	s0,8(sp)
    2270:	c606                	sw	ra,12(sp)
    2272:	842a                	mv	s0,a0
    uint32_t base = 0u;
    2274:	c002                	sw	zero,0(sp)
    uint32_t irq = 0u;
    2276:	c202                	sw	zero,4(sp)
    int32_t ret = target_usi_init(idx, &base, &irq);
    2278:	177000ef          	jal	2bee <target_usi_init>

    if (ret < 0 || ret >= CONFIG_USI_NUM) {
    227c:	4789                	li	a5,2
    227e:	02a7e163          	bltu	a5,a0,22a0 <drv_usi_initialize+0x38>
        return ERR_USI(DRV_ERROR_PARAMETER);
    }

    wj_usi_priv_t *usi_priv = &usi_instance[idx];
    usi_priv->base = base;
    2282:	4702                	lw	a4,0(sp)
    2284:	200017b7          	lui	a5,0x20001
    2288:	040e                	slli	s0,s0,0x3
    228a:	7b078793          	addi	a5,a5,1968 # 200017b0 <usi_instance>
    228e:	97a2                	add	a5,a5,s0
    2290:	c398                	sw	a4,0(a5)
    usi_priv->irq  = irq;
    2292:	4712                	lw	a4,4(sp)

    return 0;
    2294:	4501                	li	a0,0
    usi_priv->irq  = irq;
    2296:	c3d8                	sw	a4,4(a5)
}
    2298:	40b2                	lw	ra,12(sp)
    229a:	4422                	lw	s0,8(sp)
    229c:	0141                	addi	sp,sp,16
    229e:	8082                	ret
        return ERR_USI(DRV_ERROR_PARAMETER);
    22a0:	81180537          	lui	a0,0x81180
    22a4:	08450513          	addi	a0,a0,132 # 81180084 <__heap_end+0x61150084>
    22a8:	bfc5                	j	2298 <drv_usi_initialize+0x30>

000022aa <wj_usi_i2c_irqhandler>:

}
void wj_usi_i2c_irqhandler(int32_t idx)
{
    wj_usi_iic_priv_t *iic_priv = &iic_instance[idx];
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(iic_priv->base);
    22aa:	03000713          	li	a4,48
    22ae:	02e50733          	mul	a4,a0,a4
    22b2:	200017b7          	lui	a5,0x20001
    22b6:	7c878793          	addi	a5,a5,1992 # 200017c8 <iic_instance>
{
    22ba:	1121                	addi	sp,sp,-24
    22bc:	c822                	sw	s0,16(sp)

    uint32_t intr_state = addr->USI_INTR_STA & 0x3ffff;

    if ((intr_state & USI_INT_I2CM_LOSE_ARBI) || (intr_state & USI_INT_I2C_NACK)) {
    22be:	6599                	lui	a1,0x6
{
    22c0:	c626                	sw	s1,12(sp)
    22c2:	ca06                	sw	ra,20(sp)
    22c4:	84aa                	mv	s1,a0
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(iic_priv->base);
    22c6:	973e                	add	a4,a4,a5
    22c8:	4300                	lw	s0,0(a4)
    uint32_t intr_state = addr->USI_INTR_STA & 0x3ffff;
    22ca:	4874                	lw	a3,84(s0)
    22cc:	00e69613          	slli	a2,a3,0xe
    if ((intr_state & USI_INT_I2CM_LOSE_ARBI) || (intr_state & USI_INT_I2C_NACK)) {
    22d0:	8df5                	and	a1,a1,a3
    uint32_t intr_state = addr->USI_INTR_STA & 0x3ffff;
    22d2:	8239                	srli	a2,a2,0xe
    if ((intr_state & USI_INT_I2CM_LOSE_ARBI) || (intr_state & USI_INT_I2C_NACK)) {
    22d4:	c195                	beqz	a1,22f8 <wj_usi_i2c_irqhandler+0x4e>
        /* If arbitration fault, it indicates either a slave device not
        * responding as expected, or other master which is not supported
        * by this SW.
        */
        iic_priv->status    = IIC_STATE_DONE;
    22d6:	4691                	li	a3,4
    22d8:	d714                	sw	a3,40(a4)
        addr->USI_EN = 0;
    22da:	00042023          	sw	zero,0(s0) # 80000 <__ctor_end__+0x79440>
        addr->USI_INTR_UNMASK = 0;
    22de:	04042e23          	sw	zero,92(s0)
        addr->USI_INTR_EN = 0;
        addr->USI_INTR_CLR = intr_state;

        if (iic_priv->cb_event) {
    22e2:	4718                	lw	a4,8(a4)
        addr->USI_INTR_EN = 0;
    22e4:	04042823          	sw	zero,80(s0)
        addr->USI_INTR_CLR = intr_state;
    22e8:	d030                	sw	a2,96(s0)
        if (iic_priv->cb_event) {
    22ea:	cf11                	beqz	a4,2306 <wj_usi_i2c_irqhandler+0x5c>
            if (iic_priv->cb_event) {
                iic_priv->cb_event(idx, IIC_EVENT_ARBITRATION_LOST);
            }
        }
    }
}
    22ec:	4442                	lw	s0,16(sp)
    22ee:	40d2                	lw	ra,20(sp)
    22f0:	44b2                	lw	s1,12(sp)
            iic_priv->cb_event(idx, IIC_EVENT_BUS_ERROR);
    22f2:	459d                	li	a1,7
}
    22f4:	0161                	addi	sp,sp,24
            iic_priv->cb_event(idx, IIC_EVENT_BUS_ERROR);
    22f6:	8702                	jr	a4
    switch (iic_priv->status) {
    22f8:	5708                	lw	a0,40(a4)
    22fa:	4305                	li	t1,1
    22fc:	02650563          	beq	a0,t1,2326 <wj_usi_i2c_irqhandler+0x7c>
    2300:	4589                	li	a1,2
    2302:	10b50463          	beq	a0,a1,240a <wj_usi_i2c_irqhandler+0x160>
            if (iic_priv->cb_event) {
    2306:	03000713          	li	a4,48
    230a:	02e48733          	mul	a4,s1,a4
            addr->USI_INTR_CLR = intr_state;
    230e:	d030                	sw	a2,96(s0)
            addr->USI_INTR_UNMASK = 0;
    2310:	04042e23          	sw	zero,92(s0)
            addr->USI_INTR_EN = 0;
    2314:	04042823          	sw	zero,80(s0)
            addr->USI_EN = 0;
    2318:	00042023          	sw	zero,0(s0)
            if (iic_priv->cb_event) {
    231c:	97ba                	add	a5,a5,a4
    231e:	479c                	lw	a5,8(a5)
    2320:	c7f9                	beqz	a5,23ee <wj_usi_i2c_irqhandler+0x144>
                iic_priv->cb_event(idx, IIC_EVENT_ARBITRATION_LOST);
    2322:	4599                	li	a1,6
    2324:	aad1                	j	24f8 <wj_usi_i2c_irqhandler+0x24e>
    if (intr_stat & USI_INT_TX_EMPTY) {
    2326:	0026f313          	andi	t1,a3,2
    232a:	04030063          	beqz	t1,236a <wj_usi_i2c_irqhandler+0xc0>
        uint32_t remain_txfifo = iic_priv->tx_total_num - iic_priv->tx_cnt;
    232e:	02472303          	lw	t1,36(a4)
    2332:	4b08                	lw	a0,16(a4)
        emptyfifo = (remain_txfifo > (USI_TX_MAX_FIFO - USI_FIFO_STA_TX_NUM(addr))) ? USI_TX_MAX_FIFO - USI_FIFO_STA_TX_NUM(addr) : remain_txfifo;
    2334:	4458                	lw	a4,12(s0)
        uint32_t remain_txfifo = iic_priv->tx_total_num - iic_priv->tx_cnt;
    2336:	40650533          	sub	a0,a0,t1
        emptyfifo = (remain_txfifo > (USI_TX_MAX_FIFO - USI_FIFO_STA_TX_NUM(addr))) ? USI_TX_MAX_FIFO - USI_FIFO_STA_TX_NUM(addr) : remain_txfifo;
    233a:	8321                	srli	a4,a4,0x8
    233c:	8b7d                	andi	a4,a4,31
    233e:	4341                	li	t1,16
    2340:	40e30733          	sub	a4,t1,a4
    2344:	0ff57293          	zext.b	t0,a0
    2348:	00a77963          	bgeu	a4,a0,235a <wj_usi_i2c_irqhandler+0xb0>
    234c:	4458                	lw	a4,12(s0)
    234e:	8321                	srli	a4,a4,0x8
    2350:	8b7d                	andi	a4,a4,31
    2352:	40e30333          	sub	t1,t1,a4
    2356:	0ff37293          	zext.b	t0,t1
            tx_data = (uint16_t)(*iic_priv->tx_buf);
    235a:	03000713          	li	a4,48
    235e:	02e48733          	mul	a4,s1,a4
    2362:	973e                	add	a4,a4,a5
        for (i = 0; i < emptyfifo; i++) {
    2364:	8316                	mv	t1,t0
    2366:	0855e963          	bltu	a1,t0,23f8 <wj_usi_i2c_irqhandler+0x14e>
    if (iic_priv->tx_cnt == iic_priv->tx_total_num) {
    236a:	03000713          	li	a4,48
    236e:	02e48733          	mul	a4,s1,a4
    2372:	973e                	add	a4,a4,a5
    2374:	534c                	lw	a1,36(a4)
    2376:	4b18                	lw	a4,16(a4)
    2378:	00e59963          	bne	a1,a4,238a <wj_usi_i2c_irqhandler+0xe0>
        addr->USI_I2CM_CTRL |= (1 << 1);
    237c:	5418                	lw	a4,40(s0)
    237e:	00276713          	ori	a4,a4,2
    2382:	d418                	sw	a4,40(s0)
        addr->USI_INTR_EN &= ~USI_INT_TX_EMPTY;
    2384:	4838                	lw	a4,80(s0)
    2386:	9b75                	andi	a4,a4,-3
    2388:	c838                	sw	a4,80(s0)
    if (intr_stat & USI_INT_I2C_STOP) {
    238a:	01369713          	slli	a4,a3,0x13
    238e:	02075a63          	bgez	a4,23c2 <wj_usi_i2c_irqhandler+0x118>
        iic_priv->status  = IIC_STATE_SEND_DONE;
    2392:	03000713          	li	a4,48
    2396:	02e48733          	mul	a4,s1,a4
    239a:	4595                	li	a1,5
    239c:	973e                	add	a4,a4,a5
    239e:	d70c                	sw	a1,40(a4)
        if (iic_priv->cb_event) {
    23a0:	4718                	lw	a4,8(a4)
        addr->USI_EN = 0;
    23a2:	00042023          	sw	zero,0(s0)
        if (iic_priv->cb_event) {
    23a6:	cf11                	beqz	a4,23c2 <wj_usi_i2c_irqhandler+0x118>
            iic_priv->cb_event(idx, IIC_EVENT_TRANSFER_DONE);
    23a8:	4581                	li	a1,0
    23aa:	8526                	mv	a0,s1
    23ac:	c432                	sw	a2,8(sp)
    23ae:	c21a                	sw	t1,4(sp)
    23b0:	c036                	sw	a3,0(sp)
    23b2:	9702                	jalr	a4
    23b4:	4682                	lw	a3,0(sp)
    23b6:	4312                	lw	t1,4(sp)
    23b8:	4622                	lw	a2,8(sp)
    23ba:	200017b7          	lui	a5,0x20001
    23be:	7c878793          	addi	a5,a5,1992 # 200017c8 <iic_instance>
    iic_priv->tx_cnt += emptyfifo;
    23c2:	03000713          	li	a4,48
    23c6:	02e48733          	mul	a4,s1,a4
    if (intr_stat & USI_INT_TX_WERR) {
    23ca:	8ac1                	andi	a3,a3,16
    iic_priv->tx_cnt += emptyfifo;
    23cc:	97ba                	add	a5,a5,a4
    23ce:	53d8                	lw	a4,36(a5)
    23d0:	933a                	add	t1,t1,a4
    23d2:	0267a223          	sw	t1,36(a5)
    if (intr_stat & USI_INT_TX_WERR) {
    23d6:	ca99                	beqz	a3,23ec <wj_usi_i2c_irqhandler+0x142>
        iic_priv->status = IIC_STATE_ERROR;
    23d8:	459d                	li	a1,7
    23da:	d78c                	sw	a1,40(a5)
        if (iic_priv->cb_event) {
    23dc:	479c                	lw	a5,8(a5)
        addr->USI_EN = 0;
    23de:	00042023          	sw	zero,0(s0)
        if (iic_priv->cb_event) {
    23e2:	c789                	beqz	a5,23ec <wj_usi_i2c_irqhandler+0x142>
            iic_priv->cb_event(idx, IIC_EVENT_BUS_ERROR);
    23e4:	8526                	mv	a0,s1
    23e6:	c032                	sw	a2,0(sp)
    23e8:	9782                	jalr	a5
    23ea:	4602                	lw	a2,0(sp)
            addr->USI_INTR_CLR = intr_state;
    23ec:	d030                	sw	a2,96(s0)
}
    23ee:	40d2                	lw	ra,20(sp)
    23f0:	4442                	lw	s0,16(sp)
    23f2:	44b2                	lw	s1,12(sp)
    23f4:	0161                	addi	sp,sp,24
    23f6:	8082                	ret
            tx_data = (uint16_t)(*iic_priv->tx_buf);
    23f8:	4f08                	lw	a0,24(a4)
        for (i = 0; i < emptyfifo; i++) {
    23fa:	0585                	addi	a1,a1,1 # 6001 <sg_timer_config+0x71>
            addr->USI_TX_RX_FIFO = tx_data;
    23fc:	00054303          	lbu	t1,0(a0)
            iic_priv->tx_buf++;
    2400:	0505                	addi	a0,a0,1
            addr->USI_TX_RX_FIFO = tx_data;
    2402:	00642423          	sw	t1,8(s0)
            iic_priv->tx_buf++;
    2406:	cf08                	sw	a0,24(a4)
        for (i = 0; i < emptyfifo; i++) {
    2408:	bfb1                	j	2364 <wj_usi_i2c_irqhandler+0xba>
    if (intr_stat & USI_INT_RX_THOLD) {
    240a:	0206f613          	andi	a2,a3,32
    240e:	ca3d                	beqz	a2,2484 <wj_usi_i2c_irqhandler+0x1da>
        addr->USI_INTR_CLR = USI_INT_RX_THOLD;
    2410:	02000613          	li	a2,32
    2414:	d030                	sw	a2,96(s0)
        uint32_t rx_num = USI_FIFO_STA_RX_NUM(addr);
    2416:	4450                	lw	a2,12(s0)
        for (i = 0; i < rx_num; i++) {
    2418:	4501                	li	a0,0
        uint32_t rx_num = USI_FIFO_STA_RX_NUM(addr);
    241a:	8241                	srli	a2,a2,0x10
    241c:	01f67593          	andi	a1,a2,31
        for (i = 0; i < rx_num; i++) {
    2420:	0eb51263          	bne	a0,a1,2504 <wj_usi_i2c_irqhandler+0x25a>
        uint8_t rxfifo = iic_priv->rx_clk > (USI_RX_MAX_FIFO - tx_num) ? (USI_RX_MAX_FIFO - tx_num) : 1;
    2424:	03000613          	li	a2,48
    2428:	02c48633          	mul	a2,s1,a2
        uint32_t tx_num = USI_FIFO_STA_TX_NUM(addr);
    242c:	4458                	lw	a4,12(s0)
        uint8_t rxfifo = iic_priv->rx_clk > (USI_RX_MAX_FIFO - tx_num) ? (USI_RX_MAX_FIFO - tx_num) : 1;
    242e:	4505                	li	a0,1
        uint32_t tx_num = USI_FIFO_STA_TX_NUM(addr);
    2430:	8321                	srli	a4,a4,0x8
    2432:	8b7d                	andi	a4,a4,31
        uint8_t rxfifo = iic_priv->rx_clk > (USI_RX_MAX_FIFO - tx_num) ? (USI_RX_MAX_FIFO - tx_num) : 1;
    2434:	963e                	add	a2,a2,a5
    2436:	520c                	lw	a1,32(a2)
    2438:	4641                	li	a2,16
    243a:	40e60733          	sub	a4,a2,a4
    243e:	00b77463          	bgeu	a4,a1,2446 <wj_usi_i2c_irqhandler+0x19c>
    2442:	0ff77513          	zext.b	a0,a4
        if (iic_priv->rx_clk == 0) {
    2446:	03000713          	li	a4,48
    244a:	02e48733          	mul	a4,s1,a4
        for (i = 0; i < rxfifo; i++) {
    244e:	4581                	li	a1,0
            addr->USI_TX_RX_FIFO = 0x100;
    2450:	10000313          	li	t1,256
        if (iic_priv->rx_clk == 0) {
    2454:	973e                	add	a4,a4,a5
    2456:	5310                	lw	a2,32(a4)
            rxfifo = 0;
    2458:	00c03633          	snez	a2,a2
    245c:	40c00633          	neg	a2,a2
    2460:	8d71                	and	a0,a0,a2
        for (i = 0; i < rxfifo; i++) {
    2462:	0ca59063          	bne	a1,a0,2522 <wj_usi_i2c_irqhandler+0x278>
        wj_usi_set_rxfifo_th(addr, rxfifo);
    2466:	8522                	mv	a0,s0
    2468:	c236                	sw	a3,4(sp)
    246a:	c02e                	sw	a1,0(sp)
    246c:	3351                	jal	21f0 <wj_usi_set_rxfifo_th>
        if (rxfifo == 0) {
    246e:	4582                	lw	a1,0(sp)
    2470:	200017b7          	lui	a5,0x20001
    2474:	4692                	lw	a3,4(sp)
    2476:	7c878793          	addi	a5,a5,1992 # 200017c8 <iic_instance>
    247a:	e589                	bnez	a1,2484 <wj_usi_i2c_irqhandler+0x1da>
            addr->USI_INTR_EN |= USI_INT_I2C_STOP;
    247c:	4838                	lw	a4,80(s0)
    247e:	6605                	lui	a2,0x1
    2480:	8f51                	or	a4,a4,a2
    2482:	c838                	sw	a4,80(s0)
    if (iic_priv->rx_cnt == iic_priv->rx_total_num) {
    2484:	03000713          	li	a4,48
    2488:	02e48733          	mul	a4,s1,a4
    248c:	973e                	add	a4,a4,a5
    248e:	4f50                	lw	a2,28(a4)
    2490:	4758                	lw	a4,12(a4)
    2492:	00e61a63          	bne	a2,a4,24a6 <wj_usi_i2c_irqhandler+0x1fc>
        addr->USI_I2CM_CTRL |= (1 << 1);
    2496:	5418                	lw	a4,40(s0)
    2498:	00276713          	ori	a4,a4,2
    249c:	d418                	sw	a4,40(s0)
        addr->USI_INTR_EN &= ~USI_INT_RX_THOLD;
    249e:	4838                	lw	a4,80(s0)
    24a0:	fdf77713          	andi	a4,a4,-33
    24a4:	c838                	sw	a4,80(s0)
    if ((intr_stat & USI_INT_RX_WERR) || (intr_stat & USI_INT_RX_RERR)) {
    24a6:	3006f713          	andi	a4,a3,768
    24aa:	c705                	beqz	a4,24d2 <wj_usi_i2c_irqhandler+0x228>
        iic_priv->status = IIC_STATE_ERROR;
    24ac:	03000713          	li	a4,48
    24b0:	02e48733          	mul	a4,s1,a4
    24b4:	459d                	li	a1,7
    24b6:	973e                	add	a4,a4,a5
    24b8:	d70c                	sw	a1,40(a4)
        if (iic_priv->cb_event) {
    24ba:	4718                	lw	a4,8(a4)
        addr->USI_EN = 0;
    24bc:	00042023          	sw	zero,0(s0)
        if (iic_priv->cb_event) {
    24c0:	cb09                	beqz	a4,24d2 <wj_usi_i2c_irqhandler+0x228>
            iic_priv->cb_event(idx, IIC_EVENT_BUS_ERROR);
    24c2:	8526                	mv	a0,s1
    24c4:	c036                	sw	a3,0(sp)
    24c6:	9702                	jalr	a4
    24c8:	4682                	lw	a3,0(sp)
    24ca:	200017b7          	lui	a5,0x20001
    24ce:	7c878793          	addi	a5,a5,1992 # 200017c8 <iic_instance>
    if (intr_stat & USI_INT_I2C_STOP) {
    24d2:	01369713          	slli	a4,a3,0x13
    24d6:	f0075ce3          	bgez	a4,23ee <wj_usi_i2c_irqhandler+0x144>
        addr->USI_INTR_CLR = USI_INT_I2C_STOP;
    24da:	6705                	lui	a4,0x1
    24dc:	d038                	sw	a4,96(s0)
        iic_priv->status  = IIC_STATE_RECV_DONE;
    24de:	03000713          	li	a4,48
    24e2:	02e48733          	mul	a4,s1,a4
            iic_priv->cb_event(idx, IIC_EVENT_TRANSFER_DONE);
    24e6:	4581                	li	a1,0
        iic_priv->status  = IIC_STATE_RECV_DONE;
    24e8:	97ba                	add	a5,a5,a4
    24ea:	4719                	li	a4,6
    24ec:	d798                	sw	a4,40(a5)
        if (iic_priv->cb_event) {
    24ee:	479c                	lw	a5,8(a5)
        addr->USI_EN = 0;
    24f0:	00042023          	sw	zero,0(s0)
        if (iic_priv->cb_event) {
    24f4:	ee078de3          	beqz	a5,23ee <wj_usi_i2c_irqhandler+0x144>
}
    24f8:	4442                	lw	s0,16(sp)
    24fa:	40d2                	lw	ra,20(sp)
                iic_priv->cb_event(idx, IIC_EVENT_ARBITRATION_LOST);
    24fc:	8526                	mv	a0,s1
}
    24fe:	44b2                	lw	s1,12(sp)
    2500:	0161                	addi	sp,sp,24
                iic_priv->cb_event(idx, IIC_EVENT_ARBITRATION_LOST);
    2502:	8782                	jr	a5
            *iic_priv->rx_buf = addr->USI_TX_RX_FIFO;
    2504:	00842303          	lw	t1,8(s0)
    2508:	4b50                	lw	a2,20(a4)
        for (i = 0; i < rx_num; i++) {
    250a:	0505                	addi	a0,a0,1
    250c:	0ff57513          	zext.b	a0,a0
            *iic_priv->rx_buf = addr->USI_TX_RX_FIFO;
    2510:	00660023          	sb	t1,0(a2) # 1000 <__divdf3+0x19e>
            iic_priv->rx_buf++;
    2514:	4b50                	lw	a2,20(a4)
    2516:	0605                	addi	a2,a2,1
    2518:	cb50                	sw	a2,20(a4)
            iic_priv->rx_cnt++;;
    251a:	4f50                	lw	a2,28(a4)
    251c:	0605                	addi	a2,a2,1
    251e:	cf50                	sw	a2,28(a4)
        for (i = 0; i < rx_num; i++) {
    2520:	b701                	j	2420 <wj_usi_i2c_irqhandler+0x176>
            addr->USI_TX_RX_FIFO = 0x100;
    2522:	00642423          	sw	t1,8(s0)
            iic_priv->rx_clk--;
    2526:	5310                	lw	a2,32(a4)
        for (i = 0; i < rxfifo; i++) {
    2528:	0585                	addi	a1,a1,1
    252a:	0ff5f593          	zext.b	a1,a1
            iic_priv->rx_clk--;
    252e:	167d                	addi	a2,a2,-1
    2530:	d310                	sw	a2,32(a4)
        for (i = 0; i < rxfifo; i++) {
    2532:	bf05                	j	2462 <wj_usi_i2c_irqhandler+0x1b8>

00002534 <wj_spi_ss_control.isra.0>:
/**
  \brief control ss line depend on controlled Output mode.
*/
static int32_t wj_spi_ss_control(wj_usi_spi_priv_t *spi_priv, spi_ss_stat_e stat)
{
    if (spi_priv->ss_mode == SPI_SS_MASTER_HW_OUTPUT) {
    2534:	4789                	li	a5,2
    2536:	00f51f63          	bne	a0,a5,2554 <wj_spi_ss_control.isra.0+0x20>
static int32_t wj_spi_ss_control(wj_usi_spi_priv_t *spi_priv, spi_ss_stat_e stat)
    253a:	1171                	addi	sp,sp,-4
    253c:	c006                	sw	ra,0(sp)
        if (stat == SPI_SS_INACTIVE) {
            csi_gpio_pin_write(pgpio_pin_handle, true);
    253e:	0241a503          	lw	a0,36(gp) # 2000050c <pgpio_pin_handle>
        if (stat == SPI_SS_INACTIVE) {
    2542:	e599                	bnez	a1,2550 <wj_spi_ss_control.isra.0+0x1c>
            csi_gpio_pin_write(pgpio_pin_handle, true);
    2544:	4585                	li	a1,1
        } else if (stat == SPI_SS_ACTIVE) {
            csi_gpio_pin_write(pgpio_pin_handle, false);
    2546:	2715                	jal	2c6a <csi_gpio_pin_write>
            return -1;
        }
    }

    return 0;
}
    2548:	4082                	lw	ra,0(sp)
    254a:	4501                	li	a0,0
    254c:	0111                	addi	sp,sp,4
    254e:	8082                	ret
            csi_gpio_pin_write(pgpio_pin_handle, false);
    2550:	4581                	li	a1,0
    2552:	bfd5                	j	2546 <wj_spi_ss_control.isra.0+0x12>
}
    2554:	4501                	li	a0,0
    2556:	8082                	ret

00002558 <wj_usi_spi_irqhandler>:
  \brief       handler the interrupt.
  \param[in]   spi      Pointer to \ref SPI_RESOURCES
*/
void wj_usi_spi_irqhandler(int32_t idx)
{
    wj_usi_spi_priv_t *spi_priv = &spi_instance[idx];
    2558:	04c00613          	li	a2,76
    255c:	02c50633          	mul	a2,a0,a2
{
    2560:	1101                	addi	sp,sp,-32
    2562:	cc22                	sw	s0,24(sp)
    wj_usi_spi_priv_t *spi_priv = &spi_instance[idx];
    2564:	20002437          	lui	s0,0x20002
    2568:	85840413          	addi	s0,s0,-1960 # 20001858 <spi_instance>
{
    256c:	ca26                	sw	s1,20(sp)
    256e:	ce06                	sw	ra,28(sp)
    2570:	872a                	mv	a4,a0
    wj_usi_spi_priv_t *spi_priv = &spi_instance[idx];
    2572:	9622                	add	a2,a2,s0
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(spi_priv->base);
    2574:	4204                	lw	s1,0(a2)

    uint32_t intr_state = addr->USI_INTR_STA & 0x3ffff;
    2576:	0544a303          	lw	t1,84(s1)
    257a:	00e31793          	slli	a5,t1,0xe
    257e:	83b9                	srli	a5,a5,0xe
    2580:	c03e                	sw	a5,0(sp)

    /* deal with receive FIFO full interrupt */
    if (intr_state & USI_INT_SPI_STOP) {
    2582:	00e31793          	slli	a5,t1,0xe
    2586:	0807d463          	bgez	a5,260e <wj_usi_spi_irqhandler+0xb6>
    uint8_t rxnum = USI_FIFO_STA_RX_NUM(addr);
    258a:	44dc                	lw	a5,12(s1)
    uint32_t length = spi_priv->recv_num;
    258c:	4a48                	lw	a0,20(a2)
    uint8_t *pbuffer = spi_priv->recv_buf;
    258e:	4e4c                	lw	a1,28(a2)
    uint8_t rxnum = USI_FIFO_STA_RX_NUM(addr);
    2590:	83c1                	srli	a5,a5,0x10
    uint32_t rxdata_num = (rxnum > length) ? length : rxnum;
    2592:	8bfd                	andi	a5,a5,31
    2594:	00f57363          	bgeu	a0,a5,259a <wj_usi_spi_irqhandler+0x42>
    2598:	87aa                	mv	a5,a0
    for (i = 0; i < rxdata_num; i++) {
    259a:	00f582b3          	add	t0,a1,a5
    259e:	0a559f63          	bne	a1,t0,265c <wj_usi_spi_irqhandler+0x104>
    length -= rxdata_num;
    25a2:	40f502b3          	sub	t0,a0,a5
    if (length <= 0) {
    25a6:	0cf51163          	bne	a0,a5,2668 <wj_usi_spi_irqhandler+0x110>
        addr->USI_INTR_EN &= ~USI_INT_SPI_STOP;
    25aa:	48bc                	lw	a5,80(s1)
    25ac:	7581                	lui	a1,0xfffe0
    25ae:	15fd                	addi	a1,a1,-1 # fffdffff <__heap_end+0xdffaffff>
    25b0:	8fed                	and	a5,a5,a1
    25b2:	c8bc                	sw	a5,80(s1)
        spi_priv->status.busy = 0U;
    25b4:	04c00793          	li	a5,76
    25b8:	02f707b3          	mul	a5,a4,a5
    25bc:	c81a                	sw	t1,16(sp)
    25be:	c63a                	sw	a4,12(sp)
        wj_spi_ss_control(spi_priv, SPI_SS_INACTIVE);
    25c0:	c232                	sw	a2,4(sp)
        spi_priv->status.busy = 0U;
    25c2:	97a2                	add	a5,a5,s0
    25c4:	0387c583          	lbu	a1,56(a5)
        spi_priv->recv_num = 0;
    25c8:	c43e                	sw	a5,8(sp)
        spi_priv->status.busy = 0U;
    25ca:	99f9                	andi	a1,a1,-2
    25cc:	02b78c23          	sb	a1,56(a5)
        addr->USI_EN = 0x0;
    25d0:	0004a023          	sw	zero,0(s1)
        addr->USI_EN = 0xf;
    25d4:	45bd                	li	a1,15
    25d6:	c08c                	sw	a1,0(s1)
        addr->USI_EN = 0x0;
    25d8:	0004a023          	sw	zero,0(s1)
        spi_priv->recv_num = 0;
    25dc:	0007aa23          	sw	zero,20(a5)
        wj_spi_ss_control(spi_priv, SPI_SS_INACTIVE);
    25e0:	03464503          	lbu	a0,52(a2)
    25e4:	4581                	li	a1,0
    25e6:	37b9                	jal	2534 <wj_spi_ss_control.isra.0>
        if (spi_priv->cb_event) {
    25e8:	47a2                	lw	a5,8(sp)
    25ea:	4612                	lw	a2,4(sp)
    25ec:	4732                	lw	a4,12(sp)
    25ee:	00c7a383          	lw	t2,12(a5)
    25f2:	4342                	lw	t1,16(sp)
    25f4:	00038a63          	beqz	t2,2608 <wj_usi_spi_irqhandler+0xb0>
            spi_priv->cb_event(spi_priv->idx, SPI_EVENT_RX_COMPLETE);
    25f8:	43a8                	lw	a0,64(a5)
    25fa:	4589                	li	a1,2
    25fc:	c432                	sw	a2,8(sp)
    25fe:	c21a                	sw	t1,4(sp)
    2600:	9382                	jalr	t2
            return;
    2602:	4312                	lw	t1,4(sp)
    2604:	4622                	lw	a2,8(sp)
    2606:	4732                	lw	a4,12(sp)
        wj_spi_intr_rx_full(spi_priv);
        addr->USI_INTR_CLR = USI_INT_SPI_STOP;
    2608:	000207b7          	lui	a5,0x20
    260c:	d0bc                	sw	a5,96(s1)
    }

    /* deal with transmit FIFO empty interrupt */
    if (intr_state & USI_INT_TX_EMPTY) {
    260e:	00237313          	andi	t1,t1,2
    2612:	10030763          	beqz	t1,2720 <wj_usi_spi_irqhandler+0x1c8>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(spi_priv->base);
    2616:	04c00793          	li	a5,76
    261a:	02f707b3          	mul	a5,a4,a5
    261e:	97a2                	add	a5,a5,s0
    if (spi_priv->mode == WJENUM_SPI_TXRX) {
    2620:	5b8c                	lw	a1,48(a5)
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(spi_priv->base);
    2622:	0007a303          	lw	t1,0(a5) # 20000 <__ctor_end__+0x19440>
    if (spi_priv->mode == WJENUM_SPI_TXRX) {
    2626:	c5c1                	beqz	a1,26ae <wj_usi_spi_irqhandler+0x156>
        if (spi_priv->clk_num >= USI_TX_MAX_FIFO) {
    2628:	578c                	lw	a1,40(a5)
    262a:	47c1                	li	a5,16
    262c:	00b7f363          	bgeu	a5,a1,2632 <wj_usi_spi_irqhandler+0xda>
    2630:	85be                	mv	a1,a5
    2632:	04c00793          	li	a5,76
    2636:	02f707b3          	mul	a5,a4,a5
    263a:	4281                	li	t0,0
    263c:	97a2                	add	a5,a5,s0
    263e:	d3cc                	sw	a1,36(a5)
        for (i = 0; i < spi_priv->transfer_num; i++) {
    2640:	08558663          	beq	a1,t0,26cc <wj_usi_spi_irqhandler+0x174>
            addr->USI_TX_RX_FIFO = *spi_priv->send_buf;
    2644:	4f88                	lw	a0,24(a5)
        for (i = 0; i < spi_priv->transfer_num; i++) {
    2646:	0285                	addi	t0,t0,1 # 217f <memset+0x8f>
            addr->USI_TX_RX_FIFO = *spi_priv->send_buf;
    2648:	00054383          	lbu	t2,0(a0)
            spi_priv->send_buf++;
    264c:	0505                	addi	a0,a0,1
            addr->USI_TX_RX_FIFO = *spi_priv->send_buf;
    264e:	00732423          	sw	t2,8(t1)
            spi_priv->send_buf++;
    2652:	cf88                	sw	a0,24(a5)
            spi_priv->send_num--;
    2654:	4b88                	lw	a0,16(a5)
    2656:	157d                	addi	a0,a0,-1
    2658:	cb88                	sw	a0,16(a5)
        for (i = 0; i < spi_priv->transfer_num; i++) {
    265a:	b7dd                	j	2640 <wj_usi_spi_irqhandler+0xe8>
        *pbuffer = addr->USI_TX_RX_FIFO;
    265c:	0084a383          	lw	t2,8(s1)
        pbuffer++;
    2660:	0585                	addi	a1,a1,1
        *pbuffer = addr->USI_TX_RX_FIFO;
    2662:	fe758fa3          	sb	t2,-1(a1)
    for (i = 0; i < rxdata_num; i++) {
    2666:	bf25                	j	259e <wj_usi_spi_irqhandler+0x46>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(spi_priv->base);
    2668:	04c00793          	li	a5,76
    266c:	02f707b3          	mul	a5,a4,a5
    2670:	97a2                	add	a5,a5,s0
    2672:	4388                	lw	a0,0(a5)
            addr->USI_SPI_CTRL &= ~WJ_USI_SPI_CTRL_TMODE;
    2674:	04452383          	lw	t2,68(a0)
    2678:	fcf3f393          	andi	t2,t2,-49
    267c:	04752223          	sw	t2,68(a0)
            addr->USI_SPI_CTRL |= WJ_USI_SPI_CTRL_TMODE_RX;
    2680:	04452383          	lw	t2,68(a0)
    2684:	0203e393          	ori	t2,t2,32
    2688:	04752223          	sw	t2,68(a0)
    spi_priv->mode = mode;
    268c:	4509                	li	a0,2
    268e:	db88                	sw	a0,48(a5)
        spi_priv->recv_buf = pbuffer;
    2690:	cfcc                	sw	a1,28(a5)
        spi_priv->recv_num = length;
    2692:	0057aa23          	sw	t0,20(a5)
    2696:	bf8d                	j	2608 <wj_usi_spi_irqhandler+0xb0>
            *spi_priv->recv_buf = addr->USI_TX_RX_FIFO;
    2698:	00832503          	lw	a0,8(t1)
    269c:	4fcc                	lw	a1,28(a5)
    269e:	00a58023          	sb	a0,0(a1)
            spi_priv->recv_buf++;
    26a2:	4fcc                	lw	a1,28(a5)
    26a4:	0585                	addi	a1,a1,1
    26a6:	cfcc                	sw	a1,28(a5)
            spi_priv->transfer_num--;
    26a8:	53cc                	lw	a1,36(a5)
    26aa:	15fd                	addi	a1,a1,-1
    26ac:	d3cc                	sw	a1,36(a5)
        while (spi_priv->transfer_num) {
    26ae:	53c8                	lw	a0,36(a5)
    26b0:	f565                	bnez	a0,2698 <wj_usi_spi_irqhandler+0x140>
        if (spi_priv->clk_num >= USI_TX_MAX_FIFO) {
    26b2:	578c                	lw	a1,40(a5)
    26b4:	47c1                	li	a5,16
    26b6:	00b7f363          	bgeu	a5,a1,26bc <wj_usi_spi_irqhandler+0x164>
    26ba:	85be                	mv	a1,a5
    26bc:	04c00793          	li	a5,76
    26c0:	02f707b3          	mul	a5,a4,a5
    26c4:	97a2                	add	a5,a5,s0
    26c6:	d3cc                	sw	a1,36(a5)
        for (i = 0; i < spi_priv->transfer_num; i++) {
    26c8:	06b51363          	bne	a0,a1,272e <wj_usi_spi_irqhandler+0x1d6>
    if (spi_priv->clk_num == 0) {
    26cc:	04c00793          	li	a5,76
    26d0:	02f707b3          	mul	a5,a4,a5
    26d4:	97a2                	add	a5,a5,s0
    26d6:	578c                	lw	a1,40(a5)
    26d8:	edb5                	bnez	a1,2754 <wj_usi_spi_irqhandler+0x1fc>
        addr->USI_INTR_EN &= ~USI_INT_TX_EMPTY;
    26da:	05032583          	lw	a1,80(t1)
    26de:	c63a                	sw	a4,12(sp)
    26e0:	c41a                	sw	t1,8(sp)
    26e2:	99f5                	andi	a1,a1,-3
    26e4:	04b32823          	sw	a1,80(t1)
        spi_priv->status.busy = 0U;
    26e8:	0387c583          	lbu	a1,56(a5)
        spi_priv->send_num = 0;
    26ec:	0007a823          	sw	zero,16(a5)
    26f0:	c23e                	sw	a5,4(sp)
        spi_priv->status.busy = 0U;
    26f2:	99f9                	andi	a1,a1,-2
    26f4:	02b78c23          	sb	a1,56(a5)
        wj_spi_ss_control(spi_priv, SPI_SS_INACTIVE);
    26f8:	03464503          	lbu	a0,52(a2)
    26fc:	4581                	li	a1,0
    26fe:	3d1d                	jal	2534 <wj_spi_ss_control.isra.0>
            if (spi_priv->cb_event) {
    2700:	4792                	lw	a5,4(sp)
        addr->USI_EN = 0x0;
    2702:	4322                	lw	t1,8(sp)
        addr->USI_EN = 0xf;
    2704:	463d                	li	a2,15
        if (spi_priv->mode == WJENUM_SPI_TXRX) {
    2706:	5b8c                	lw	a1,48(a5)
        addr->USI_EN = 0x0;
    2708:	00032023          	sw	zero,0(t1)
        addr->USI_EN = 0xf;
    270c:	00c32023          	sw	a2,0(t1)
        if (spi_priv->mode == WJENUM_SPI_TXRX) {
    2710:	4732                	lw	a4,12(sp)
            if (spi_priv->cb_event) {
    2712:	47d0                	lw	a2,12(a5)
        if (spi_priv->mode == WJENUM_SPI_TXRX) {
    2714:	ed8d                	bnez	a1,274e <wj_usi_spi_irqhandler+0x1f6>
            if (spi_priv->cb_event) {
    2716:	ce1d                	beqz	a2,2754 <wj_usi_spi_irqhandler+0x1fc>
                spi_priv->cb_event(spi_priv->idx, SPI_EVENT_TX_COMPLETE);
    2718:	43a8                	lw	a0,64(a5)
    271a:	9602                	jalr	a2
        wj_spi_intr_tx_empty(spi_priv);
        addr->USI_INTR_CLR = USI_INT_TX_EMPTY;
    271c:	4789                	li	a5,2
    271e:	d0bc                	sw	a5,96(s1)
    }

    addr->USI_INTR_CLR = intr_state;
    2720:	4782                	lw	a5,0(sp)
}
    2722:	40f2                	lw	ra,28(sp)
    2724:	4462                	lw	s0,24(sp)
    addr->USI_INTR_CLR = intr_state;
    2726:	d0bc                	sw	a5,96(s1)
}
    2728:	44d2                	lw	s1,20(sp)
    272a:	6105                	addi	sp,sp,32
    272c:	8082                	ret
            addr->USI_TX_RX_FIFO = *spi_priv->send_buf;
    272e:	0187a283          	lw	t0,24(a5)
        for (i = 0; i < spi_priv->transfer_num; i++) {
    2732:	0505                	addi	a0,a0,1
            addr->USI_TX_RX_FIFO = *spi_priv->send_buf;
    2734:	0002c383          	lbu	t2,0(t0)
            spi_priv->send_buf++;
    2738:	0285                	addi	t0,t0,1
            addr->USI_TX_RX_FIFO = *spi_priv->send_buf;
    273a:	00732423          	sw	t2,8(t1)
            spi_priv->send_buf++;
    273e:	0057ac23          	sw	t0,24(a5)
            spi_priv->send_num--;
    2742:	0107a283          	lw	t0,16(a5)
    2746:	12fd                	addi	t0,t0,-1
    2748:	0057a823          	sw	t0,16(a5)
        for (i = 0; i < spi_priv->transfer_num; i++) {
    274c:	bfb5                	j	26c8 <wj_usi_spi_irqhandler+0x170>
            if (spi_priv->cb_event) {
    274e:	c219                	beqz	a2,2754 <wj_usi_spi_irqhandler+0x1fc>
                spi_priv->cb_event(spi_priv->idx, SPI_EVENT_TX_COMPLETE);
    2750:	4585                	li	a1,1
    2752:	b7d9                	j	2718 <wj_usi_spi_irqhandler+0x1c0>
    spi_priv->clk_num -= spi_priv->transfer_num;
    2754:	04c00793          	li	a5,76
    2758:	02f70733          	mul	a4,a4,a5
    275c:	943a                	add	s0,s0,a4
    275e:	541c                	lw	a5,40(s0)
    2760:	5058                	lw	a4,36(s0)
    2762:	8f99                	sub	a5,a5,a4
    2764:	d41c                	sw	a5,40(s0)
    2766:	bf5d                	j	271c <wj_usi_spi_irqhandler+0x1c4>

00002768 <ck_usart_intr_recv_data>:
  \brief        interrupt service function for receiver data available.
  \param[in]   usart_priv usart private to operate.
*/
static void ck_usart_intr_recv_data(wj_usi_usart_priv_t *usart_priv)
{
    if ((usart_priv->rx_total_num == 0) || (usart_priv->rx_buf == NULL)) {
    2768:	4558                	lw	a4,12(a0)
    276a:	c319                	beqz	a4,2770 <ck_usart_intr_recv_data+0x8>
    276c:	495c                	lw	a5,20(a0)
    276e:	e789                	bnez	a5,2778 <ck_usart_intr_recv_data+0x10>
        usart_priv->cb_event(usart_priv->idx, USART_EVENT_RECEIVED);
    2770:	451c                	lw	a5,8(a0)
    2772:	45b9                	li	a1,14
        usart_priv->rx_buf = NULL;
        usart_priv->rx_busy = 0;
        usart_priv->rx_total_num = 0;

        if (usart_priv->cb_event) {
            usart_priv->cb_event(usart_priv->idx, USART_EVENT_RECEIVE_COMPLETE);
    2774:	5948                	lw	a0,52(a0)
    2776:	8782                	jr	a5
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2778:	4110                	lw	a2,0(a0)
    uint32_t rxfifo_num = (addr->USI_FIFO_STA >> 16) & 0xf;
    277a:	465c                	lw	a5,12(a2)
    277c:	83c1                	srli	a5,a5,0x10
    277e:	8bbd                	andi	a5,a5,15
    uint32_t rxdata_num = (rxfifo_num > usart_priv->rx_total_num) ? usart_priv->rx_total_num : rxfifo_num;
    2780:	00f77363          	bgeu	a4,a5,2786 <ck_usart_intr_recv_data+0x1e>
    2784:	87ba                	mv	a5,a4
    for (i = 0; i < rxdata_num; i++) {
    2786:	4701                	li	a4,0
    2788:	02f71363          	bne	a4,a5,27ae <ck_usart_intr_recv_data+0x46>
    if (usart_priv->rx_cnt >= usart_priv->rx_total_num) {
    278c:	4d58                	lw	a4,28(a0)
    278e:	455c                	lw	a5,12(a0)
    2790:	02f76b63          	bltu	a4,a5,27c6 <ck_usart_intr_recv_data+0x5e>
        usart_priv->last_rx_num = usart_priv->rx_total_num;
    2794:	d91c                	sw	a5,48(a0)
        if (usart_priv->cb_event) {
    2796:	451c                	lw	a5,8(a0)
        usart_priv->rx_cnt = 0;
    2798:	00052e23          	sw	zero,28(a0)
        usart_priv->rx_buf = NULL;
    279c:	00052a23          	sw	zero,20(a0)
        usart_priv->rx_busy = 0;
    27a0:	02052423          	sw	zero,40(a0)
        usart_priv->rx_total_num = 0;
    27a4:	00052623          	sw	zero,12(a0)
        if (usart_priv->cb_event) {
    27a8:	cf99                	beqz	a5,27c6 <ck_usart_intr_recv_data+0x5e>
            usart_priv->cb_event(usart_priv->idx, USART_EVENT_RECEIVE_COMPLETE);
    27aa:	4585                	li	a1,1
    27ac:	b7e1                	j	2774 <ck_usart_intr_recv_data+0xc>
        *((uint8_t *)usart_priv->rx_buf) = addr->USI_TX_RX_FIFO;;
    27ae:	460c                	lw	a1,8(a2)
    27b0:	4954                	lw	a3,20(a0)
    for (i = 0; i < rxdata_num; i++) {
    27b2:	0705                	addi	a4,a4,1 # 1001 <__divdf3+0x19f>
        *((uint8_t *)usart_priv->rx_buf) = addr->USI_TX_RX_FIFO;;
    27b4:	00b68023          	sb	a1,0(a3)
        usart_priv->rx_cnt++;
    27b8:	4d54                	lw	a3,28(a0)
    27ba:	0685                	addi	a3,a3,1
    27bc:	cd54                	sw	a3,28(a0)
        usart_priv->rx_buf++;
    27be:	4954                	lw	a3,20(a0)
    27c0:	0685                	addi	a3,a3,1
    27c2:	c954                	sw	a3,20(a0)
    for (i = 0; i < rxdata_num; i++) {
    27c4:	b7d1                	j	2788 <ck_usart_intr_recv_data+0x20>
        }
    }
}
    27c6:	8082                	ret

000027c8 <drv_usi_usart_config_baudrate>:
{
    27c8:	1151                	addi	sp,sp,-12
    27ca:	c222                	sw	s0,4(sp)
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    27cc:	4100                	lw	s0,0(a0)
    uint32_t divisor = ((drv_get_usi_freq(usart_priv->idx)  * 10) / baudrate) >> 4;
    27ce:	5948                	lw	a0,52(a0)
{
    27d0:	c026                	sw	s1,0(sp)
    27d2:	c406                	sw	ra,8(sp)
    addr->USI_EN = 0x0;
    27d4:	00042023          	sw	zero,0(s0)
{
    27d8:	84ae                	mv	s1,a1
    uint32_t divisor = ((drv_get_usi_freq(usart_priv->idx)  * 10) / baudrate) >> 4;
    27da:	2ed000ef          	jal	32c6 <drv_get_usi_freq>
    27de:	4729                	li	a4,10
    27e0:	02e50533          	mul	a0,a0,a4
}
    27e4:	40a2                	lw	ra,8(sp)
    uint32_t divisor = ((drv_get_usi_freq(usart_priv->idx)  * 10) / baudrate) >> 4;
    27e6:	02955533          	divu	a0,a0,s1
}
    27ea:	4482                	lw	s1,0(sp)
    uint32_t divisor = ((drv_get_usi_freq(usart_priv->idx)  * 10) / baudrate) >> 4;
    27ec:	8111                	srli	a0,a0,0x4
        divisor = (divisor / 10);
    27ee:	02e557b3          	divu	a5,a0,a4
    if ((divisor % 10) >= 5) {
    27f2:	02e57533          	remu	a0,a0,a4
        divisor = divisor / 10 - 1;
    27f6:	00553513          	sltiu	a0,a0,5
    27fa:	8f89                	sub	a5,a5,a0
    addr->USI_CLK_DIV0 = divisor;
    27fc:	c81c                	sw	a5,16(s0)
    addr->USI_EN = 0xf;
    27fe:	47bd                	li	a5,15
    2800:	c01c                	sw	a5,0(s0)
}
    2802:	4412                	lw	s0,4(sp)
    2804:	4501                	li	a0,0
    2806:	0131                	addi	sp,sp,12
    2808:	8082                	ret

0000280a <drv_usi_usart_config_mode>:
    USART_NULL_PARAM_CHK(handle);
    280a:	cd11                	beqz	a0,2826 <drv_usi_usart_config_mode+0x1c>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    280c:	411c                	lw	a5,0(a0)
    addr->USI_EN = 0x0;
    280e:	473d                	li	a4,15
    2810:	0007a023          	sw	zero,0(a5)
        addr->USI_EN = 0xf;
    2814:	c398                	sw	a4,0(a5)
    if (mode == USART_MODE_ASYNCHRONOUS) {
    2816:	e199                	bnez	a1,281c <drv_usi_usart_config_mode+0x12>
        return 0;
    2818:	4501                	li	a0,0
    281a:	8082                	ret
    return ERR_USART(USART_ERROR_MODE);
    281c:	81020537          	lui	a0,0x81020
    2820:	08650513          	addi	a0,a0,134 # 81020086 <__heap_end+0x60ff0086>
    2824:	8082                	ret
    USART_NULL_PARAM_CHK(handle);
    2826:	81020537          	lui	a0,0x81020
    282a:	08450513          	addi	a0,a0,132 # 81020084 <__heap_end+0x60ff0084>
}
    282e:	8082                	ret

00002830 <drv_usi_usart_config_parity>:
    USART_NULL_PARAM_CHK(handle);
    2830:	c531                	beqz	a0,287c <drv_usi_usart_config_parity+0x4c>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2832:	411c                	lw	a5,0(a0)
    switch (parity) {
    2834:	4705                	li	a4,1
    addr->USI_EN = 0x0;
    2836:	0007a023          	sw	zero,0(a5)
    switch (parity) {
    283a:	02e58663          	beq	a1,a4,2866 <drv_usi_usart_config_parity+0x36>
    283e:	4709                	li	a4,2
    2840:	00e58a63          	beq	a1,a4,2854 <drv_usi_usart_config_parity+0x24>
    2844:	e1a9                	bnez	a1,2886 <drv_usi_usart_config_parity+0x56>
            addr->USI_UART_CTRL &= ~CTRL_PARITY_ENABLE;
    2846:	4f98                	lw	a4,24(a5)
    2848:	9b3d                	andi	a4,a4,-17
            addr->USI_UART_CTRL |= CTRL_PARITY_EVEN;
    284a:	cf98                	sw	a4,24(a5)
    addr->USI_EN = 0xf;
    284c:	473d                	li	a4,15
    284e:	c398                	sw	a4,0(a5)
    return 0;
    2850:	4501                	li	a0,0
    2852:	8082                	ret
            addr->USI_UART_CTRL &= CTRL_PARITY_BITS;
    2854:	4f98                	lw	a4,24(a5)
    2856:	8b3d                	andi	a4,a4,15
    2858:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_PARITY_ENABLE;
    285a:	4f98                	lw	a4,24(a5)
    285c:	01076713          	ori	a4,a4,16
    2860:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_PARITY_ODD;
    2862:	4f98                	lw	a4,24(a5)
    2864:	b7dd                	j	284a <drv_usi_usart_config_parity+0x1a>
            addr->USI_UART_CTRL &= CTRL_PARITY_BITS;
    2866:	4f98                	lw	a4,24(a5)
    2868:	8b3d                	andi	a4,a4,15
    286a:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_PARITY_ENABLE;
    286c:	4f98                	lw	a4,24(a5)
    286e:	01076713          	ori	a4,a4,16
    2872:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_PARITY_EVEN;
    2874:	4f98                	lw	a4,24(a5)
    2876:	02076713          	ori	a4,a4,32
    287a:	bfc1                	j	284a <drv_usi_usart_config_parity+0x1a>
    USART_NULL_PARAM_CHK(handle);
    287c:	81020537          	lui	a0,0x81020
    2880:	08450513          	addi	a0,a0,132 # 81020084 <__heap_end+0x60ff0084>
    2884:	8082                	ret
    switch (parity) {
    2886:	81020537          	lui	a0,0x81020
    288a:	08950513          	addi	a0,a0,137 # 81020089 <__heap_end+0x60ff0089>
}
    288e:	8082                	ret

00002890 <drv_usi_usart_config_stopbits>:
    USART_NULL_PARAM_CHK(handle);
    2890:	c529                	beqz	a0,28da <drv_usi_usart_config_stopbits+0x4a>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2892:	411c                	lw	a5,0(a0)
    switch (stopbit) {
    2894:	4705                	li	a4,1
    addr->USI_EN = 0x0;
    2896:	0007a023          	sw	zero,0(a5)
    switch (stopbit) {
    289a:	02e58863          	beq	a1,a4,28ca <drv_usi_usart_config_stopbits+0x3a>
    289e:	4709                	li	a4,2
    28a0:	00e58d63          	beq	a1,a4,28ba <drv_usi_usart_config_stopbits+0x2a>
    28a4:	e1a1                	bnez	a1,28e4 <drv_usi_usart_config_stopbits+0x54>
            addr->USI_UART_CTRL &= CTRL_STOP_BITS;
    28a6:	4f98                	lw	a4,24(a5)
    28a8:	03377713          	andi	a4,a4,51
    28ac:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_STOP_1;
    28ae:	4f98                	lw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_STOP_2;
    28b0:	cf98                	sw	a4,24(a5)
    addr->USI_EN = 0xf;
    28b2:	473d                	li	a4,15
    28b4:	c398                	sw	a4,0(a5)
    return 0;
    28b6:	4501                	li	a0,0
    28b8:	8082                	ret
            addr->USI_UART_CTRL &= CTRL_STOP_BITS;
    28ba:	4f98                	lw	a4,24(a5)
    28bc:	03377713          	andi	a4,a4,51
    28c0:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_STOP_1_5;
    28c2:	4f98                	lw	a4,24(a5)
    28c4:	00476713          	ori	a4,a4,4
    28c8:	b7e5                	j	28b0 <drv_usi_usart_config_stopbits+0x20>
            addr->USI_UART_CTRL &= CTRL_STOP_BITS;
    28ca:	4f98                	lw	a4,24(a5)
    28cc:	03377713          	andi	a4,a4,51
    28d0:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_STOP_2;
    28d2:	4f98                	lw	a4,24(a5)
    28d4:	00876713          	ori	a4,a4,8
    28d8:	bfe1                	j	28b0 <drv_usi_usart_config_stopbits+0x20>
    USART_NULL_PARAM_CHK(handle);
    28da:	81020537          	lui	a0,0x81020
    28de:	08450513          	addi	a0,a0,132 # 81020084 <__heap_end+0x60ff0084>
    28e2:	8082                	ret
    switch (stopbit) {
    28e4:	81020537          	lui	a0,0x81020
    28e8:	08a50513          	addi	a0,a0,138 # 8102008a <__heap_end+0x60ff008a>
}
    28ec:	8082                	ret

000028ee <drv_usi_usart_config_databits>:
    USART_NULL_PARAM_CHK(handle);
    28ee:	c525                	beqz	a0,2956 <drv_usi_usart_config_databits+0x68>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    28f0:	411c                	lw	a5,0(a0)
    switch (databits) {
    28f2:	4709                	li	a4,2
    addr->USI_EN = 0x0;
    28f4:	0007a023          	sw	zero,0(a5)
    switch (databits) {
    28f8:	02e58f63          	beq	a1,a4,2936 <drv_usi_usart_config_databits+0x48>
    28fc:	00b76d63          	bltu	a4,a1,2916 <drv_usi_usart_config_databits+0x28>
    2900:	e19d                	bnez	a1,2926 <drv_usi_usart_config_databits+0x38>
            addr->USI_UART_CTRL &= CTRL_DBIT_BITS;
    2902:	4f98                	lw	a4,24(a5)
    2904:	03c77713          	andi	a4,a4,60
    2908:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_DBIT_5;
    290a:	4f98                	lw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_DBIT_8;
    290c:	cf98                	sw	a4,24(a5)
    addr->USI_EN = 0xf;
    290e:	473d                	li	a4,15
    2910:	c398                	sw	a4,0(a5)
    return 0;
    2912:	4501                	li	a0,0
    2914:	8082                	ret
    switch (databits) {
    2916:	470d                	li	a4,3
    2918:	02e58763          	beq	a1,a4,2946 <drv_usi_usart_config_databits+0x58>
    291c:	81020537          	lui	a0,0x81020
    2920:	08850513          	addi	a0,a0,136 # 81020088 <__heap_end+0x60ff0088>
    2924:	8082                	ret
            addr->USI_UART_CTRL &= CTRL_DBIT_BITS;
    2926:	4f98                	lw	a4,24(a5)
    2928:	03c77713          	andi	a4,a4,60
    292c:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_DBIT_6;
    292e:	4f98                	lw	a4,24(a5)
    2930:	00176713          	ori	a4,a4,1
    2934:	bfe1                	j	290c <drv_usi_usart_config_databits+0x1e>
            addr->USI_UART_CTRL &= CTRL_DBIT_BITS;
    2936:	4f98                	lw	a4,24(a5)
    2938:	03c77713          	andi	a4,a4,60
    293c:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_DBIT_7;
    293e:	4f98                	lw	a4,24(a5)
    2940:	00276713          	ori	a4,a4,2
    2944:	b7e1                	j	290c <drv_usi_usart_config_databits+0x1e>
            addr->USI_UART_CTRL &= CTRL_DBIT_BITS;
    2946:	4f98                	lw	a4,24(a5)
    2948:	03c77713          	andi	a4,a4,60
    294c:	cf98                	sw	a4,24(a5)
            addr->USI_UART_CTRL |= CTRL_DBIT_8;
    294e:	4f98                	lw	a4,24(a5)
    2950:	00376713          	ori	a4,a4,3
    2954:	bf65                	j	290c <drv_usi_usart_config_databits+0x1e>
    USART_NULL_PARAM_CHK(handle);
    2956:	81020537          	lui	a0,0x81020
    295a:	08450513          	addi	a0,a0,132 # 81020084 <__heap_end+0x60ff0084>
}
    295e:	8082                	ret

00002960 <wj_usi_usart_irqhandler>:
    }
}

void wj_usi_usart_irqhandler(int idx)
{
    wj_usi_usart_priv_t *usart_priv = &usi_usart_instance[idx];
    2960:	03800793          	li	a5,56
    2964:	02f507b3          	mul	a5,a0,a5
    2968:	20002737          	lui	a4,0x20002
    296c:	93c70713          	addi	a4,a4,-1732 # 2000193c <usi_usart_instance>
{
    2970:	1101                	addi	sp,sp,-32
    2972:	ca26                	sw	s1,20(sp)
    wj_usi_usart_priv_t *usart_priv = &usi_usart_instance[idx];
    2974:	c23a                	sw	a4,4(sp)
{
    2976:	cc22                	sw	s0,24(sp)
    2978:	ce06                	sw	ra,28(sp)
    297a:	842a                	mv	s0,a0
    wj_usi_usart_priv_t *usart_priv = &usi_usart_instance[idx];
    297c:	97ba                	add	a5,a5,a4
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    297e:	4384                	lw	s1,0(a5)

    uint32_t intr_state = addr->USI_INTR_STA & 0x3ffff;
    2980:	48f8                	lw	a4,84(s1)
    2982:	00e71693          	slli	a3,a4,0xe
    2986:	c03a                	sw	a4,0(sp)
    2988:	00e6d713          	srli	a4,a3,0xe
    298c:	c43a                	sw	a4,8(sp)

    if (intr_state & USI_INT_TX_EMPTY) {
    298e:	4702                	lw	a4,0(sp)
    2990:	00277693          	andi	a3,a4,2
    2994:	ce9d                	beqz	a3,29d2 <wj_usi_usart_irqhandler+0x72>
    if (usart_priv->tx_total_num == 0) {
    2996:	4b94                	lw	a3,16(a5)
    2998:	ca9d                	beqz	a3,29ce <wj_usi_usart_irqhandler+0x6e>
    if (usart_priv->tx_cnt >= usart_priv->tx_total_num) {
    299a:	5390                	lw	a2,32(a5)
    299c:	0cd66063          	bltu	a2,a3,2a5c <wj_usi_usart_irqhandler+0xfc>
        addr->USI_INTR_EN &= (~USI_INT_TX_EMPTY);
    29a0:	48b0                	lw	a2,80(s1)
    29a2:	9a75                	andi	a2,a2,-3
    29a4:	c8b0                	sw	a2,80(s1)
        addr->USI_INTR_EN |= USI_INT_UART_STOP;
    29a6:	48b0                	lw	a2,80(s1)
    29a8:	40066613          	ori	a2,a2,1024
    29ac:	c8b0                	sw	a2,80(s1)
        usart_priv->last_tx_num = usart_priv->tx_total_num;
    29ae:	d7d4                	sw	a3,44(a5)
        if (usart_priv->cb_event) {
    29b0:	4794                	lw	a3,8(a5)
        usart_priv->tx_cnt = 0;
    29b2:	0207a023          	sw	zero,32(a5)
        usart_priv->tx_busy = 0;
    29b6:	0207a223          	sw	zero,36(a5)
        usart_priv->tx_buf = NULL;
    29ba:	0007ac23          	sw	zero,24(a5)
        usart_priv->tx_total_num = 0;
    29be:	0007a823          	sw	zero,16(a5)
        if (usart_priv->cb_event) {
    29c2:	c691                	beqz	a3,29ce <wj_usi_usart_irqhandler+0x6e>
            usart_priv->cb_event(usart_priv->idx, USART_EVENT_SEND_COMPLETE);
    29c4:	5bc8                	lw	a0,52(a5)
    29c6:	4581                	li	a1,0
    29c8:	c63e                	sw	a5,12(sp)
    29ca:	9682                	jalr	a3
    29cc:	47b2                	lw	a5,12(sp)
        ck_usart_intr_threshold_empty(usart_priv);
        addr->USI_INTR_CLR = USI_INT_TX_EMPTY;
    29ce:	4689                	li	a3,2
    29d0:	d0b4                	sw	a3,96(s1)
    }

    if (intr_state & USI_INT_RX_THOLD) {
    29d2:	4702                	lw	a4,0(sp)
    29d4:	02077693          	andi	a3,a4,32
    29d8:	ca81                	beqz	a3,29e8 <wj_usi_usart_irqhandler+0x88>
        ck_usart_intr_recv_data(usart_priv);
    29da:	853e                	mv	a0,a5
    29dc:	c63e                	sw	a5,12(sp)
    29de:	3369                	jal	2768 <ck_usart_intr_recv_data>
        addr->USI_INTR_CLR = USI_INT_RX_THOLD;
    29e0:	47b2                	lw	a5,12(sp)
    29e2:	02000693          	li	a3,32
    29e6:	d0b4                	sw	a3,96(s1)
    }

    if (intr_state & USI_INT_UART_STOP) {
    29e8:	4702                	lw	a4,0(sp)
    29ea:	40077693          	andi	a3,a4,1024
    29ee:	c68d                	beqz	a3,2a18 <wj_usi_usart_irqhandler+0xb8>
        if (USI_FIFO_STA_RX_NUM(addr) > 0) {
    29f0:	44d4                	lw	a3,12(s1)
    29f2:	0106d613          	srli	a2,a3,0x10
    29f6:	8a7d                	andi	a2,a2,31
    29f8:	ce09                	beqz	a2,2a12 <wj_usi_usart_irqhandler+0xb2>
    if ((usart_priv->rx_total_num != 0) && (usart_priv->rx_buf != NULL)) {
    29fa:	03800693          	li	a3,56
    29fe:	02d406b3          	mul	a3,s0,a3
    2a02:	4712                	lw	a4,4(sp)
    2a04:	96ba                	add	a3,a3,a4
    2a06:	46d0                	lw	a2,12(a3)
    2a08:	ce41                	beqz	a2,2aa0 <wj_usi_usart_irqhandler+0x140>
    2a0a:	4ad4                	lw	a3,20(a3)
    2a0c:	cad1                	beqz	a3,2aa0 <wj_usi_usart_irqhandler+0x140>
        ck_usart_intr_recv_data(usart_priv);
    2a0e:	853e                	mv	a0,a5
    2a10:	3ba1                	jal	2768 <ck_usart_intr_recv_data>
            ck_usart_intr_char_timeout(usart_priv);     //receive small data
        }

        addr->USI_INTR_CLR = USI_INT_RX_THOLD;
    2a12:	02000793          	li	a5,32
    2a16:	d0bc                	sw	a5,96(s1)
    }

    if (intr_state & USI_INT_UART_PERR) {
    2a18:	4702                	lw	a4,0(sp)
    2a1a:	01471793          	slli	a5,a4,0x14
    2a1e:	0207d863          	bgez	a5,2a4e <wj_usi_usart_irqhandler+0xee>
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2a22:	03800793          	li	a5,56
    2a26:	02f40433          	mul	s0,s0,a5
    2a2a:	4792                	lw	a5,4(sp)
    2a2c:	943e                	add	s0,s0,a5
    2a2e:	401c                	lw	a5,0(s0)
    addr->USI_EN &= ~USI_RX_FIFO_EN;
    2a30:	4394                	lw	a3,0(a5)
    2a32:	9add                	andi	a3,a3,-9
    2a34:	c394                	sw	a3,0(a5)
    addr->USI_EN |= USI_RX_FIFO_EN;
    2a36:	4394                	lw	a3,0(a5)
    2a38:	0086e693          	ori	a3,a3,8
    2a3c:	c394                	sw	a3,0(a5)
    if (usart_priv->cb_event) {
    2a3e:	441c                	lw	a5,8(s0)
    2a40:	c781                	beqz	a5,2a48 <wj_usi_usart_irqhandler+0xe8>
        usart_priv->cb_event(usart_priv->idx, USART_EVENT_RX_PARITY_ERROR);
    2a42:	5848                	lw	a0,52(s0)
    2a44:	45a5                	li	a1,9
    2a46:	9782                	jalr	a5
        ck_usart_intr_recv_line(usart_priv);
        addr->USI_INTR_CLR = USI_INT_RX_THOLD;
    2a48:	02000793          	li	a5,32
    2a4c:	d0bc                	sw	a5,96(s1)
    }

    addr->USI_INTR_CLR = intr_state;
    2a4e:	47a2                	lw	a5,8(sp)
}
    2a50:	40f2                	lw	ra,28(sp)
    2a52:	4462                	lw	s0,24(sp)
    addr->USI_INTR_CLR = intr_state;
    2a54:	d0bc                	sw	a5,96(s1)
}
    2a56:	44d2                	lw	s1,20(sp)
    2a58:	6105                	addi	sp,sp,32
    2a5a:	8082                	ret
        uint32_t remain_txdata  = usart_priv->tx_total_num - usart_priv->tx_cnt;
    2a5c:	5390                	lw	a2,32(a5)
    2a5e:	40c685b3          	sub	a1,a3,a2
        uint32_t txdata_num = (remain_txdata > (USI_TX_MAX_FIFO - 1)) ? (USI_TX_MAX_FIFO - 1) : remain_txdata;
    2a62:	46bd                	li	a3,15
    2a64:	00b6f363          	bgeu	a3,a1,2a6a <wj_usi_usart_irqhandler+0x10a>
    2a68:	85b6                	mv	a1,a3
            addr->USI_TX_RX_FIFO = *((uint8_t *)usart_priv->tx_buf);
    2a6a:	03800693          	li	a3,56
    2a6e:	02d406b3          	mul	a3,s0,a3
    2a72:	4712                	lw	a4,4(sp)
        volatile uint32_t i = 0u;
    2a74:	c802                	sw	zero,16(sp)
        for (i = 0; i < txdata_num; i++) {
    2a76:	c802                	sw	zero,16(sp)
            addr->USI_TX_RX_FIFO = *((uint8_t *)usart_priv->tx_buf);
    2a78:	96ba                	add	a3,a3,a4
        for (i = 0; i < txdata_num; i++) {
    2a7a:	4642                	lw	a2,16(sp)
    2a7c:	00b66563          	bltu	a2,a1,2a86 <wj_usi_usart_irqhandler+0x126>
        addr->USI_INTR_CLR = USI_INT_TX_EMPTY;
    2a80:	4689                	li	a3,2
    2a82:	d0b4                	sw	a3,96(s1)
    2a84:	b7a9                	j	29ce <wj_usi_usart_irqhandler+0x6e>
            addr->USI_TX_RX_FIFO = *((uint8_t *)usart_priv->tx_buf);
    2a86:	4e90                	lw	a2,24(a3)
    2a88:	00064503          	lbu	a0,0(a2)
            usart_priv->tx_buf++;
    2a8c:	0605                	addi	a2,a2,1
            addr->USI_TX_RX_FIFO = *((uint8_t *)usart_priv->tx_buf);
    2a8e:	c488                	sw	a0,8(s1)
            usart_priv->tx_cnt++;
    2a90:	5288                	lw	a0,32(a3)
            usart_priv->tx_buf++;
    2a92:	ce90                	sw	a2,24(a3)
            usart_priv->tx_cnt++;
    2a94:	0505                	addi	a0,a0,1
    2a96:	d288                	sw	a0,32(a3)
        for (i = 0; i < txdata_num; i++) {
    2a98:	4642                	lw	a2,16(sp)
    2a9a:	0605                	addi	a2,a2,1
    2a9c:	c832                	sw	a2,16(sp)
    2a9e:	bff1                	j	2a7a <wj_usi_usart_irqhandler+0x11a>
    if (usart_priv->cb_event) {
    2aa0:	03800793          	li	a5,56
    2aa4:	02f407b3          	mul	a5,s0,a5
    2aa8:	4712                	lw	a4,4(sp)
    2aaa:	97ba                	add	a5,a5,a4
    2aac:	4794                	lw	a3,8(a5)
    2aae:	c689                	beqz	a3,2ab8 <wj_usi_usart_irqhandler+0x158>
        usart_priv->cb_event(usart_priv->idx, USART_EVENT_RECEIVED);
    2ab0:	5bc8                	lw	a0,52(a5)
    2ab2:	45b9                	li	a1,14
    2ab4:	9682                	jalr	a3
    2ab6:	bfb1                	j	2a12 <wj_usi_usart_irqhandler+0xb2>
        wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2ab8:	439c                	lw	a5,0(a5)
        addr->USI_EN &= ~USI_RX_FIFO_EN;
    2aba:	4394                	lw	a3,0(a5)
    2abc:	9add                	andi	a3,a3,-9
    2abe:	c394                	sw	a3,0(a5)
        addr->USI_EN |= USI_RX_FIFO_EN;
    2ac0:	4394                	lw	a3,0(a5)
    2ac2:	0086e693          	ori	a3,a3,8
    2ac6:	c394                	sw	a3,0(a5)
    2ac8:	b7a9                	j	2a12 <wj_usi_usart_irqhandler+0xb2>

00002aca <drv_usi_usart_putchar>:
  \return      error code
*/
int32_t drv_usi_usart_putchar(usart_handle_t handle, uint8_t ch)
{
    wj_usi_usart_priv_t *usart_priv = handle;
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2aca:	4118                	lw	a4,0(a0)
    //addr->USI_EN = 0xb;
    //addr->USI_EN = 0xf;
    addr->USI_TX_RX_FIFO = ch;
    2acc:	c70c                	sw	a1,8(a4)

    while (!(addr->USI_FIFO_STA & 0x1));
    2ace:	475c                	lw	a5,12(a4)
    2ad0:	8b85                	andi	a5,a5,1
    2ad2:	dff5                	beqz	a5,2ace <drv_usi_usart_putchar+0x4>

    return 0;
}
    2ad4:	4501                	li	a0,0
    2ad6:	8082                	ret

00002ad8 <drv_usi_usart_initialize>:
  \param[in]   idx usart index
  \param[in]   cb_event event call back function \ref usart_event_cb_t
  \return      return usart handle if success
*/
usart_handle_t drv_usi_usart_initialize(int32_t idx, usart_event_cb_t cb_event)
{
    2ad8:	1111                	addi	sp,sp,-28
    2ada:	c02e                	sw	a1,0(sp)
    //initialize instace
    uint32_t base;
    uint32_t irq;
    void *handler;

    int32_t ret  = target_usi_usart_init(idx, &base, &irq, &handler);
    2adc:	0074                	addi	a3,sp,12
    2ade:	0030                	addi	a2,sp,8
    2ae0:	004c                	addi	a1,sp,4
{
    2ae2:	ca22                	sw	s0,20(sp)
    2ae4:	cc06                	sw	ra,24(sp)
    2ae6:	c826                	sw	s1,16(sp)
    2ae8:	842a                	mv	s0,a0
    int32_t ret  = target_usi_usart_init(idx, &base, &irq, &handler);
    2aea:	2a25                	jal	2c22 <target_usi_usart_init>

    if (ret < 0 || ret >= CONFIG_USI_NUM) {
    2aec:	4789                	li	a5,2
    2aee:	00a7f963          	bgeu	a5,a0,2b00 <drv_usi_usart_initialize+0x28>
        return NULL;
    2af2:	4481                	li	s1,0
    addr->USI_MODE_SEL = USI_MODE_UART;
    drv_irq_register(usart_priv->irq, handler);
    drv_irq_enable(usart_priv->irq);

    return usart_priv;
}
    2af4:	40e2                	lw	ra,24(sp)
    2af6:	4452                	lw	s0,20(sp)
    2af8:	8526                	mv	a0,s1
    2afa:	44c2                	lw	s1,16(sp)
    2afc:	0171                	addi	sp,sp,28
    2afe:	8082                	ret
    ret = drv_usi_initialize(idx);
    2b00:	8522                	mv	a0,s0
    2b02:	f66ff0ef          	jal	2268 <drv_usi_initialize>
    if (ret < 0) {
    2b06:	fe0546e3          	bltz	a0,2af2 <drv_usi_usart_initialize+0x1a>
    wj_usi_usart_priv_t *usart_priv = &usi_usart_instance[idx];
    2b0a:	03800793          	li	a5,56
    2b0e:	02f407b3          	mul	a5,s0,a5
    2b12:	20002737          	lui	a4,0x20002
    2b16:	93c70713          	addi	a4,a4,-1732 # 2000193c <usi_usart_instance>
    usart_priv->base = base;
    2b1a:	4512                	lw	a0,4(sp)
    wj_usi_set_rxfifo_th(addr, USI_RX_MAX_FIFO);
    2b1c:	45c1                	li	a1,16
    wj_usi_usart_priv_t *usart_priv = &usi_usart_instance[idx];
    2b1e:	00e784b3          	add	s1,a5,a4
    usart_priv->irq = irq;
    2b22:	4722                	lw	a4,8(sp)
    usart_priv->cb_event = cb_event;
    2b24:	4782                	lw	a5,0(sp)
    usart_priv->base = base;
    2b26:	c088                	sw	a0,0(s1)
    usart_priv->irq = irq;
    2b28:	c0d8                	sw	a4,4(s1)
    usart_priv->cb_event = cb_event;
    2b2a:	c49c                	sw	a5,8(s1)
    usart_priv->idx = idx;
    2b2c:	d8c0                	sw	s0,52(s1)
    addr->USI_INTR_UNMASK = WJ_UART_INT_ENABLE_DEFAUL;
    2b2e:	6705                	lui	a4,0x1
    2b30:	f9870713          	addi	a4,a4,-104 # f98 <__divdf3+0x136>
    addr->USI_EN = 0x0;
    2b34:	00052023          	sw	zero,0(a0)
    addr->USI_INTR_UNMASK = WJ_UART_INT_ENABLE_DEFAUL;
    2b38:	cd78                	sw	a4,92(a0)
    addr->USI_INTR_EN = WJ_UART_INT_ENABLE_DEFAUL;
    2b3a:	c938                	sw	a4,80(a0)
    wj_usi_set_rxfifo_th(addr, USI_RX_MAX_FIFO);
    2b3c:	c02a                	sw	a0,0(sp)
    2b3e:	eb2ff0ef          	jal	21f0 <wj_usi_set_rxfifo_th>
    addr->USI_MODE_SEL = USI_MODE_UART;
    2b42:	4502                	lw	a0,0(sp)
    drv_irq_register(usart_priv->irq, handler);
    2b44:	45b2                	lw	a1,12(sp)
    addr->USI_MODE_SEL = USI_MODE_UART;
    2b46:	00052223          	sw	zero,4(a0)
    drv_irq_register(usart_priv->irq, handler);
    2b4a:	40c8                	lw	a0,4(s1)
    2b4c:	e94ff0ef          	jal	21e0 <drv_irq_register>
    drv_irq_enable(usart_priv->irq);
    2b50:	40c8                	lw	a0,4(s1)
    2b52:	e76ff0ef          	jal	21c8 <drv_irq_enable>
    return usart_priv;
    2b56:	bf79                	j	2af4 <drv_usi_usart_initialize+0x1c>

00002b58 <drv_usi_usart_config>:
                             uint32_t baud,
                             usart_mode_e mode,
                             usart_parity_e parity,
                             usart_stop_bits_e stopbits,
                             usart_data_bits_e bits)
{
    2b58:	1111                	addi	sp,sp,-28
    2b5a:	c826                	sw	s1,16(sp)
    int32_t ret;
    wj_usi_usart_priv_t *usart_priv = handle;
    wj_usi_reg_t *addr = (wj_usi_reg_t *)(usart_priv->base);
    2b5c:	4104                	lw	s1,0(a0)
{
    2b5e:	ca22                	sw	s0,20(sp)
    2b60:	cc06                	sw	ra,24(sp)

    addr->USI_EN = 0x0;
    2b62:	0004a023          	sw	zero,0(s1)
{
    2b66:	842a                	mv	s0,a0
    2b68:	c032                	sw	a2,0(sp)
    2b6a:	c236                	sw	a3,4(sp)
    2b6c:	c43a                	sw	a4,8(sp)
    2b6e:	c63e                	sw	a5,12(sp)
    /* control the data_bit of the usart*/
    ret = drv_usi_usart_config_baudrate(handle, baud);
    2b70:	39a1                	jal	27c8 <drv_usi_usart_config_baudrate>
    if (ret < 0) {
        return ret;
    }

    /* control the parity of the usart*/
    ret = drv_usi_usart_config_parity(handle, parity);
    2b72:	4592                	lw	a1,4(sp)
    2b74:	8522                	mv	a0,s0
    2b76:	396d                	jal	2830 <drv_usi_usart_config_parity>

    if (ret < 0) {
    2b78:	ed19                	bnez	a0,2b96 <drv_usi_usart_config+0x3e>
        return ret;
    }

    /* control mode of the usart*/
    ret = drv_usi_usart_config_mode(handle, mode);
    2b7a:	4582                	lw	a1,0(sp)
    2b7c:	8522                	mv	a0,s0
    2b7e:	3171                	jal	280a <drv_usi_usart_config_mode>

    if (ret < 0) {
    2b80:	e919                	bnez	a0,2b96 <drv_usi_usart_config+0x3e>
        return ret;
    }

    /* control the stopbit of the usart*/
    ret = drv_usi_usart_config_stopbits(handle, stopbits);
    2b82:	45a2                	lw	a1,8(sp)
    2b84:	8522                	mv	a0,s0
    2b86:	3329                	jal	2890 <drv_usi_usart_config_stopbits>

    if (ret < 0) {
    2b88:	e519                	bnez	a0,2b96 <drv_usi_usart_config+0x3e>
        return ret;
    }

    ret = drv_usi_usart_config_databits(handle, bits);
    2b8a:	45b2                	lw	a1,12(sp)
    2b8c:	8522                	mv	a0,s0
    2b8e:	3385                	jal	28ee <drv_usi_usart_config_databits>

    if (ret < 0) {
    2b90:	e119                	bnez	a0,2b96 <drv_usi_usart_config+0x3e>
        return ret;
    }

    addr->USI_EN = 0xf;
    2b92:	47bd                	li	a5,15
    2b94:	c09c                	sw	a5,0(s1)
    return 0;
}
    2b96:	40e2                	lw	ra,24(sp)
    2b98:	4452                	lw	s0,20(sp)
    2b9a:	44c2                	lw	s1,16(sp)
    2b9c:	0171                	addi	sp,sp,28
    2b9e:	8082                	ret

00002ba0 <csi_usart_putchar>:
  \param[in]   ch  the input character
  \return      error code
*/
int32_t csi_usart_putchar(usart_handle_t handle, uint8_t ch)
{
    return drv_usi_usart_putchar(handle, ch);
    2ba0:	b72d                	j	2aca <drv_usi_usart_putchar>

00002ba2 <csi_usart_initialize>:
  \param[in]   cb_event  Pointer to \ref usart_event_cb_t
  \return      return usart handle if success
*/
usart_handle_t csi_usart_initialize(int32_t idx, usart_event_cb_t cb_event)
{
    return drv_usi_usart_initialize(idx, cb_event);
    2ba2:	bf1d                	j	2ad8 <drv_usi_usart_initialize>

00002ba4 <csi_usart_config>:
                         usart_mode_e mode,
                         usart_parity_e parity,
                         usart_stop_bits_e stopbits,
                         usart_data_bits_e bits)
{
    return drv_usi_usart_config(handle, baud, mode, parity, stopbits, bits);
    2ba4:	bf55                	j	2b58 <drv_usi_usart_config>

00002ba6 <target_get_timer>:
    return CONFIG_TIMER_NUM;
}

int32_t target_get_timer(int32_t idx, uint32_t *base, uint32_t *irq, void **handler)
{
    if (idx >= target_get_timer_count()) {
    2ba6:	47bd                	li	a5,15
    2ba8:	04a7c163          	blt	a5,a0,2bea <target_get_timer+0x44>
        return -1;
    }

    if (base != NULL) {
    2bac:	c991                	beqz	a1,2bc0 <target_get_timer+0x1a>
        *base = sg_timer_config[idx].base;
    2bae:	4731                	li	a4,12
    2bb0:	02e50733          	mul	a4,a0,a4
    2bb4:	6799                	lui	a5,0x6
    2bb6:	f9078793          	addi	a5,a5,-112 # 5f90 <sg_timer_config>
    2bba:	97ba                	add	a5,a5,a4
    2bbc:	439c                	lw	a5,0(a5)
    2bbe:	c19c                	sw	a5,0(a1)
    }

    if (irq != NULL) {
    2bc0:	ca11                	beqz	a2,2bd4 <target_get_timer+0x2e>
        *irq = sg_timer_config[idx].irq;
    2bc2:	4731                	li	a4,12
    2bc4:	02e50733          	mul	a4,a0,a4
    2bc8:	6799                	lui	a5,0x6
    2bca:	f9078793          	addi	a5,a5,-112 # 5f90 <sg_timer_config>
    2bce:	97ba                	add	a5,a5,a4
    2bd0:	43dc                	lw	a5,4(a5)
    2bd2:	c21c                	sw	a5,0(a2)
    }

    if (handler != NULL) {
    2bd4:	ce81                	beqz	a3,2bec <target_get_timer+0x46>
        *handler = sg_timer_config[idx].handler;
    2bd6:	4731                	li	a4,12
    2bd8:	02e50733          	mul	a4,a0,a4
    2bdc:	6799                	lui	a5,0x6
    2bde:	f9078793          	addi	a5,a5,-112 # 5f90 <sg_timer_config>
    2be2:	97ba                	add	a5,a5,a4
    2be4:	479c                	lw	a5,8(a5)
    2be6:	c29c                	sw	a5,0(a3)
    2be8:	8082                	ret
        return -1;
    2bea:	557d                	li	a0,-1
    }

    return idx;
}
    2bec:	8082                	ret

00002bee <target_usi_init>:
    {WJ_USI2_BASE, USI2_IRQn, USI2_IRQHandler},
};

int32_t target_usi_init(int32_t idx, uint32_t *base, uint32_t *irq)
{
    if (idx >= CONFIG_USI_NUM) {
    2bee:	4789                	li	a5,2
    2bf0:	02a7c763          	blt	a5,a0,2c1e <target_usi_init+0x30>
        return -1;
    }

    if (base != NULL) {
    2bf4:	c991                	beqz	a1,2c08 <target_usi_init+0x1a>
        *base = sg_usi_config[idx].base;
    2bf6:	4731                	li	a4,12
    2bf8:	02e50733          	mul	a4,a0,a4
    2bfc:	6799                	lui	a5,0x6
    2bfe:	f6c78793          	addi	a5,a5,-148 # 5f6c <sg_usi_config>
    2c02:	97ba                	add	a5,a5,a4
    2c04:	439c                	lw	a5,0(a5)
    2c06:	c19c                	sw	a5,0(a1)
    }

    if (irq != NULL) {
    2c08:	ce01                	beqz	a2,2c20 <target_usi_init+0x32>
        *irq = sg_usi_config[idx].irq;
    2c0a:	4731                	li	a4,12
    2c0c:	02e50733          	mul	a4,a0,a4
    2c10:	6799                	lui	a5,0x6
    2c12:	f6c78793          	addi	a5,a5,-148 # 5f6c <sg_usi_config>
    2c16:	97ba                	add	a5,a5,a4
    2c18:	43dc                	lw	a5,4(a5)
    2c1a:	c21c                	sw	a5,0(a2)
    2c1c:	8082                	ret
        return -1;
    2c1e:	557d                	li	a0,-1
    }

    return idx;
}
    2c20:	8082                	ret

00002c22 <target_usi_usart_init>:

int32_t target_usi_usart_init(int32_t idx, uint32_t *base, uint32_t *irq, void **handler)
{
    if (idx >= CONFIG_USI_SPI_NUM) {
    2c22:	4789                	li	a5,2
    2c24:	04a7c163          	blt	a5,a0,2c66 <target_usi_usart_init+0x44>
        return -1;
    }

    if (base != NULL) {
    2c28:	c991                	beqz	a1,2c3c <target_usi_usart_init+0x1a>
        *base = sg_usi_config[idx].base;
    2c2a:	4731                	li	a4,12
    2c2c:	02e50733          	mul	a4,a0,a4
    2c30:	6799                	lui	a5,0x6
    2c32:	f6c78793          	addi	a5,a5,-148 # 5f6c <sg_usi_config>
    2c36:	97ba                	add	a5,a5,a4
    2c38:	439c                	lw	a5,0(a5)
    2c3a:	c19c                	sw	a5,0(a1)
    }

    if (irq != NULL) {
    2c3c:	ca11                	beqz	a2,2c50 <target_usi_usart_init+0x2e>
        *irq = sg_usi_config[idx].irq;
    2c3e:	4731                	li	a4,12
    2c40:	02e50733          	mul	a4,a0,a4
    2c44:	6799                	lui	a5,0x6
    2c46:	f6c78793          	addi	a5,a5,-148 # 5f6c <sg_usi_config>
    2c4a:	97ba                	add	a5,a5,a4
    2c4c:	43dc                	lw	a5,4(a5)
    2c4e:	c21c                	sw	a5,0(a2)
    }

    if (handler != NULL) {
    2c50:	ce81                	beqz	a3,2c68 <target_usi_usart_init+0x46>
        *handler = sg_usi_config[idx].handler;
    2c52:	4731                	li	a4,12
    2c54:	02e50733          	mul	a4,a0,a4
    2c58:	6799                	lui	a5,0x6
    2c5a:	f6c78793          	addi	a5,a5,-148 # 5f6c <sg_usi_config>
    2c5e:	97ba                	add	a5,a5,a4
    2c60:	479c                	lw	a5,8(a5)
    2c62:	c29c                	sw	a5,0(a3)
    2c64:	8082                	ret
        return -1;
    2c66:	557d                	li	a0,-1
    }

    return idx;
}
    2c68:	8082                	ret

00002c6a <csi_gpio_pin_write>:
  \param[in]   value     the value to be set
  \return      error code
*/
int32_t csi_gpio_pin_write(gpio_pin_handle_t handle, bool value)
{
    GPIO_NULL_PARAM_CHK(handle);
    2c6a:	cd05                	beqz	a0,2ca2 <csi_gpio_pin_write+0x38>

    wj_oip_gpio_pin_priv_t *gpio_pin_priv = handle;

    /* convert portidx to port handle */
    wj_oip_gpio_priv_t *port_handle = &gpio_handle[gpio_pin_priv->portidx];
    2c6c:	00054703          	lbu	a4,0(a0)

    uint8_t offset = gpio_pin_priv->idx;
    uint32_t port_value = value << offset;

    port_handle->value = port_value;
    2c70:	4671                	li	a2,28
    2c72:	200027b7          	lui	a5,0x20002
    2c76:	02c70733          	mul	a4,a4,a2
    2c7a:	9e478793          	addi	a5,a5,-1564 # 200019e4 <gpio_handle>
    uint32_t port_value = value << offset;
    2c7e:	00154683          	lbu	a3,1(a0)
    gpio_write(port_handle, (1 << offset));

    return 0;
    2c82:	4501                	li	a0,0
    uint32_t port_value = value << offset;
    2c84:	00d595b3          	sll	a1,a1,a3
    port_handle->value = port_value;
    2c88:	97ba                	add	a5,a5,a4
    wj_oip_gpio_reg_t *gpio_reg = (wj_oip_gpio_reg_t *)(gpio_priv->base);
    2c8a:	4398                	lw	a4,0(a5)
    port_handle->value = port_value;
    2c8c:	cf8c                	sw	a1,24(a5)
    gpio_write(port_handle, (1 << offset));
    2c8e:	4785                	li	a5,1
    uint32_t value = gpio_reg->SWPORT_DR;
    2c90:	4310                	lw	a2,0(a4)
    gpio_write(port_handle, (1 << offset));
    2c92:	00d797b3          	sll	a5,a5,a3
    value &= ~(mask);
    2c96:	fff7c793          	not	a5,a5
    2c9a:	8ff1                	and	a5,a5,a2
    value |= gpio_priv->value;
    2c9c:	8ddd                	or	a1,a1,a5
    gpio_reg->SWPORT_DR = value;
    2c9e:	c30c                	sw	a1,0(a4)
    return 0;
    2ca0:	8082                	ret
    GPIO_NULL_PARAM_CHK(handle);
    2ca2:	81010537          	lui	a0,0x81010
    2ca6:	08450513          	addi	a0,a0,132 # 81010084 <__heap_end+0x60fe0084>

}
    2caa:	8082                	ret

00002cac <wj_oip_timer_irqhandler>:

// timer global interrupt handler
void wj_oip_timer_irqhandler(int idx)
{
    wj_oip_timer_priv_t *timer_priv = &timer_instance[idx];
    timer_priv->timeout_flag = 1;
    2cac:	4761                	li	a4,24
    2cae:	02e50733          	mul	a4,a0,a4
    2cb2:	200027b7          	lui	a5,0x20002
    2cb6:	a0078793          	addi	a5,a5,-1536 # 20001a00 <timer_instance>
    2cba:	97ba                	add	a5,a5,a4
    2cbc:	4705                	li	a4,1
    2cbe:	cbd8                	sw	a4,20(a5)

    wj_oip_timer_reg_t *addr = (wj_oip_timer_reg_t *)(timer_priv->base);
    2cc0:	43d8                	lw	a4,4(a5)

    addr->TxEOI;

    if (timer_priv->cb_event) {
    2cc2:	47dc                	lw	a5,12(a5)
    addr->TxEOI;
    2cc4:	4758                	lw	a4,12(a4)
    if (timer_priv->cb_event) {
    2cc6:	c399                	beqz	a5,2ccc <wj_oip_timer_irqhandler+0x20>
        return timer_priv->cb_event(idx, TIMER_EVENT_TIMEOUT);
    2cc8:	4581                	li	a1,0
    2cca:	8782                	jr	a5
    }
	
}
    2ccc:	8082                	ret

00002cce <csi_timer_initialize>:
  \param[in]   idx  instance timer index
  \param[in]   cb_event  Pointer to \ref timer_event_cb_t
  \return      pointer to timer instance
*/
timer_handle_t csi_timer_initialize(int32_t idx, timer_event_cb_t cb_event)
{
    2cce:	1111                	addi	sp,sp,-28
    2cd0:	cc06                	sw	ra,24(sp)
    2cd2:	ca22                	sw	s0,20(sp)
    2cd4:	c826                	sw	s1,16(sp)
    if (idx < 0 || idx >= CONFIG_TIMER_NUM) {
    2cd6:	47bd                	li	a5,15
    2cd8:	00a7f963          	bgeu	a5,a0,2cea <csi_timer_initialize+0x1c>
        return NULL;
    2cdc:	4401                	li	s0,0
        drv_irq_register(timer_priv->irq, handler);
        drv_irq_enable(timer_priv->irq);
    }

    return (timer_handle_t)timer_priv;
}
    2cde:	40e2                	lw	ra,24(sp)
    2ce0:	8522                	mv	a0,s0
    2ce2:	4452                	lw	s0,20(sp)
    2ce4:	44c2                	lw	s1,16(sp)
    2ce6:	0171                	addi	sp,sp,28
    2ce8:	8082                	ret
    2cea:	84ae                	mv	s1,a1
    int32_t real_idx = target_get_timer(idx, &base, &irq, &handler);
    2cec:	0074                	addi	a3,sp,12
    2cee:	0030                	addi	a2,sp,8
    2cf0:	004c                	addi	a1,sp,4
    2cf2:	c02a                	sw	a0,0(sp)
    uint32_t base = 0u;
    2cf4:	c202                	sw	zero,4(sp)
    uint32_t irq = 0u;
    2cf6:	c402                	sw	zero,8(sp)
    int32_t real_idx = target_get_timer(idx, &base, &irq, &handler);
    2cf8:	357d                	jal	2ba6 <target_get_timer>
    if (real_idx != idx) {
    2cfa:	4702                	lw	a4,0(sp)
    2cfc:	fea710e3          	bne	a4,a0,2cdc <csi_timer_initialize+0xe>
    wj_oip_timer_priv_t *timer_priv = &timer_instance[idx];
    2d00:	4461                	li	s0,24
    2d02:	02870433          	mul	s0,a4,s0
    2d06:	200027b7          	lui	a5,0x20002
    2d0a:	a0078793          	addi	a5,a5,-1536 # 20001a00 <timer_instance>
    timer_priv->irq  = irq;
    2d0e:	46a2                	lw	a3,8(sp)
    timer_priv->timeout = WJ_OIP_TIMER_INIT_DEFAULT_VALUE;
    2d10:	4501                	li	a0,0
    wj_oip_timer_priv_t *timer_priv = &timer_instance[idx];
    2d12:	943e                	add	s0,s0,a5
    timer_priv->base = base;
    2d14:	4792                	lw	a5,4(sp)
    timer_priv->irq  = irq;
    2d16:	c414                	sw	a3,8(s0)
    timer_priv->idx = idx;
    2d18:	00e40023          	sb	a4,0(s0)
    timer_priv->base = base;
    2d1c:	c05c                	sw	a5,4(s0)
    2d1e:	c03e                	sw	a5,0(sp)
    timer_priv->timeout = WJ_OIP_TIMER_INIT_DEFAULT_VALUE;
    2d20:	2b4d                	jal	32d2 <drv_get_timer_freq>
    2d22:	577d                	li	a4,-1
    2d24:	02a75733          	divu	a4,a4,a0
    2d28:	000f46b7          	lui	a3,0xf4
    2d2c:	24068693          	addi	a3,a3,576 # f4240 <__ctor_end__+0xed680>
    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_ENABLE;
    2d30:	4782                	lw	a5,0(sp)
    timer_priv->timeout = WJ_OIP_TIMER_INIT_DEFAULT_VALUE;
    2d32:	02d70733          	mul	a4,a4,a3
    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_ENABLE;
    2d36:	4794                	lw	a3,8(a5)
    2d38:	8af9                	andi	a3,a3,30
    timer_priv->timeout = WJ_OIP_TIMER_INIT_DEFAULT_VALUE;
    2d3a:	c818                	sw	a4,16(s0)
    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_ENABLE;
    2d3c:	0087c703          	lbu	a4,8(a5)
    2d40:	9b01                	andi	a4,a4,-32
    2d42:	8f55                	or	a4,a4,a3
    2d44:	00e78423          	sb	a4,8(a5)
    addr->TxControl |= WJ_OIP_TIMER_TXCONTROL_INTMASK;
    2d48:	4794                	lw	a3,8(a5)
    2d4a:	0087c703          	lbu	a4,8(a5)
    2d4e:	8afd                	andi	a3,a3,31
    2d50:	0046e693          	ori	a3,a3,4
    2d54:	9b01                	andi	a4,a4,-32
    2d56:	8f55                	or	a4,a4,a3
    2d58:	00e78423          	sb	a4,8(a5)
    timer_priv->cb_event = cb_event;
    2d5c:	c444                	sw	s1,12(s0)
    if (cb_event != NULL) {
    2d5e:	d0c1                	beqz	s1,2cde <csi_timer_initialize+0x10>
        drv_irq_register(timer_priv->irq, handler);
    2d60:	4408                	lw	a0,8(s0)
    2d62:	45b2                	lw	a1,12(sp)
    2d64:	c7cff0ef          	jal	21e0 <drv_irq_register>
        drv_irq_enable(timer_priv->irq);
    2d68:	4408                	lw	a0,8(s0)
    2d6a:	c5eff0ef          	jal	21c8 <drv_irq_enable>
    2d6e:	bf85                	j	2cde <csi_timer_initialize+0x10>

00002d70 <csi_timer_config>:
  \param[in]   mode      \ref timer_mode_e
  \return      error code
*/
int32_t csi_timer_config(timer_handle_t handle, timer_mode_e mode)
{
    TIMER_NULL_PARAM_CHK(handle);
    2d70:	c511                	beqz	a0,2d7c <csi_timer_config+0xc>

    wj_oip_timer_priv_t *timer_priv = handle;
    wj_oip_timer_reg_t *addr = (wj_oip_timer_reg_t *)(timer_priv->base);
    2d72:	415c                	lw	a5,4(a0)

    switch (mode) {
    2d74:	c989                	beqz	a1,2d86 <csi_timer_config+0x16>
    2d76:	4705                	li	a4,1
    2d78:	02e58b63          	beq	a1,a4,2dae <csi_timer_config+0x3e>
    2d7c:	81070537          	lui	a0,0x81070
    2d80:	08450513          	addi	a0,a0,132 # 81070084 <__heap_end+0x61040084>
    }

    addr->TxControl |= (WJ_OIP_TIMER_TXCONTROL_TRIGGER);

    return 0;
}
    2d84:	8082                	ret
            addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_MODE;
    2d86:	4794                	lw	a3,8(a5)
    2d88:	8af5                	andi	a3,a3,29
            addr->TxControl |= WJ_OIP_TIMER_TXCONTROL_MODE;
    2d8a:	0087c703          	lbu	a4,8(a5)
    return 0;
    2d8e:	4501                	li	a0,0
            addr->TxControl |= WJ_OIP_TIMER_TXCONTROL_MODE;
    2d90:	9b01                	andi	a4,a4,-32
    2d92:	8f55                	or	a4,a4,a3
    2d94:	00e78423          	sb	a4,8(a5)
    addr->TxControl |= (WJ_OIP_TIMER_TXCONTROL_TRIGGER);
    2d98:	4794                	lw	a3,8(a5)
    2d9a:	0087c703          	lbu	a4,8(a5)
    2d9e:	8afd                	andi	a3,a3,31
    2da0:	0106e693          	ori	a3,a3,16
    2da4:	9b01                	andi	a4,a4,-32
    2da6:	8f55                	or	a4,a4,a3
    2da8:	00e78423          	sb	a4,8(a5)
    return 0;
    2dac:	8082                	ret
            addr->TxControl |= WJ_OIP_TIMER_TXCONTROL_MODE;
    2dae:	4794                	lw	a3,8(a5)
    2db0:	8afd                	andi	a3,a3,31
    2db2:	0026e693          	ori	a3,a3,2
    2db6:	bfd1                	j	2d8a <csi_timer_config+0x1a>

00002db8 <csi_timer_set_timeout>:
  \param[in]   timeout the timeout value in microseconds(us).
  \return      error code
*/
int32_t csi_timer_set_timeout(timer_handle_t handle, uint32_t timeout)
{
    TIMER_NULL_PARAM_CHK(handle);
    2db8:	c501                	beqz	a0,2dc0 <csi_timer_set_timeout+0x8>

    wj_oip_timer_priv_t *timer_priv = handle;
    timer_priv->timeout = timeout;
    2dba:	c90c                	sw	a1,16(a0)
    return 0;
    2dbc:	4501                	li	a0,0
    2dbe:	8082                	ret
    TIMER_NULL_PARAM_CHK(handle);
    2dc0:	81070537          	lui	a0,0x81070
    2dc4:	08450513          	addi	a0,a0,132 # 81070084 <__heap_end+0x61040084>
}
    2dc8:	8082                	ret

00002dca <csi_timer_start>:
  \return      error code
*/

int32_t csi_timer_start(timer_handle_t handle)
{
    TIMER_NULL_PARAM_CHK(handle);
    2dca:	c155                	beqz	a0,2e6e <csi_timer_start+0xa4>
{
    2dcc:	1141                	addi	sp,sp,-16
    2dce:	c606                	sw	ra,12(sp)
    2dd0:	c422                	sw	s0,8(sp)
    2dd2:	c226                	sw	s1,4(sp)
    2dd4:	842a                	mv	s0,a0

    wj_oip_timer_priv_t *timer_priv = handle;

    timer_priv->timeout_flag = 0;
    2dd6:	00052a23          	sw	zero,20(a0)

    uint32_t min_us = drv_get_timer_freq(timer_priv->idx) / 1000000;
    2dda:	00054503          	lbu	a0,0(a0)
    2dde:	29d5                	jal	32d2 <drv_get_timer_freq>
    2de0:	000f47b7          	lui	a5,0xf4
    2de4:	24078793          	addi	a5,a5,576 # f4240 <__ctor_end__+0xed680>
    2de8:	02f544b3          	div	s1,a0,a5
    uint32_t load;

    if (((timer_priv->timeout * drv_get_timer_freq(timer_priv->idx)) / 1000000) > 0xffffffff) {
    2dec:	00044503          	lbu	a0,0(s0)
    2df0:	21cd                	jal	32d2 <drv_get_timer_freq>
        return ERR_TIMER(DRV_ERROR_PARAMETER);
    }

    if (min_us) {
        load = (uint32_t)(timer_priv->timeout * min_us);
    2df2:	481c                	lw	a5,16(s0)
    2df4:	02f48533          	mul	a0,s1,a5
    if (min_us) {
    2df8:	e08d                	bnez	s1,2e1a <csi_timer_start+0x50>
    } else {
        load = (uint32_t)(((uint64_t)(timer_priv->timeout) * drv_get_timer_freq(timer_priv->idx)) / 1000000);
    2dfa:	00044503          	lbu	a0,0(s0)
    2dfe:	c03e                	sw	a5,0(sp)
    2e00:	29c9                	jal	32d2 <drv_get_timer_freq>
    2e02:	4782                	lw	a5,0(sp)
    2e04:	000f4637          	lui	a2,0xf4
    2e08:	24060613          	addi	a2,a2,576 # f4240 <__ctor_end__+0xed680>
    2e0c:	4681                	li	a3,0
    2e0e:	02f525b3          	mulhsu	a1,a0,a5
    2e12:	02a78533          	mul	a0,a5,a0
    2e16:	be0fd0ef          	jal	1f6 <__udivdi3>
    }

    wj_oip_timer_reg_t *addr = (wj_oip_timer_reg_t *)(timer_priv->base);

    if (timer_priv->timeout == 0) {
    2e1a:	4818                	lw	a4,16(s0)
    wj_oip_timer_reg_t *addr = (wj_oip_timer_reg_t *)(timer_priv->base);
    2e1c:	405c                	lw	a5,4(s0)
    if (timer_priv->timeout == 0) {
    2e1e:	e339                	bnez	a4,2e64 <csi_timer_start+0x9a>
        addr->TxLoadCount = 0xffffffff;                           /* load time(us) */
    } else {
        if ((addr->TxControl | 0x2) == 0x2) {
            addr->TxLoadCount = 0xffffffff;                           /* load time(us) */
    2e20:	577d                	li	a4,-1
    2e22:	c398                	sw	a4,0(a5)
        } else {
            addr->TxLoadCount = load;                           /* load time(us) */
        }
    }

    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_ENABLE;      /* disable the timer */
    2e24:	4794                	lw	a3,8(a5)
    2e26:	0087c703          	lbu	a4,8(a5)
    }

#endif

    return 0;
}
    2e2a:	40b2                	lw	ra,12(sp)
    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_ENABLE;      /* disable the timer */
    2e2c:	8af9                	andi	a3,a3,30
    2e2e:	9b01                	andi	a4,a4,-32
    2e30:	8f55                	or	a4,a4,a3
    2e32:	00e78423          	sb	a4,8(a5)
    addr->TxControl |= WJ_OIP_TIMER_TXCONTROL_ENABLE;       /* enable the corresponding timer */
    2e36:	4794                	lw	a3,8(a5)
    2e38:	0087c703          	lbu	a4,8(a5)
}
    2e3c:	4422                	lw	s0,8(sp)
    addr->TxControl |= WJ_OIP_TIMER_TXCONTROL_ENABLE;       /* enable the corresponding timer */
    2e3e:	8afd                	andi	a3,a3,31
    2e40:	0016e693          	ori	a3,a3,1
    2e44:	9b01                	andi	a4,a4,-32
    2e46:	8f55                	or	a4,a4,a3
    2e48:	00e78423          	sb	a4,8(a5)
    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_INTMASK;     /* enable interrupt */
    2e4c:	4794                	lw	a3,8(a5)
    2e4e:	0087c703          	lbu	a4,8(a5)
}
    2e52:	4492                	lw	s1,4(sp)
    addr->TxControl &= ~WJ_OIP_TIMER_TXCONTROL_INTMASK;     /* enable interrupt */
    2e54:	8aed                	andi	a3,a3,27
    2e56:	9b01                	andi	a4,a4,-32
    2e58:	8f55                	or	a4,a4,a3
    2e5a:	00e78423          	sb	a4,8(a5)
    return 0;
    2e5e:	4501                	li	a0,0
}
    2e60:	0141                	addi	sp,sp,16
    2e62:	8082                	ret
        if ((addr->TxControl | 0x2) == 0x2) {
    2e64:	4798                	lw	a4,8(a5)
    2e66:	8b75                	andi	a4,a4,29
    2e68:	df45                	beqz	a4,2e20 <csi_timer_start+0x56>
            addr->TxLoadCount = load;                           /* load time(us) */
    2e6a:	c388                	sw	a0,0(a5)
    2e6c:	bf65                	j	2e24 <csi_timer_start+0x5a>
    TIMER_NULL_PARAM_CHK(handle);
    2e6e:	81070537          	lui	a0,0x81070
    2e72:	08450513          	addi	a0,a0,132 # 81070084 <__heap_end+0x61040084>
}
    2e76:	8082                	ret

00002e78 <csi_timer_get_current_value>:
  \param[out]   value     timer current value
  \return      error code
*/
int32_t csi_timer_get_current_value(timer_handle_t handle, uint32_t *value)
{
    TIMER_NULL_PARAM_CHK(handle);
    2e78:	c519                	beqz	a0,2e86 <csi_timer_get_current_value+0xe>
    TIMER_NULL_PARAM_CHK(value);
    2e7a:	c591                	beqz	a1,2e86 <csi_timer_get_current_value+0xe>

    wj_oip_timer_priv_t *timer_priv = handle;
    wj_oip_timer_reg_t *addr = (wj_oip_timer_reg_t *)(timer_priv->base);
    2e7c:	415c                	lw	a5,4(a0)

    *value = addr->TxCurrentValue;
    return 0;
    2e7e:	4501                	li	a0,0
    *value = addr->TxCurrentValue;
    2e80:	43dc                	lw	a5,4(a5)
    2e82:	c19c                	sw	a5,0(a1)
    return 0;
    2e84:	8082                	ret
    TIMER_NULL_PARAM_CHK(handle);
    2e86:	81070537          	lui	a0,0x81070
    2e8a:	08450513          	addi	a0,a0,132 # 81070084 <__heap_end+0x61040084>
}
    2e8e:	8082                	ret

00002e90 <TIM0_IRQHandler>:
			
		}
	}
	 */
	
	time_flag_count++;
    2e90:	0981a783          	lw	a5,152(gp) # 20000580 <time_flag_count>
    2e94:	0785                	addi	a5,a5,1
    2e96:	08f1ac23          	sw	a5,152(gp) # 20000580 <time_flag_count>
	
	
	
	
	if(TimeInitial==1){
    2e9a:	0561c783          	lbu	a5,86(gp) # 2000053e <TimeInitial>
    2e9e:	4705                	li	a4,1
    2ea0:	3ae79463          	bne	a5,a4,3248 <TIM0_IRQHandler+0x3b8>
{
    2ea4:	1141                	addi	sp,sp,-16
    2ea6:	c606                	sw	ra,12(sp)
    2ea8:	c422                	sw	s0,8(sp)
    2eaa:	c226                	sw	s1,4(sp)
    2eac:	0ff7f613          	zext.b	a2,a5
		//pickupCL  Cluth_REG[1]
		//RegiCL    Cluth_REG[0]
		//Fuser_SOL Cluth_REG[2]
		//flag++;
		/////////////////////////////////// SENS_Regi /////////////////////////////////////////////
		SENS_Regi[0] = SENS_Regi[1];
    2eb0:	01818793          	addi	a5,gp,24 # 20000500 <SENS_Regi>
    2eb4:	0017c683          	lbu	a3,1(a5)
    2eb8:	0ff6f693          	zext.b	a3,a3
    2ebc:	00d18c23          	sb	a3,24(gp) # 20000500 <SENS_Regi>
		SENS_Regi[1] = ((*SENS_REG & SENS_REGI_BIT) > 0) ? 1 : 0;
    2ec0:	600186b7          	lui	a3,0x60018
    2ec4:	4ed4                	lw	a3,28(a3)
    2ec6:	8a85                	andi	a3,a3,1
    2ec8:	00d780a3          	sb	a3,1(a5)

		if (SENS_Regi[0] == 1 && SENS_Regi[1] == 0)
    2ecc:	0181c683          	lbu	a3,24(gp) # 20000500 <SENS_Regi>
    2ed0:	0ff6f593          	zext.b	a1,a3
    2ed4:	22c69e63          	bne	a3,a2,3110 <TIM0_IRQHandler+0x280>
    2ed8:	0017c683          	lbu	a3,1(a5)
    2edc:	22069a63          	bnez	a3,3110 <TIM0_IRQHandler+0x280>
		{
			SENS_RegiLflag = 1;
    2ee0:	06b18c23          	sb	a1,120(gp) # 20000560 <SENS_RegiLflag>
		{
			SENS_RegiHflag = 1;
		}
		
		///////////////////////////////////// SENS_Feed /////////////////////////////////////////////
		SENS_Feed[0] = SENS_Feed[1];
    2ee4:	01418713          	addi	a4,gp,20 # 200004fc <SENS_Feed>
    2ee8:	00174783          	lbu	a5,1(a4)
		SENS_Feed[1] = ((*SENS_REG & SENS_FEED_BIT) > 0) ? 1 : 0;

		if (SENS_Feed[0] == 1 && SENS_Feed[1] == 0)
    2eec:	4585                	li	a1,1
		SENS_Feed[0] = SENS_Feed[1];
    2eee:	0ff7f793          	zext.b	a5,a5
    2ef2:	00f18a23          	sb	a5,20(gp) # 200004fc <SENS_Feed>
		SENS_Feed[1] = ((*SENS_REG & SENS_FEED_BIT) > 0) ? 1 : 0;
    2ef6:	600187b7          	lui	a5,0x60018
    2efa:	4fdc                	lw	a5,28(a5)
    2efc:	8385                	srli	a5,a5,0x1
    2efe:	8b85                	andi	a5,a5,1
    2f00:	00f700a3          	sb	a5,1(a4)
		if (SENS_Feed[0] == 1 && SENS_Feed[1] == 0)
    2f04:	0141c783          	lbu	a5,20(gp) # 200004fc <SENS_Feed>
    2f08:	0ff7f613          	zext.b	a2,a5
    2f0c:	22b79063          	bne	a5,a1,312c <TIM0_IRQHandler+0x29c>
    2f10:	00174783          	lbu	a5,1(a4)
    2f14:	20079c63          	bnez	a5,312c <TIM0_IRQHandler+0x29c>
		{
			SENS_FeedLflag = 1;
    2f18:	06c18b23          	sb	a2,118(gp) # 2000055e <SENS_FeedLflag>
		{
			SENS_FeedHflag = 1;
		}
		
		///////////////////////////////////// SENS_Exit /////////////////////////////////////////////
		SENS_Exit[0] = SENS_Exit[1];
    2f1c:	01018713          	addi	a4,gp,16 # 200004f8 <SENS_Exit>
    2f20:	00174783          	lbu	a5,1(a4)
		SENS_Exit[1] = ((*SENS_REG & SENS_EXIT_BIT) > 0) ? 1 : 0;

		if (SENS_Exit[0] == 1 && SENS_Exit[1] == 0)
    2f24:	4585                	li	a1,1
		SENS_Exit[0] = SENS_Exit[1];
    2f26:	0ff7f793          	zext.b	a5,a5
    2f2a:	00f18823          	sb	a5,16(gp) # 200004f8 <SENS_Exit>
		SENS_Exit[1] = ((*SENS_REG & SENS_EXIT_BIT) > 0) ? 1 : 0;
    2f2e:	600187b7          	lui	a5,0x60018
    2f32:	4fdc                	lw	a5,28(a5)
    2f34:	8389                	srli	a5,a5,0x2
    2f36:	8b85                	andi	a5,a5,1
    2f38:	00f700a3          	sb	a5,1(a4)
		if (SENS_Exit[0] == 1 && SENS_Exit[1] == 0)
    2f3c:	0101c783          	lbu	a5,16(gp) # 200004f8 <SENS_Exit>
    2f40:	0ff7f613          	zext.b	a2,a5
    2f44:	20b79263          	bne	a5,a1,3148 <TIM0_IRQHandler+0x2b8>
    2f48:	00174783          	lbu	a5,1(a4)
    2f4c:	1e079e63          	bnez	a5,3148 <TIM0_IRQHandler+0x2b8>
		{
			SENS_ExitLflag = 1;
    2f50:	06c18a23          	sb	a2,116(gp) # 2000055c <SENS_ExitLflag>
//			}
//		}
		
		
		//Page_SYNC 脉宽控制逻辑 ---
		if (PageSync_Enable == 1) {
    2f54:	0501a703          	lw	a4,80(gp) # 20000538 <PageSync_Enable>
    2f58:	4785                	li	a5,1
    2f5a:	20f71563          	bne	a4,a5,3164 <TIM0_IRQHandler+0x2d4>
			PageSync_Timer++;    
    2f5e:	04c1a783          	lw	a5,76(gp) # 20000534 <PageSync_Timer>
    2f62:	0785                	addi	a5,a5,1 # 60018001 <__heap_end+0x3ffe8001>
    2f64:	04f1a623          	sw	a5,76(gp) # 20000534 <PageSync_Timer>
    // 满 10ms 后拉低信号并停止计时
			if (PageSync_Timer >= 10) { 
    2f68:	04c1a683          	lw	a3,76(gp) # 20000534 <PageSync_Timer>
    2f6c:	47a5                	li	a5,9
    2f6e:	02d7de63          	bge	a5,a3,2faa <TIM0_IRQHandler+0x11a>
    2f72:	c03a                	sw	a4,0(sp)
				Page_Sync_Close();   // 拉低 Page_SYNC 信号
    2f74:	4ea010ef          	jal	445e <Page_Sync_Close>
				PageSync_Enable = 0; //关闭 Enable
    2f78:	0401a823          	sw	zero,80(gp) # 20000538 <PageSync_Enable>
				PageSync_Timer = 0;  // 计数器清零
    2f7c:	0401a623          	sw	zero,76(gp) # 20000534 <PageSync_Timer>
				Page_sync_printed++; 
    2f80:	0a41d783          	lhu	a5,164(gp) # 2000058c <Page_sync_printed>
				Page_sync_print = *PrintPage_REG & 0x000F;
    2f84:	600186b7          	lui	a3,0x60018
				Page_sync_printed++; 
    2f88:	0785                	addi	a5,a5,1
    2f8a:	07c2                	slli	a5,a5,0x10
    2f8c:	83c1                	srli	a5,a5,0x10
    2f8e:	0af19223          	sh	a5,164(gp) # 2000058c <Page_sync_printed>
				Page_sync_print = *PrintPage_REG & 0x000F;
    2f92:	469c                	lw	a5,8(a3)
				StopPrint = (*PrintCtrl_REG & 0x0008) > 0 ? 1 : 0;
				Next_Page_Sync_Enable=1;
    2f94:	4702                	lw	a4,0(sp)
				Page_sync_print = *PrintPage_REG & 0x000F;
    2f96:	8bbd                	andi	a5,a5,15
    2f98:	0af19123          	sh	a5,162(gp) # 2000058a <Page_sync_print>
				StopPrint = (*PrintCtrl_REG & 0x0008) > 0 ? 1 : 0;
    2f9c:	4a9c                	lw	a5,16(a3)
    2f9e:	838d                	srli	a5,a5,0x3
    2fa0:	8b85                	andi	a5,a5,1
    2fa2:	0af18d23          	sb	a5,186(gp) # 200005a2 <StopPrint>
				Next_Page_Sync_Enable=1;
    2fa6:	0ae19023          	sh	a4,160(gp) # 20000588 <Next_Page_Sync_Enable>
    // --- 如果 PageSync_Enable 为 0 (空闲状态) ---
			Page_Sync_Close(); 
			PageSync_Timer = 0; 
		}
		
	if (Page_sync_printed==1) {
    2faa:	0a41d783          	lhu	a5,164(gp) # 2000058c <Page_sync_printed>
    2fae:	4705                	li	a4,1
    2fb0:	01079613          	slli	a2,a5,0x10
    2fb4:	8241                	srli	a2,a2,0x10
    2fb6:	04e79263          	bne	a5,a4,2ffa <TIM0_IRQHandler+0x16a>
		if (Next_Page_Sync_Enable==1) {
    2fba:	0a01d783          	lhu	a5,160(gp) # 20000588 <Next_Page_Sync_Enable>
    2fbe:	00c79963          	bne	a5,a2,2fd0 <TIM0_IRQHandler+0x140>
			Next_Page_Sync_Timer++;
    2fc2:	09e1d783          	lhu	a5,158(gp) # 20000586 <Next_Page_Sync_Timer>
    2fc6:	0785                	addi	a5,a5,1
    2fc8:	07c2                	slli	a5,a5,0x10
    2fca:	83c1                	srli	a5,a5,0x10
    2fcc:	08f19f23          	sh	a5,158(gp) # 20000586 <Next_Page_Sync_Timer>
		}
		if (Next_Page_Sync_Timer==2016) {
    2fd0:	09e1d603          	lhu	a2,158(gp) # 20000586 <Next_Page_Sync_Timer>
    2fd4:	7e000793          	li	a5,2016
    2fd8:	02f61163          	bne	a2,a5,2ffa <TIM0_IRQHandler+0x16a>
			if (Page_sync_printed < Page_sync_print){
    2fdc:	0a41d603          	lhu	a2,164(gp) # 2000058c <Page_sync_printed>
    2fe0:	0a21d783          	lhu	a5,162(gp) # 2000058a <Page_sync_print>
    2fe4:	00f67b63          	bgeu	a2,a5,2ffa <TIM0_IRQHandler+0x16a>
				Page_Sync_ON();      // 提前开启下一页的信号
    2fe8:	46a010ef          	jal	4452 <Page_Sync_ON>
				PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
    2fec:	4785                	li	a5,1
    2fee:	04f1a823          	sw	a5,80(gp) # 20000538 <PageSync_Enable>
				Next_Page_Sync_Timer = 0;  // 清零，准备算10ms
    2ff2:	08019f23          	sh	zero,158(gp) # 20000586 <Next_Page_Sync_Timer>
				Next_Page_Sync_Enable=0;
    2ff6:	0a019023          	sh	zero,160(gp) # 20000588 <Next_Page_Sync_Enable>
	
		/////////////开始动作//////////
		
/////////////regCL关的时间////////////如果未来能够使得两个电机速度一样 就可以由传感器上升沿关闭对齐离合
		
		if(SENS_RegiHflag==1){
    2ffa:	0791c683          	lbu	a3,121(gp) # 20000561 <SENS_RegiHflag>
    2ffe:	4705                	li	a4,1
    3000:	00e69763          	bne	a3,a4,300e <TIM0_IRQHandler+0x17e>
				//printf("SENS_RegiHflag==1\n");	
				SENS_RegiH_timer++;
    3004:	0601a703          	lw	a4,96(gp) # 20000548 <SENS_RegiH_timer>
    3008:	0705                	addi	a4,a4,1
    300a:	06e1a023          	sw	a4,96(gp) # 20000548 <SENS_RegiH_timer>
										
			}
			if(SENS_RegiH_timer==18){	//检测到sens_regi上升沿后18ms，关闭regcl			
    300e:	0601a683          	lw	a3,96(gp) # 20000548 <SENS_RegiH_timer>
    3012:	4749                	li	a4,18
    3014:	00e69c63          	bne	a3,a4,302c <TIM0_IRQHandler+0x19c>
					
				Clutch_CtrlREG=RegiCL_Close(Clutch_CtrlREG);//关regi离合
    3018:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    301c:	1b0010ef          	jal	41cc <RegiCL_Close>
				//printf("RegiCL_Close\n");			
				SENS_RegiHflag=0;	
    3020:	06018ca3          	sb	zero,121(gp) # 20000561 <SENS_RegiHflag>
				Clutch_CtrlREG=RegiCL_Close(Clutch_CtrlREG);//关regi离合
    3024:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				SENS_RegiH_timer = 0;			
    3028:	0601a023          	sw	zero,96(gp) # 20000548 <SENS_RegiH_timer>
				
			}

			if(SENS_ExitHflag==1){
    302c:	0751c683          	lbu	a3,117(gp) # 2000055d <SENS_ExitHflag>
    3030:	4705                	li	a4,1
    3032:	00e69763          	bne	a3,a4,3040 <TIM0_IRQHandler+0x1b0>
				//printf("SENS_ExitHflag==1\n");
				SENS_ExitH_timer++;
    3036:	0581a703          	lw	a4,88(gp) # 20000540 <SENS_ExitH_timer>
    303a:	0705                	addi	a4,a4,1
    303c:	04e1ac23          	sw	a4,88(gp) # 20000540 <SENS_ExitH_timer>
			
			}
			if(SENS_ExitH_timer==200){
    3040:	0581a683          	lw	a3,88(gp) # 20000540 <SENS_ExitH_timer>
    3044:	0c800713          	li	a4,200
    3048:	00e69963          	bne	a3,a4,305a <TIM0_IRQHandler+0x1ca>
				Stop_MotorFlag=1;
    304c:	4685                	li	a3,1
    304e:	08d19523          	sh	a3,138(gp) # 20000572 <Stop_MotorFlag>
				SENS_ExitH_timer=0;
    3052:	0401ac23          	sw	zero,88(gp) # 20000540 <SENS_ExitH_timer>
				SENS_ExitHflag=0;
    3056:	06018aa3          	sb	zero,117(gp) # 2000055d <SENS_ExitHflag>
			}

		if(Printed_Page==0){//打印第一页时 
    305a:	0ae1d783          	lhu	a5,174(gp) # 20000596 <Printed_Page>
    305e:	10078863          	beqz	a5,316e <TIM0_IRQHandler+0x2de>
				SENS_RegiLflag=0;
			
			}
		}
		if (Printed_Page > 0) {
			if(SENS_RegiLflag == 1){
    3062:	0781c683          	lbu	a3,120(gp) # 20000560 <SENS_RegiLflag>
    3066:	4705                	li	a4,1
    3068:	00e69763          	bne	a3,a4,3076 <TIM0_IRQHandler+0x1e6>
				//temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
				//*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
				//printf("SENS_RegiLflag == 1\n");
				SENS_RegiL_timer2++;									
    306c:	0641a703          	lw	a4,100(gp) # 2000054c <SENS_RegiL_timer2>
    3070:	0705                	addi	a4,a4,1
    3072:	06e1a223          	sw	a4,100(gp) # 2000054c <SENS_RegiL_timer2>
				}
			if (SENS_RegiL_timer2 == 43) { 
    3076:	0641a683          	lw	a3,100(gp) # 2000054c <SENS_RegiL_timer2>
    307a:	02b00713          	li	a4,43
    307e:	00e69863          	bne	a3,a4,308e <TIM0_IRQHandler+0x1fe>

				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关pickup离合
    3082:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3086:	164010ef          	jal	41ea <PickupCL_Close>
    308a:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>

			}
			if (SENS_RegiL_timer2==158) {
    308e:	0641a683          	lw	a3,100(gp) # 2000054c <SENS_RegiL_timer2>
    3092:	09e00713          	li	a4,158
    3096:	00e69c63          	bne	a3,a4,30ae <TIM0_IRQHandler+0x21e>
				Clutch_CtrlREG=RegiCL_Open(Clutch_CtrlREG);//开对齐离合
    309a:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    309e:	120010ef          	jal	41be <RegiCL_Open>
    30a2:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
    30a6:	136010ef          	jal	41dc <PickupCL_Open>
    30aa:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				//printf("RegiCL_Open\n");		
			
			}
			if (SENS_RegiL_timer2==188) {
    30ae:	0641a683          	lw	a3,100(gp) # 2000054c <SENS_RegiL_timer2>
    30b2:	0bc00713          	li	a4,188
    30b6:	00e69863          	bne	a3,a4,30c6 <TIM0_IRQHandler+0x236>
				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关进纸离合	
    30ba:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    30be:	12c010ef          	jal	41ea <PickupCL_Close>
    30c2:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				//printf("PickupCL_Close\n");	
				//temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
				//*HVCtrl_REG =temp_HVPS_Ctrol_REG;
			
			}
			if (SENS_RegiL_timer2 == 830) { ///859 840
    30c6:	0641a683          	lw	a3,100(gp) # 2000054c <SENS_RegiL_timer2>
    30ca:	33e00713          	li	a4,830
    30ce:	02e69363          	bne	a3,a4,30f4 <TIM0_IRQHandler+0x264>
				if ((Page_sync_printed < Page_sync_print)&&(Page_sync_printed>=2)) {
    30d2:	0a41d683          	lhu	a3,164(gp) # 2000058c <Page_sync_printed>
    30d6:	0a21d703          	lhu	a4,162(gp) # 2000058a <Page_sync_print>
    30da:	00e6fd63          	bgeu	a3,a4,30f4 <TIM0_IRQHandler+0x264>
    30de:	0a41d703          	lhu	a4,164(gp) # 2000058c <Page_sync_printed>
    30e2:	4405                	li	s0,1
    30e4:	00e47863          	bgeu	s0,a4,30f4 <TIM0_IRQHandler+0x264>
					Page_Sync_ON();      // 提前开启下一页的信号
    30e8:	36a010ef          	jal	4452 <Page_Sync_ON>
					//printf("Page_Sync_ON\n");
					PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
    30ec:	0481a823          	sw	s0,80(gp) # 20000538 <PageSync_Enable>
					PageSync_Timer = 0;  // 清零，准备算10ms
    30f0:	0401a623          	sw	zero,76(gp) # 20000534 <PageSync_Timer>
				}
			}
			if (SENS_RegiL_timer2==NextPaperTime2) {///该值为已经测试好的值
    30f4:	0641a683          	lw	a3,100(gp) # 2000054c <SENS_RegiL_timer2>
    30f8:	0041a703          	lw	a4,4(gp) # 200004ec <NextPaperTime2>
    30fc:	12e69e63          	bne	a3,a4,3238 <TIM0_IRQHandler+0x3a8>
				again_paper=1;
    3100:	4685                	li	a3,1
    3102:	04d19a23          	sh	a3,84(gp) # 2000053c <again_paper>
				SENS_RegiL_timer2=0;
    3106:	0601a223          	sw	zero,100(gp) # 2000054c <SENS_RegiL_timer2>
				SENS_RegiLflag=0;	
    310a:	06018c23          	sb	zero,120(gp) # 20000560 <SENS_RegiLflag>
    310e:	a22d                	j	3238 <TIM0_IRQHandler+0x3a8>
		else if (SENS_Regi[0] == 0 && SENS_Regi[1] == 1)
    3110:	0181c703          	lbu	a4,24(gp) # 20000500 <SENS_Regi>
    3114:	dc0718e3          	bnez	a4,2ee4 <TIM0_IRQHandler+0x54>
    3118:	0017c783          	lbu	a5,1(a5)
    311c:	4685                	li	a3,1
    311e:	0ff7f713          	zext.b	a4,a5
    3122:	dcd791e3          	bne	a5,a3,2ee4 <TIM0_IRQHandler+0x54>
			SENS_RegiHflag = 1;
    3126:	06e18ca3          	sb	a4,121(gp) # 20000561 <SENS_RegiHflag>
    312a:	bb6d                	j	2ee4 <TIM0_IRQHandler+0x54>
		else if (SENS_Feed[0] == 0 && SENS_Feed[1] == 1)
    312c:	0141c783          	lbu	a5,20(gp) # 200004fc <SENS_Feed>
    3130:	de0796e3          	bnez	a5,2f1c <TIM0_IRQHandler+0x8c>
    3134:	00174783          	lbu	a5,1(a4)
    3138:	4685                	li	a3,1
    313a:	0ff7f713          	zext.b	a4,a5
    313e:	dcd79fe3          	bne	a5,a3,2f1c <TIM0_IRQHandler+0x8c>
			SENS_FeedHflag = 1;
    3142:	06e18ba3          	sb	a4,119(gp) # 2000055f <SENS_FeedHflag>
    3146:	bbd9                	j	2f1c <TIM0_IRQHandler+0x8c>
		else if (SENS_Exit[0] == 0 && SENS_Exit[1] == 1)
    3148:	0101c783          	lbu	a5,16(gp) # 200004f8 <SENS_Exit>
    314c:	e00794e3          	bnez	a5,2f54 <TIM0_IRQHandler+0xc4>
    3150:	00174783          	lbu	a5,1(a4)
    3154:	4685                	li	a3,1
    3156:	0ff7f713          	zext.b	a4,a5
    315a:	ded79de3          	bne	a5,a3,2f54 <TIM0_IRQHandler+0xc4>
			SENS_ExitHflag = 1;
    315e:	06e18aa3          	sb	a4,117(gp) # 2000055d <SENS_ExitHflag>
    3162:	bbcd                	j	2f54 <TIM0_IRQHandler+0xc4>
			Page_Sync_Close(); 
    3164:	2fa010ef          	jal	445e <Page_Sync_Close>
			PageSync_Timer = 0; 
    3168:	0401a623          	sw	zero,76(gp) # 20000534 <PageSync_Timer>
    316c:	bd3d                	j	2faa <TIM0_IRQHandler+0x11a>
			if(SENS_RegiLflag==1){
    316e:	0781c683          	lbu	a3,120(gp) # 20000560 <SENS_RegiLflag>
    3172:	4705                	li	a4,1
    3174:	00e69763          	bne	a3,a4,3182 <TIM0_IRQHandler+0x2f2>
				SENS_RegiL_timer1++;
    3178:	0681a703          	lw	a4,104(gp) # 20000550 <SENS_RegiL_timer1>
    317c:	0705                	addi	a4,a4,1
    317e:	06e1a423          	sw	a4,104(gp) # 20000550 <SENS_RegiL_timer1>
			if (SENS_RegiL_timer1 == 43) { 
    3182:	0681a683          	lw	a3,104(gp) # 20000550 <SENS_RegiL_timer1>
    3186:	02b00713          	li	a4,43
    318a:	00e69863          	bne	a3,a4,319a <TIM0_IRQHandler+0x30a>
				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关pickup离合
    318e:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3192:	058010ef          	jal	41ea <PickupCL_Close>
    3196:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			if(SENS_RegiL_timer1==158){
    319a:	0681a683          	lw	a3,104(gp) # 20000550 <SENS_RegiL_timer1>
    319e:	09e00713          	li	a4,158
    31a2:	02e69363          	bne	a3,a4,31c8 <TIM0_IRQHandler+0x338>
				time1=1;
    31a6:	4685                	li	a3,1
    31a8:	02d184a3          	sb	a3,41(gp) # 20000511 <time1>
				Clutch_CtrlREG=RegiCL_Open(Clutch_CtrlREG);//开对齐离合
    31ac:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    31b0:	00e010ef          	jal	41be <RegiCL_Open>
    31b4:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
    31b8:	024010ef          	jal	41dc <PickupCL_Open>
				time_flag_count_C=time_flag_count;
    31bc:	0981a683          	lw	a3,152(gp) # 20000580 <time_flag_count>
				Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
    31c0:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				time_flag_count_C=time_flag_count;
    31c4:	08d1aa23          	sw	a3,148(gp) # 2000057c <time_flag_count_C>
			if(SENS_RegiL_timer1==188){
    31c8:	0681a683          	lw	a3,104(gp) # 20000550 <SENS_RegiL_timer1>
    31cc:	0bc00713          	li	a4,188
    31d0:	00e69b63          	bne	a3,a4,31e6 <TIM0_IRQHandler+0x356>
				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关pickup离合
    31d4:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    31d8:	012010ef          	jal	41ea <PickupCL_Close>
    31dc:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				time2=1;
    31e0:	4685                	li	a3,1
    31e2:	02d18423          	sb	a3,40(gp) # 20000510 <time2>
			if (SENS_RegiL_timer1 == 840) { //859  图发早一点，在纸张上向上调整
    31e6:	0681a683          	lw	a3,104(gp) # 20000550 <SENS_RegiL_timer1>
    31ea:	34800713          	li	a4,840
    31ee:	02e69463          	bne	a3,a4,3216 <TIM0_IRQHandler+0x386>
				if ((Page_sync_printed < Page_sync_print)&&(Page_sync_printed>=2)) {
    31f2:	0a41d683          	lhu	a3,164(gp) # 2000058c <Page_sync_printed>
    31f6:	0a21d703          	lhu	a4,162(gp) # 2000058a <Page_sync_print>
    31fa:	00e6fe63          	bgeu	a3,a4,3216 <TIM0_IRQHandler+0x386>
    31fe:	0a41d683          	lhu	a3,164(gp) # 2000058c <Page_sync_printed>
    3202:	4705                	li	a4,1
    3204:	00d77963          	bgeu	a4,a3,3216 <TIM0_IRQHandler+0x386>
					Page_Sync_ON();      // 提前开启下一页的信号
    3208:	24a010ef          	jal	4452 <Page_Sync_ON>
					PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
    320c:	4705                	li	a4,1
    320e:	04e1a823          	sw	a4,80(gp) # 20000538 <PageSync_Enable>
					PageSync_Timer = 0;  // 清零，准备算10ms
    3212:	0401a623          	sw	zero,76(gp) # 20000534 <PageSync_Timer>
			if (SENS_RegiL_timer1==NextPaperTime1) {///该值为已经测试好的值
    3216:	0681a683          	lw	a3,104(gp) # 20000550 <SENS_RegiL_timer1>
    321a:	0081a703          	lw	a4,8(gp) # 200004f0 <NextPaperTime1>
    321e:	00e69963          	bne	a3,a4,3230 <TIM0_IRQHandler+0x3a0>
				again_paper=1;
    3222:	4685                	li	a3,1
    3224:	04d19a23          	sh	a3,84(gp) # 2000053c <again_paper>
				SENS_RegiL_timer1=0;
    3228:	0601a423          	sw	zero,104(gp) # 20000550 <SENS_RegiL_timer1>
				SENS_RegiLflag=0;
    322c:	06018c23          	sb	zero,120(gp) # 20000560 <SENS_RegiLflag>
		if (Printed_Page > 0) {
    3230:	0ae1d783          	lhu	a5,174(gp) # 20000596 <Printed_Page>
    3234:	e20797e3          	bnez	a5,3062 <TIM0_IRQHandler+0x1d2>
		}
	}
	// clear interrupt Timer1_int_clr
	*((volatile uint32_t *)(0x50000000 + 0x0c));  // tim0
    CSI_INTRPT_EXIT();
}
    3238:	40b2                	lw	ra,12(sp)
    323a:	4422                	lw	s0,8(sp)
	*((volatile uint32_t *)(0x50000000 + 0x0c));  // tim0
    323c:	500007b7          	lui	a5,0x50000
}
    3240:	4492                	lw	s1,4(sp)
	*((volatile uint32_t *)(0x50000000 + 0x0c));  // tim0
    3242:	47dc                	lw	a5,12(a5)
}
    3244:	0141                	addi	sp,sp,16
    3246:	8082                	ret
	*((volatile uint32_t *)(0x50000000 + 0x0c));  // tim0
    3248:	500007b7          	lui	a5,0x50000
    324c:	47dc                	lw	a5,12(a5)
    324e:	8082                	ret

00003250 <TIM1_IRQHandler>:
	 * 
	 * 
	 */

 
	*((volatile uint32_t *)(0x60000000 + 0x0c));  // tim1
    3250:	600007b7          	lui	a5,0x60000
    3254:	47dc                	lw	a5,12(a5)
    CSI_INTRPT_EXIT();
}
    3256:	8082                	ret

00003258 <TIM2_IRQHandler>:
	 
	 
	 
	 
	 
	*((volatile uint32_t *)(0x50000400 + 0x0c));  // tim2
    3258:	500007b7          	lui	a5,0x50000
    325c:	40c7a783          	lw	a5,1036(a5) # 5000040c <__heap_end+0x2ffd040c>
    CSI_INTRPT_EXIT();
}
    3260:	8082                	ret

00003262 <TIM3_IRQHandler>:
	 * 
	 * 
	 * 
	 */
	
	*((volatile uint32_t *)(0x60000400 + 0x0c));  // tim3
    3262:	600007b7          	lui	a5,0x60000
    3266:	40c7a783          	lw	a5,1036(a5) # 6000040c <__heap_end+0x3ffd040c>
    CSI_INTRPT_EXIT();
}
    326a:	8082                	ret

0000326c <TIM4_IRQHandler>:

ATTRIBUTE_ISR void TIM4_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(4);
    326c:	4511                	li	a0,4
    326e:	a3fff06f          	j	2cac <wj_oip_timer_irqhandler>

00003272 <TIM5_IRQHandler>:
}

ATTRIBUTE_ISR void TIM5_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(5);
    3272:	4515                	li	a0,5
    3274:	a39ff06f          	j	2cac <wj_oip_timer_irqhandler>

00003278 <TIM6_IRQHandler>:
}

ATTRIBUTE_ISR void TIM6_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(6);
    3278:	4519                	li	a0,6
    327a:	a33ff06f          	j	2cac <wj_oip_timer_irqhandler>

0000327e <TIM7_IRQHandler>:
}

ATTRIBUTE_ISR void TIM7_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(7);
    327e:	451d                	li	a0,7
    3280:	a2dff06f          	j	2cac <wj_oip_timer_irqhandler>

00003284 <TIM8_IRQHandler>:
}

ATTRIBUTE_ISR void TIM8_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(8);
    3284:	4521                	li	a0,8
    3286:	a27ff06f          	j	2cac <wj_oip_timer_irqhandler>

0000328a <TIM9_IRQHandler>:
}

ATTRIBUTE_ISR void TIM9_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(9);
    328a:	4525                	li	a0,9
    328c:	a21ff06f          	j	2cac <wj_oip_timer_irqhandler>

00003290 <TIM10_IRQHandler>:
}

ATTRIBUTE_ISR void TIM10_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(10);
    3290:	4529                	li	a0,10
    3292:	a1bff06f          	j	2cac <wj_oip_timer_irqhandler>

00003296 <TIM11_IRQHandler>:
}

ATTRIBUTE_ISR void TIM11_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(11);
    3296:	452d                	li	a0,11
    3298:	a15ff06f          	j	2cac <wj_oip_timer_irqhandler>

0000329c <TIM12_IRQHandler>:
}

ATTRIBUTE_ISR void TIM12_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(12);
    329c:	4531                	li	a0,12
    329e:	a0fff06f          	j	2cac <wj_oip_timer_irqhandler>

000032a2 <TIM13_IRQHandler>:
}

ATTRIBUTE_ISR void TIM13_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(13);
    32a2:	4535                	li	a0,13
    32a4:	a09ff06f          	j	2cac <wj_oip_timer_irqhandler>

000032a8 <TIM14_IRQHandler>:
}

ATTRIBUTE_ISR void TIM14_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(14);
    32a8:	4539                	li	a0,14
    32aa:	a03ff06f          	j	2cac <wj_oip_timer_irqhandler>

000032ae <TIM15_IRQHandler>:
}

ATTRIBUTE_ISR void TIM15_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(15);
    32ae:	453d                	li	a0,15
    32b0:	9fdff06f          	j	2cac <wj_oip_timer_irqhandler>

000032b4 <USI0_IRQHandler>:
}

ATTRIBUTE_ISR void USI0_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_usi_irqhandler(0);
    32b4:	4501                	li	a0,0
    32b6:	f89fe06f          	j	223e <wj_usi_irqhandler>

000032ba <USI1_IRQHandler>:
}

ATTRIBUTE_ISR void USI1_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_usi_irqhandler(1);
    32ba:	4505                	li	a0,1
    32bc:	f83fe06f          	j	223e <wj_usi_irqhandler>

000032c0 <USI2_IRQHandler>:
}

ATTRIBUTE_ISR void USI2_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_usi_irqhandler(2);
    32c0:	4509                	li	a0,2
    32c2:	f7dfe06f          	j	223e <wj_usi_irqhandler>

000032c6 <drv_get_usi_freq>:
int32_t drv_get_cpu_freq(int32_t idx)
{
    return g_system_clock;
}

int32_t drv_get_usi_freq(int32_t idx)
    32c6:	0001a503          	lw	a0,0(gp) # 200004e8 <g_system_clock>
    32ca:	8082                	ret

000032cc <drv_get_sys_freq>:
}

int32_t drv_get_sys_freq(void)
{
    return g_system_clock;
}
    32cc:	0001a503          	lw	a0,0(gp) # 200004e8 <g_system_clock>
    32d0:	8082                	ret

000032d2 <drv_get_timer_freq>:
int32_t drv_get_apb_freq(void)
{
    return g_system_clock;
}

int32_t drv_get_timer_freq(int32_t idx)
    32d2:	0001a503          	lw	a0,0(gp) # 200004e8 <g_system_clock>
    32d6:	8082                	ret

000032d8 <SystemInit>:
  *         Initialize the psr and vbr.
  * @param  None
  * @return None
  */
void SystemInit(void)
{
    32d8:	1171                	addi	sp,sp,-4
    int i;

    CLIC->CLICCFG = 0x4UL;
    32da:	e000f7b7          	lui	a5,0xe000f
    32de:	4691                	li	a3,4
{
    32e0:	c006                	sw	ra,0(sp)
    CLIC->CLICCFG = 0x4UL;
    32e2:	e000e737          	lui	a4,0xe000e
    32e6:	c0d78023          	sb	a3,-1024(a5) # e000ec00 <__heap_end+0xbffdec00>
    32ea:	10070713          	addi	a4,a4,256 # e000e100 <__heap_end+0xbffde100>

    for (i = 0; i < 12; i++) {
    32ee:	4781                	li	a5,0
    32f0:	46b1                	li	a3,12
        CLIC->INTIP[i] = 0;
    32f2:	00f70633          	add	a2,a4,a5
    32f6:	00060023          	sb	zero,0(a2)
    for (i = 0; i < 12; i++) {
    32fa:	0785                	addi	a5,a5,1
    32fc:	fed79be3          	bne	a5,a3,32f2 <SystemInit+0x1a>
    }

    drv_irq_enable(Machine_Software_IRQn);
    3300:	450d                	li	a0,3
    3302:	ec7fe0ef          	jal	21c8 <drv_irq_enable>
  \details Enables IRQ interrupts by setting the IE-bit in the PSR.
           Can only be executed in Privileged modes.
 */
__ALWAYS_STATIC_INLINE void __enable_irq(void)
{
    __ASM volatile("csrs mstatus, 8");
    3306:	30046073          	csrsi	mstatus,8
    csi_coret_config(drv_get_sys_freq() / CONFIG_SYSTICK_HZ, CORET_IRQn);    //10ms
    330a:	37c9                	jal	32cc <drv_get_sys_freq>
    330c:	06400793          	li	a5,100
    3310:	02f54533          	div	a0,a0,a5
           function <b>SysTick_Config</b> is not included. In this case, the file <b><i>device</i>.h</b>
           must contain a vendor-specific implementation of this function.
 */
__STATIC_INLINE uint32_t csi_coret_config(uint32_t ticks, int32_t IRQn)
{
    if ((ticks - 1UL) > CORET_LOAD_RELOAD_Msk) {
    3314:	010007b7          	lui	a5,0x1000
    3318:	157d                	addi	a0,a0,-1
    331a:	00f57b63          	bgeu	a0,a5,3330 <SystemInit+0x58>
        return (1UL);                                                   /* Reload value impossible */
    }

    CORET->LOAD = (uint32_t)(ticks - 1UL);                              /* set reload register */
    331e:	e000e7b7          	lui	a5,0xe000e
    3322:	cbc8                	sw	a0,20(a5)
    CORET->VAL  = 0UL;                                                  /* Load the CORET Counter Value */
    3324:	0007ac23          	sw	zero,24(a5) # e000e018 <__heap_end+0xbffde018>
    CORET->CTRL = CORET_CTRL_CLKSOURCE_Msk |
    3328:	471d                	li	a4,7
    332a:	e000e7b7          	lui	a5,0xe000e
    332e:	cb98                	sw	a4,16(a5)
#ifdef CONFIG_KERNEL_NONE
    _system_init_for_baremetal();
#else
    _system_init_for_kernel();
#endif
}
    3330:	4082                	lw	ra,0(sp)
    3332:	0111                	addi	sp,sp,4
    mm_heap_initialize();
    3334:	a449                	j	35b6 <mm_heap_initialize>

00003336 <trap_c>:
#include <csi_core.h>

void (*trap_c_callback)(void);

void trap_c(uint32_t *regs)
{
    3336:	1131                	addi	sp,sp,-20
    3338:	c426                	sw	s1,8(sp)
    333a:	c806                	sw	ra,16(sp)
    333c:	c622                	sw	s0,12(sp)
    333e:	84aa                	mv	s1,a0
 */
__ALWAYS_STATIC_INLINE uint32_t __get_MCAUSE(void)
{
    uint32_t result;

    __ASM volatile("csrr %0, mcause" : "=r"(result));
    3340:	342025f3          	csrr	a1,mcause
    int i;
    uint32_t vec = 0;

    vec = __get_MCAUSE() & 0x3FF;

    printf("CPU Exception: NO.%d", vec);
    3344:	6519                	lui	a0,0x6
    3346:	3ff5f593          	andi	a1,a1,1023
    334a:	05050513          	addi	a0,a0,80 # 6050 <sg_timer_config+0xc0>
    334e:	7e6010ef          	jal	4b34 <printf>
    printf("\n");
    3352:	4529                	li	a0,10
    3354:	0f7010ef          	jal	4c4a <putchar>

    for (i = 0; i < 15; i++) {
    3358:	8426                	mv	s0,s1
    335a:	4781                	li	a5,0
        printf("x%d: %08x\t", i + 1, regs[i]);
    335c:	4010                	lw	a2,0(s0)
    335e:	6519                	lui	a0,0x6
    3360:	00178593          	addi	a1,a5,1 # e000e001 <__heap_end+0xbffde001>
    3364:	06850513          	addi	a0,a0,104 # 6068 <sg_timer_config+0xd8>
    3368:	c23e                	sw	a5,4(sp)
    336a:	c02e                	sw	a1,0(sp)
    336c:	7c8010ef          	jal	4b34 <printf>

        if ((i % 4) == 3) {
    3370:	4792                	lw	a5,4(sp)
    3372:	470d                	li	a4,3
    3374:	4582                	lw	a1,0(sp)
    3376:	8b8d                	andi	a5,a5,3
    3378:	0411                	addi	s0,s0,4
    337a:	00e79863          	bne	a5,a4,338a <trap_c+0x54>
            printf("\n");
    337e:	4529                	li	a0,10
    3380:	0cb010ef          	jal	4c4a <putchar>
    for (i = 0; i < 15; i++) {
    3384:	4582                	lw	a1,0(sp)
{
    3386:	87ae                	mv	a5,a1
    3388:	bfd1                	j	335c <trap_c+0x26>
    for (i = 0; i < 15; i++) {
    338a:	47bd                	li	a5,15
    338c:	fef59de3          	bne	a1,a5,3386 <trap_c+0x50>
        }
    }

    printf("\n");
    3390:	4529                	li	a0,10
    3392:	0b9010ef          	jal	4c4a <putchar>
    printf("mepc   : %08x\n", regs[15]);
    3396:	5ccc                	lw	a1,60(s1)
    3398:	6519                	lui	a0,0x6
    339a:	07450513          	addi	a0,a0,116 # 6074 <sg_timer_config+0xe4>
    339e:	796010ef          	jal	4b34 <printf>
    printf("mstatus: %08x\n", regs[16]);
    33a2:	40ac                	lw	a1,64(s1)
    33a4:	6519                	lui	a0,0x6
    33a6:	08450513          	addi	a0,a0,132 # 6084 <sg_timer_config+0xf4>
    33aa:	78a010ef          	jal	4b34 <printf>

    if (trap_c_callback) {
    33ae:	02c1a783          	lw	a5,44(gp) # 20000514 <trap_c_callback>
    33b2:	c391                	beqz	a5,33b6 <trap_c+0x80>
        trap_c_callback();
    33b4:	9782                	jalr	a5
    }

    while (1);
    33b6:	a001                	j	33b6 <trap_c+0x80>

000033b8 <timer_cb_fun>:
static unsigned int Timer_LoopCount;    /* Count unit is 10 seconds */
static uint8_t timer_count_rise = 0;    /*1: timer cont increasing, 0: timer cont diminishing*/

static void timer_cb_fun(int32_t idx, timer_event_e event)
{
    if (TIMER_EVENT_TIMEOUT == event) {
    33b8:	e591                	bnez	a1,33c4 <timer_cb_fun+0xc>
        Timer_LoopCount++;
    33ba:	0341a783          	lw	a5,52(gp) # 2000051c <Timer_LoopCount>
    33be:	0785                	addi	a5,a5,1
    33c0:	02f1aa23          	sw	a5,52(gp) # 2000051c <Timer_LoopCount>
    }
}
    33c4:	8082                	ret

000033c6 <clock_timer_init>:
    if (CLOCK_GETTIME_USE_TIMER_ID > CONFIG_TIMER_NUM) {
        return EPERM;
    }

    uint32_t timer_loadtimer;
    timer_handle = csi_timer_initialize(CLOCK_GETTIME_USE_TIMER_ID, timer_cb_fun);
    33c6:	658d                	lui	a1,0x3
{
    33c8:	1131                	addi	sp,sp,-20
    timer_handle = csi_timer_initialize(CLOCK_GETTIME_USE_TIMER_ID, timer_cb_fun);
    33ca:	3b858593          	addi	a1,a1,952 # 33b8 <timer_cb_fun>
    33ce:	4501                	li	a0,0
{
    33d0:	c622                	sw	s0,12(sp)
    33d2:	c806                	sw	ra,16(sp)
    33d4:	c426                	sw	s1,8(sp)
    timer_handle = csi_timer_initialize(CLOCK_GETTIME_USE_TIMER_ID, timer_cb_fun);
    33d6:	38e5                	jal	2cce <csi_timer_initialize>
    33d8:	02a1ac23          	sw	a0,56(gp) # 20000520 <timer_handle>

    if (timer_handle == NULL) {
    33dc:	e901                	bnez	a0,33ec <clock_timer_init+0x26>
        return -1;
    33de:	54fd                	li	s1,-1
    if (cv2 > cv1) {
        timer_count_rise = 1;
    }

    return 0;
}
    33e0:	40c2                	lw	ra,16(sp)
    33e2:	4432                	lw	s0,12(sp)
    33e4:	8526                	mv	a0,s1
    33e6:	44a2                	lw	s1,8(sp)
    33e8:	0151                	addi	sp,sp,20
    33ea:	8082                	ret
    APB_FREQ = drv_get_timer_freq(CLOCK_GETTIME_USE_TIMER_ID);
    33ec:	4501                	li	a0,0
    33ee:	35d5                	jal	32d2 <drv_get_timer_freq>
    33f0:	04a1a023          	sw	a0,64(gp) # 20000528 <APB_FREQ>
    TIMER_LOADCOUNT = timer_loadtimer * (APB_FREQ / MILLION);
    33f4:	000f47b7          	lui	a5,0xf4
    33f8:	24078793          	addi	a5,a5,576 # f4240 <__ctor_end__+0xed680>
    33fc:	02f55533          	divu	a0,a0,a5
    3400:	009894b7          	lui	s1,0x989
    3404:	68048493          	addi	s1,s1,1664 # 989680 <__ctor_end__+0x982ac0>
    int ret = csi_timer_config(timer_handle, TIMER_MODE_RELOAD);
    3408:	4585                	li	a1,1
    TIMER_LOADCOUNT = timer_loadtimer * (APB_FREQ / MILLION);
    340a:	02950533          	mul	a0,a0,s1
    340e:	02a1ae23          	sw	a0,60(gp) # 20000524 <TIMER_LOADCOUNT>
    int ret = csi_timer_config(timer_handle, TIMER_MODE_RELOAD);
    3412:	0381a503          	lw	a0,56(gp) # 20000520 <timer_handle>
    3416:	3aa9                	jal	2d70 <csi_timer_config>
    if (ret != 0) {
    3418:	f179                	bnez	a0,33de <clock_timer_init+0x18>
    ret = csi_timer_set_timeout(timer_handle, timer_loadtimer);
    341a:	0381a503          	lw	a0,56(gp) # 20000520 <timer_handle>
    341e:	85a6                	mv	a1,s1
    3420:	3a61                	jal	2db8 <csi_timer_set_timeout>
    3422:	84aa                	mv	s1,a0
    if (ret != 0) {
    3424:	fd4d                	bnez	a0,33de <clock_timer_init+0x18>
    csi_timer_get_current_value(timer_handle, &cv1);
    3426:	0381a503          	lw	a0,56(gp) # 20000520 <timer_handle>
    342a:	858a                	mv	a1,sp
    342c:	34b1                	jal	2e78 <csi_timer_get_current_value>
    csi_timer_get_current_value(timer_handle, &cv2);
    342e:	0381a503          	lw	a0,56(gp) # 20000520 <timer_handle>
    3432:	004c                	addi	a1,sp,4
    3434:	3491                	jal	2e78 <csi_timer_get_current_value>
    if (cv2 > cv1) {
    3436:	4712                	lw	a4,4(sp)
    3438:	4782                	lw	a5,0(sp)
    343a:	fae7f3e3          	bgeu	a5,a4,33e0 <clock_timer_init+0x1a>
        timer_count_rise = 1;
    343e:	4705                	li	a4,1
    3440:	02e18823          	sb	a4,48(gp) # 20000518 <timer_count_rise>
    3444:	bf71                	j	33e0 <clock_timer_init+0x1a>

00003446 <clock_timer_start>:

    return 0;
}

int clock_timer_start(void)
{
    3446:	1171                	addi	sp,sp,-4
    int ret = -1;
    Timer_LoopCount = 0;
    3448:	0201aa23          	sw	zero,52(gp) # 2000051c <Timer_LoopCount>

    ret = csi_timer_start(timer_handle);
    344c:	0381a503          	lw	a0,56(gp) # 20000520 <timer_handle>
{
    3450:	c006                	sw	ra,0(sp)
    ret = csi_timer_start(timer_handle);
    3452:	3aa5                	jal	2dca <csi_timer_start>
        (ts_begin.tv_sec * 1000000000 + ts_begin.tv_nsec);
    printf("clock_gettime() timing deviation is +%llu ns\n", error_margin_ns);
#endif

    return 0;
}
    3454:	4082                	lw	ra,0(sp)
    if (ret != 0) {
    3456:	00a03533          	snez	a0,a0
}
    345a:	40a00533          	neg	a0,a0
    345e:	0111                	addi	sp,sp,4
    3460:	8082                	ret

00003462 <_init>:
extern int __ctor_start__;

typedef void (*func_ptr) (void);

CPP_WEAK void _init(void)
{
    3462:	1161                	addi	sp,sp,-8
    3464:	c022                	sw	s0,0(sp)
    3466:	641d                	lui	s0,0x7
    3468:	c206                	sw	ra,4(sp)
    346a:	bc040413          	addi	s0,s0,-1088 # 6bc0 <__ctor_end__>
    func_ptr *p;
    for (p = (func_ptr *)&__ctor_end__ - 1; p >= (func_ptr *)&__ctor_start__; p--) {
    346e:	679d                	lui	a5,0x7
    3470:	1471                	addi	s0,s0,-4
    3472:	bc078793          	addi	a5,a5,-1088 # 6bc0 <__ctor_end__>
    3476:	00f47663          	bgeu	s0,a5,3482 <_init+0x20>
        (*p) ();
    }
}
    347a:	4092                	lw	ra,4(sp)
    347c:	4402                	lw	s0,0(sp)
    347e:	0121                	addi	sp,sp,8
    3480:	8082                	ret
        (*p) ();
    3482:	401c                	lw	a5,0(s0)
    3484:	9782                	jalr	a5
    for (p = (func_ptr *)&__ctor_end__ - 1; p >= (func_ptr *)&__ctor_start__; p--) {
    3486:	b7e5                	j	346e <_init+0xc>

00003488 <_fini>:

CPP_WEAK void _fini(void)
{
    3488:	1161                	addi	sp,sp,-8
    348a:	c022                	sw	s0,0(sp)
    func_ptr *p;
    for (p = (func_ptr *)&__ctor_end__; p <= (func_ptr *)&__dtor_end__ - 1; p++) {
    348c:	641d                	lui	s0,0x7
{
    348e:	c206                	sw	ra,4(sp)
    for (p = (func_ptr *)&__ctor_end__; p <= (func_ptr *)&__dtor_end__ - 1; p++) {
    3490:	bc040413          	addi	s0,s0,-1088 # 6bc0 <__ctor_end__>
    3494:	679d                	lui	a5,0x7
    3496:	bbc78793          	addi	a5,a5,-1092 # 6bbc <_ctype_+0x100>
    349a:	0087f663          	bgeu	a5,s0,34a6 <_fini+0x1e>
        (*p) ();
    }
}
    349e:	4092                	lw	ra,4(sp)
    34a0:	4402                	lw	s0,0(sp)
    34a2:	0121                	addi	sp,sp,8
    34a4:	8082                	ret
        (*p) ();
    34a6:	401c                	lw	a5,0(s0)
    for (p = (func_ptr *)&__ctor_end__; p <= (func_ptr *)&__dtor_end__ - 1; p++) {
    34a8:	0411                	addi	s0,s0,4
        (*p) ();
    34aa:	9782                	jalr	a5
    for (p = (func_ptr *)&__ctor_end__; p <= (func_ptr *)&__dtor_end__ - 1; p++) {
    34ac:	b7e5                	j	3494 <_fini+0xc>

000034ae <fputc>:
{
    return 0;
}

int fputc(int ch, FILE *stream)
{
    34ae:	1151                	addi	sp,sp,-12
    34b0:	c026                	sw	s1,0(sp)
    34b2:	c222                	sw	s0,4(sp)
    34b4:	842a                	mv	s0,a0
    (void)stream;

    if (console_handle == NULL) {
    34b6:	0441a503          	lw	a0,68(gp) # 2000052c <console_handle>
{
    34ba:	c406                	sw	ra,8(sp)
    if (console_handle == NULL) {
    34bc:	c11d                	beqz	a0,34e2 <fputc+0x34>
        return -1;
    }

    if (ch == '\n') {
    34be:	47a9                	li	a5,10
    34c0:	00f41563          	bne	s0,a5,34ca <fputc+0x1c>
        csi_usart_putchar(console_handle, '\r');
    34c4:	45b5                	li	a1,13
    34c6:	edaff0ef          	jal	2ba0 <csi_usart_putchar>
    }

    csi_usart_putchar(console_handle, ch);
    34ca:	0441a503          	lw	a0,68(gp) # 2000052c <console_handle>
    34ce:	0ff47593          	zext.b	a1,s0
    34d2:	eceff0ef          	jal	2ba0 <csi_usart_putchar>

    return 0;
    34d6:	4501                	li	a0,0
}
    34d8:	40a2                	lw	ra,8(sp)
    34da:	4412                	lw	s0,4(sp)
    34dc:	4482                	lw	s1,0(sp)
    34de:	0131                	addi	sp,sp,12
    34e0:	8082                	ret
        return -1;
    34e2:	557d                	li	a0,-1
    34e4:	bfd5                	j	34d8 <fputc+0x2a>

000034e6 <os_critical_enter>:
#ifndef CONFIG_KERNEL_NONE
    csi_kernel_sched_suspend();
#endif

    return 0;
}
    34e6:	4501                	li	a0,0
    34e8:	8082                	ret

000034ea <os_critical_exit>:

int os_critical_exit(unsigned int *lock)
    34ea:	4501                	li	a0,0
    34ec:	8082                	ret

000034ee <mm_addfreechunk>:
 *   the mm semaphore
 *
 ****************************************************************************/

void mm_addfreechunk(struct mm_heap_s *heap, struct mm_freenode_s *node)
{
    34ee:	1151                	addi	sp,sp,-12
    34f0:	c026                	sw	s1,0(sp)
    34f2:	84aa                	mv	s1,a0
  struct mm_freenode_s *next;
  struct mm_freenode_s *prev;

  /* Convert the size to a nodelist index */

  int ndx = mm_size2ndx(node->size);
    34f4:	4188                	lw	a0,0(a1)
{
    34f6:	c222                	sw	s0,4(sp)
    34f8:	c406                	sw	ra,8(sp)
    34fa:	842e                	mv	s0,a1
  int ndx = mm_size2ndx(node->size);
    34fc:	28d9                	jal	35d2 <mm_size2ndx>

  /* Now put the new node int the next */

  for (prev = &heap->mm_nodelist[ndx], next = heap->mm_nodelist[ndx].flink;
    34fe:	00451713          	slli	a4,a0,0x4
    3502:	00150793          	addi	a5,a0,1
    3506:	0792                	slli	a5,a5,0x4
    3508:	0761                	addi	a4,a4,24
    350a:	9726                	add	a4,a4,s1
    350c:	94be                	add	s1,s1,a5
    350e:	489c                	lw	a5,16(s1)
       next && next->size && next->size < node->size;
    3510:	c791                	beqz	a5,351c <mm_addfreechunk+0x2e>
    3512:	4394                	lw	a3,0(a5)
    3514:	c681                	beqz	a3,351c <mm_addfreechunk+0x2e>
    3516:	4010                	lw	a2,0(s0)
    3518:	00c6ec63          	bltu	a3,a2,3530 <mm_addfreechunk+0x42>
       prev = next, next = next->flink);

  /* Does it go in mid next or at the end? */

  prev->flink = node;
    351c:	c700                	sw	s0,8(a4)
  node->blink = prev;
    351e:	c458                	sw	a4,12(s0)
  node->flink = next;
    3520:	c41c                	sw	a5,8(s0)

  if (next)
    3522:	c391                	beqz	a5,3526 <mm_addfreechunk+0x38>
    {
      /* The new node goes between prev and next */

      next->blink = node;
    3524:	c7c0                	sw	s0,12(a5)
    }
}
    3526:	40a2                	lw	ra,8(sp)
    3528:	4412                	lw	s0,4(sp)
    352a:	4482                	lw	s1,0(sp)
    352c:	0131                	addi	sp,sp,12
    352e:	8082                	ret
       prev = next, next = next->flink);
    3530:	873e                	mv	a4,a5
    3532:	479c                	lw	a5,8(a5)
    3534:	bff1                	j	3510 <mm_addfreechunk+0x22>

00003536 <mm_addregion>:
  /* Adjust the provide heap start and size so that they are both aligned
   * with the MM_MIN_CHUNK size.
   */

  heapbase = MM_ALIGN_UP((uintptr_t)heapstart);
  heapend  = MM_ALIGN_DOWN((uintptr_t)heapstart + (uintptr_t)heapsize);
    3536:	00c587b3          	add	a5,a1,a2
  heapbase = MM_ALIGN_UP((uintptr_t)heapstart);
    353a:	00f58713          	addi	a4,a1,15

  //mlldbg("Region %d: base=%p size=%u\n", IDX+1, heapstart, heapsize);

  /* Add the size of this region to the total size of the heap */

  heap->mm_heapsize += heapsize;
    353e:	4550                	lw	a2,12(a0)
  heapbase = MM_ALIGN_UP((uintptr_t)heapstart);
    3540:	9b41                	andi	a4,a4,-16
  heapend  = MM_ALIGN_DOWN((uintptr_t)heapstart + (uintptr_t)heapsize);
    3542:	9bc1                	andi	a5,a5,-16
  heapsize = heapend - heapbase;
    3544:	40e786b3          	sub	a3,a5,a4
  heap->mm_heapsize += heapsize;
    3548:	9636                	add	a2,a2,a3
    354a:	c550                	sw	a2,12(a0)
   *
   * And create one free node between the guard nodes that contains
   * all available memory.
   */

  heap->mm_heapstart[IDX]            = (struct mm_allocnode_s *)heapbase;
    354c:	c918                	sw	a4,16(a0)
  heap->mm_heapstart[IDX]->size      = SIZEOF_MM_ALLOCNODE;
    354e:	4621                	li	a2,8
  heap->mm_heapstart[IDX]->preceding = MM_ALLOC_BIT;
    3550:	800002b7          	lui	t0,0x80000

  node                        = (struct mm_freenode_s *)(heapbase + SIZEOF_MM_ALLOCNODE);
  node->size                  = heapsize - 2*SIZEOF_MM_ALLOCNODE;
    3554:	16c1                	addi	a3,a3,-16 # 60017ff0 <__heap_end+0x3ffe7ff0>
    3556:	c714                	sw	a3,8(a4)
  heap->mm_heapstart[IDX]->size      = SIZEOF_MM_ALLOCNODE;
    3558:	c310                	sw	a2,0(a4)
  heap->mm_heapstart[IDX]->preceding = MM_ALLOC_BIT;
    355a:	00572223          	sw	t0,4(a4)
  node                        = (struct mm_freenode_s *)(heapbase + SIZEOF_MM_ALLOCNODE);
    355e:	00c705b3          	add	a1,a4,a2
  node->preceding             = SIZEOF_MM_ALLOCNODE;
    3562:	c1d0                	sw	a2,4(a1)

  heap->mm_heapend[IDX]              = (struct mm_allocnode_s *)(heapend - SIZEOF_MM_ALLOCNODE);
    3564:	17e1                	addi	a5,a5,-8
    3566:	c95c                	sw	a5,20(a0)
  heap->mm_heapend[IDX]->size        = SIZEOF_MM_ALLOCNODE;
  heap->mm_heapend[IDX]->preceding   = node->size | MM_ALLOC_BIT;
    3568:	0056e6b3          	or	a3,a3,t0
  heap->mm_heapend[IDX]->size        = SIZEOF_MM_ALLOCNODE;
    356c:	c390                	sw	a2,0(a5)
  heap->mm_heapend[IDX]->preceding   = node->size | MM_ALLOC_BIT;
    356e:	c3d4                	sw	a3,4(a5)
  heap->mm_nregions++;
#endif

  /* Add the single, large free node to the nodelist */

  mm_addfreechunk(heap, node);
    3570:	bfbd                	j	34ee <mm_addfreechunk>

00003572 <mm_initialize>:
 *
 ****************************************************************************/

void mm_initialize(struct mm_heap_s *heap, void *heapstart,
                   size_t heapsize)
{
    3572:	1141                	addi	sp,sp,-16
    3574:	c422                	sw	s0,8(sp)
    3576:	c226                	sw	s1,4(sp)
  heap->mm_nregions = 0;
#endif

  /* Initialize the node array */

  memset(heap->mm_nodelist, 0, sizeof(struct mm_freenode_s) * MM_NNODES);
    3578:	01850793          	addi	a5,a0,24
{
    357c:	c606                	sw	ra,12(sp)
    357e:	842a                	mv	s0,a0
    3580:	c02e                	sw	a1,0(sp)
  heap->mm_heapsize = 0;
    3582:	00052623          	sw	zero,12(a0)
{
    3586:	84b2                	mv	s1,a2
  memset(heap->mm_nodelist, 0, sizeof(struct mm_freenode_s) * MM_NNODES);
    3588:	853e                	mv	a0,a5
    358a:	13000613          	li	a2,304
    358e:	4581                	li	a1,0
    3590:	b61fe0ef          	jal	20f0 <memset>
    3594:	87aa                	mv	a5,a0
  for (i = 1; i < MM_NNODES; i++)
    3596:	13840613          	addi	a2,s0,312
    {
      heap->mm_nodelist[i-1].flink = &heap->mm_nodelist[i];
    359a:	86be                	mv	a3,a5
    359c:	07c1                	addi	a5,a5,16
    359e:	c69c                	sw	a5,8(a3)
      heap->mm_nodelist[i].blink   = &heap->mm_nodelist[i-1];
    35a0:	ced4                	sw	a3,28(a3)
  for (i = 1; i < MM_NNODES; i++)
    35a2:	fec79ce3          	bne	a5,a2,359a <mm_initialize+0x28>

  mm_seminitialize(heap);

  /* Add the initial region of memory to the heap */

  mm_addregion(heap, heapstart, heapsize);
    35a6:	8522                	mv	a0,s0
}
    35a8:	4422                	lw	s0,8(sp)
  mm_addregion(heap, heapstart, heapsize);
    35aa:	4582                	lw	a1,0(sp)
}
    35ac:	40b2                	lw	ra,12(sp)
  mm_addregion(heap, heapstart, heapsize);
    35ae:	8626                	mv	a2,s1
}
    35b0:	4492                	lw	s1,4(sp)
    35b2:	0141                	addi	sp,sp,16
  mm_addregion(heap, heapstart, heapsize);
    35b4:	b749                	j	3536 <mm_addregion>

000035b6 <mm_heap_initialize>:

void mm_heap_initialize(void)
{
    mm_initialize(&g_mmheap, &__heap_start, (uint32_t)(&__heap_end) - (uint32_t)(&__heap_start));
    35b6:	200025b7          	lui	a1,0x20002
    35ba:	20030637          	lui	a2,0x20030
    35be:	d9458593          	addi	a1,a1,-620 # 20001d94 <__bss_end__>
    35c2:	00060613          	mv	a2,a2
    35c6:	20002537          	lui	a0,0x20002
    35ca:	8e0d                	sub	a2,a2,a1
    35cc:	c4050513          	addi	a0,a0,-960 # 20001c40 <g_mmheap>
    35d0:	b74d                	j	3572 <mm_initialize>

000035d2 <mm_size2ndx>:

int mm_size2ndx(size_t size)
{
  int ndx = 0;

  if (size >= MM_MAX_CHUNK)
    35d2:	004007b7          	lui	a5,0x400
    35d6:	00f57c63          	bgeu	a0,a5,35ee <mm_size2ndx+0x1c>
    {
       return MM_NNODES-1;
    }

  size >>= MM_MIN_SHIFT;
    35da:	00455793          	srli	a5,a0,0x4
  while (size > 1)
    35de:	4705                	li	a4,1
  int ndx = 0;
    35e0:	4501                	li	a0,0
  while (size > 1)
    35e2:	00f76363          	bltu	a4,a5,35e8 <mm_size2ndx+0x16>
    35e6:	8082                	ret
    {
      ndx++;
    35e8:	0505                	addi	a0,a0,1
      size >>= 1;
    35ea:	8385                	srli	a5,a5,0x1
    35ec:	bfdd                	j	35e2 <mm_size2ndx+0x10>
       return MM_NNODES-1;
    35ee:	4549                	li	a0,18
    }

  return ndx;
}
    35f0:	8082                	ret

000035f2 <main>:


volatile int32_t flag = 0;
uint8_t ret;
int main(void)
{
    35f2:	1141                	addi	sp,sp,-16
    35f4:	c606                	sw	ra,12(sp)
    35f6:	c422                	sw	s0,8(sp)
    35f8:	c226                	sw	s1,4(sp)
//		Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);	
//		Delay_ms(1000);
//		Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
//		Delay_ms(100);
//	}
	SET_PRT_DATA_PARP();
    35fa:	0f5000ef          	jal	3eee <SET_PRT_DATA_PARP>
	uint32_t state = *RD_State_REG;
    35fe:	600186b7          	lui	a3,0x60018
    3602:	529c                	lw	a5,32(a3)
//	printf("%d\n", state);
	//初始化：定时器、寄存器初始化 高压初始化/////////////
	timer_init(0, 1000); // 1ms的中断
    3604:	3e800593          	li	a1,1000
    3608:	4501                	li	a0,0
    360a:	095000ef          	jal	3e9e <timer_init>
	Mot_Register_Initial();
    360e:	469000ef          	jal	4276 <Mot_Register_Initial>
	Delay_ms(50);
    3612:	03200513          	li	a0,50
    3616:	225000ef          	jal	403a <Delay_ms>
	*COLOR_CTR_REG = 0b1111;
    361a:	600187b7          	lui	a5,0x60018
    361e:	473d                	li	a4,15
    3620:	0ae7a823          	sw	a4,176(a5) # 600180b0 <__heap_end+0x3ffe80b0>
	
	//////////////////////////////self_check////////////
	///TI NIP之前开启所有的电机  高压复位 启动高压自检
	Delay_ms(2000);
    3624:	7d000513          	li	a0,2000
    3628:	213000ef          	jal	403a <Delay_ms>
	FEED_Motor_Start();
    362c:	337000ef          	jal	4162 <FEED_Motor_Start>
	Delay_ms(100);
    3630:	06400513          	li	a0,100
    3634:	207000ef          	jal	403a <Delay_ms>
	FUSER_Motor_Start();
    3638:	21b000ef          	jal	4052 <FUSER_Motor_Start>
	Delay_ms(100);
    363c:	06400513          	li	a0,100
    3640:	1fb000ef          	jal	403a <Delay_ms>
	BLDC_K_Motor_Start();
    3644:	125000ef          	jal	3f68 <BLDC_K_Motor_Start>
	Delay_ms(100);		
    3648:	06400513          	li	a0,100
    364c:	1ef000ef          	jal	403a <Delay_ms>
	BLDC_YMC_Motor_Start();
    3650:	15d000ef          	jal	3fac <BLDC_YMC_Motor_Start>
	Delay_ms(143);
    3654:	08f00513          	li	a0,143
    3658:	1e3000ef          	jal	403a <Delay_ms>
	Clutch_CtrlREG = FAN_SMPS_Open(Clutch_CtrlREG);
    365c:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3660:	3f7000ef          	jal	4256 <FAN_SMPS_Open>
    3664:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
	Delay_ms(150);
    3668:	09600513          	li	a0,150
    366c:	1cf000ef          	jal	403a <Delay_ms>
    *HVCtrl_REG = 0x0000;//高压模块reset,bit4 复位
    3670:	600187b7          	lui	a5,0x60018
    3674:	09878793          	addi	a5,a5,152 # 60018098 <__heap_end+0x3ffe8098>
    3678:	0007a023          	sw	zero,0(a5)
    *HVCtrl_PrintPage_REG = 0 ;//打印页数为0
    367c:	60018737          	lui	a4,0x60018
    3680:	08072e23          	sw	zero,156(a4) # 6001809c <__heap_end+0x3ffe809c>
	Delay_ms(20);
    3684:	4551                	li	a0,20
    3686:	1b5000ef          	jal	403a <Delay_ms>
	temp_HVPS_Ctrol_REG |= 0x0054; //0b000010000;/reset end,bit2启动高压自检
    368a:	07c1a703          	lw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
	*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    368e:	600187b7          	lui	a5,0x60018
    3692:	09878793          	addi	a5,a5,152 # 60018098 <__heap_end+0x3ffe8098>
	temp_HVPS_Ctrol_REG |= 0x0054; //0b000010000;/reset end,bit2启动高压自检
    3696:	05476713          	ori	a4,a4,84
    369a:	06e1ae23          	sw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
	*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    369e:	c398                	sw	a4,0(a5)
	Delay_ms(380);//根据原装机时序，高压初始化在T1之前	
    36a0:	17c00513          	li	a0,380
    36a4:	197000ef          	jal	403a <Delay_ms>
	
	///T1_Clutch
	int times=400;
	T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
    36a8:	600186b7          	lui	a3,0x60018
    36ac:	4edc                	lw	a5,28(a3)
    36ae:	8bc1                	andi	a5,a5,16
    36b0:	0047d713          	srli	a4,a5,0x4
    36b4:	08e18ea3          	sb	a4,157(gp) # 20000585 <T1_RELEASE_HOME>
	if (T1_RELEASE_HOME==1) {
    36b8:	c79d                	beqz	a5,36e6 <main+0xf4>
		Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
    36ba:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    36be:	379000ef          	jal	4236 <T1_SOL_Open>
    36c2:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
	int times=400;
    36c6:	19000793          	li	a5,400
		while (1) {
			Delay_ms(5);
    36ca:	4515                	li	a0,5
    36cc:	c03e                	sw	a5,0(sp)
    36ce:	16d000ef          	jal	403a <Delay_ms>
			if (T1_RELEASE_HOME==0) {
    36d2:	09d1c703          	lbu	a4,157(gp) # 20000585 <T1_RELEASE_HOME>
    36d6:	4782                	lw	a5,0(sp)
    36d8:	60071663          	bnez	a4,3ce4 <main+0x6f2>
				printf("T1_SENS_RELEASE_HOME OK!\n");
    36dc:	6519                	lui	a0,0x6
    36de:	09450513          	addi	a0,a0,148 # 6094 <sg_timer_config+0x104>
				break;
			}
			else {
				if (times--==0) {
					printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
    36e2:	57c010ef          	jal	4c5e <puts>
					break;
				}
			}
		}
	}
	Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
    36e6:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    36ea:	35b000ef          	jal	4244 <T1_SOL_Close>
    36ee:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
	
	Delay_ms(100);
    36f2:	06400513          	li	a0,100
    36f6:	145000ef          	jal	403a <Delay_ms>
	
	//NIP
	SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//	
    36fa:	600187b7          	lui	a5,0x60018
    36fe:	4fdc                	lw	a5,28(a5)
    3700:	8ba1                	andi	a5,a5,8
    3702:	0037d713          	srli	a4,a5,0x3
    3706:	08e18e23          	sb	a4,156(gp) # 20000584 <SENS_NIP_HOME>
	if (SENS_NIP_HOME==1) {
    370a:	cf9d                	beqz	a5,3748 <main+0x156>
		Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
    370c:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3710:	309000ef          	jal	4218 <NipSOL_Open>
    3714:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
		Delay_ms(110);
    3718:	06e00513          	li	a0,110
    371c:	11f000ef          	jal	403a <Delay_ms>
		Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
    3720:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3724:	303000ef          	jal	4226 <NipSOL_Close>
    3728:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
		Delay_ms(500);
    372c:	1f400513          	li	a0,500
    3730:	10b000ef          	jal	403a <Delay_ms>
		if (SENS_NIP_HOME==1) {
    3734:	09c1c703          	lbu	a4,156(gp) # 20000584 <SENS_NIP_HOME>
    3738:	4785                	li	a5,1
    373a:	00f71763          	bne	a4,a5,3748 <main+0x156>
			printf("NIP_SENS-timeout!!!\n");
    373e:	6519                	lui	a0,0x6
    3740:	0d050513          	addi	a0,a0,208 # 60d0 <sg_timer_config+0x140>
    3744:	51a010ef          	jal	4c5e <puts>
		}
	}
	printf("NIP_SENS-ok!\n");
    3748:	6799                	lui	a5,0x6
    374a:	0e478513          	addi	a0,a5,228 # 60e4 <sg_timer_config+0x154>
    374e:	510010ef          	jal	4c5e <puts>
	
	BLDC_YMC_Motor_Stop();
    3752:	0a3000ef          	jal	3ff4 <BLDC_YMC_Motor_Stop>
	Delay_ms(472);
    3756:	1d800513          	li	a0,472
    375a:	0e1000ef          	jal	403a <Delay_ms>
	FEED_Motor_Stop();
    375e:	7f0000ef          	jal	3f4e <FEED_Motor_Stop>
	Delay_ms(100);
    3762:	06400513          	li	a0,100
    3766:	0d5000ef          	jal	403a <Delay_ms>
	BLDC_K_Motor_Stop();
    376a:	037000ef          	jal	3fa0 <BLDC_K_Motor_Stop>
	Delay_ms(100);
    376e:	06400513          	li	a0,100
    3772:	0c9000ef          	jal	403a <Delay_ms>
	FUSER_Motor_Stop();
    3776:	7b2000ef          	jal	3f28 <FUSER_Motor_Stop>
//
//	////自检完成后，关闭所有电机 
	Delay_ms(4000);
	All_Motor_Stop();
 */
   	Delay_ms(2200);//高压自检剩余时间
    377a:	6505                	lui	a0,0x1
    377c:	89850513          	addi	a0,a0,-1896 # 898 <__umoddi3+0x346>
    3780:	0bb000ef          	jal	403a <Delay_ms>
	//////////////////////////作业开始信号读取 此处为while(1)循环，当一次作业完成之后，程序将在此处等待上位机发送的下一次任务
	////////////////////////在while(1)函数内部的最开始地方会有循环读取上位机发送的信号，现在测试时进行了屏蔽。
	while (1) {

		temp_HVPS_Ctrol_REG = 0x0000; //0b000010000;//reset ,
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3784:	60018737          	lui	a4,0x60018
    3788:	09870713          	addi	a4,a4,152 # 60018098 <__heap_end+0x3ffe8098>
		temp_HVPS_Ctrol_REG = 0x0000; //0b000010000;//reset ,
    378c:	0601ae23          	sw	zero,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
		Delay_ms(100);
    3790:	06400513          	li	a0,100
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3794:	00072023          	sw	zero,0(a4)
		Delay_ms(100);
    3798:	0a3000ef          	jal	403a <Delay_ms>
			temp_HVPS_Ctrol_REG = 0x0010; //0b000010000;//reset end,
    379c:	46c1                	li	a3,16
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    379e:	600187b7          	lui	a5,0x60018
			temp_HVPS_Ctrol_REG = 0x0010; //0b000010000;//reset end,
    37a2:	06d1ae23          	sw	a3,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    37a6:	09878713          	addi	a4,a5,152 # 60018098 <__heap_end+0x3ffe8098>
    37aa:	c314                	sw	a3,0(a4)

		*THV_EN_DELAY_REG   = 4000000;//高压THV_EN400ms高电平部分时间
    37ac:	003d1737          	lui	a4,0x3d1
    37b0:	90070713          	addi	a4,a4,-1792 # 3d0900 <__ctor_end__+0x3c9d40>
    37b4:	12e7a223          	sw	a4,292(a5)
		*CH_DELAY_REG=7738000;
    37b8:	00761737          	lui	a4,0x761
    37bc:	29070713          	addi	a4,a4,656 # 761290 <__ctor_end__+0x75a6d0>
    37c0:	12e7a423          	sw	a4,296(a5)
		*DEVE_DELAY_REG=3300000;
    37c4:	00326737          	lui	a4,0x326
    37c8:	aa070713          	addi	a4,a4,-1376 # 325aa0 <__ctor_end__+0x31eee0>
    37cc:	12e7a623          	sw	a4,300(a5)
		
		TimeInitial=0;
    37d0:	04018b23          	sb	zero,86(gp) # 2000053e <TimeInitial>
		Printer_Para_init();//打印相关变量初始化
    37d4:	2ef000ef          	jal	42c2 <Printer_Para_init>
		Printer_Var_Init();//打印过程中计数器等进行初始化
    37d8:	337000ef          	jal	430e <Printer_Var_Init>
		Page_Sync_Close();
    37dc:	483000ef          	jal	445e <Page_Sync_Close>
		fuser_release();
    37e0:	48b000ef          	jal	446a <fuser_release>
	
		int32_t num;
		num = *PRINTHEAD_REG;
		///与上位机同步握手信号
		ReSet = (*PrintCtrl_REG & 0x0001) > 0 ? 1 : 0;
    37e4:	600187b7          	lui	a5,0x60018
		num = *PRINTHEAD_REG;
    37e8:	60018737          	lui	a4,0x60018
    37ec:	09072703          	lw	a4,144(a4) # 60018090 <__heap_end+0x3ffe8090>
		ReSet = (*PrintCtrl_REG & 0x0001) > 0 ? 1 : 0;
    37f0:	4b98                	lw	a4,16(a5)
    37f2:	07c1                	addi	a5,a5,16 # 60018010 <__heap_end+0x3ffe8010>
    37f4:	8b05                	andi	a4,a4,1
    37f6:	0ae18423          	sb	a4,168(gp) # 20000590 <ReSet>
		while (ReSet == 0) {
    37fa:	4601                	li	a2,0
    37fc:	4e070d63          	beqz	a4,3cf6 <main+0x704>
    3800:	c601                	beqz	a2,3808 <main+0x216>
    3802:	4705                	li	a4,1
    3804:	0ae18423          	sb	a4,168(gp) # 20000590 <ReSet>
			ReSet = (*PrintCtrl_REG & 0x0001) > 0 ? 1 : 0;
		}
		//printf("ACK OK\n");
		
		/////判断参数是否设置成功
		Mode_Finish = (*PrintCtrl_REG & 0x0040) > 0 ? 1 : 0;
    3808:	4398                	lw	a4,0(a5)
		while (Mode_Finish == 0) {
    380a:	4601                	li	a2,0
		Mode_Finish = (*PrintCtrl_REG & 0x0040) > 0 ? 1 : 0;
    380c:	8319                	srli	a4,a4,0x6
    380e:	8b05                	andi	a4,a4,1
    3810:	0ae19a23          	sh	a4,180(gp) # 2000059c <Mode_Finish>
		while (Mode_Finish == 0) {
    3814:	4e070563          	beqz	a4,3cfe <main+0x70c>
    3818:	c601                	beqz	a2,3820 <main+0x22e>
    381a:	4705                	li	a4,1
    381c:	0ae19a23          	sh	a4,180(gp) # 2000059c <Mode_Finish>
			Mode_Finish = (*PrintCtrl_REG & 0x0040) > 0 ? 1 : 0;
		}
		//printf("Mode_Finish ok\n");
		
		TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;//作业开始命令
    3820:	4394                	lw	a3,0(a5)
    3822:	8295                	srli	a3,a3,0x5
    3824:	8a85                	andi	a3,a3,1
    3826:	0ad18623          	sb	a3,172(gp) # 20000594 <TaskStart>
		StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;//打印终止命令
    382a:	4398                	lw	a4,0(a5)
		while(TaskStart==0 || StopPrint==1){ ////循环接收打印开始信号
    382c:	4501                	li	a0,0
		StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;//打印终止命令
    382e:	830d                	srli	a4,a4,0x3
    3830:	8b05                	andi	a4,a4,1
    3832:	0ae18d23          	sb	a4,186(gp) # 200005a2 <StopPrint>
		while(TaskStart==0 || StopPrint==1){ ////循环接收打印开始信号
    3836:	4585                	li	a1,1
    3838:	4c068863          	beqz	a3,3d08 <main+0x716>
    383c:	4cb70663          	beq	a4,a1,3d08 <main+0x716>
    3840:	c509                	beqz	a0,384a <main+0x258>
    3842:	0ab18623          	sb	a1,172(gp) # 20000594 <TaskStart>
    3846:	0a018d23          	sb	zero,186(gp) # 200005a2 <StopPrint>
			TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;
			StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;			

		}
		//printf("TaskStart ok\n");		
	    Color_Choose = (*PrintMode_REG & 0x0040) > 0 ? 1 : 0;
    384a:	60018737          	lui	a4,0x60018
    384e:	4758                	lw	a4,12(a4)
/////在打开加热电机之前，打开所有运动所需电机
		
		//PrintPage = 1;//读取潜像页数  第2次
		//*HVCtrl_PrintPage_REG = PrintPage ;

		Delay_ms(20);
    3850:	4551                	li	a0,20
	    Color_Choose = (*PrintMode_REG & 0x0040) > 0 ? 1 : 0;
    3852:	8319                	srli	a4,a4,0x6
    3854:	8b05                	andi	a4,a4,1
    3856:	0ae184a3          	sb	a4,169(gp) # 20000591 <Color_Choose>
		Delay_ms(20);
    385a:	7e0000ef          	jal	403a <Delay_ms>
		//*HVCtrl_REG = 0b000010000;//reset end
		////over
		///HV waiting
		/*0615暂时先将这段放置开加热之后，防止加热前开高压，飞粉*/
		Delay_ms(20);
    385e:	4551                	li	a0,20
    3860:	7da000ef          	jal	403a <Delay_ms>
		temp_HVPS_Ctrol_REG |= 0x0032 | (Color_Choose? 0x0100:0x0000);//0b100110010;//bit1 startup 启动任务，bit8选择是否彩色打印
    3864:	0a91c703          	lbu	a4,169(gp) # 20000591 <Color_Choose>
    3868:	07c1a683          	lw	a3,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
    386c:	00173713          	seqz	a4,a4
    3870:	40e00733          	neg	a4,a4
    3874:	f0077713          	andi	a4,a4,-256
    3878:	13270713          	addi	a4,a4,306 # 60018132 <__heap_end+0x3ffe8132>
    387c:	8f55                	or	a4,a4,a3
      //temp_HVPS_Ctrol_REG |= 0x0032 ;//0b100110010;//bit1 startup 启动任务，bit8选择是否彩色打印	
	    *HVCtrl_REG =temp_HVPS_Ctrol_REG;		
    387e:	600186b7          	lui	a3,0x60018
		temp_HVPS_Ctrol_REG |= 0x0032 | (Color_Choose? 0x0100:0x0000);//0b100110010;//bit1 startup 启动任务，bit8选择是否彩色打印
    3882:	06e1ae23          	sw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
	    *HVCtrl_REG =temp_HVPS_Ctrol_REG;		
    3886:	09868693          	addi	a3,a3,152 # 60018098 <__heap_end+0x3ffe8098>
    388a:	c298                	sw	a4,0(a3)
	
		FEED_Motor_Start();
    388c:	0d7000ef          	jal	4162 <FEED_Motor_Start>
		Delay_ms(100);
    3890:	06400513          	li	a0,100
    3894:	7a6000ef          	jal	403a <Delay_ms>
		/*0615暂时先将这段放置开加热之后，防止加热前开高压，飞粉*/
		Delay_ms(2000);
    3898:	7d000513          	li	a0,2000
    389c:	79e000ef          	jal	403a <Delay_ms>
		temp_HVPS_Ctrol_REG &= 0xFFDF;//0b100010010;//bit5 低电平有效nfeed_en
    38a0:	07c1a703          	lw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
    38a4:	6641                	lui	a2,0x10
    38a6:	fdf60613          	addi	a2,a2,-33 # ffdf <__ctor_end__+0x941f>
    38aa:	8f71                	and	a4,a4,a2
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
    38ac:	600187b7          	lui	a5,0x60018
    38b0:	09878693          	addi	a3,a5,152 # 60018098 <__heap_end+0x3ffe8098>
		temp_HVPS_Ctrol_REG &= 0xFFDF;//0b100010010;//bit5 低电平有效nfeed_en
    38b4:	06e1ae23          	sw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
    38b8:	c298                	sw	a4,0(a3)
		
		fuser_clamping();
    38ba:	453000ef          	jal	450c <fuser_clamping>
		Delay_ms(1170);
    38be:	49200513          	li	a0,1170
    38c2:	2fa5                	jal	403a <Delay_ms>
		FUSER_Motor_Start();
    38c4:	2779                	jal	4052 <FUSER_Motor_Start>
		Delay_ms(100);
    38c6:	06400513          	li	a0,100
    38ca:	2f85                	jal	403a <Delay_ms>
		LSU_Motor_Start();
    38cc:	2f15                	jal	4000 <LSU_Motor_Start>
		Delay_ms(100);
    38ce:	06400513          	li	a0,100
    38d2:	27a5                	jal	403a <Delay_ms>
		BLDC_K_Motor_Start();
    38d4:	2d51                	jal	3f68 <BLDC_K_Motor_Start>
		Delay_ms(100);		
    38d6:	06400513          	li	a0,100
    38da:	2785                	jal	403a <Delay_ms>
		BLDC_YMC_Motor_Start();
    38dc:	2dc1                	jal	3fac <BLDC_YMC_Motor_Start>
		Delay_ms(100);
    38de:	06400513          	li	a0,100
    38e2:	2fa1                	jal	403a <Delay_ms>
		///打开电机后，进行打印头初始化
		PrintHead_Initial();
    38e4:	2df000ef          	jal	43c2 <PrintHead_Initial>
		Delay_ms(20);
    38e8:	4551                	li	a0,20
    38ea:	2f81                	jal	403a <Delay_ms>
		PrintHead_PrintMode_Set();
    38ec:	35b000ef          	jal	4446 <PrintHead_PrintMode_Set>
		Delay_ms(2930);
    38f0:	6505                	lui	a0,0x1
    38f2:	b7250513          	addi	a0,a0,-1166 # b72 <__adddf3+0x2d6>
    38f6:	2791                	jal	403a <Delay_ms>


//		///打开加热
		#ifdef heat_open
			//AVR_DATA_start=1;
			*ADC_HeaterCtrl_REG=0x0002;//模块初始化
    38f8:	60018737          	lui	a4,0x60018
    38fc:	4689                	li	a3,2
    38fe:	0cd72c23          	sw	a3,216(a4) # 600180d8 <__heap_end+0x3ffe80d8>
			Heat_Open();
    3902:	493000ef          	jal	4594 <Heat_Open>
			//printf("Heat_Open\n");
		#endif
		

		//////等待打印开始命令
		CMD_Start = (*PrintCtrl_REG&0X0010)>0?1:0; //作业开始命令
    3906:	600187b7          	lui	a5,0x60018
    390a:	4b94                	lw	a3,16(a5)
    390c:	8291                	srli	a3,a3,0x4
    390e:	8a85                	andi	a3,a3,1
    3910:	0ad18da3          	sb	a3,187(gp) # 200005a3 <CMD_Start>
		StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//打印终止命令
    3914:	4b90                	lw	a2,16(a5)
		CMD_Start = (*PrintCtrl_REG&0X0010)>0?1:0; //作业开始命令
    3916:	07c1                	addi	a5,a5,16 # 60018010 <__heap_end+0x3ffe8010>
		///等待打印开始命令
		while (CMD_Start == 0)
    3918:	4581                	li	a1,0
		StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//打印终止命令
    391a:	820d                	srli	a2,a2,0x3
    391c:	8a05                	andi	a2,a2,1
    391e:	0ac18d23          	sb	a2,186(gp) # 200005a2 <StopPrint>
		while (CMD_Start == 0)
    3922:	4305                	li	t1,1
    3924:	8732                	mv	a4,a2
    3926:	3e068963          	beqz	a3,3d18 <main+0x726>
    392a:	c591                	beqz	a1,3936 <main+0x344>
    392c:	0a618da3          	sb	t1,187(gp) # 200005a3 <CMD_Start>
    3930:	0ae18d23          	sb	a4,186(gp) # 200005a2 <StopPrint>
    3934:	863a                	mv	a2,a4
			CMD_Start  = (*PrintCtrl_REG & 0x0010) ? 1 : 0;
			StopPrint = (*PrintCtrl_REG & 0x0008) ? 1 : 0;
		}
		//printf("CMD_Start ok\n");	
		////如果作业取消则停止打印
		if(StopPrint==1){
    3936:	4705                	li	a4,1
    3938:	3ee60863          	beq	a2,a4,3d28 <main+0x736>
			Delay_ms(5000);
			//printf("StopPrint==1\n");	
			continue;
		}	
	 	//读取打印页数寄存器
		StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
    393c:	4390                	lw	a2,0(a5)
    393e:	8a21                	andi	a2,a2,8
    3940:	00365713          	srli	a4,a2,0x3
    3944:	0ae18d23          	sb	a4,186(gp) # 200005a2 <StopPrint>
		DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
    3948:	4398                	lw	a4,0(a5)
    394a:	8305                	srli	a4,a4,0x1
    394c:	8b05                	andi	a4,a4,1
    394e:	0ae18823          	sb	a4,176(gp) # 20000598 <DataFinsh>
		PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3952:	600186b7          	lui	a3,0x60018
    3956:	4694                	lw	a3,8(a3)
    3958:	0ad19923          	sh	a3,178(gp) # 2000059a <PrintPage>
	////20260412 增加页数更新和数据传输结束
		*HVCtrl_PrintPage_REG = PrintPage ;
    395c:	06c2                	slli	a3,a3,0x10
    395e:	82c1                	srli	a3,a3,0x10
    3960:	600185b7          	lui	a1,0x60018
    3964:	08d5ae23          	sw	a3,156(a1) # 6001809c <__heap_end+0x3ffe809c>
		
		temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3968:	66a1                	lui	a3,0x8
    396a:	e219                	bnez	a2,3970 <main+0x37e>
    396c:	00f71693          	slli	a3,a4,0xf
    3970:	07c1a703          	lw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
    3974:	8f55                	or	a4,a4,a3
    3976:	06e1ae23          	sw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    397a:	600186b7          	lui	a3,0x60018
    397e:	08e6ac23          	sw	a4,152(a3) # 60018098 <__heap_end+0x3ffe8098>
		//检测是否预热到指定温度
		#ifdef heat_open
			//check_temperature2();
			unsigned int Heat_Count = 0;
    
			for (Heat_Count = 0; Heat_Count < 20; Heat_Count++)
    3982:	4681                	li	a3,0
			{
				// 读取就绪标志
				Heat_Ready = (*ERROR_CPU_REG & 0x0001) ? 1 : 0;
    3984:	60018737          	lui	a4,0x60018
    3988:	4f18                	lw	a4,24(a4)
    398a:	8b05                	andi	a4,a4,1
    398c:	0ae183a3          	sb	a4,167(gp) # 2000058f <Heat_Ready>
        
				if (Heat_Ready == 1)
    3990:	3a070963          	beqz	a4,3d42 <main+0x750>
				{
					heat_is_timeout = 0; // 10s内读到就绪，未超时
    3994:	00018623          	sb	zero,12(gp) # 200004f4 <heat_is_timeout>
				// 未就绪，延时1s再检测下一次
				Delay_ms(1000);
			}

			// 仅超时才执行关机流程
			if (heat_is_timeout == 1)
    3998:	00c1c683          	lbu	a3,12(gp) # 200004f4 <heat_is_timeout>
    399c:	4705                	li	a4,1
    399e:	3ae68c63          	beq	a3,a4,3d56 <main+0x764>
		
		//*HVCtrl_PrintPage_REG=2;
		//只有当打印页数不为0时，才向下继续运行，才给打印头发送enable信号，以此来保证打印头收到enable之前页数不为0
		while(1){
		
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    39a2:	600186b7          	lui	a3,0x60018
			*HVCtrl_PrintPage_REG = PrintPage ;
    39a6:	60018737          	lui	a4,0x60018
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    39aa:	06a1                	addi	a3,a3,8 # 60018008 <__heap_end+0x3ffe8008>
			*HVCtrl_PrintPage_REG = PrintPage ;
    39ac:	09c70713          	addi	a4,a4,156 # 6001809c <__heap_end+0x3ffe809c>
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    39b0:	429c                	lw	a5,0(a3)
    39b2:	07c2                	slli	a5,a5,0x10
    39b4:	83c1                	srli	a5,a5,0x10
			*HVCtrl_PrintPage_REG = PrintPage ;
    39b6:	c31c                	sw	a5,0(a4)
			if(PrintPage!=0)
    39b8:	dfe5                	beqz	a5,39b0 <main+0x3be>
    39ba:	0af19923          	sh	a5,178(gp) # 2000059a <PrintPage>
				break;
			//printf("printpage is %d\n", PrintPage);
		}

		TimeInitial=1;//打印流程定时器开启  此信号不能过早也不能过晚设置 此时中断开始检测regi sens信号的边沿变化
    39be:	4785                	li	a5,1
    39c0:	04f18b23          	sb	a5,86(gp) # 2000053e <TimeInitial>
		Printed_Page = 0;//已经打印的页数
    39c4:	0a019723          	sh	zero,174(gp) # 20000596 <Printed_Page>
		//测试用，默认单面打印
		Douflag=1;
    39c8:	00f18da3          	sb	a5,27(gp) # 20000503 <Douflag>
			//PrintStartHflag=1;//模拟打印头start信号，暂时不用这个信号。纸张从纸盒中搓出的行为，在主函数中执行。
			//打印头ON
			//Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
			///T1_Clutch
			
			temp_HVPS_Ctrol_REG |=0x0040; // 0b101010010;//bit6 SYN_HV_EN	
    39cc:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    39d0:	60018737          	lui	a4,0x60018
			temp_HVPS_Ctrol_REG |=0x0040; // 0b101010010;//bit6 SYN_HV_EN	
    39d4:	0407e793          	ori	a5,a5,64
    39d8:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    39dc:	08f72c23          	sw	a5,152(a4) # 60018098 <__heap_end+0x3ffe8098>
			times=400;
			T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
    39e0:	4f5c                	lw	a5,28(a4)
    39e2:	8bc1                	andi	a5,a5,16
    39e4:	0047d713          	srli	a4,a5,0x4
    39e8:	08e18ea3          	sb	a4,157(gp) # 20000585 <T1_RELEASE_HOME>
			if (T1_RELEASE_HOME==1) {
    39ec:	c795                	beqz	a5,3a18 <main+0x426>
				Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
    39ee:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    39f2:	045000ef          	jal	4236 <T1_SOL_Open>
    39f6:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			times=400;
    39fa:	19000793          	li	a5,400
				while (1) {
					Delay_ms(5);
    39fe:	4515                	li	a0,5
    3a00:	c03e                	sw	a5,0(sp)
    3a02:	2d25                	jal	403a <Delay_ms>
					if (T1_RELEASE_HOME==0) {
    3a04:	09d1c703          	lbu	a4,157(gp) # 20000585 <T1_RELEASE_HOME>
    3a08:	4782                	lw	a5,0(sp)
    3a0a:	36071d63          	bnez	a4,3d84 <main+0x792>
						printf("T1_SENS_RELEASE_HOME OK!\n");
    3a0e:	6519                	lui	a0,0x6
    3a10:	09450513          	addi	a0,a0,148 # 6094 <sg_timer_config+0x104>
						break;
					}
					else {
						if (times--==0) {
							printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
    3a14:	24a010ef          	jal	4c5e <puts>
							break;
						}
					}
				}
			}
			Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
    3a18:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3a1c:	029000ef          	jal	4244 <T1_SOL_Close>
    3a20:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
	
			Delay_ms(100);
    3a24:	06400513          	li	a0,100
    3a28:	2d09                	jal	403a <Delay_ms>
	
			//NIP
			SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//	
    3a2a:	600187b7          	lui	a5,0x60018
    3a2e:	4fdc                	lw	a5,28(a5)
    3a30:	8ba1                	andi	a5,a5,8
    3a32:	0037d713          	srli	a4,a5,0x3
    3a36:	08e18e23          	sb	a4,156(gp) # 20000584 <SENS_NIP_HOME>
			if (SENS_NIP_HOME==1) {
    3a3a:	cf8d                	beqz	a5,3a74 <main+0x482>
				Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
    3a3c:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3a40:	7d8000ef          	jal	4218 <NipSOL_Open>
    3a44:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				Delay_ms(110);
    3a48:	06e00513          	li	a0,110
    3a4c:	23fd                	jal	403a <Delay_ms>
				Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
    3a4e:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3a52:	7d4000ef          	jal	4226 <NipSOL_Close>
    3a56:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
				Delay_ms(500);
    3a5a:	1f400513          	li	a0,500
    3a5e:	2bf1                	jal	403a <Delay_ms>
				if (SENS_NIP_HOME==1) {
    3a60:	09c1c703          	lbu	a4,156(gp) # 20000584 <SENS_NIP_HOME>
    3a64:	4785                	li	a5,1
    3a66:	00f71763          	bne	a4,a5,3a74 <main+0x482>
				printf("NIP_SENS-timeout!!!\n");
    3a6a:	6519                	lui	a0,0x6
    3a6c:	0d050513          	addi	a0,a0,208 # 60d0 <sg_timer_config+0x140>
    3a70:	1ee010ef          	jal	4c5e <puts>
				}	
			}
			printf("NIP_SENS-ok!\n");
    3a74:	6799                	lui	a5,0x6
    3a76:	0e478513          	addi	a0,a5,228 # 60e4 <sg_timer_config+0x154>
    3a7a:	1e4010ef          	jal	4c5e <puts>
			Delay_ms(150);
			Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
	
			*/
			
			*PRINTHEAD_REG = 0b00110;	//打印头寄存器置初值
    3a7e:	600187b7          	lui	a5,0x60018
    3a82:	4719                	li	a4,6
    3a84:	08e7a823          	sw	a4,144(a5) # 60018090 <__heap_end+0x3ffe8090>
			//HV sync
			//*HVCtrl_REG = 0b101010010;//SYN_HV_EN
			Delay_ms(24);//根据原装机信号修改T1延时			
    3a88:	4561                	li	a0,24
    3a8a:	2b45                	jal	403a <Delay_ms>
			//Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);		
			Delay_ms(1416);//	1016ms与高压nTHV_EN信号400ms高电平起始对齐,400ms后检测高压反馈信号
    3a8c:	58800513          	li	a0,1416
    3a90:	236d                	jal	403a <Delay_ms>
	  		HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
    3a92:	600187b7          	lui	a5,0x60018
    3a96:	43dc                	lw	a5,4(a5)
			while (HV_Ready == 0) {
		
				HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
    3a98:	60018737          	lui	a4,0x60018
	  		HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
    3a9c:	8391                	srli	a5,a5,0x4
    3a9e:	8b85                	andi	a5,a5,1
    3aa0:	0af18323          	sb	a5,166(gp) # 2000058e <HV_Ready>
			while (HV_Ready == 0) {
    3aa4:	4601                	li	a2,0
				HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
    3aa6:	0711                	addi	a4,a4,4 # 60018004 <__heap_end+0x3ffe8004>
			while (HV_Ready == 0) {
    3aa8:	2e078663          	beqz	a5,3d94 <main+0x7a2>
    3aac:	c601                	beqz	a2,3ab4 <main+0x4c2>
    3aae:	4785                	li	a5,1
    3ab0:	0af18323          	sb	a5,166(gp) # 2000058e <HV_Ready>
			}
			//printf("HV_Ready=1\n");
			//	Delay_ms(400);
			////页同步信号，1页是1856ms，页和页之间的间隔是200ms 所以页同步信号是2056ms
		////////////////pagesync到pickupcl开启的时间是：3.386s/////////////////////////
			Page_Sync_ON();
    3ab4:	19f000ef          	jal	4452 <Page_Sync_ON>
			//time_flag_count_A=time_flag_count;
			//printf("Page_Sync_ON send\n");
			PageSync_Enable=1;		
			Delay_ms(2700);//调整这个参数能够 调整图像在纸张上的位置   Y数据到pickup开 //1900  2700
    3ab8:	6505                	lui	a0,0x1
			PageSync_Enable=1;		
    3aba:	4705                	li	a4,1
			Delay_ms(2700);//调整这个参数能够 调整图像在纸张上的位置   Y数据到pickup开 //1900  2700
    3abc:	a8c50513          	addi	a0,a0,-1396 # a8c <__adddf3+0x1f0>
			PageSync_Enable=1;		
    3ac0:	04e1a823          	sw	a4,80(gp) # 20000538 <PageSync_Enable>
			Delay_ms(2700);//调整这个参数能够 调整图像在纸张上的位置   Y数据到pickup开 //1900  2700
    3ac4:	2b9d                	jal	403a <Delay_ms>
			
		
			Clutch_CtrlREG=PlateSOL_Open(Clutch_CtrlREG);//开plate离合 //从开plate离合到while(!again_paper){}之间的延时总和不能变！
    3ac6:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3aca:	2f05                	jal	41fa <PlateSOL_Open>
    3acc:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			//printf("PlateSOL_Open\n");
			Delay_ms(160);
    3ad0:	0a000513          	li	a0,160
    3ad4:	239d                	jal	403a <Delay_ms>
			
			Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
    3ad6:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3ada:	2709                	jal	41dc <PickupCL_Open>
			////////////////pagesync到pickupcl开启的时间是：3.386s////////////////////////////
		
			//printf("time_flag_count is %d\n",time_flag_count);
			//printf("PickupCL_Open\n");
		
			temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
    3adc:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    3ae0:	600186b7          	lui	a3,0x60018
			Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
    3ae4:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
    3ae8:	0807e793          	ori	a5,a5,128
    3aec:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    3af0:	09868713          	addi	a4,a3,152 # 60018098 <__heap_end+0x3ffe8098>
    3af4:	c31c                	sw	a5,0(a4)
			
				//*	************20260623 调整DataFinsh与PICKUP时序关系，因为实际DataFinsh完成后才能PICKUP，所以先给高压发送DataFinsh			
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
    3af6:	4a90                	lw	a2,16(a3)
    3af8:	8a21                	andi	a2,a2,8
    3afa:	00365793          	srli	a5,a2,0x3
    3afe:	0af18d23          	sb	a5,186(gp) # 200005a2 <StopPrint>
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
    3b02:	4a9c                	lw	a5,16(a3)
    3b04:	8385                	srli	a5,a5,0x1
    3b06:	8b85                	andi	a5,a5,1
    3b08:	0af18823          	sb	a5,176(gp) # 20000598 <DataFinsh>
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3b0c:	4694                	lw	a3,8(a3)
    3b0e:	0ad19923          	sh	a3,178(gp) # 2000059a <PrintPage>
	
			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
    3b12:	06c2                	slli	a3,a3,0x10
    3b14:	82c1                	srli	a3,a3,0x10
    3b16:	600185b7          	lui	a1,0x60018
    3b1a:	08d5ae23          	sw	a3,156(a1) # 6001809c <__heap_end+0x3ffe809c>
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3b1e:	66a1                	lui	a3,0x8
    3b20:	e219                	bnez	a2,3b26 <main+0x534>
    3b22:	00f79693          	slli	a3,a5,0xf
    3b26:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
				
			
			
			Delay_ms(320);
    3b2a:	14000513          	li	a0,320
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3b2e:	8fd5                	or	a5,a5,a3
    3b30:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    3b34:	c31c                	sw	a5,0(a4)
			Delay_ms(320);
    3b36:	2311                	jal	403a <Delay_ms>
		
			temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
    3b38:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
    3b3c:	66c1                	lui	a3,0x10
    3b3e:	f7f68693          	addi	a3,a3,-129 # ff7f <__ctor_end__+0x93bf>
    3b42:	8ff5                	and	a5,a5,a3
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
			Clutch_CtrlREG=PlateSOL_Close(Clutch_CtrlREG);//关plate离合
    3b44:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
    3b48:	60018737          	lui	a4,0x60018
			temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
    3b4c:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
    3b50:	09870713          	addi	a4,a4,152 # 60018098 <__heap_end+0x3ffe8098>
    3b54:	c31c                	sw	a5,0(a4)
			Clutch_CtrlREG=PlateSOL_Close(Clutch_CtrlREG);//关plate离合
    3b56:	2d4d                	jal	4208 <PlateSOL_Close>
    3b58:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			//printf("PlateSOL_Close\n");
	
		
								
			while(!again_paper){}	//在中断中完成一页后，200ms后，again paper置1，实现两张纸之间的间隔	
    3b5c:	0541d783          	lhu	a5,84(gp) # 2000053c <again_paper>
    3b60:	dff5                	beqz	a5,3b5c <main+0x56a>
			again_paper=0;				
    3b62:	04019a23          	sh	zero,84(gp) # 2000053c <again_paper>
			//在下一张纸前对打印的页数等数据进行再次读取					
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
    3b66:	600187b7          	lui	a5,0x60018
    3b6a:	4b88                	lw	a0,16(a5)
    3b6c:	8921                	andi	a0,a0,8
    3b6e:	00355613          	srli	a2,a0,0x3
    3b72:	0ac18d23          	sb	a2,186(gp) # 200005a2 <StopPrint>
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
    3b76:	4b98                	lw	a4,16(a5)
    3b78:	8305                	srli	a4,a4,0x1
    3b7a:	8b05                	andi	a4,a4,1
    3b7c:	0ae18823          	sb	a4,176(gp) # 20000598 <DataFinsh>
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3b80:	479c                	lw	a5,8(a5)
    3b82:	07c2                	slli	a5,a5,0x10
    3b84:	83c1                	srli	a5,a5,0x10
    3b86:	0af19923          	sh	a5,178(gp) # 2000059a <PrintPage>
	
			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
    3b8a:	600185b7          	lui	a1,0x60018
    3b8e:	08f5ae23          	sw	a5,156(a1) # 6001809c <__heap_end+0x3ffe809c>
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3b92:	65a1                	lui	a1,0x8
    3b94:	e119                	bnez	a0,3b9a <main+0x5a8>
    3b96:	00f71593          	slli	a1,a4,0xf
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数

			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3b9a:	07c1a703          	lw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
    3b9e:	8f4d                	or	a4,a4,a1
    3ba0:	06e1ae23          	sw	a4,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3ba4:	600185b7          	lui	a1,0x60018
    3ba8:	08e5ac23          	sw	a4,152(a1) # 60018098 <__heap_end+0x3ffe8098>

			if(Douflag==1)//单面
    3bac:	01b1c583          	lbu	a1,27(gp) # 20000503 <Douflag>
    3bb0:	4705                	li	a4,1
    3bb2:	00e58663          	beq	a1,a4,3bbe <main+0x5cc>
			{
				SendPage= PrintPage;			
			}else    //双面      
			{
				SendPage=(PrintPage+PrintPage%2)/2;			
    3bb6:	97ba                	add	a5,a5,a4
    3bb8:	8785                	srai	a5,a5,0x1
    3bba:	07c2                	slli	a5,a5,0x10
    3bbc:	83c1                	srli	a5,a5,0x10
    3bbe:	0af19c23          	sh	a5,184(gp) # 200005a0 <SendPage>
			}
			Printed_Page = Printed_Page + 1;//已打印页数加1	
    3bc2:	0ae1d783          	lhu	a5,174(gp) # 20000596 <Printed_Page>
    3bc6:	0785                	addi	a5,a5,1 # 60018001 <__heap_end+0x3ffe8001>
    3bc8:	07c2                	slli	a5,a5,0x10
    3bca:	83c1                	srli	a5,a5,0x10
    3bcc:	0af19723          	sh	a5,174(gp) # 20000596 <Printed_Page>
			*PrintedPageNum_REG = Printed_Page;//更新已打印页数	
    3bd0:	60018737          	lui	a4,0x60018
    3bd4:	0cf72423          	sw	a5,200(a4) # 600180c8 <__heap_end+0x3ffe80c8>
		while(StopPrint==0 && Printed_Page<SendPage){
    3bd8:	e619                	bnez	a2,3be6 <main+0x5f4>
    3bda:	0ae1d703          	lhu	a4,174(gp) # 20000596 <Printed_Page>
    3bde:	0b81d783          	lhu	a5,184(gp) # 200005a0 <SendPage>
    3be2:	1af76e63          	bltu	a4,a5,3d9e <main+0x7ac>
		}
	

		//*ErrorCode_REG= 0x0040;//作业完成后给上位机发送作业结束信号  收到stop信号也发送0040
		//多页打印结束需要增加NIP T1信号
		Delay_ms(300);
    3be6:	12c00513          	li	a0,300
    3bea:	2981                	jal	403a <Delay_ms>
		
		///T1_Clutch
		times=400;
		T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
    3bec:	600187b7          	lui	a5,0x60018
    3bf0:	4fdc                	lw	a5,28(a5)
    3bf2:	8bc1                	andi	a5,a5,16
    3bf4:	0047d713          	srli	a4,a5,0x4
    3bf8:	08e18ea3          	sb	a4,157(gp) # 20000585 <T1_RELEASE_HOME>
		if (T1_RELEASE_HOME==1) {
    3bfc:	c78d                	beqz	a5,3c26 <main+0x634>
			Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
    3bfe:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3c02:	2d15                	jal	4236 <T1_SOL_Open>
    3c04:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
		times=400;
    3c08:	19000793          	li	a5,400
			while (1) {
				Delay_ms(5);
    3c0c:	4515                	li	a0,5
    3c0e:	c03e                	sw	a5,0(sp)
    3c10:	212d                	jal	403a <Delay_ms>
				if (T1_RELEASE_HOME==0) {
    3c12:	09d1c703          	lbu	a4,157(gp) # 20000585 <T1_RELEASE_HOME>
    3c16:	4782                	lw	a5,0(sp)
    3c18:	26071b63          	bnez	a4,3e8e <main+0x89c>
					printf("T1_SENS_RELEASE_HOME OK!\n");
    3c1c:	6519                	lui	a0,0x6
    3c1e:	09450513          	addi	a0,a0,148 # 6094 <sg_timer_config+0x104>
					break;
				}
				else {
					if (times--==0) {
						printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
    3c22:	03c010ef          	jal	4c5e <puts>
						break;
					}
				}
			}
		}
		Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
    3c26:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3c2a:	2d29                	jal	4244 <T1_SOL_Close>
    3c2c:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
	
		Delay_ms(100);
    3c30:	06400513          	li	a0,100
    3c34:	2119                	jal	403a <Delay_ms>
	
		//NIP
		SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//	
    3c36:	600187b7          	lui	a5,0x60018
    3c3a:	4fdc                	lw	a5,28(a5)
    3c3c:	8ba1                	andi	a5,a5,8
    3c3e:	0037d693          	srli	a3,a5,0x3
    3c42:	08d18e23          	sb	a3,156(gp) # 20000584 <SENS_NIP_HOME>
		if (SENS_NIP_HOME==1) {
    3c46:	cb9d                	beqz	a5,3c7c <main+0x68a>
			Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
    3c48:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3c4c:	23f1                	jal	4218 <NipSOL_Open>
    3c4e:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			Delay_ms(110);
    3c52:	06e00513          	li	a0,110
    3c56:	26d5                	jal	403a <Delay_ms>
			Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
    3c58:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3c5c:	23e9                	jal	4226 <NipSOL_Close>
    3c5e:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			Delay_ms(500);
    3c62:	1f400513          	li	a0,500
    3c66:	2ed1                	jal	403a <Delay_ms>
			if (SENS_NIP_HOME==1) {
    3c68:	09c1c703          	lbu	a4,156(gp) # 20000584 <SENS_NIP_HOME>
    3c6c:	4785                	li	a5,1
    3c6e:	00f71763          	bne	a4,a5,3c7c <main+0x68a>
			printf("NIP_SENS-timeout!!!\n");
    3c72:	6519                	lui	a0,0x6
    3c74:	0d050513          	addi	a0,a0,208 # 60d0 <sg_timer_config+0x140>
    3c78:	7e7000ef          	jal	4c5e <puts>
			}	
		}
		printf("NIP_SENS-ok!\n");
    3c7c:	6519                	lui	a0,0x6
    3c7e:	0e450513          	addi	a0,a0,228 # 60e4 <sg_timer_config+0x154>
    3c82:	7dd000ef          	jal	4c5e <puts>
		Delay_ms(410);
		Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);		
	 */
	
			
		while(!Stop_MotorFlag){}		
    3c86:	08a1d703          	lhu	a4,138(gp) # 20000572 <Stop_MotorFlag>
    3c8a:	df75                	beqz	a4,3c86 <main+0x694>
		Stop_MotorFlag=0;		
		Delay_ms(8000);////经测试，当检测到EXIT的上升沿后，纸只能出来一半,所以延时3S	
    3c8c:	6509                	lui	a0,0x2
    3c8e:	f4050513          	addi	a0,a0,-192 # 1f40 <__subdf3+0x52e>
		Stop_MotorFlag=0;		
    3c92:	08019523          	sh	zero,138(gp) # 20000572 <Stop_MotorFlag>
		Delay_ms(8000);////经测试，当检测到EXIT的上升沿后，纸只能出来一半,所以延时3S	
    3c96:	2655                	jal	403a <Delay_ms>
		TimeInitial=0;//打印作业定时器关闭
    3c98:	04018b23          	sb	zero,86(gp) # 2000053e <TimeInitial>
	
	
		//关加热
		Heat_Close();
    3c9c:	147000ef          	jal	45e2 <Heat_Close>
		//printf("Heat_Close\n");
	
		Delay_ms(5000);
    3ca0:	6505                	lui	a0,0x1
    3ca2:	38850513          	addi	a0,a0,904 # 1388 <__divdf3+0x526>
    3ca6:	2e51                	jal	403a <Delay_ms>
		*HVCtrl_REG = 0x0034;//100111000;//bit3 打印结束HV END//
    3ca8:	600187b7          	lui	a5,0x60018
    3cac:	03400713          	li	a4,52
    3cb0:	09878793          	addi	a5,a5,152 # 60018098 <__heap_end+0x3ffe8098>
    3cb4:	c398                	sw	a4,0(a5)
	    Delay_ms(100);		
    3cb6:	06400513          	li	a0,100
    3cba:	2641                	jal	403a <Delay_ms>
		//一次作业完成 给上位机发信号
		//*ErrorCode_REG= 0x0001;///暂时用这个寄存器的bit0位作为和贵圆交互的信号，bit0=1则清除所有寄存器设置。
		temp_HVPS_Ctrol_REG = 0x0000; //0b000010000;//reset ,
	    *HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3cbc:	600187b7          	lui	a5,0x60018
    3cc0:	09878793          	addi	a5,a5,152 # 60018098 <__heap_end+0x3ffe8098>
		temp_HVPS_Ctrol_REG = 0x0000; //0b000010000;//reset ,
    3cc4:	0601ae23          	sw	zero,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
	    *HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3cc8:	0007a023          	sw	zero,0(a5)

//		temp_HVPS_Ctrol_REG = 0x0010; //0b000010000;//reset end,
//	*HVCtrl_REG =temp_HVPS_Ctrol_REG;			
		All_Motor_Stop();//关闭电机
    3ccc:	2b65                	jal	4284 <All_Motor_Stop>
		//printf("All_Motor_Stop\n");
		//printf("time_flag_count_B- time_flag_count_A=%d\n",time_flag_count_B - time_flag_count_A);
		//printf("time_flag_count_C- time_flag_count_B=%d\n",time_flag_count_C - time_flag_count_B);
		Delay_ms(100);
    3cce:	06400513          	li	a0,100
    3cd2:	26a5                	jal	403a <Delay_ms>
		fuser_release();
    3cd4:	796000ef          	jal	446a <fuser_release>
		Clutch_CtrlREG = FAN_SMPS_Close(Clutch_CtrlREG);
    3cd8:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3cdc:	2361                	jal	4264 <FAN_SMPS_Close>
    3cde:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
		while (1);
    3ce2:	a001                	j	3ce2 <main+0x6f0>
				if (times--==0) {
    3ce4:	17fd                	addi	a5,a5,-1
    3ce6:	577d                	li	a4,-1
    3ce8:	9ee791e3          	bne	a5,a4,36ca <main+0xd8>
					printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
    3cec:	6519                	lui	a0,0x6
    3cee:	0b050513          	addi	a0,a0,176 # 60b0 <sg_timer_config+0x120>
    3cf2:	9f1ff06f          	j	36e2 <main+0xf0>
			ReSet = (*PrintCtrl_REG & 0x0001) > 0 ? 1 : 0;
    3cf6:	4398                	lw	a4,0(a5)
    3cf8:	4605                	li	a2,1
    3cfa:	8b05                	andi	a4,a4,1
    3cfc:	b601                	j	37fc <main+0x20a>
			Mode_Finish = (*PrintCtrl_REG & 0x0040) > 0 ? 1 : 0;
    3cfe:	4398                	lw	a4,0(a5)
    3d00:	4605                	li	a2,1
    3d02:	8319                	srli	a4,a4,0x6
    3d04:	8b05                	andi	a4,a4,1
    3d06:	b639                	j	3814 <main+0x222>
			TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;
    3d08:	4394                	lw	a3,0(a5)
			StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;			
    3d0a:	4398                	lw	a4,0(a5)
    3d0c:	4505                	li	a0,1
			TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;
    3d0e:	8295                	srli	a3,a3,0x5
			StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;			
    3d10:	830d                	srli	a4,a4,0x3
			TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;
    3d12:	8a85                	andi	a3,a3,1
			StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;			
    3d14:	8b05                	andi	a4,a4,1
    3d16:	b60d                	j	3838 <main+0x246>
			if (StopPrint == 1)
    3d18:	00671d63          	bne	a4,t1,3d32 <main+0x740>
    3d1c:	c0058de3          	beqz	a1,3936 <main+0x344>
    3d20:	0a018da3          	sb	zero,187(gp) # 200005a3 <CMD_Start>
    3d24:	0ae18d23          	sb	a4,186(gp) # 200005a2 <StopPrint>
			All_Motor_Stop();//关闭所有电机
    3d28:	2bb1                	jal	4284 <All_Motor_Stop>
			Delay_ms(5000);
    3d2a:	6505                	lui	a0,0x1
    3d2c:	38850513          	addi	a0,a0,904 # 1388 <__divdf3+0x526>
    3d30:	bc81                	j	3780 <main+0x18e>
			CMD_Start  = (*PrintCtrl_REG & 0x0010) ? 1 : 0;
    3d32:	4394                	lw	a3,0(a5)
			StopPrint = (*PrintCtrl_REG & 0x0008) ? 1 : 0;
    3d34:	4398                	lw	a4,0(a5)
    3d36:	4585                	li	a1,1
			CMD_Start  = (*PrintCtrl_REG & 0x0010) ? 1 : 0;
    3d38:	8291                	srli	a3,a3,0x4
			StopPrint = (*PrintCtrl_REG & 0x0008) ? 1 : 0;
    3d3a:	830d                	srli	a4,a4,0x3
			CMD_Start  = (*PrintCtrl_REG & 0x0010) ? 1 : 0;
    3d3c:	8a85                	andi	a3,a3,1
			StopPrint = (*PrintCtrl_REG & 0x0008) ? 1 : 0;
    3d3e:	8b05                	andi	a4,a4,1
    3d40:	b6dd                	j	3926 <main+0x334>
				Delay_ms(1000);
    3d42:	3e800513          	li	a0,1000
    3d46:	c036                	sw	a3,0(sp)
    3d48:	2ccd                	jal	403a <Delay_ms>
			for (Heat_Count = 0; Heat_Count < 20; Heat_Count++)
    3d4a:	4682                	lw	a3,0(sp)
    3d4c:	4751                	li	a4,20
    3d4e:	0685                	addi	a3,a3,1
    3d50:	c2e69ae3          	bne	a3,a4,3984 <main+0x392>
    3d54:	b191                	j	3998 <main+0x3a6>
				printf("heat_is_timeout\n");	
    3d56:	6519                	lui	a0,0x6
    3d58:	0f450513          	addi	a0,a0,244 # 60f4 <sg_timer_config+0x164>
    3d5c:	703000ef          	jal	4c5e <puts>
				Heat_Close();
    3d60:	083000ef          	jal	45e2 <Heat_Close>
				Delay_ms(5000);
    3d64:	6505                	lui	a0,0x1
    3d66:	38850513          	addi	a0,a0,904 # 1388 <__divdf3+0x526>
    3d6a:	2cc1                	jal	403a <Delay_ms>
				All_Motor_Stop();
    3d6c:	2b21                	jal	4284 <All_Motor_Stop>
				Delay_ms(100);
    3d6e:	06400513          	li	a0,100
    3d72:	24e1                	jal	403a <Delay_ms>
				fuser_release();
    3d74:	2ddd                	jal	446a <fuser_release>
				Delay_ms(500);
    3d76:	1f400513          	li	a0,500
    3d7a:	24c1                	jal	403a <Delay_ms>
				Delay_ms(500);
    3d7c:	1f400513          	li	a0,500
    3d80:	a01ff06f          	j	3780 <main+0x18e>
						if (times--==0) {
    3d84:	17fd                	addi	a5,a5,-1
    3d86:	577d                	li	a4,-1
    3d88:	c6e79be3          	bne	a5,a4,39fe <main+0x40c>
							printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
    3d8c:	6519                	lui	a0,0x6
    3d8e:	0b050513          	addi	a0,a0,176 # 60b0 <sg_timer_config+0x120>
    3d92:	b149                	j	3a14 <main+0x422>
				HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
    3d94:	431c                	lw	a5,0(a4)
    3d96:	4605                	li	a2,1
    3d98:	8391                	srli	a5,a5,0x4
    3d9a:	8b85                	andi	a5,a5,1
    3d9c:	b331                	j	3aa8 <main+0x4b6>
			printf("now is in while\n");
    3d9e:	6519                	lui	a0,0x6
    3da0:	10450513          	addi	a0,a0,260 # 6104 <sg_timer_config+0x174>
    3da4:	6bb000ef          	jal	4c5e <puts>
			Clutch_CtrlREG=PlateSOL_Open(Clutch_CtrlREG);//plate离合打开
    3da8:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3dac:	21b9                	jal	41fa <PlateSOL_Open>
    3dae:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			Delay_ms(160);//160
    3db2:	0a000513          	li	a0,160
    3db6:	2451                	jal	403a <Delay_ms>
			Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开取纸离合
    3db8:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
    3dbc:	2105                	jal	41dc <PickupCL_Open>
			temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
    3dbe:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3dc2:	60018737          	lui	a4,0x60018
			Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开取纸离合
    3dc6:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
    3dca:	0807e793          	ori	a5,a5,128
    3dce:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;
    3dd2:	09870713          	addi	a4,a4,152 # 60018098 <__heap_end+0x3ffe8098>
    3dd6:	c31c                	sw	a5,0(a4)
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
    3dd8:	600187b7          	lui	a5,0x60018
    3ddc:	4b8c                	lw	a1,16(a5)
    3dde:	07c1                	addi	a5,a5,16 # 60018010 <__heap_end+0x3ffe8010>
    3de0:	89a1                	andi	a1,a1,8
    3de2:	0035d613          	srli	a2,a1,0x3
    3de6:	0ac18d23          	sb	a2,186(gp) # 200005a2 <StopPrint>
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
    3dea:	439c                	lw	a5,0(a5)
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3dec:	60018637          	lui	a2,0x60018
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
    3df0:	8385                	srli	a5,a5,0x1
    3df2:	8b85                	andi	a5,a5,1
    3df4:	0af18823          	sb	a5,176(gp) # 20000598 <DataFinsh>
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3df8:	4610                	lw	a2,8(a2)
			*HVCtrl_PrintPage_REG = PrintPage ;
    3dfa:	60018537          	lui	a0,0x60018
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3dfe:	0ac19923          	sh	a2,178(gp) # 2000059a <PrintPage>
			*HVCtrl_PrintPage_REG = PrintPage ;
    3e02:	0642                	slli	a2,a2,0x10
    3e04:	8241                	srli	a2,a2,0x10
    3e06:	08c52e23          	sw	a2,156(a0) # 6001809c <__heap_end+0x3ffe809c>
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3e0a:	6621                	lui	a2,0x8
    3e0c:	e199                	bnez	a1,3e12 <main+0x820>
    3e0e:	00f79613          	slli	a2,a5,0xf
    3e12:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			Delay_ms(320);	
    3e16:	14000513          	li	a0,320
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3e1a:	8fd1                	or	a5,a5,a2
    3e1c:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    3e20:	c31c                	sw	a5,0(a4)
			Delay_ms(320);	
    3e22:	2c21                	jal	403a <Delay_ms>
			temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
    3e24:	07c1a783          	lw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
    3e28:	6641                	lui	a2,0x10
    3e2a:	f7f60613          	addi	a2,a2,-129 # ff7f <__ctor_end__+0x93bf>
    3e2e:	8ff1                	and	a5,a5,a2
			Clutch_CtrlREG=PlateSOL_Close(Clutch_CtrlREG);//plate离合关闭
    3e30:	0861d503          	lhu	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    3e34:	60018737          	lui	a4,0x60018
			temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
    3e38:	06f1ae23          	sw	a5,124(gp) # 20000564 <temp_HVPS_Ctrol_REG>
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
    3e3c:	09870713          	addi	a4,a4,152 # 60018098 <__heap_end+0x3ffe8098>
    3e40:	c31c                	sw	a5,0(a4)
			Clutch_CtrlREG=PlateSOL_Close(Clutch_CtrlREG);//plate离合关闭
    3e42:	26d9                	jal	4208 <PlateSOL_Close>
    3e44:	08a19323          	sh	a0,134(gp) # 2000056e <Clutch_CtrlREG>
			while(!again_paper){}//在中断中完成一页后，200ms后，again paper置1，实现两张纸之间的间隔			
    3e48:	0541d783          	lhu	a5,84(gp) # 2000053c <again_paper>
    3e4c:	dff5                	beqz	a5,3e48 <main+0x856>
			again_paper=0;		
    3e4e:	04019a23          	sh	zero,84(gp) # 2000053c <again_paper>
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
    3e52:	600187b7          	lui	a5,0x60018
    3e56:	4b88                	lw	a0,16(a5)
    3e58:	8921                	andi	a0,a0,8
    3e5a:	00355613          	srli	a2,a0,0x3
    3e5e:	0ac18d23          	sb	a2,186(gp) # 200005a2 <StopPrint>
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
    3e62:	4b98                	lw	a4,16(a5)
    3e64:	8305                	srli	a4,a4,0x1
    3e66:	8b05                	andi	a4,a4,1
    3e68:	0ae18823          	sb	a4,176(gp) # 20000598 <DataFinsh>
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
    3e6c:	600187b7          	lui	a5,0x60018
    3e70:	479c                	lw	a5,8(a5)
    3e72:	07c2                	slli	a5,a5,0x10
    3e74:	83c1                	srli	a5,a5,0x10
    3e76:	0af19923          	sh	a5,178(gp) # 2000059a <PrintPage>
			*HVCtrl_PrintPage_REG = PrintPage ;
    3e7a:	600185b7          	lui	a1,0x60018
    3e7e:	08f5ae23          	sw	a5,156(a1) # 6001809c <__heap_end+0x3ffe809c>
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
    3e82:	65a1                	lui	a1,0x8
    3e84:	d0051be3          	bnez	a0,3b9a <main+0x5a8>
    3e88:	00f71593          	slli	a1,a4,0xf
    3e8c:	b339                	j	3b9a <main+0x5a8>
					if (times--==0) {
    3e8e:	17fd                	addi	a5,a5,-1 # 60017fff <__heap_end+0x3ffe7fff>
    3e90:	577d                	li	a4,-1
    3e92:	d6e79de3          	bne	a5,a4,3c0c <main+0x61a>
						printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
    3e96:	6519                	lui	a0,0x6
    3e98:	0b050513          	addi	a0,a0,176 # 60b0 <sg_timer_config+0x120>
    3e9c:	b359                	j	3c22 <main+0x630>

00003e9e <timer_init>:
 * 
 */
 
 
int32_t timer_init(uint32_t timer_num ,uint32_t timeout)
{
    3e9e:	1141                	addi	sp,sp,-16
    3ea0:	c02e                	sw	a1,0(sp)

    int32_t ret;
	// timer0 initialize and register callback function
	
    timer_handle[timer_num] = csi_timer_initialize(timer_num, NULL);
    3ea2:	4581                	li	a1,0
{
    3ea4:	c422                	sw	s0,8(sp)
    3ea6:	c226                	sw	s1,4(sp)
    3ea8:	c606                	sw	ra,12(sp)
    3eaa:	84aa                	mv	s1,a0
    timer_handle[timer_num] = csi_timer_initialize(timer_num, NULL);
    3eac:	20002437          	lui	s0,0x20002
    3eb0:	e1ffe0ef          	jal	2cce <csi_timer_initialize>
    3eb4:	00249793          	slli	a5,s1,0x2
    3eb8:	d8840413          	addi	s0,s0,-632 # 20001d88 <timer_handle>
    3ebc:	943e                	add	s0,s0,a5
    3ebe:	c008                	sw	a0,0(s0)

    if (timer_handle[timer_num] == NULL) {
    3ec0:	e519                	bnez	a0,3ece <timer_init+0x30>
        //printf("csi_timer_initialize error\n");
        return -1;
    3ec2:	557d                	li	a0,-1

    if (ret < 0) {
        return -1;
    }
	return 0;
}
    3ec4:	40b2                	lw	ra,12(sp)
    3ec6:	4422                	lw	s0,8(sp)
    3ec8:	4492                	lw	s1,4(sp)
    3eca:	0141                	addi	sp,sp,16
    3ecc:	8082                	ret
    ret = csi_timer_config(timer_handle[timer_num], TIMER_MODE_RELOAD);
    3ece:	4585                	li	a1,1
    3ed0:	ea1fe0ef          	jal	2d70 <csi_timer_config>
    if (ret < 0) {
    3ed4:	fe0547e3          	bltz	a0,3ec2 <timer_init+0x24>
    ret = csi_timer_set_timeout(timer_handle[timer_num], timeout);
    3ed8:	4582                	lw	a1,0(sp)
    3eda:	4008                	lw	a0,0(s0)
    3edc:	eddfe0ef          	jal	2db8 <csi_timer_set_timeout>
    if (ret < 0) {
    3ee0:	fe0541e3          	bltz	a0,3ec2 <timer_init+0x24>
    ret = csi_timer_start(timer_handle[timer_num]);
    3ee4:	4008                	lw	a0,0(s0)
    3ee6:	ee5fe0ef          	jal	2dca <csi_timer_start>
    if (ret < 0) {
    3eea:	857d                	srai	a0,a0,0x1f
    3eec:	bfe1                	j	3ec4 <timer_init+0x26>

00003eee <SET_PRT_DATA_PARP>:

extern uint16_t Clutch_CtrlREG;

void    SET_PRT_DATA_PARP ()
{
	*HYNC_REG          =    3963;
    3eee:	600187b7          	lui	a5,0x60018
    3ef2:	6705                	lui	a4,0x1
    3ef4:	10078693          	addi	a3,a5,256 # 60018100 <__heap_end+0x3ffe8100>
    3ef8:	f7b70713          	addi	a4,a4,-133 # f7b <__divdf3+0x119>
    3efc:	c298                	sw	a4,0(a3)
//	*Y_PRT_DATA_REG    =    1354;///1515+46   正值方向向右，负值方向向左 1400-46  
//	*M_PRT_DATA_REG    =    1337;
//	*C_PRT_DATA_REG    =    1531;
//	*K_PRT_DATA_REG    =    1602;  //1602-46
	
	*Y_PRT_DATA_REG    =    1440;///1515+46   正值方向向右，负值方向向左 1400-46   1442
    3efe:	10478713          	addi	a4,a5,260
    3f02:	5a000693          	li	a3,1440
    3f06:	c314                	sw	a3,0(a4)
	*M_PRT_DATA_REG    =    1420;//正值向右，负值向左1430
    3f08:	10878713          	addi	a4,a5,264
    3f0c:	58c00693          	li	a3,1420
    3f10:	c314                	sw	a3,0(a4)
	*C_PRT_DATA_REG    =    1629;//蓝的方向是反的，正值向左，负值向右1636
    3f12:	10c78713          	addi	a4,a5,268
    3f16:	65d00693          	li	a3,1629
    3f1a:	c314                	sw	a3,0(a4)
	*K_PRT_DATA_REG    =    1602;  //1602-46
    3f1c:	11078793          	addi	a5,a5,272
    3f20:	64200713          	li	a4,1602
    3f24:	c398                	sw	a4,0(a5)
	
}
    3f26:	8082                	ret

00003f28 <FUSER_Motor_Stop>:
	*FUSER_WORK_CTRL_REG        = 0b001100;
}

void	FUSER_Motor_Stop()
{
	*FUSER_WORK_CTRL_REG 		= 0b0011;
    3f28:	600187b7          	lui	a5,0x60018
    3f2c:	470d                	li	a4,3
    3f2e:	df98                	sw	a4,56(a5)
	*FUSER_FRE_DIV_REG          = 0;
    3f30:	0e478713          	addi	a4,a5,228 # 600180e4 <__heap_end+0x3ffe80e4>
    3f34:	00072023          	sw	zero,0(a4)
	*FUSER_High_Time_REG        = 0;
    3f38:	0e878713          	addi	a4,a5,232
    3f3c:	00072023          	sw	zero,0(a4)
	*FUSER_START_CTRL_REG 	    = 0;
    3f40:	0207ae23          	sw	zero,60(a5)
	*FUSER_END_CTRL_REG 		= 0;
    3f44:	0407a023          	sw	zero,64(a5)
	*FUSER_PER_CTRL_REG			= 0;
    3f48:	0407a223          	sw	zero,68(a5)
}
    3f4c:	8082                	ret

00003f4e <FEED_Motor_Stop>:
	*FEED_WORK_CTRL_REG 		= 0b1100;
}

void	FEED_Motor_Stop()
{
	*FEED_WORK_CTRL_REG 		= 0b0011;
    3f4e:	600187b7          	lui	a5,0x60018
    3f52:	470d                	li	a4,3
    3f54:	d3d8                	sw	a4,36(a5)
	*FEED_FRE_DIV_REG          = 0;
    3f56:	0ec78713          	addi	a4,a5,236 # 600180ec <__heap_end+0x3ffe80ec>
    3f5a:	00072023          	sw	zero,0(a4)
	*FEED_High_Time_REG        = 0;
    3f5e:	0f078793          	addi	a5,a5,240
    3f62:	0007a023          	sw	zero,0(a5)
}
    3f66:	8082                	ret

00003f68 <BLDC_K_Motor_Start>:

void	BLDC_K_Motor_Start()
{
	*BLDC_K_WORK_CTRL_REG = 0b1010011;//第5、第4位分别为0，1，表示加速到第一个加速段
    3f68:	600187b7          	lui	a5,0x60018
    3f6c:	05300713          	li	a4,83
    3f70:	d3b8                	sw	a4,96(a5)
	*BLDC_K_MOTO_CTRL_REG = 0b1;
    3f72:	4705                	li	a4,1
    3f74:	dbf8                	sw	a4,116(a5)
	*BLDC_K_START_CTRL_REG = 216450;//初始频率462Hz
    3f76:	00035737          	lui	a4,0x35
    3f7a:	d8270713          	addi	a4,a4,-638 # 34d82 <__ctor_end__+0x2e1c2>
    3f7e:	d3f8                	sw	a4,100(a5)
	*BLDC_K_NO1_CTRL_REG = 51540;//最终频率1.94kHz
    3f80:	6735                	lui	a4,0xd
    3f82:	95470713          	addi	a4,a4,-1708 # c954 <__ctor_end__+0x5d94>
    3f86:	d7b8                	sw	a4,104(a5)
	*BLDC_K_NO2_CTRL_REG = 219780;
    3f88:	00036737          	lui	a4,0x36
    3f8c:	a8470713          	addi	a4,a4,-1404 # 35a84 <__ctor_end__+0x2eec4>
    3f90:	d7f8                	sw	a4,108(a5)
	*BLDC_K_PER_CTRL_REG = 1000;
    3f92:	3e800713          	li	a4,1000
    3f96:	dbb8                	sw	a4,112(a5)
	*BLDC_K_WORK_CTRL_REG = 0b1011100;
    3f98:	05c00713          	li	a4,92
    3f9c:	d3b8                	sw	a4,96(a5)
}
    3f9e:	8082                	ret

00003fa0 <BLDC_K_Motor_Stop>:

void	BLDC_K_Motor_Stop()
{
	*BLDC_K_WORK_CTRL_REG = 0b1010011;
    3fa0:	600187b7          	lui	a5,0x60018
    3fa4:	05300713          	li	a4,83
    3fa8:	d3b8                	sw	a4,96(a5)
}
    3faa:	8082                	ret

00003fac <BLDC_YMC_Motor_Start>:

void	BLDC_YMC_Motor_Start()
{
	*BLDC_YMC_WORK_CTRL_REG = 0b1010011;
    3fac:	600187b7          	lui	a5,0x60018
    3fb0:	05300713          	li	a4,83
    3fb4:	dfb8                	sw	a4,120(a5)
	*BLDC_YMC_MOTO_CTRL_REG = 0b1;
    3fb6:	4685                	li	a3,1
    3fb8:	08c78713          	addi	a4,a5,140 # 6001808c <__heap_end+0x3ffe808c>
    3fbc:	c314                	sw	a3,0(a4)
	*BLDC_YMC_START_CTRL_REG = 216450;//10989
    3fbe:	00035737          	lui	a4,0x35
    3fc2:	d8270713          	addi	a4,a4,-638 # 34d82 <__ctor_end__+0x2e1c2>
    3fc6:	dff8                	sw	a4,124(a5)
	*BLDC_YMC_NO1_CTRL_REG = 51540;
    3fc8:	6735                	lui	a4,0xd
    3fca:	08078693          	addi	a3,a5,128
    3fce:	95470713          	addi	a4,a4,-1708 # c954 <__ctor_end__+0x5d94>
    3fd2:	c298                	sw	a4,0(a3)
	*BLDC_YMC_NO2_CTRL_REG = 219780;
    3fd4:	00036737          	lui	a4,0x36
    3fd8:	08478693          	addi	a3,a5,132
    3fdc:	a8470713          	addi	a4,a4,-1404 # 35a84 <__ctor_end__+0x2eec4>
    3fe0:	c298                	sw	a4,0(a3)
	*BLDC_YMC_PER_CTRL_REG = 1000;
    3fe2:	08878713          	addi	a4,a5,136
    3fe6:	3e800693          	li	a3,1000
    3fea:	c314                	sw	a3,0(a4)
	*BLDC_YMC_WORK_CTRL_REG = 0b1011100;
    3fec:	05c00713          	li	a4,92
    3ff0:	dfb8                	sw	a4,120(a5)
}
    3ff2:	8082                	ret

00003ff4 <BLDC_YMC_Motor_Stop>:

void	BLDC_YMC_Motor_Stop()
{
	*BLDC_YMC_WORK_CTRL_REG = 0b1010011;
    3ff4:	600187b7          	lui	a5,0x60018
    3ff8:	05300713          	li	a4,83
    3ffc:	dfb8                	sw	a4,120(a5)
}
    3ffe:	8082                	ret

00004000 <LSU_Motor_Start>:

void	LSU_Motor_Start()
{
	*LSU_WORK_CTRL_REG = 0b00011;
    4000:	600187b7          	lui	a5,0x60018
    4004:	470d                	li	a4,3
    4006:	c7f8                	sw	a4,76(a5)
	*LSU_START_CTRL_REG = 23294;
    4008:	6719                	lui	a4,0x6
    400a:	afe70713          	addi	a4,a4,-1282 # 5afe <_strtol_l.isra.0+0x5c>
    400e:	cbb8                	sw	a4,80(a5)
	*LSU_END_CTRL_REG = 23294;
    4010:	cbf8                	sw	a4,84(a5)
	*LSU_PER_CTRL_REG = 23294;
    4012:	cfb8                	sw	a4,88(a5)
	*LSU_MOTO_CTRL_REG = 0b0010;
    4014:	4709                	li	a4,2
    4016:	cff8                	sw	a4,92(a5)
	*LSU_WORK_CTRL_REG = 0b01100;
    4018:	4731                	li	a4,12
    401a:	c7f8                	sw	a4,76(a5)
}
    401c:	8082                	ret

0000401e <delay_1ms>:
{
	*CLUTCH_REG = OperatingCommand;
}

void    delay_1ms()
{
    401e:	1171                	addi	sp,sp,-4
	for (volatile uint32_t i = 0; i < 5548; i++);
    4020:	6785                	lui	a5,0x1
    4022:	c002                	sw	zero,0(sp)
    4024:	5ab78793          	addi	a5,a5,1451 # 15ab <__muldf3+0x19>
    4028:	4702                	lw	a4,0(sp)
    402a:	00e7f463          	bgeu	a5,a4,4032 <delay_1ms+0x14>
}
    402e:	0111                	addi	sp,sp,4
    4030:	8082                	ret
	for (volatile uint32_t i = 0; i < 5548; i++);
    4032:	4702                	lw	a4,0(sp)
    4034:	0705                	addi	a4,a4,1
    4036:	c03a                	sw	a4,0(sp)
    4038:	bfc5                	j	4028 <delay_1ms+0xa>

0000403a <Delay_ms>:

void Delay_ms(uint32_t delay_ms)
{
    403a:	1161                	addi	sp,sp,-8
    403c:	c022                	sw	s0,0(sp)
    403e:	c206                	sw	ra,4(sp)
    4040:	842a                	mv	s0,a0
    while (delay_ms--)
    4042:	e409                	bnez	s0,404c <Delay_ms+0x12>
    {
        delay_1ms();
    }
}
    4044:	4092                	lw	ra,4(sp)
    4046:	4402                	lw	s0,0(sp)
    4048:	0121                	addi	sp,sp,8
    404a:	8082                	ret
        delay_1ms();
    404c:	3fc9                	jal	401e <delay_1ms>
    404e:	147d                	addi	s0,s0,-1
    4050:	bfcd                	j	4042 <Delay_ms+0x8>

00004052 <FUSER_Motor_Start>:
{
    4052:	1151                	addi	sp,sp,-12
    4054:	c406                	sw	ra,8(sp)
    4056:	c222                	sw	s0,4(sp)
    4058:	c026                	sw	s1,0(sp)
	*FUSER_WORK_CTRL_REG        = 0b000011;//整个电机复位
    405a:	60018437          	lui	s0,0x60018
    405e:	478d                	li	a5,3
    4060:	dc1c                	sw	a5,56(s0)
	*FUSER_MOTO_CTRL_REG        = 0b000011;//dir正转
    4062:	c43c                	sw	a5,72(s0)
	*FUSER_WORK_CTRL_REG        = 0b100000;//单脉冲使能
    4064:	02000793          	li	a5,32
    4068:	dc1c                	sw	a5,56(s0)
	*FUSER_FRE_DIV_REG          = 2200;
    406a:	6785                	lui	a5,0x1
    406c:	0e440713          	addi	a4,s0,228 # 600180e4 <__heap_end+0x3ffe80e4>
    4070:	89878793          	addi	a5,a5,-1896 # 898 <__umoddi3+0x346>
    4074:	c31c                	sw	a5,0(a4)
	*FUSER_High_Time_REG        = 1060;   //48%占空比
    4076:	0e840493          	addi	s1,s0,232
    407a:	42400793          	li	a5,1060
    407e:	c09c                	sw	a5,0(s1)
	Delay_ms(90);
    4080:	05a00513          	li	a0,90
    4084:	3f5d                	jal	403a <Delay_ms>
	*FUSER_High_Time_REG        = 1960;   //89%占空比
    4086:	7a800793          	li	a5,1960
    408a:	c09c                	sw	a5,0(s1)
	Delay_ms(112);     
    408c:	07000513          	li	a0,112
    4090:	376d                	jal	403a <Delay_ms>
    *FUSER_START_CTRL_REG       = 400000;//250Hz
    4092:	000627b7          	lui	a5,0x62
    4096:	a8078793          	addi	a5,a5,-1408 # 61a80 <__ctor_end__+0x5aec0>
    409a:	dc5c                	sw	a5,60(s0)
	*FUSER_MID_CTRL_REG         = 200000;//500Hz
    409c:	000317b7          	lui	a5,0x31
    40a0:	0f440713          	addi	a4,s0,244
    40a4:	d4078793          	addi	a5,a5,-704 # 30d40 <__ctor_end__+0x2a180>
    40a8:	c31c                	sw	a5,0(a4)
	*FUSER_PER_CTRL_REG         = 1080;  //第一段的加速度1-185
    40aa:	43800793          	li	a5,1080
    40ae:	c07c                	sw	a5,68(s0)
	*FUSER_ST_DELAY_REG         = 190000000; //延时1900ms 
    40b0:	0b5337b7          	lui	a5,0xb533
    40b4:	0f840713          	addi	a4,s0,248
    40b8:	b8078793          	addi	a5,a5,-1152 # b532b80 <__ctor_end__+0xb52bfc0>
    40bc:	c31c                	sw	a5,0(a4)
	*FUSER_END_CTRL_REG         = 90722; //1.1kHz
    40be:	67d9                	lui	a5,0x16
    40c0:	26278793          	addi	a5,a5,610 # 16262 <__ctor_end__+0xf6a2>
    40c4:	c03c                	sw	a5,64(s0)
	*FUSER_PER_CTRL_REG2        = 230;    //第二段加速度1134 -1609
    40c6:	0e600713          	li	a4,230
    40ca:	0fc40793          	addi	a5,s0,252
    40ce:	c398                	sw	a4,0(a5)
	*FUSER_WORK_CTRL_REG        = 0b001100;
    40d0:	47b1                	li	a5,12
}
    40d2:	40a2                	lw	ra,8(sp)
	*FUSER_WORK_CTRL_REG        = 0b001100;
    40d4:	dc1c                	sw	a5,56(s0)
}
    40d6:	4412                	lw	s0,4(sp)
    40d8:	4482                	lw	s1,0(sp)
    40da:	0131                	addi	sp,sp,12
    40dc:	8082                	ret

000040de <FUSER_Motor_Start_Rev>:
{
    40de:	1151                	addi	sp,sp,-12
    40e0:	c406                	sw	ra,8(sp)
    40e2:	c222                	sw	s0,4(sp)
    40e4:	c026                	sw	s1,0(sp)
	*FUSER_WORK_CTRL_REG        = 0b000011;//整个电机复位
    40e6:	60018437          	lui	s0,0x60018
    40ea:	478d                	li	a5,3
    40ec:	dc1c                	sw	a5,56(s0)
	*FUSER_MOTO_CTRL_REG        = 0b000001;//dir反转
    40ee:	4785                	li	a5,1
    40f0:	c43c                	sw	a5,72(s0)
	*FUSER_FRE_DIV_REG          = 2420;
    40f2:	6485                	lui	s1,0x1
	*FUSER_WORK_CTRL_REG        = 0b100000;//单脉冲使能
    40f4:	02000793          	li	a5,32
    40f8:	dc1c                	sw	a5,56(s0)
	*FUSER_FRE_DIV_REG          = 2420;
    40fa:	97448713          	addi	a4,s1,-1676 # 974 <__adddf3+0xd8>
    40fe:	0e440793          	addi	a5,s0,228 # 600180e4 <__heap_end+0x3ffe80e4>
    4102:	c398                	sw	a4,0(a5)
	*FUSER_High_Time_REG        = 1060;   //48%占空比
    4104:	0e840793          	addi	a5,s0,232
    4108:	42400713          	li	a4,1060
    410c:	c398                	sw	a4,0(a5)
	Delay_ms(90);
    410e:	05a00513          	li	a0,90
    4112:	3725                	jal	403a <Delay_ms>
	*FUSER_High_Time_REG        = 1960;   //89%占空比
    4114:	0e840793          	addi	a5,s0,232
    4118:	7a800713          	li	a4,1960
    411c:	c398                	sw	a4,0(a5)
	Delay_ms(112);     
    411e:	07000513          	li	a0,112
    4122:	3f21                	jal	403a <Delay_ms>
	*FUSER_START_CTRL_REG       = 400000;//250Hz
    4124:	000627b7          	lui	a5,0x62
    4128:	a8078793          	addi	a5,a5,-1408 # 61a80 <__ctor_end__+0x5aec0>
    412c:	dc5c                	sw	a5,60(s0)
	*FUSER_MID_CTRL_REG         = 166667;//600Hz
    412e:	000297b7          	lui	a5,0x29
    4132:	0f440713          	addi	a4,s0,244
    4136:	b0b78793          	addi	a5,a5,-1269 # 28b0b <__ctor_end__+0x21f4b>
    413a:	c31c                	sw	a5,0(a4)
	*FUSER_PER_CTRL_REG         = 4580;
    413c:	1e448493          	addi	s1,s1,484
    4140:	c064                	sw	s1,68(s0)
	*FUSER_ST_DELAY_REG         = 0; //延时
    4142:	0f840713          	addi	a4,s0,248
    4146:	00072023          	sw	zero,0(a4)
	*FUSER_END_CTRL_REG         = 166667;
    414a:	c03c                	sw	a5,64(s0)
	*FUSER_PER_CTRL_REG2        = 0;   
    414c:	0fc40793          	addi	a5,s0,252
    4150:	0007a023          	sw	zero,0(a5)
	*FUSER_WORK_CTRL_REG        = 0b001100;
    4154:	47b1                	li	a5,12
}
    4156:	40a2                	lw	ra,8(sp)
	*FUSER_WORK_CTRL_REG        = 0b001100;
    4158:	dc1c                	sw	a5,56(s0)
}
    415a:	4412                	lw	s0,4(sp)
    415c:	4482                	lw	s1,0(sp)
    415e:	0131                	addi	sp,sp,12
    4160:	8082                	ret

00004162 <FEED_Motor_Start>:
{
    4162:	1151                	addi	sp,sp,-12
    4164:	c222                	sw	s0,4(sp)
    4166:	c026                	sw	s1,0(sp)
	*FEED_WORK_CTRL_REG 		= 0b0011;
    4168:	60018437          	lui	s0,0x60018
{
    416c:	c406                	sw	ra,8(sp)
	*FEED_WORK_CTRL_REG 		= 0b0011;
    416e:	448d                	li	s1,3
	*FEED_FRE_DIV_REG          = 2200;
    4170:	6785                	lui	a5,0x1
	*FEED_WORK_CTRL_REG 		= 0b0011;
    4172:	d044                	sw	s1,36(s0)
	*FEED_FRE_DIV_REG          = 2200;
    4174:	0ec40713          	addi	a4,s0,236 # 600180ec <__heap_end+0x3ffe80ec>
    4178:	89878793          	addi	a5,a5,-1896 # 898 <__umoddi3+0x346>
    417c:	c31c                	sw	a5,0(a4)
	*FEED_High_Time_REG        = 1760;
    417e:	0f040793          	addi	a5,s0,240
    4182:	6e000713          	li	a4,1760
    4186:	c398                	sw	a4,0(a5)
	*FEED_WORK_CTRL_REG        = 0b100000;
    4188:	02000793          	li	a5,32
    418c:	d05c                	sw	a5,36(s0)
	Delay_ms(200);
    418e:	0c800513          	li	a0,200
    4192:	3565                	jal	403a <Delay_ms>
	*FEED_START_CTRL_REG 		= 389100;//257Hz
    4194:	0005f7b7          	lui	a5,0x5f
	*FEED_WORK_CTRL_REG        = 0b000000;
    4198:	02042223          	sw	zero,36(s0)
	*FEED_MOTO_CTRL_REG 		= 0b0011;
    419c:	d844                	sw	s1,52(s0)
	*FEED_START_CTRL_REG 		= 389100;//257Hz
    419e:	17b1                	addi	a5,a5,-20 # 5efec <__ctor_end__+0x5842c>
    41a0:	d41c                	sw	a5,40(s0)
	*FEED_END_CTRL_REG 			= 94690;//1.06kHz 9469
    41a2:	67dd                	lui	a5,0x17
    41a4:	1e278793          	addi	a5,a5,482 # 171e2 <__ctor_end__+0x10622>
    41a8:	d45c                	sw	a5,44(s0)
	*FEED_PER_CTRL_REG 			= 450;
    41aa:	1c200793          	li	a5,450
    41ae:	d81c                	sw	a5,48(s0)
	*FEED_WORK_CTRL_REG 		= 0b1100;
    41b0:	47b1                	li	a5,12
}
    41b2:	40a2                	lw	ra,8(sp)
	*FEED_WORK_CTRL_REG 		= 0b1100;
    41b4:	d05c                	sw	a5,36(s0)
}
    41b6:	4412                	lw	s0,4(sp)
    41b8:	4482                	lw	s1,0(sp)
    41ba:	0131                	addi	sp,sp,12
    41bc:	8082                	ret

000041be <RegiCL_Open>:
////对齐离合打开 bit0=1
uint16_t RegiCL_Open(uint16_t Operating_Command){
	uint16_t Intermed_Var;
	Intermed_Var=Operating_Command|0X0001;
    41be:	00156513          	ori	a0,a0,1
	*CLUTCH_REG = Intermed_Var;
    41c2:	600187b7          	lui	a5,0x60018
    41c6:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
	return Intermed_Var;
}
    41ca:	8082                	ret

000041cc <RegiCL_Close>:
////对齐离合关闭 bit0=0
uint16_t RegiCL_Close(uint16_t Operating_Command){
	uint16_t Intermed_Var;
	Intermed_Var=Operating_Command&0XFFFE;
    41cc:	67c1                	lui	a5,0x10
    41ce:	17f9                	addi	a5,a5,-2 # fffe <__ctor_end__+0x943e>
    41d0:	8d7d                	and	a0,a0,a5
	*CLUTCH_REG = Intermed_Var;
    41d2:	600187b7          	lui	a5,0x60018
    41d6:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
	return Intermed_Var;
}
    41da:	8082                	ret

000041dc <PickupCL_Open>:

//// 拾纸离合打开 bit1 = 1
uint16_t PickupCL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0002;
    41dc:	00256513          	ori	a0,a0,2
    *CLUTCH_REG = Intermed_Var;
    41e0:	600187b7          	lui	a5,0x60018
    41e4:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    41e8:	8082                	ret

000041ea <PickupCL_Close>:

//// 拾纸离合关闭 bit1 = 0
uint16_t PickupCL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFFD;   // 清 bit1
    41ea:	67c1                	lui	a5,0x10
    41ec:	17f5                	addi	a5,a5,-3 # fffd <__ctor_end__+0x943d>
    41ee:	8d7d                	and	a0,a0,a5
    *CLUTCH_REG = Intermed_Var;
    41f0:	600187b7          	lui	a5,0x60018
    41f4:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    41f8:	8082                	ret

000041fa <PlateSOL_Open>:

/////CST_PALTE_SOL离合打开  bit3=1
uint16_t PlateSOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0008; ///bit3置1
    41fa:	00856513          	ori	a0,a0,8
    *CLUTCH_REG = Intermed_Var;
    41fe:	600187b7          	lui	a5,0x60018
    4202:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4206:	8082                	ret

00004208 <PlateSOL_Close>:

////CST_PALTE_SOL离合关闭   bit3=0
uint16_t PlateSOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFF7;   // 清 bit3
    4208:	67c1                	lui	a5,0x10
    420a:	17dd                	addi	a5,a5,-9 # fff7 <__ctor_end__+0x9437>
    420c:	8d7d                	and	a0,a0,a5
    *CLUTCH_REG = Intermed_Var;
    420e:	600187b7          	lui	a5,0x60018
    4212:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4216:	8082                	ret

00004218 <NipSOL_Open>:

/////NIP离合打开  bit4=1
uint16_t NipSOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0010; ///bit4置1
    4218:	01056513          	ori	a0,a0,16
    *CLUTCH_REG = Intermed_Var;
    421c:	600187b7          	lui	a5,0x60018
    4220:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4224:	8082                	ret

00004226 <NipSOL_Close>:

////NIP离合关闭   bit4=0
uint16_t NipSOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFEF;   // 清 bit4
    4226:	67c1                	lui	a5,0x10
    4228:	17bd                	addi	a5,a5,-17 # ffef <__ctor_end__+0x942f>
    422a:	8d7d                	and	a0,a0,a5
    *CLUTCH_REG = Intermed_Var;
    422c:	600187b7          	lui	a5,0x60018
    4230:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4234:	8082                	ret

00004236 <T1_SOL_Open>:

/////T1离合打开  bit5=1
uint16_t T1_SOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0020; ///bit5置1
    4236:	02056513          	ori	a0,a0,32
    *CLUTCH_REG = Intermed_Var;
    423a:	600187b7          	lui	a5,0x60018
    423e:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4242:	8082                	ret

00004244 <T1_SOL_Close>:

////T1离合关闭   bit5=0
uint16_t T1_SOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFDF;   // 清 bit5
    4244:	67c1                	lui	a5,0x10
    4246:	fdf78793          	addi	a5,a5,-33 # ffdf <__ctor_end__+0x941f>
    424a:	8d7d                	and	a0,a0,a5
    *CLUTCH_REG = Intermed_Var;
    424c:	600187b7          	lui	a5,0x60018
    4250:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4254:	8082                	ret

00004256 <FAN_SMPS_Open>:

/////风扇打开  bit6=1
uint16_t FAN_SMPS_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0040; ///bit6置1
    4256:	04056513          	ori	a0,a0,64
    *CLUTCH_REG = Intermed_Var;
    425a:	600187b7          	lui	a5,0x60018
    425e:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4262:	8082                	ret

00004264 <FAN_SMPS_Close>:

/////风扇打开  bit6=0
uint16_t FAN_SMPS_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFBF; ///bit6置0
    4264:	67c1                	lui	a5,0x10
    4266:	fbf78793          	addi	a5,a5,-65 # ffbf <__ctor_end__+0x93ff>
    426a:	8d7d                	and	a0,a0,a5
    *CLUTCH_REG = Intermed_Var;
    426c:	600187b7          	lui	a5,0x60018
    4270:	08a7aa23          	sw	a0,148(a5) # 60018094 <__heap_end+0x3ffe8094>
    return Intermed_Var;
}
    4274:	8082                	ret

00004276 <Mot_Register_Initial>:

void Mot_Register_Initial(void){
	//各寄存器复位 
	Clutch_CtrlREG=0X0000;//离合控制
    4276:	08019323          	sh	zero,134(gp) # 2000056e <Clutch_CtrlREG>
	//离合、电机控制初始化
     *CLUTCH_REG = Clutch_CtrlREG;//离合
    427a:	600187b7          	lui	a5,0x60018
    427e:	0807aa23          	sw	zero,148(a5) # 60018094 <__heap_end+0x3ffe8094>
  
}
    4282:	8082                	ret

00004284 <All_Motor_Stop>:


void All_Motor_Stop(void)
{
    4284:	1151                	addi	sp,sp,-12
    4286:	c406                	sw	ra,8(sp)
    4288:	c222                	sw	s0,4(sp)
    428a:	c026                	sw	s1,0(sp)
    FEED_Motor_Stop();
    428c:	31c9                	jal	3f4e <FEED_Motor_Stop>
	Delay_ms(200);
    428e:	0c800513          	li	a0,200
    4292:	3365                	jal	403a <Delay_ms>
	FUSER_Motor_Stop();
    4294:	3951                	jal	3f28 <FUSER_Motor_Stop>
	Delay_ms(200);
    4296:	0c800513          	li	a0,200
    429a:	3345                	jal	403a <Delay_ms>
	*LSU_WORK_CTRL_REG = 0b00011;
    429c:	60018437          	lui	s0,0x60018
    42a0:	478d                	li	a5,3
    42a2:	c47c                	sw	a5,76(s0)
	LSU_Motor_Stop();
	Delay_ms(200);
    42a4:	0c800513          	li	a0,200
    42a8:	3b49                	jal	403a <Delay_ms>
	*BLDC_K_WORK_CTRL_REG = 0b1010011;
    42aa:	05300493          	li	s1,83
    42ae:	d024                	sw	s1,96(s0)
	BLDC_K_Motor_Stop();
	Delay_ms(200);
    42b0:	0c800513          	li	a0,200
    42b4:	3359                	jal	403a <Delay_ms>
	BLDC_YMC_Motor_Stop();
    
}
    42b6:	40a2                	lw	ra,8(sp)
	*BLDC_YMC_WORK_CTRL_REG = 0b1010011;
    42b8:	dc24                	sw	s1,120(s0)
}
    42ba:	4412                	lw	s0,4(sp)
    42bc:	4482                	lw	s1,0(sp)
    42be:	0131                	addi	sp,sp,12
    42c0:	8082                	ret

000042c2 <Printer_Para_init>:

////////////////////////////////////////////////////打印机状态信号初始化/////////////////////////////////////////////////////
void Printer_Para_init()
{
    //PaperFeed     = 1;//进纸方式 纸盘进纸
    Printed_Page  = 0;//当前已打印页数寄存器	
    42c2:	0a019723          	sh	zero,174(gp) # 20000596 <Printed_Page>
	PageX_Paper_Arrived = 0;
    42c6:	08018423          	sb	zero,136(gp) # 20000570 <PageX_Paper_Arrived>
    *PrintedPageNum_REG = Printed_Page;//更新已打印页数
    42ca:	600187b7          	lui	a5,0x60018
    42ce:	0c878713          	addi	a4,a5,200 # 600180c8 <__heap_end+0x3ffe80c8>
    42d2:	00072023          	sw	zero,0(a4)
    PrintPage 	  = 0;//打印页数寄存器
    42d6:	0a019923          	sh	zero,178(gp) # 2000059a <PrintPage>
	Mode_Finish = 0;//参数设置完成标志
    42da:	0a019a23          	sh	zero,180(gp) # 2000059c <Mode_Finish>
    CMD_Start 	  = 0;//打印开始命令
    42de:	0a018da3          	sb	zero,187(gp) # 200005a3 <CMD_Start>
    StopPrint 	  = 0;//停止打印命令
    42e2:	0a018d23          	sb	zero,186(gp) # 200005a2 <StopPrint>
    TaskStart 	  = 0; //作业开始命令
    42e6:	0a018623          	sb	zero,172(gp) # 20000594 <TaskStart>
	again_paper   = 0;
    42ea:	04019a23          	sh	zero,84(gp) # 2000053c <again_paper>
	
    ErrorStatusReg = 0X0080;//错误寄存器1    先置0080 ，然后自检，自检出错则	强制停止
    42ee:	08000713          	li	a4,128
	*ErrorCode_REG = ErrorStatusReg;//初始化错误寄存器
    42f2:	0cc78793          	addi	a5,a5,204
    ErrorStatusReg = 0X0080;//错误寄存器1    先置0080 ，然后自检，自检出错则	强制停止
    42f6:	08e19223          	sh	a4,132(gp) # 2000056c <ErrorStatusReg>
	*ErrorCode_REG = ErrorStatusReg;//初始化错误寄存器
    42fa:	c398                	sw	a4,0(a5)
	
    PrintModeReg   = 0X0000;//打印模式寄存器
    42fc:	08019123          	sh	zero,130(gp) # 2000056a <PrintModeReg>
	Clutch_CtrlREG = 0X0000;
    4300:	08019323          	sh	zero,134(gp) # 2000056e <Clutch_CtrlREG>
	
    PrintCtrlReg   = 0X0000;//命令控制寄存器
    4304:	08019023          	sh	zero,128(gp) # 20000568 <PrintCtrlReg>
	Page_sync_printed = 0;
    4308:	0a019223          	sh	zero,164(gp) # 2000058c <Page_sync_printed>
    //PrnSensorReg   = FSMC_Read(0x2D);//纸张传感器寄存器(卡纸)
	
	//FSMC_Write(0x32,0x8000);  ///打印头逻辑复位信号 bit15=1
	
	//////////////时间变量初试化/////////////
}
    430c:	8082                	ret

0000430e <Printer_Var_Init>:

////////////////////////////////////////打印过程的计数器、变量初始化 每打印一张都需要进行初始化///////////////////////////////////////
void Printer_Var_Init(){
//走纸过程中计数器、标志位、变量初始化

	SENS_RegiHflag = 0;
    430e:	06018ca3          	sb	zero,121(gp) # 20000561 <SENS_RegiHflag>
    SENS_RegiLflag = 0;
    4312:	06018c23          	sb	zero,120(gp) # 20000560 <SENS_RegiLflag>

    SENS_FeedHflag = 0;
    4316:	06018ba3          	sb	zero,119(gp) # 2000055f <SENS_FeedHflag>
    SENS_FeedLflag = 0;
    431a:	06018b23          	sb	zero,118(gp) # 2000055e <SENS_FeedLflag>

    SENS_ExitHflag = 0;
    431e:	06018aa3          	sb	zero,117(gp) # 2000055d <SENS_ExitHflag>
    SENS_ExitLflag = 0;
    4322:	06018a23          	sb	zero,116(gp) # 2000055c <SENS_ExitLflag>

    PrintStartHflag = 0;
    4326:	060189a3          	sb	zero,115(gp) # 2000055b <PrintStartHflag>
    PrintStartLflag = 0;
    432a:	06018923          	sb	zero,114(gp) # 2000055a <PrintStartLflag>

    K_SyncHflag = 0;
    432e:	060188a3          	sb	zero,113(gp) # 20000559 <K_SyncHflag>
    K_SyncLflag = 0;
    4332:	06018823          	sb	zero,112(gp) # 20000558 <K_SyncLflag>
	
	Stop_MotorFlag=0;
    4336:	08019523          	sh	zero,138(gp) # 20000572 <Stop_MotorFlag>
	
	//计数器清零
	timetest1 =0;
    433a:	0601a623          	sw	zero,108(gp) # 20000554 <timetest1>
	SENS_RegiL_timer1=0;
    433e:	0601a423          	sw	zero,104(gp) # 20000550 <SENS_RegiL_timer1>
	SENS_RegiL_timer2=0;
    4342:	0601a223          	sw	zero,100(gp) # 2000054c <SENS_RegiL_timer2>
	SENS_RegiH_timer=0;
    4346:	0601a023          	sw	zero,96(gp) # 20000548 <SENS_RegiH_timer>
	K_SyncH_time1=0;
    434a:	0401ae23          	sw	zero,92(gp) # 20000544 <K_SyncH_time1>
	
	CMD_Start = 0;        // 开始打印命令
    434e:	0a018da3          	sb	zero,187(gp) # 200005a3 <CMD_Start>
  StopPrint = 0;        // 结束打印命令
    4352:	0a018d23          	sb	zero,186(gp) # 200005a2 <StopPrint>
  PaperFeed = 1;        // 进纸方式
    4356:	4785                	li	a5,1
    4358:	00f18ea3          	sb	a5,29(gp) # 20000505 <PaperFeed>
 SendPage = 0;
    435c:	0a019c23          	sh	zero,184(gp) # 200005a0 <SendPage>
 PaperFeedPre = 0;     // 进纸方式
    4360:	0a019b23          	sh	zero,182(gp) # 2000059e <PaperFeedPre>
 Mode_Finish = 0;      // 参数设置完成标志
    4364:	0a019a23          	sh	zero,180(gp) # 2000059c <Mode_Finish>
 PrintPage = 0;        // 打印页数
    4368:	0a019923          	sh	zero,178(gp) # 2000059a <PrintPage>
  //PrintStyle;           // 打印方式：单/双面（当前未使用）
  PaperType = 0x38;     // 纸张类型
    436c:	03800693          	li	a3,56
    4370:	00d18e23          	sb	a3,28(gp) # 20000504 <PaperType>
  DataFinsh = 0;        // 打印数据下传完成
    4374:	0a018823          	sb	zero,176(gp) # 20000598 <DataFinsh>
 Printed_Page = 0;     // 已打印页数
    4378:	0a019723          	sh	zero,174(gp) # 20000596 <Printed_Page>
  TaskStart = 0;        // 作业开始命令
    437c:	0a018623          	sb	zero,172(gp) # 20000594 <TaskStart>
  DataReady = 0;        // 打印数据下传完成
    4380:	0a0185a3          	sb	zero,171(gp) # 20000593 <DataReady>
  DPI_Choose = 0;       // 0:600DPI, 1:1200DPI
    4384:	0a018523          	sb	zero,170(gp) # 20000592 <DPI_Choose>
  Douflag = 1;          // 1:单面, 0:双面
    4388:	00f18da3          	sb	a5,27(gp) # 20000503 <Douflag>
  Color_Choose = 0;     // 0:黑白, 1:彩色
    438c:	0a0184a3          	sb	zero,169(gp) # 20000591 <Color_Choose>
  ReSet = 0;            // ARM 同步信号
    4390:	0a018423          	sb	zero,168(gp) # 20000590 <ReSet>
   ERROR_CPU = 1;   
    4394:	00f18d23          	sb	a5,26(gp) # 20000502 <ERROR_CPU>
  Heat_Ready=0; 
    4398:	0a0183a3          	sb	zero,167(gp) # 2000058f <Heat_Ready>
  HV_Ready = 0; 
    439c:	0a018323          	sb	zero,166(gp) # 2000058e <HV_Ready>
  heat_is_timeout = 1;///超时初始值为1
    43a0:	00f18623          	sb	a5,12(gp) # 200004f4 <heat_is_timeout>

  again_paper=0;
    43a4:	04019a23          	sh	zero,84(gp) # 2000053c <again_paper>

	Page_sync_printed = 0;     // 已经发送的pagesync
    43a8:	0a019223          	sh	zero,164(gp) # 2000058c <Page_sync_printed>
 Page_sync_print = 0;     // 需要发送的pagesync 
    43ac:	0a019123          	sh	zero,162(gp) # 2000058a <Page_sync_print>


	Next_Page_Sync_Enable=0;
    43b0:	0a019023          	sh	zero,160(gp) # 20000588 <Next_Page_Sync_Enable>
	Next_Page_Sync_Timer=0;
    43b4:	08019f23          	sh	zero,158(gp) # 20000586 <Next_Page_Sync_Timer>
 nSENS_FUSER_RELEASE = 0;
    43b8:	0801a823          	sw	zero,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
 Stop_HVFlag = 0;
    43bc:	08019623          	sh	zero,140(gp) # 20000574 <Stop_HVFlag>

 


}
    43c0:	8082                	ret

000043c2 <PrintHead_Initial>:
{
	*PRINTHEAD_REG = 0x00000006;
}

void PrintHead_Initial()
{
    43c2:	1161                	addi	sp,sp,-8
    43c4:	c022                	sw	s0,0(sp)
    43c6:	c206                	sw	ra,4(sp)
	//初始化定义行数据、行数、以及纸张到激光头的时间
	*ByteNum_Per_Line_REG = 620;
    43c8:	600187b7          	lui	a5,0x60018
    43cc:	26c00713          	li	a4,620
    43d0:	0ae7a023          	sw	a4,160(a5) # 600180a0 <__heap_end+0x3ffe80a0>
	*LineNum_Per_Page_REG = 7016;
    43d4:	873e                	mv	a4,a5
    43d6:	6789                	lui	a5,0x2
    43d8:	b6878793          	addi	a5,a5,-1176 # 1b68 <__subdf3+0x156>
    43dc:	0af72223          	sw	a5,164(a4)
	*PageNum_Per_Job      = 1;
    43e0:	87ba                	mv	a5,a4
    43e2:	4705                	li	a4,1
    43e4:	0ae7a623          	sw	a4,172(a5)
	//*CYC_ST_DATA_M_REG      = 13134372;  //70mm对应13134372 
	//*CYC_ST_DATA_C_REG      = 26268744;
	//*CYC_ST_DATA_K_REG      = 39403116;
	
	
	*CYC_ST_DATA_Y_REG      = 0;
    43e8:	0a07aa23          	sw	zero,180(a5)
	*CYC_ST_DATA_M_REG      = 13322005;  //70mm对应13134372 
    43ec:	86be                	mv	a3,a5
    43ee:	00cb47b7          	lui	a5,0xcb4
    43f2:	71578793          	addi	a5,a5,1813 # cb4715 <__ctor_end__+0xcadb55>
    43f6:	0af6ac23          	sw	a5,184(a3)
	*CYC_ST_DATA_C_REG      = 26475140;
    43fa:	019407b7          	lui	a5,0x1940
    43fe:	a8478793          	addi	a5,a5,-1404 # 193fa84 <__ctor_end__+0x1938ec4>
    4402:	0af6ae23          	sw	a5,188(a3)
	*CYC_ST_DATA_K_REG      = 39684565;
    4406:	025d97b7          	lui	a5,0x25d9
    440a:	9d578793          	addi	a5,a5,-1579 # 25d89d5 <__ctor_end__+0x25d1e15>
    440e:	0af6a423          	sw	a5,168(a3)
//	*CYC_ST_DATA_Y_REG      = 0;
//	*CYC_ST_DATA_M_REG      = 0;
//	*CYC_ST_DATA_C_REG      = 0;
	
	
	*Start_Line_Reg         = 0;
    4412:	0c06a023          	sw	zero,192(a3)
    4416:	87b6                	mv	a5,a3
	*End_Line_Reg           = 200;
    4418:	0c800693          	li	a3,200
    441c:	0cd7a223          	sw	a3,196(a5)
	
	*PRINTHEAD_REG = 0b00001;	//RST PH Module
    4420:	09078413          	addi	s0,a5,144
    4424:	c018                	sw	a4,0(s0)
//	LSU_Motor_Start();
	while((*STATUS_REG)&0b0001)	;
    4426:	00478713          	addi	a4,a5,4
    442a:	431c                	lw	a5,0(a4)
    442c:	8b85                	andi	a5,a5,1
    442e:	fff5                	bnez	a5,442a <PrintHead_Initial+0x68>
	Delay_ms(20);
    4430:	4551                	li	a0,20
    4432:	3121                	jal	403a <Delay_ms>
	*PRINTHEAD_REG = 0b00010;	//RST PH Module
    4434:	4789                	li	a5,2
    4436:	c01c                	sw	a5,0(s0)
	delay_1ms();
    4438:	36dd                	jal	401e <delay_1ms>
	*PRINTHEAD_REG = 0b01010;	//RST PH Module
    443a:	47a9                	li	a5,10
}
    443c:	4092                	lw	ra,4(sp)
	*PRINTHEAD_REG = 0b01010;	//RST PH Module
    443e:	c01c                	sw	a5,0(s0)
}
    4440:	4402                	lw	s0,0(sp)
    4442:	0121                	addi	sp,sp,8
    4444:	8082                	ret

00004446 <PrintHead_PrintMode_Set>:

void PrintHead_PrintMode_Set()
    4446:	600187b7          	lui	a5,0x60018
    444a:	4719                	li	a4,6
    444c:	08e7a823          	sw	a4,144(a5) # 60018090 <__heap_end+0x3ffe8090>
    4450:	8082                	ret

00004452 <Page_Sync_ON>:

void Page_Sync_ON()
{
	//*PRINTHEAD_REG = 0b00110;
	//Delay_ms(20);
	*PRINTHEAD_REG = 0b10110;
    4452:	600187b7          	lui	a5,0x60018
    4456:	4759                	li	a4,22
    4458:	08e7a823          	sw	a4,144(a5) # 60018090 <__heap_end+0x3ffe8090>
}
    445c:	8082                	ret

0000445e <Page_Sync_Close>:

void Page_Sync_Close()
    445e:	600187b7          	lui	a5,0x60018
    4462:	4719                	li	a4,6
    4464:	08e7a823          	sw	a4,144(a5) # 60018090 <__heap_end+0x3ffe8090>
    4468:	8082                	ret

0000446a <fuser_release>:
{	
	*PRINTHEAD_REG = 0b00110;
}

void fuser_release(){///fuser电机释放
    446a:	1161                	addi	sp,sp,-8
    446c:	c206                	sw	ra,4(sp)
    446e:	c022                	sw	s0,0(sp)
	
	*Fuser_Count_Num_REG 	=110;
    4470:	600187b7          	lui	a5,0x60018
    4474:	06e00713          	li	a4,110
    4478:	0ee7a023          	sw	a4,224(a5) # 600180e0 <__heap_end+0x3ffe80e0>
	Delay_ms(10);
    447c:	4529                	li	a0,10
    447e:	3e75                	jal	403a <Delay_ms>
	nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    4480:	600187b7          	lui	a5,0x60018
    4484:	4fdc                	lw	a5,28(a5)
    4486:	0207f793          	andi	a5,a5,32
    448a:	08f1a823          	sw	a5,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
	FUSER_Motor_Start_Rev();
    448e:	3981                	jal	40de <FUSER_Motor_Start_Rev>
	//Delay_ms(5);
	while (nSENS_FUSER_RELEASE==0) {
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    4490:	600187b7          	lui	a5,0x60018
    4494:	07f1                	addi	a5,a5,28 # 6001801c <__heap_end+0x3ffe801c>
	while (nSENS_FUSER_RELEASE==0) {
    4496:	0901a703          	lw	a4,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
    449a:	cf31                	beqz	a4,44f6 <fuser_release+0x8c>
		if (nSENS_FUSER_RELEASE==1) {///变高后跳出
			break;
		}
	}
	while (nSENS_FUSER_RELEASE==0x0020) {
    449c:	02000793          	li	a5,32
    44a0:	02f71063          	bne	a4,a5,44c0 <fuser_release+0x56>
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    44a4:	60018737          	lui	a4,0x60018
    44a8:	0771                	addi	a4,a4,28 # 6001801c <__heap_end+0x3ffe801c>
    44aa:	431c                	lw	a5,0(a4)
    44ac:	0207f793          	andi	a5,a5,32
    44b0:	08f1a823          	sw	a5,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
		if (nSENS_FUSER_RELEASE==0) {
    44b4:	fbfd                	bnez	a5,44aa <fuser_release+0x40>
			*Fuser_Count_Enable_REG=0x0001;
    44b6:	600187b7          	lui	a5,0x60018
    44ba:	4705                	li	a4,1
    44bc:	0ce7ae23          	sw	a4,220(a5) # 600180dc <__heap_end+0x3ffe80dc>
		}
		
	}
		///运行110		
			
	count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    44c0:	600187b7          	lui	a5,0x60018
    44c4:	4fdc                	lw	a5,28(a5)
	while (count_over_flag == 0) {
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    44c6:	60018737          	lui	a4,0x60018
	count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    44ca:	839d                	srli	a5,a5,0x7
    44cc:	8b85                	andi	a5,a5,1
    44ce:	04f184a3          	sb	a5,73(gp) # 20000531 <count_over_flag>
	while (count_over_flag == 0) {
    44d2:	4601                	li	a2,0
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    44d4:	0771                	addi	a4,a4,28 # 6001801c <__heap_end+0x3ffe801c>
	while (count_over_flag == 0) {
    44d6:	c795                	beqz	a5,4502 <fuser_release+0x98>
    44d8:	c601                	beqz	a2,44e0 <fuser_release+0x76>
    44da:	4785                	li	a5,1
    44dc:	04f184a3          	sb	a5,73(gp) # 20000531 <count_over_flag>
	}			
	FUSER_Motor_Stop();
    44e0:	34a1                	jal	3f28 <FUSER_Motor_Stop>
	*Fuser_Count_Enable_REG = 0x0000;
	*Fuser_Count_Num_REG 	=0;
}
    44e2:	4092                	lw	ra,4(sp)
    44e4:	4402                	lw	s0,0(sp)
	*Fuser_Count_Enable_REG = 0x0000;
    44e6:	600187b7          	lui	a5,0x60018
    44ea:	0c07ae23          	sw	zero,220(a5) # 600180dc <__heap_end+0x3ffe80dc>
	*Fuser_Count_Num_REG 	=0;
    44ee:	0e07a023          	sw	zero,224(a5)
}
    44f2:	0121                	addi	sp,sp,8
    44f4:	8082                	ret
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    44f6:	4398                	lw	a4,0(a5)
    44f8:	02077713          	andi	a4,a4,32
    44fc:	08e1a823          	sw	a4,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
		if (nSENS_FUSER_RELEASE==1) {///变高后跳出
    4500:	bf59                	j	4496 <fuser_release+0x2c>
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    4502:	431c                	lw	a5,0(a4)
    4504:	4605                	li	a2,1
    4506:	839d                	srli	a5,a5,0x7
    4508:	8b85                	andi	a5,a5,1
    450a:	b7f1                	j	44d6 <fuser_release+0x6c>

0000450c <fuser_clamping>:

void fuser_clamping(){///fuser电机压紧
    450c:	1161                	addi	sp,sp,-8
	
	
	*Fuser_Count_Num_REG 	=46;//48		
    450e:	02e00713          	li	a4,46
void fuser_clamping(){///fuser电机压紧
    4512:	c206                	sw	ra,4(sp)
    4514:	c022                	sw	s0,0(sp)
	*Fuser_Count_Num_REG 	=46;//48		
    4516:	600187b7          	lui	a5,0x60018
    451a:	0ee7a023          	sw	a4,224(a5) # 600180e0 <__heap_end+0x3ffe80e0>
	Delay_ms(10);
    451e:	4529                	li	a0,10
    4520:	3e29                	jal	403a <Delay_ms>
	nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    4522:	600187b7          	lui	a5,0x60018
    4526:	4fdc                	lw	a5,28(a5)
    4528:	0207f793          	andi	a5,a5,32
    452c:	08f1a823          	sw	a5,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
	FUSER_Motor_Start_Rev();
    4530:	367d                	jal	40de <FUSER_Motor_Start_Rev>
	//持续检测传感器 
	while (nSENS_FUSER_RELEASE==0) {
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    4532:	60018737          	lui	a4,0x60018
    4536:	0771                	addi	a4,a4,28 # 6001801c <__heap_end+0x3ffe801c>
	while (nSENS_FUSER_RELEASE==0) {
    4538:	0901a783          	lw	a5,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
    453c:	ef81                	bnez	a5,4554 <fuser_clamping+0x48>
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
    453e:	431c                	lw	a5,0(a4)
    4540:	0207f793          	andi	a5,a5,32
    4544:	08f1a823          	sw	a5,144(gp) # 20000578 <nSENS_FUSER_RELEASE>
		if (nSENS_FUSER_RELEASE==0x0020) {///变高后跳出
    4548:	dbe5                	beqz	a5,4538 <fuser_clamping+0x2c>
			*Fuser_Count_Enable_REG=0x0001;
    454a:	600187b7          	lui	a5,0x60018
    454e:	4705                	li	a4,1
    4550:	0ce7ae23          	sw	a4,220(a5) # 600180dc <__heap_end+0x3ffe80dc>
		}
	}
	///运行48步
//	*Fuser_Count_Reset_REG = 0b1;
//	*Fuser_Count_Num_REG 	=48;			
	count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    4554:	600187b7          	lui	a5,0x60018
    4558:	4fdc                	lw	a5,28(a5)
	while (count_over_flag == 0) {
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    455a:	60018737          	lui	a4,0x60018
	count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    455e:	839d                	srli	a5,a5,0x7
    4560:	8b85                	andi	a5,a5,1
    4562:	04f184a3          	sb	a5,73(gp) # 20000531 <count_over_flag>
	while (count_over_flag == 0) {
    4566:	4601                	li	a2,0
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    4568:	0771                	addi	a4,a4,28 # 6001801c <__heap_end+0x3ffe801c>
	while (count_over_flag == 0) {
    456a:	c385                	beqz	a5,458a <fuser_clamping+0x7e>
    456c:	c601                	beqz	a2,4574 <fuser_clamping+0x68>
    456e:	4785                	li	a5,1
    4570:	04f184a3          	sb	a5,73(gp) # 20000531 <count_over_flag>
	}			
	FUSER_Motor_Stop();
    4574:	3a55                	jal	3f28 <FUSER_Motor_Stop>
	*Fuser_Count_Enable_REG = 0x0000;
	*Fuser_Count_Num_REG 	=0;	
}
    4576:	4092                	lw	ra,4(sp)
    4578:	4402                	lw	s0,0(sp)
	*Fuser_Count_Enable_REG = 0x0000;
    457a:	600187b7          	lui	a5,0x60018
    457e:	0c07ae23          	sw	zero,220(a5) # 600180dc <__heap_end+0x3ffe80dc>
	*Fuser_Count_Num_REG 	=0;	
    4582:	0e07a023          	sw	zero,224(a5)
}
    4586:	0121                	addi	sp,sp,8
    4588:	8082                	ret
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
    458a:	431c                	lw	a5,0(a4)
    458c:	4605                	li	a2,1
    458e:	839d                	srli	a5,a5,0x7
    4590:	8b85                	andi	a5,a5,1
    4592:	bfe1                	j	456a <fuser_clamping+0x5e>

00004594 <Heat_Open>:

void Heat_Open(){
    4594:	1151                	addi	sp,sp,-12
    4596:	c222                	sw	s0,4(sp)
		
		Delay_ms(100);
    4598:	06400513          	li	a0,100
		*ADC_HeaterCtrl_REG=0x0001;//ADC复位  定影复位
    459c:	60018437          	lui	s0,0x60018
void Heat_Open(){
    45a0:	c406                	sw	ra,8(sp)
    45a2:	c026                	sw	s1,0(sp)
		*ADC_HeaterCtrl_REG=0x0001;//ADC复位  定影复位
    45a4:	0d840413          	addi	s0,s0,216 # 600180d8 <__heap_end+0x3ffe80d8>
		Delay_ms(100);
    45a8:	3c49                	jal	403a <Delay_ms>
		*ADC_HeaterCtrl_REG=0x0001;//ADC复位  定影复位
    45aa:	4485                	li	s1,1
    45ac:	c004                	sw	s1,0(s0)
		AVR_DATA_start=1;
		Delay_ms(300);
    45ae:	12c00513          	li	a0,300
		AVR_DATA_start=1;
    45b2:	04918423          	sb	s1,72(gp) # 20000530 <AVR_DATA_start>
		Delay_ms(300);
    45b6:	3451                	jal	403a <Delay_ms>

		*ADC_HeaterCtrl_REG = 0b1001;///定影模块使能 bit3=1
    45b8:	47a5                	li	a5,9
    45ba:	c01c                	sw	a5,0(s0)
		while (ERROR_CPU == 1) 
    45bc:	01a1c783          	lbu	a5,26(gp) # 20000502 <ERROR_CPU>
    45c0:	00979c63          	bne	a5,s1,45d8 <Heat_Open+0x44>
		{
			ERROR_CPU = (*ERROR_CPU_REG & 0x0002) ? 1 : 0;
    45c4:	60018737          	lui	a4,0x60018
    45c8:	0761                	addi	a4,a4,24 # 60018018 <__heap_end+0x3ffe8018>
    45ca:	431c                	lw	a5,0(a4)
    45cc:	8b89                	andi	a5,a5,2
			if (ERROR_CPU == 0) 
    45ce:	fff5                	bnez	a5,45ca <Heat_Open+0x36>
    45d0:	00018d23          	sb	zero,26(gp) # 20000502 <ERROR_CPU>
			{
				*ADC_HeaterCtrl_REG = 0b1101;
    45d4:	47b5                	li	a5,13
    45d6:	c01c                	sw	a5,0(s0)
				break;
			}				
		}
}
    45d8:	40a2                	lw	ra,8(sp)
    45da:	4412                	lw	s0,4(sp)
    45dc:	4482                	lw	s1,0(sp)
    45de:	0131                	addi	sp,sp,12
    45e0:	8082                	ret

000045e2 <Heat_Close>:
void Heat_Close(){
	*ADC_HeaterCtrl_REG = 0b0101;
    45e2:	600187b7          	lui	a5,0x60018
    45e6:	4715                	li	a4,5
    45e8:	0ce7ac23          	sw	a4,216(a5) # 600180d8 <__heap_end+0x3ffe80d8>
	while (ERROR_CPU == 0)
    45ec:	01a1c783          	lbu	a5,26(gp) # 20000502 <ERROR_CPU>
    45f0:	ef91                	bnez	a5,460c <Heat_Close+0x2a>
	{
		ERROR_CPU = (*ERROR_CPU_REG & 0x0002) ? 1 : 0;
    45f2:	60018737          	lui	a4,0x60018
    45f6:	0761                	addi	a4,a4,24 # 60018018 <__heap_end+0x3ffe8018>
    45f8:	431c                	lw	a5,0(a4)
    45fa:	8b89                	andi	a5,a5,2
		if (ERROR_CPU == 1)
    45fc:	dff5                	beqz	a5,45f8 <Heat_Close+0x16>
    45fe:	4785                	li	a5,1
    4600:	00f18d23          	sb	a5,26(gp) # 20000502 <ERROR_CPU>
		{
			*ADC_HeaterCtrl_REG = 0b0001;
    4604:	60018737          	lui	a4,0x60018
    4608:	0cf72c23          	sw	a5,216(a4) # 600180d8 <__heap_end+0x3ffe80d8>
			break;
		}
	}
}
    460c:	8082                	ret

0000460e <copystring>:
    460e:	4781                	li	a5,0
    4610:	470d                	li	a4,3
    4612:	00b7c463          	blt	a5,a1,461a <copystring+0xc>
    4616:	853e                	mv	a0,a5
    4618:	8082                	ret
    461a:	00f606b3          	add	a3,a2,a5
    461e:	0006c303          	lbu	t1,0(a3)
    4622:	00f506b3          	add	a3,a0,a5
    4626:	0785                	addi	a5,a5,1
    4628:	00668023          	sb	t1,0(a3)
    462c:	fee793e3          	bne	a5,a4,4612 <copystring+0x4>
    4630:	feb7d3e3          	bge	a5,a1,4616 <copystring+0x8>
    4634:	000501a3          	sb	zero,3(a0)
    4638:	4791                	li	a5,4
    463a:	bff1                	j	4616 <copystring+0x8>

0000463c <__dtostr>:
    463c:	fa810113          	addi	sp,sp,-88
    4640:	c8a2                	sw	s0,80(sp)
    4642:	ca86                	sw	ra,84(sp)
    4644:	c6a6                	sw	s1,76(sp)
    4646:	d02a                	sw	a0,32(sp)
    4648:	c42e                	sw	a1,8(sp)
    464a:	c032                	sw	a2,0(sp)
    464c:	8436                	mv	s0,a3
    464e:	d43a                	sw	a4,40(sp)
    4650:	c23e                	sw	a5,4(sp)
    4652:	2edd                	jal	4a48 <__isinf>
    4654:	cd09                	beqz	a0,466e <__dtostr+0x32>
    4656:	6619                	lui	a2,0x6
    4658:	11460613          	addi	a2,a2,276 # 6114 <sg_timer_config+0x184>
    465c:	85a2                	mv	a1,s0
    465e:	4446                	lw	s0,80(sp)
    4660:	4502                	lw	a0,0(sp)
    4662:	40d6                	lw	ra,84(sp)
    4664:	44b6                	lw	s1,76(sp)
    4666:	05810113          	addi	sp,sp,88
    466a:	fa5ff06f          	j	460e <copystring>
    466e:	5702                	lw	a4,32(sp)
    4670:	47a2                	lw	a5,8(sp)
    4672:	853a                	mv	a0,a4
    4674:	85be                	mv	a1,a5
    4676:	2b15                	jal	4baa <__isnan>
    4678:	d22a                	sw	a0,36(sp)
    467a:	c509                	beqz	a0,4684 <__dtostr+0x48>
    467c:	6619                	lui	a2,0x6
    467e:	11860613          	addi	a2,a2,280 # 6118 <sg_timer_config+0x188>
    4682:	bfe9                	j	465c <__dtostr+0x20>
    4684:	5702                	lw	a4,32(sp)
    4686:	47a2                	lw	a5,8(sp)
    4688:	4601                	li	a2,0
    468a:	4681                	li	a3,0
    468c:	853a                	mv	a0,a4
    468e:	85be                	mv	a1,a5
    4690:	d39fc0ef          	jal	13c8 <__eqdf2>
    4694:	e925                	bnez	a0,4704 <__dtostr+0xc8>
    4696:	4792                	lw	a5,4(sp)
    4698:	3a078363          	beqz	a5,4a3e <__dtostr+0x402>
    469c:	0789                	addi	a5,a5,2
    469e:	02f46163          	bltu	s0,a5,46c0 <__dtostr+0x84>
    46a2:	cb85                	beqz	a5,46d2 <__dtostr+0x96>
    46a4:	4722                	lw	a4,8(sp)
    46a6:	04075c63          	bgez	a4,46fe <__dtostr+0xc2>
    46aa:	4682                	lw	a3,0(sp)
    46ac:	02d00713          	li	a4,45
    46b0:	00e68023          	sb	a4,0(a3)
    46b4:	00178713          	addi	a4,a5,1
    46b8:	4785                	li	a5,1
    46ba:	03000693          	li	a3,48
    46be:	a801                	j	46ce <__dtostr+0x92>
    46c0:	47a1                	li	a5,8
    46c2:	b7cd                	j	46a4 <__dtostr+0x68>
    46c4:	4602                	lw	a2,0(sp)
    46c6:	963e                	add	a2,a2,a5
    46c8:	00d60023          	sb	a3,0(a2)
    46cc:	0785                	addi	a5,a5,1
    46ce:	fee7ebe3          	bltu	a5,a4,46c4 <__dtostr+0x88>
    46d2:	4702                	lw	a4,0(sp)
    46d4:	03000693          	li	a3,48
    46d8:	00074603          	lbu	a2,0(a4)
    46dc:	4705                	li	a4,1
    46de:	00d60363          	beq	a2,a3,46e4 <__dtostr+0xa8>
    46e2:	4709                	li	a4,2
    46e4:	4682                	lw	a3,0(sp)
    46e6:	9736                	add	a4,a4,a3
    46e8:	02e00693          	li	a3,46
    46ec:	00d70023          	sb	a3,0(a4)
    46f0:	4702                	lw	a4,0(sp)
    46f2:	00f704b3          	add	s1,a4,a5
    46f6:	00048023          	sb	zero,0(s1)
    46fa:	d23e                	sw	a5,36(sp)
    46fc:	a459                	j	4982 <__dtostr+0x346>
    46fe:	873e                	mv	a4,a5
    4700:	4781                	li	a5,0
    4702:	bf65                	j	46ba <__dtostr+0x7e>
    4704:	5702                	lw	a4,32(sp)
    4706:	47a2                	lw	a5,8(sp)
    4708:	4601                	li	a2,0
    470a:	4681                	li	a3,0
    470c:	853a                	mv	a0,a4
    470e:	85be                	mv	a1,a5
    4710:	ddbfc0ef          	jal	14ea <__ledf2>
    4714:	16055f63          	bgez	a0,4892 <__dtostr+0x256>
    4718:	47a2                	lw	a5,8(sp)
    471a:	4702                	lw	a4,0(sp)
    471c:	800002b7          	lui	t0,0x80000
    4720:	00f2c2b3          	xor	t0,t0,a5
    4724:	02d00793          	li	a5,45
    4728:	00f70023          	sb	a5,0(a4)
    472c:	147d                	addi	s0,s0,-1
    472e:	00170493          	addi	s1,a4,1
    4732:	679d                	lui	a5,0x7
    4734:	8287a503          	lw	a0,-2008(a5) # 6828 <sg_timer_config+0x898>
    4738:	82c7a583          	lw	a1,-2004(a5)
    473c:	679d                	lui	a5,0x7
    473e:	8387a703          	lw	a4,-1992(a5) # 6838 <sg_timer_config+0x8a8>
    4742:	83c7a783          	lw	a5,-1988(a5)
    4746:	4381                	li	t2,0
    4748:	4692                	lw	a3,4(sp)
    474a:	14d39763          	bne	t2,a3,4898 <__dtostr+0x25c>
    474e:	5702                	lw	a4,32(sp)
    4750:	862a                	mv	a2,a0
    4752:	86ae                	mv	a3,a1
    4754:	853a                	mv	a0,a4
    4756:	8596                	mv	a1,t0
    4758:	944fc0ef          	jal	89c <__adddf3>
    475c:	679d                	lui	a5,0x7
    475e:	8407a603          	lw	a2,-1984(a5) # 6840 <sg_timer_config+0x8b0>
    4762:	8447a683          	lw	a3,-1980(a5)
    4766:	c82a                	sw	a0,16(sp)
    4768:	ca2e                	sw	a1,20(sp)
    476a:	d81fc0ef          	jal	14ea <__ledf2>
    476e:	00055863          	bgez	a0,477e <__dtostr+0x142>
    4772:	03000793          	li	a5,48
    4776:	00f48023          	sb	a5,0(s1)
    477a:	147d                	addi	s0,s0,-1
    477c:	0485                	addi	s1,s1,1
    477e:	47a2                	lw	a5,8(sp)
    4780:	0147d513          	srli	a0,a5,0x14
    4784:	7ff57513          	andi	a0,a0,2047
    4788:	c0150513          	addi	a0,a0,-1023
    478c:	8c3fd0ef          	jal	204e <__floatsidf>
    4790:	679d                	lui	a5,0x7
    4792:	8487a603          	lw	a2,-1976(a5) # 6848 <sg_timer_config+0x8b8>
    4796:	84c7a683          	lw	a3,-1972(a5)
    479a:	df9fc0ef          	jal	1592 <__muldf3>
    479e:	84bfd0ef          	jal	1fe8 <__fixdfsi>
    47a2:	00150793          	addi	a5,a0,1
    47a6:	cc3e                	sw	a5,24(sp)
    47a8:	22f05763          	blez	a5,49d6 <__dtostr+0x39a>
    47ac:	669d                	lui	a3,0x7
    47ae:	8506a603          	lw	a2,-1968(a3) # 6850 <sg_timer_config+0x8c0>
    47b2:	82be                	mv	t0,a5
    47b4:	8546a683          	lw	a3,-1964(a3)
    47b8:	679d                	lui	a5,0x7
    47ba:	8307a703          	lw	a4,-2000(a5) # 6830 <sg_timer_config+0x8a0>
    47be:	8347a783          	lw	a5,-1996(a5)
    47c2:	43a9                	li	t2,10
    47c4:	d632                	sw	a2,44(sp)
    47c6:	d836                	sw	a3,48(sp)
    47c8:	0e53e663          	bltu	t2,t0,48b4 <__dtostr+0x278>
    47cc:	669d                	lui	a3,0x7
    47ce:	8306a603          	lw	a2,-2000(a3) # 6830 <sg_timer_config+0x8a0>
    47d2:	8346a683          	lw	a3,-1996(a3)
    47d6:	4385                	li	t2,1
    47d8:	d632                	sw	a2,44(sp)
    47da:	d836                	sw	a3,48(sp)
    47dc:	0e729963          	bne	t0,t2,48ce <__dtostr+0x292>
    47e0:	4685                	li	a3,1
    47e2:	d636                	sw	a3,44(sp)
    47e4:	669d                	lui	a3,0x7
    47e6:	8586a603          	lw	a2,-1960(a3) # 6858 <sg_timer_config+0x8c8>
    47ea:	85c6a683          	lw	a3,-1956(a3)
    47ee:	da32                	sw	a2,52(sp)
    47f0:	dc36                	sw	a3,56(sp)
    47f2:	669d                	lui	a3,0x7
    47f4:	8306a603          	lw	a2,-2000(a3) # 6830 <sg_timer_config+0x8a0>
    47f8:	8346a683          	lw	a3,-1996(a3)
    47fc:	de32                	sw	a2,60(sp)
    47fe:	c0b6                	sw	a3,64(sp)
    4800:	5652                	lw	a2,52(sp)
    4802:	56e2                	lw	a3,56(sp)
    4804:	853a                	mv	a0,a4
    4806:	85be                	mv	a1,a5
    4808:	c2ba                	sw	a4,68(sp)
    480a:	c4be                	sw	a5,72(sp)
    480c:	c37fc0ef          	jal	1442 <__gedf2>
    4810:	4716                	lw	a4,68(sp)
    4812:	47a6                	lw	a5,72(sp)
    4814:	0ca04a63          	bgtz	a0,48e8 <__dtostr+0x2ac>
    4818:	4682                	lw	a3,0(sp)
    481a:	00d49a63          	bne	s1,a3,482e <__dtostr+0x1f2>
    481e:	16040263          	beqz	s0,4982 <__dtostr+0x346>
    4822:	03000693          	li	a3,48
    4826:	00d48023          	sb	a3,0(s1)
    482a:	147d                	addi	s0,s0,-1
    482c:	0485                	addi	s1,s1,1
    482e:	4692                	lw	a3,4(sp)
    4830:	ea81                	bnez	a3,4840 <__dtostr+0x204>
    4832:	4682                	lw	a3,0(sp)
    4834:	5622                	lw	a2,40(sp)
    4836:	40d486b3          	sub	a3,s1,a3
    483a:	0685                	addi	a3,a3,1
    483c:	04c6f563          	bgeu	a3,a2,4886 <__dtostr+0x24a>
    4840:	14040163          	beqz	s0,4982 <__dtostr+0x346>
    4844:	02e00693          	li	a3,46
    4848:	00d48023          	sb	a3,0(s1)
    484c:	4692                	lw	a3,4(sp)
    484e:	147d                	addi	s0,s0,-1
    4850:	00148293          	addi	t0,s1,1
    4854:	ea81                	bnez	a3,4864 <__dtostr+0x228>
    4856:	56a2                	lw	a3,40(sp)
    4858:	4602                	lw	a2,0(sp)
    485a:	0685                	addi	a3,a3,1
    485c:	40c28633          	sub	a2,t0,a2
    4860:	8e91                	sub	a3,a3,a2
    4862:	c236                	sw	a3,4(sp)
    4864:	4692                	lw	a3,4(sp)
    4866:	10d46e63          	bltu	s0,a3,4982 <__dtostr+0x346>
    486a:	8426                	mv	s0,s1
    486c:	94b6                	add	s1,s1,a3
    486e:	669d                	lui	a3,0x7
    4870:	8306a603          	lw	a2,-2000(a3) # 6830 <sg_timer_config+0x8a0>
    4874:	8346a683          	lw	a3,-1996(a3)
    4878:	c432                	sw	a2,8(sp)
    487a:	c636                	sw	a3,12(sp)
    487c:	16941363          	bne	s0,s1,49e2 <__dtostr+0x3a6>
    4880:	4792                	lw	a5,4(sp)
    4882:	00f284b3          	add	s1,t0,a5
    4886:	4782                	lw	a5,0(sp)
    4888:	00048023          	sb	zero,0(s1)
    488c:	40f487b3          	sub	a5,s1,a5
    4890:	b5ad                	j	46fa <__dtostr+0xbe>
    4892:	4482                	lw	s1,0(sp)
    4894:	42a2                	lw	t0,8(sp)
    4896:	bd71                	j	4732 <__dtostr+0xf6>
    4898:	863a                	mv	a2,a4
    489a:	86be                	mv	a3,a5
    489c:	d616                	sw	t0,44(sp)
    489e:	cc1e                	sw	t2,24(sp)
    48a0:	c83a                	sw	a4,16(sp)
    48a2:	ca3e                	sw	a5,20(sp)
    48a4:	ceffc0ef          	jal	1592 <__muldf3>
    48a8:	43e2                	lw	t2,24(sp)
    48aa:	52b2                	lw	t0,44(sp)
    48ac:	4742                	lw	a4,16(sp)
    48ae:	0385                	addi	t2,t2,1
    48b0:	47d2                	lw	a5,20(sp)
    48b2:	bd59                	j	4748 <__dtostr+0x10c>
    48b4:	5632                	lw	a2,44(sp)
    48b6:	56c2                	lw	a3,48(sp)
    48b8:	853a                	mv	a0,a4
    48ba:	85be                	mv	a1,a5
    48bc:	da16                	sw	t0,52(sp)
    48be:	cd5fc0ef          	jal	1592 <__muldf3>
    48c2:	52d2                	lw	t0,52(sp)
    48c4:	872a                	mv	a4,a0
    48c6:	87ae                	mv	a5,a1
    48c8:	12d9                	addi	t0,t0,-10 # 7ffffff6 <__heap_end+0x5ffcfff6>
    48ca:	43a9                	li	t2,10
    48cc:	bdf5                	j	47c8 <__dtostr+0x18c>
    48ce:	5632                	lw	a2,44(sp)
    48d0:	56c2                	lw	a3,48(sp)
    48d2:	853a                	mv	a0,a4
    48d4:	85be                	mv	a1,a5
    48d6:	da16                	sw	t0,52(sp)
    48d8:	cbbfc0ef          	jal	1592 <__muldf3>
    48dc:	52d2                	lw	t0,52(sp)
    48de:	872a                	mv	a4,a0
    48e0:	87ae                	mv	a5,a1
    48e2:	12fd                	addi	t0,t0,-1
    48e4:	4385                	li	t2,1
    48e6:	bddd                	j	47dc <__dtostr+0x1a0>
    48e8:	4542                	lw	a0,16(sp)
    48ea:	45d2                	lw	a1,20(sp)
    48ec:	863a                	mv	a2,a4
    48ee:	86be                	mv	a3,a5
    48f0:	c2ba                	sw	a4,68(sp)
    48f2:	c4be                	sw	a5,72(sp)
    48f4:	d6efc0ef          	jal	e62 <__divdf3>
    48f8:	ef0fd0ef          	jal	1fe8 <__fixdfsi>
    48fc:	5632                	lw	a2,44(sp)
    48fe:	0ff57693          	zext.b	a3,a0
    4902:	4716                	lw	a4,68(sp)
    4904:	47a6                	lw	a5,72(sp)
    4906:	c211                	beqz	a2,490a <__dtostr+0x2ce>
    4908:	ced5                	beqz	a3,49c4 <__dtostr+0x388>
    490a:	03068693          	addi	a3,a3,48
    490e:	00d48023          	sb	a3,0(s1)
    4912:	0485                	addi	s1,s1,1
    4914:	ec35                	bnez	s0,4990 <__dtostr+0x354>
    4916:	863a                	mv	a2,a4
    4918:	86be                	mv	a3,a5
    491a:	5702                	lw	a4,32(sp)
    491c:	47a2                	lw	a5,8(sp)
    491e:	853a                	mv	a0,a4
    4920:	85be                	mv	a1,a5
    4922:	d40fc0ef          	jal	e62 <__divdf3>
    4926:	4792                	lw	a5,4(sp)
    4928:	5722                	lw	a4,40(sp)
    492a:	4602                	lw	a2,0(sp)
    492c:	4681                	li	a3,0
    492e:	3339                	jal	463c <__dtostr>
    4930:	c929                	beqz	a0,4982 <__dtostr+0x346>
    4932:	00a48333          	add	t1,s1,a0
    4936:	06500793          	li	a5,101
    493a:	00f30023          	sb	a5,0(t1)
    493e:	00130493          	addi	s1,t1,1
    4942:	fff54513          	not	a0,a0
    4946:	4711                	li	a4,4
    4948:	4685                	li	a3,1
    494a:	3e800793          	li	a5,1000
    494e:	4629                	li	a2,10
    4950:	45e2                	lw	a1,24(sp)
    4952:	00f5d363          	bge	a1,a5,4958 <__dtostr+0x31c>
    4956:	e285                	bnez	a3,4976 <__dtostr+0x33a>
    4958:	c909                	beqz	a0,496a <__dtostr+0x32e>
    495a:	46e2                	lw	a3,24(sp)
    495c:	0485                	addi	s1,s1,1
    495e:	02f6c6b3          	div	a3,a3,a5
    4962:	03068693          	addi	a3,a3,48
    4966:	fed48fa3          	sb	a3,-1(s1)
    496a:	46e2                	lw	a3,24(sp)
    496c:	157d                	addi	a0,a0,-1
    496e:	02f6e6b3          	rem	a3,a3,a5
    4972:	cc36                	sw	a3,24(sp)
    4974:	4681                	li	a3,0
    4976:	177d                	addi	a4,a4,-1
    4978:	02c7c7b3          	div	a5,a5,a2
    497c:	fb71                	bnez	a4,4950 <__dtostr+0x314>
    497e:	f00514e3          	bnez	a0,4886 <__dtostr+0x24a>
    4982:	40d6                	lw	ra,84(sp)
    4984:	4446                	lw	s0,80(sp)
    4986:	5512                	lw	a0,36(sp)
    4988:	44b6                	lw	s1,76(sp)
    498a:	05810113          	addi	sp,sp,88
    498e:	8082                	ret
    4990:	0ff57513          	zext.b	a0,a0
    4994:	d63a                	sw	a4,44(sp)
    4996:	d83e                	sw	a5,48(sp)
    4998:	eb6fd0ef          	jal	204e <__floatsidf>
    499c:	5732                	lw	a4,44(sp)
    499e:	57c2                	lw	a5,48(sp)
    49a0:	147d                	addi	s0,s0,-1
    49a2:	863a                	mv	a2,a4
    49a4:	86be                	mv	a3,a5
    49a6:	c2ba                	sw	a4,68(sp)
    49a8:	c4be                	sw	a5,72(sp)
    49aa:	be9fc0ef          	jal	1592 <__muldf3>
    49ae:	862a                	mv	a2,a0
    49b0:	86ae                	mv	a3,a1
    49b2:	4542                	lw	a0,16(sp)
    49b4:	45d2                	lw	a1,20(sp)
    49b6:	85cfd0ef          	jal	1a12 <__subdf3>
    49ba:	4716                	lw	a4,68(sp)
    49bc:	47a6                	lw	a5,72(sp)
    49be:	c82a                	sw	a0,16(sp)
    49c0:	ca2e                	sw	a1,20(sp)
    49c2:	d602                	sw	zero,44(sp)
    49c4:	5672                	lw	a2,60(sp)
    49c6:	4686                	lw	a3,64(sp)
    49c8:	853a                	mv	a0,a4
    49ca:	85be                	mv	a1,a5
    49cc:	c96fc0ef          	jal	e62 <__divdf3>
    49d0:	872a                	mv	a4,a0
    49d2:	87ae                	mv	a5,a1
    49d4:	b535                	j	4800 <__dtostr+0x1c4>
    49d6:	679d                	lui	a5,0x7
    49d8:	8387a703          	lw	a4,-1992(a5) # 6838 <sg_timer_config+0x8a8>
    49dc:	83c7a783          	lw	a5,-1988(a5)
    49e0:	bd25                	j	4818 <__dtostr+0x1dc>
    49e2:	4542                	lw	a0,16(sp)
    49e4:	45d2                	lw	a1,20(sp)
    49e6:	863a                	mv	a2,a4
    49e8:	86be                	mv	a3,a5
    49ea:	d016                	sw	t0,32(sp)
    49ec:	cc3a                	sw	a4,24(sp)
    49ee:	ce3e                	sw	a5,28(sp)
    49f0:	c72fc0ef          	jal	e62 <__divdf3>
    49f4:	df4fd0ef          	jal	1fe8 <__fixdfsi>
    49f8:	03050693          	addi	a3,a0,48
    49fc:	00d400a3          	sb	a3,1(s0)
    4a00:	0ff57513          	zext.b	a0,a0
    4a04:	e4afd0ef          	jal	204e <__floatsidf>
    4a08:	4762                	lw	a4,24(sp)
    4a0a:	47f2                	lw	a5,28(sp)
    4a0c:	0405                	addi	s0,s0,1
    4a0e:	863a                	mv	a2,a4
    4a10:	86be                	mv	a3,a5
    4a12:	b81fc0ef          	jal	1592 <__muldf3>
    4a16:	862a                	mv	a2,a0
    4a18:	86ae                	mv	a3,a1
    4a1a:	4542                	lw	a0,16(sp)
    4a1c:	45d2                	lw	a1,20(sp)
    4a1e:	ff5fc0ef          	jal	1a12 <__subdf3>
    4a22:	4762                	lw	a4,24(sp)
    4a24:	47f2                	lw	a5,28(sp)
    4a26:	4622                	lw	a2,8(sp)
    4a28:	46b2                	lw	a3,12(sp)
    4a2a:	c82a                	sw	a0,16(sp)
    4a2c:	ca2e                	sw	a1,20(sp)
    4a2e:	853a                	mv	a0,a4
    4a30:	85be                	mv	a1,a5
    4a32:	c30fc0ef          	jal	e62 <__divdf3>
    4a36:	872a                	mv	a4,a0
    4a38:	87ae                	mv	a5,a1
    4a3a:	5282                	lw	t0,32(sp)
    4a3c:	b581                	j	487c <__dtostr+0x240>
    4a3e:	47a1                	li	a5,8
    4a40:	c60402e3          	beqz	s0,46a4 <__dtostr+0x68>
    4a44:	4785                	li	a5,1
    4a46:	b9b9                	j	46a4 <__dtostr+0x68>

00004a48 <__isinf>:
    4a48:	e509                	bnez	a0,4a52 <__isinf+0xa>
    4a4a:	7ff007b7          	lui	a5,0x7ff00
    4a4e:	00f58b63          	beq	a1,a5,4a64 <__isinf+0x1c>
    4a52:	fff007b7          	lui	a5,0xfff00
    4a56:	8fad                	xor	a5,a5,a1
    4a58:	8d5d                	or	a0,a0,a5
    4a5a:	00153513          	seqz	a0,a0
    4a5e:	40a00533          	neg	a0,a0
    4a62:	8082                	ret
    4a64:	4505                	li	a0,1
    4a66:	8082                	ret

00004a68 <__lltostr>:
    4a68:	fdc10113          	addi	sp,sp,-36
    4a6c:	15fd                	addi	a1,a1,-1 # 7fff <__ctor_end__+0x143f>
    4a6e:	ce22                	sw	s0,28(sp)
    4a70:	d006                	sw	ra,32(sp)
    4a72:	cc26                	sw	s1,24(sp)
    4a74:	95aa                	add	a1,a1,a0
    4a76:	00058023          	sb	zero,0(a1)
    4a7a:	842a                	mv	s0,a0
    4a7c:	82b2                	mv	t0,a2
    4a7e:	8336                	mv	t1,a3
    4a80:	c709                	beqz	a4,4a8a <__lltostr+0x22>
    4a82:	02400693          	li	a3,36
    4a86:	00e6d363          	bge	a3,a4,4a8c <__lltostr+0x24>
    4a8a:	4729                	li	a4,10
    4a8c:	0062e6b3          	or	a3,t0,t1
    4a90:	4601                	li	a2,0
    4a92:	e699                	bnez	a3,4aa0 <__lltostr+0x38>
    4a94:	03000693          	li	a3,48
    4a98:	fed58fa3          	sb	a3,-1(a1)
    4a9c:	4605                	li	a2,1
    4a9e:	15fd                	addi	a1,a1,-1
    4aa0:	02700693          	li	a3,39
    4aa4:	c391                	beqz	a5,4aa8 <__lltostr+0x40>
    4aa6:	469d                	li	a3,7
    4aa8:	0ff6f793          	zext.b	a5,a3
    4aac:	c23e                	sw	a5,4(sp)
    4aae:	00c587b3          	add	a5,a1,a2
    4ab2:	c43e                	sw	a5,8(sp)
    4ab4:	41f75793          	srai	a5,a4,0x1f
    4ab8:	84ae                	mv	s1,a1
    4aba:	c03e                	sw	a5,0(sp)
    4abc:	47a2                	lw	a5,8(sp)
    4abe:	409786b3          	sub	a3,a5,s1
    4ac2:	00947563          	bgeu	s0,s1,4acc <__lltostr+0x64>
    4ac6:	0062e633          	or	a2,t0,t1
    4aca:	e205                	bnez	a2,4aea <__lltostr+0x82>
    4acc:	00168613          	addi	a2,a3,1
    4ad0:	85a6                	mv	a1,s1
    4ad2:	8522                	mv	a0,s0
    4ad4:	c036                	sw	a3,0(sp)
    4ad6:	187000ef          	jal	545c <memmove>
    4ada:	4682                	lw	a3,0(sp)
    4adc:	5082                	lw	ra,32(sp)
    4ade:	4472                	lw	s0,28(sp)
    4ae0:	44e2                	lw	s1,24(sp)
    4ae2:	8536                	mv	a0,a3
    4ae4:	02410113          	addi	sp,sp,36
    4ae8:	8082                	ret
    4aea:	4682                	lw	a3,0(sp)
    4aec:	863a                	mv	a2,a4
    4aee:	8516                	mv	a0,t0
    4af0:	859a                	mv	a1,t1
    4af2:	ca3a                	sw	a4,20(sp)
    4af4:	c816                	sw	t0,16(sp)
    4af6:	c61a                	sw	t1,12(sp)
    4af8:	a5bfb0ef          	jal	552 <__umoddi3>
    4afc:	03050513          	addi	a0,a0,48
    4b00:	0ff57513          	zext.b	a0,a0
    4b04:	03900793          	li	a5,57
    4b08:	14fd                	addi	s1,s1,-1
    4b0a:	4332                	lw	t1,12(sp)
    4b0c:	42c2                	lw	t0,16(sp)
    4b0e:	4752                	lw	a4,20(sp)
    4b10:	00a7ef63          	bltu	a5,a0,4b2e <__lltostr+0xc6>
    4b14:	4682                	lw	a3,0(sp)
    4b16:	00a48023          	sb	a0,0(s1)
    4b1a:	863a                	mv	a2,a4
    4b1c:	8516                	mv	a0,t0
    4b1e:	859a                	mv	a1,t1
    4b20:	c63a                	sw	a4,12(sp)
    4b22:	ed4fb0ef          	jal	1f6 <__udivdi3>
    4b26:	82aa                	mv	t0,a0
    4b28:	832e                	mv	t1,a1
    4b2a:	4732                	lw	a4,12(sp)
    4b2c:	bf41                	j	4abc <__lltostr+0x54>
    4b2e:	4792                	lw	a5,4(sp)
    4b30:	953e                	add	a0,a0,a5
    4b32:	b7cd                	j	4b14 <__lltostr+0xac>

00004b34 <printf>:
    4b34:	fdc10113          	addi	sp,sp,-36
    4b38:	c82e                	sw	a1,16(sp)
    4b3a:	080c                	addi	a1,sp,16
    4b3c:	c606                	sw	ra,12(sp)
    4b3e:	ca32                	sw	a2,20(sp)
    4b40:	cc36                	sw	a3,24(sp)
    4b42:	ce3a                	sw	a4,28(sp)
    4b44:	d03e                	sw	a5,32(sp)
    4b46:	c02e                	sw	a1,0(sp)
    4b48:	2099                	jal	4b8e <vprintf>
    4b4a:	40b2                	lw	ra,12(sp)
    4b4c:	02410113          	addi	sp,sp,36
    4b50:	8082                	ret

00004b52 <putc>:
    4b52:	95dfe06f          	j	34ae <fputc>

00004b56 <__stdio_outs>:
    4b56:	1151                	addi	sp,sp,-12
    4b58:	c222                	sw	s0,4(sp)
    4b5a:	c026                	sw	s1,0(sp)
    4b5c:	842a                	mv	s0,a0
    4b5e:	84ae                	mv	s1,a1
    4b60:	c406                	sw	ra,8(sp)
    4b62:	94a2                	add	s1,s1,s0
    4b64:	983fe0ef          	jal	34e6 <os_critical_enter>
    4b68:	00941a63          	bne	s0,s1,4b7c <__stdio_outs+0x26>
    4b6c:	97ffe0ef          	jal	34ea <os_critical_exit>
    4b70:	40a2                	lw	ra,8(sp)
    4b72:	4412                	lw	s0,4(sp)
    4b74:	4482                	lw	s1,0(sp)
    4b76:	4505                	li	a0,1
    4b78:	0131                	addi	sp,sp,12
    4b7a:	8082                	ret
    4b7c:	0201a703          	lw	a4,32(gp) # 20000508 <_impure_ptr>
    4b80:	00044503          	lbu	a0,0(s0)
    4b84:	0405                	addi	s0,s0,1
    4b86:	470c                	lw	a1,8(a4)
    4b88:	927fe0ef          	jal	34ae <fputc>
    4b8c:	bff1                	j	4b68 <__stdio_outs+0x12>

00004b8e <vprintf>:
    4b8e:	1131                	addi	sp,sp,-20
    4b90:	6795                	lui	a5,0x5
    4b92:	b5678793          	addi	a5,a5,-1194 # 4b56 <__stdio_outs>
    4b96:	862e                	mv	a2,a1
    4b98:	85aa                	mv	a1,a0
    4b9a:	850a                	mv	a0,sp
    4b9c:	c806                	sw	ra,16(sp)
    4b9e:	c002                	sw	zero,0(sp)
    4ba0:	c23e                	sw	a5,4(sp)
    4ba2:	2291                	jal	4ce6 <__v_printf>
    4ba4:	40c2                	lw	ra,16(sp)
    4ba6:	0151                	addi	sp,sp,20
    4ba8:	8082                	ret

00004baa <__isnan>:
    4baa:	fff80737          	lui	a4,0xfff80
    4bae:	177d                	addi	a4,a4,-1 # fff7ffff <__heap_end+0xdff4ffff>
    4bb0:	8f6d                	and	a4,a4,a1
    4bb2:	e509                	bnez	a0,4bbc <__isnan+0x12>
    4bb4:	7ff007b7          	lui	a5,0x7ff00
    4bb8:	00f70963          	beq	a4,a5,4bca <__isnan+0x20>
    4bbc:	fff807b7          	lui	a5,0xfff80
    4bc0:	8fad                	xor	a5,a5,a1
    4bc2:	8fc9                	or	a5,a5,a0
    4bc4:	0017b513          	seqz	a0,a5
    4bc8:	8082                	ret
    4bca:	4505                	li	a0,1
    4bcc:	8082                	ret

00004bce <__ltostr>:
    4bce:	1151                	addi	sp,sp,-12
    4bd0:	15fd                	addi	a1,a1,-1
    4bd2:	c406                	sw	ra,8(sp)
    4bd4:	c222                	sw	s0,4(sp)
    4bd6:	95aa                	add	a1,a1,a0
    4bd8:	00058023          	sb	zero,0(a1)
    4bdc:	fff68313          	addi	t1,a3,-1
    4be0:	02300793          	li	a5,35
    4be4:	0067f363          	bgeu	a5,t1,4bea <__ltostr+0x1c>
    4be8:	46a9                	li	a3,10
    4bea:	4781                	li	a5,0
    4bec:	e619                	bnez	a2,4bfa <__ltostr+0x2c>
    4bee:	03000793          	li	a5,48
    4bf2:	fef58fa3          	sb	a5,-1(a1)
    4bf6:	15fd                	addi	a1,a1,-1
    4bf8:	4785                	li	a5,1
    4bfa:	02700313          	li	t1,39
    4bfe:	c311                	beqz	a4,4c02 <__ltostr+0x34>
    4c00:	431d                	li	t1,7
    4c02:	0ff37713          	zext.b	a4,t1
    4c06:	03900293          	li	t0,57
    4c0a:	00f58333          	add	t1,a1,a5
    4c0e:	40b30433          	sub	s0,t1,a1
    4c12:	00b57363          	bgeu	a0,a1,4c18 <__ltostr+0x4a>
    4c16:	ea11                	bnez	a2,4c2a <__ltostr+0x5c>
    4c18:	00140613          	addi	a2,s0,1
    4c1c:	041000ef          	jal	545c <memmove>
    4c20:	8522                	mv	a0,s0
    4c22:	40a2                	lw	ra,8(sp)
    4c24:	4412                	lw	s0,4(sp)
    4c26:	0131                	addi	sp,sp,12
    4c28:	8082                	ret
    4c2a:	02d677b3          	remu	a5,a2,a3
    4c2e:	15fd                	addi	a1,a1,-1
    4c30:	03078793          	addi	a5,a5,48 # fff80030 <__heap_end+0xdff50030>
    4c34:	0ff7f793          	zext.b	a5,a5
    4c38:	00f2e763          	bltu	t0,a5,4c46 <__ltostr+0x78>
    4c3c:	00f58023          	sb	a5,0(a1)
    4c40:	02d65633          	divu	a2,a2,a3
    4c44:	b7e9                	j	4c0e <__ltostr+0x40>
    4c46:	97ba                	add	a5,a5,a4
    4c48:	bfd5                	j	4c3c <__ltostr+0x6e>

00004c4a <putchar>:
    4c4a:	0201a783          	lw	a5,32(gp) # 20000508 <_impure_ptr>
    4c4e:	1151                	addi	sp,sp,-12
    4c50:	c406                	sw	ra,8(sp)
    4c52:	478c                	lw	a1,8(a5)
    4c54:	3dfd                	jal	4b52 <putc>
    4c56:	40a2                	lw	ra,8(sp)
    4c58:	4501                	li	a0,0
    4c5a:	0131                	addi	sp,sp,12
    4c5c:	8082                	ret

00004c5e <puts>:
    4c5e:	1151                	addi	sp,sp,-12
    4c60:	c222                	sw	s0,4(sp)
    4c62:	c406                	sw	ra,8(sp)
    4c64:	842a                	mv	s0,a0
    4c66:	00044503          	lbu	a0,0(s0)
    4c6a:	55fd                	li	a1,-1
    4c6c:	e909                	bnez	a0,4c7e <puts+0x20>
    4c6e:	4529                	li	a0,10
    4c70:	83ffe0ef          	jal	34ae <fputc>
    4c74:	40a2                	lw	ra,8(sp)
    4c76:	4412                	lw	s0,4(sp)
    4c78:	4501                	li	a0,0
    4c7a:	0131                	addi	sp,sp,12
    4c7c:	8082                	ret
    4c7e:	831fe0ef          	jal	34ae <fputc>
    4c82:	0405                	addi	s0,s0,1
    4c84:	b7cd                	j	4c66 <puts+0x8>

00004c86 <write_pad>:
    4c86:	1131                	addi	sp,sp,-20
    4c88:	fd060613          	addi	a2,a2,-48
    4c8c:	c426                	sw	s1,8(sp)
    4c8e:	00163613          	seqz	a2,a2
    4c92:	649d                	lui	s1,0x7
    4c94:	0612                	slli	a2,a2,0x4
    4c96:	86048493          	addi	s1,s1,-1952 # 6860 <pad_line>
    4c9a:	c622                	sw	s0,12(sp)
    4c9c:	c806                	sw	ra,16(sp)
    4c9e:	87aa                	mv	a5,a0
    4ca0:	872e                	mv	a4,a1
    4ca2:	94b2                	add	s1,s1,a2
    4ca4:	842e                	mv	s0,a1
    4ca6:	463d                	li	a2,15
    4ca8:	408706b3          	sub	a3,a4,s0
    4cac:	02864263          	blt	a2,s0,4cd0 <write_pad+0x4a>
    4cb0:	00805a63          	blez	s0,4cc4 <write_pad+0x3e>
    4cb4:	43d8                	lw	a4,4(a5)
    4cb6:	4390                	lw	a2,0(a5)
    4cb8:	85a2                	mv	a1,s0
    4cba:	8526                	mv	a0,s1
    4cbc:	c036                	sw	a3,0(sp)
    4cbe:	9702                	jalr	a4
    4cc0:	4682                	lw	a3,0(sp)
    4cc2:	96a2                	add	a3,a3,s0
    4cc4:	40c2                	lw	ra,16(sp)
    4cc6:	4432                	lw	s0,12(sp)
    4cc8:	44a2                	lw	s1,8(sp)
    4cca:	8536                	mv	a0,a3
    4ccc:	0151                	addi	sp,sp,20
    4cce:	8082                	ret
    4cd0:	43d4                	lw	a3,4(a5)
    4cd2:	4390                	lw	a2,0(a5)
    4cd4:	45c1                	li	a1,16
    4cd6:	8526                	mv	a0,s1
    4cd8:	c23a                	sw	a4,4(sp)
    4cda:	c03e                	sw	a5,0(sp)
    4cdc:	9682                	jalr	a3
    4cde:	1441                	addi	s0,s0,-16
    4ce0:	4712                	lw	a4,4(sp)
    4ce2:	4782                	lw	a5,0(sp)
    4ce4:	b7c9                	j	4ca6 <write_pad+0x20>

00004ce6 <__v_printf>:
    4ce6:	0bc1a783          	lw	a5,188(gp) # 200005a4 <errno>
    4cea:	f2810113          	addi	sp,sp,-216
    4cee:	c9a2                	sw	s0,208(sp)
    4cf0:	c7a6                	sw	s1,204(sp)
    4cf2:	cb86                	sw	ra,212(sp)
    4cf4:	84aa                	mv	s1,a0
    4cf6:	c82e                	sw	a1,16(sp)
    4cf8:	8432                	mv	s0,a2
    4cfa:	d83e                	sw	a5,48(sp)
    4cfc:	c202                	sw	zero,4(sp)
    4cfe:	47c2                	lw	a5,16(sp)
    4d00:	0007c783          	lbu	a5,0(a5)
    4d04:	66078663          	beqz	a5,5370 <__v_printf+0x68a>
    4d08:	4701                	li	a4,0
    4d0a:	02500613          	li	a2,37
    4d0e:	a011                	j	4d12 <__v_printf+0x2c>
    4d10:	0705                	addi	a4,a4,1
    4d12:	47c2                	lw	a5,16(sp)
    4d14:	97ba                	add	a5,a5,a4
    4d16:	0007c683          	lbu	a3,0(a5)
    4d1a:	72068c63          	beqz	a3,5452 <__v_printf+0x76c>
    4d1e:	fec699e3          	bne	a3,a2,4d10 <__v_printf+0x2a>
    4d22:	e319                	bnez	a4,4d28 <__v_printf+0x42>
    4d24:	47c2                	lw	a5,16(sp)
    4d26:	a01d                	j	4d4c <__v_printf+0x66>
    4d28:	40d4                	lw	a3,4(s1)
    4d2a:	4090                	lw	a2,0(s1)
    4d2c:	4542                	lw	a0,16(sp)
    4d2e:	85ba                	mv	a1,a4
    4d30:	c43e                	sw	a5,8(sp)
    4d32:	c03a                	sw	a4,0(sp)
    4d34:	9682                	jalr	a3
    4d36:	4792                	lw	a5,4(sp)
    4d38:	4702                	lw	a4,0(sp)
    4d3a:	97ba                	add	a5,a5,a4
    4d3c:	c23e                	sw	a5,4(sp)
    4d3e:	47a2                	lw	a5,8(sp)
    4d40:	02500713          	li	a4,37
    4d44:	0007c683          	lbu	a3,0(a5)
    4d48:	70e69863          	bne	a3,a4,5458 <__v_printf+0x772>
    4d4c:	00178513          	addi	a0,a5,1
    4d50:	02000793          	li	a5,32
    4d54:	c002                	sw	zero,0(sp)
    4d56:	c602                	sw	zero,12(sp)
    4d58:	4701                	li	a4,0
    4d5a:	ca02                	sw	zero,20(sp)
    4d5c:	ce02                	sw	zero,28(sp)
    4d5e:	d602                	sw	zero,44(sp)
    4d60:	d002                	sw	zero,32(sp)
    4d62:	c402                	sw	zero,8(sp)
    4d64:	cc3e                	sw	a5,24(sp)
    4d66:	00054303          	lbu	t1,0(a0)
    4d6a:	00150793          	addi	a5,a0,1
    4d6e:	c83e                	sw	a5,16(sp)
    4d70:	046103a3          	sb	t1,71(sp)
    4d74:	06300793          	li	a5,99
    4d78:	1cf30963          	beq	t1,a5,4f4a <__v_printf+0x264>
    4d7c:	0c67e863          	bltu	a5,t1,4e4c <__v_printf+0x166>
    4d80:	02d00793          	li	a5,45
    4d84:	02f30363          	beq	t1,a5,4daa <__v_printf+0xc4>
    4d88:	0667e263          	bltu	a5,t1,4dec <__v_printf+0x106>
    4d8c:	02300793          	li	a5,35
    4d90:	02f30163          	beq	t1,a5,4db2 <__v_printf+0xcc>
    4d94:	0267e663          	bltu	a5,t1,4dc0 <__v_printf+0xda>
    4d98:	5c030a63          	beqz	t1,536c <__v_printf+0x686>
    4d9c:	02000793          	li	a5,32
    4da0:	f4f31fe3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4da4:	4785                	li	a5,1
    4da6:	d63e                	sw	a5,44(sp)
    4da8:	a019                	j	4dae <__v_printf+0xc8>
    4daa:	4785                	li	a5,1
    4dac:	d03e                	sw	a5,32(sp)
    4dae:	4542                	lw	a0,16(sp)
    4db0:	bf5d                	j	4d66 <__v_printf+0x80>
    4db2:	0ff00793          	li	a5,255
    4db6:	c43e                	sw	a5,8(sp)
    4db8:	bfdd                	j	4dae <__v_printf+0xc8>
    4dba:	4785                	li	a5,1
    4dbc:	ce3e                	sw	a5,28(sp)
    4dbe:	bfc5                	j	4dae <__v_printf+0xc8>
    4dc0:	02a00793          	li	a5,42
    4dc4:	16f30163          	beq	t1,a5,4f26 <__v_printf+0x240>
    4dc8:	02b00793          	li	a5,43
    4dcc:	fef307e3          	beq	t1,a5,4dba <__v_printf+0xd4>
    4dd0:	02500793          	li	a5,37
    4dd4:	f2f315e3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4dd8:	40dc                	lw	a5,4(s1)
    4dda:	4090                	lw	a2,0(s1)
    4ddc:	4585                	li	a1,1
    4dde:	04710513          	addi	a0,sp,71
    4de2:	9782                	jalr	a5
    4de4:	4792                	lw	a5,4(sp)
    4de6:	0785                	addi	a5,a5,1
    4de8:	c23e                	sw	a5,4(sp)
    4dea:	bf11                	j	4cfe <__v_printf+0x18>
    4dec:	03900793          	li	a5,57
    4df0:	0267ee63          	bltu	a5,t1,4e2c <__v_printf+0x146>
    4df4:	03000793          	li	a5,48
    4df8:	0ef37f63          	bgeu	t1,a5,4ef6 <__v_printf+0x210>
    4dfc:	02e00793          	li	a5,46
    4e00:	eef31fe3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4e04:	00154683          	lbu	a3,1(a0)
    4e08:	02a00793          	li	a5,42
    4e0c:	12f69163          	bne	a3,a5,4f2e <__v_printf+0x248>
    4e10:	4014                	lw	a3,0(s0)
    4e12:	00440793          	addi	a5,s0,4
    4e16:	c036                	sw	a3,0(sp)
    4e18:	0006d363          	bgez	a3,4e1e <__v_printf+0x138>
    4e1c:	c002                	sw	zero,0(sp)
    4e1e:	00250693          	addi	a3,a0,2
    4e22:	c836                	sw	a3,16(sp)
    4e24:	843e                	mv	s0,a5
    4e26:	4785                	li	a5,1
    4e28:	ca3e                	sw	a5,20(sp)
    4e2a:	b751                	j	4dae <__v_printf+0xc8>
    4e2c:	05800793          	li	a5,88
    4e30:	28f30f63          	beq	t1,a5,50ce <__v_printf+0x3e8>
    4e34:	06200793          	li	a5,98
    4e38:	34f30f63          	beq	t1,a5,5196 <__v_printf+0x4b0>
    4e3c:	04c00793          	li	a5,76
    4e40:	eaf31fe3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4e44:	0705                	addi	a4,a4,1
    4e46:	0762                	slli	a4,a4,0x18
    4e48:	8761                	srai	a4,a4,0x18
    4e4a:	a091                	j	4e8e <__v_printf+0x1a8>
    4e4c:	06d00793          	li	a5,109
    4e50:	10f30263          	beq	t1,a5,4f54 <__v_printf+0x26e>
    4e54:	0267ef63          	bltu	a5,t1,4e92 <__v_printf+0x1ac>
    4e58:	06700793          	li	a5,103
    4e5c:	0067ef63          	bltu	a5,t1,4e7a <__v_printf+0x194>
    4e60:	06600793          	li	a5,102
    4e64:	3cf37d63          	bgeu	t1,a5,523e <__v_printf+0x558>
    4e68:	06400793          	li	a5,100
    4e6c:	e8f319e3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4e70:	4529                	li	a0,10
    4e72:	4781                	li	a5,0
    4e74:	4285                	li	t0,1
    4e76:	4301                	li	t1,0
    4e78:	a471                	j	5104 <__v_printf+0x41e>
    4e7a:	06900793          	li	a5,105
    4e7e:	fef309e3          	beq	t1,a5,4e70 <__v_printf+0x18a>
    4e82:	06f36663          	bltu	t1,a5,4eee <__v_printf+0x208>
    4e86:	06c00793          	li	a5,108
    4e8a:	e6f31ae3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4e8e:	0705                	addi	a4,a4,1
    4e90:	a085                	j	4ef0 <__v_printf+0x20a>
    4e92:	07300793          	li	a5,115
    4e96:	0ef30163          	beq	t1,a5,4f78 <__v_printf+0x292>
    4e9a:	0267ec63          	bltu	a5,t1,4ed2 <__v_printf+0x1ec>
    4e9e:	07000793          	li	a5,112
    4ea2:	20f30f63          	beq	t1,a5,50c0 <__v_printf+0x3da>
    4ea6:	07100793          	li	a5,113
    4eaa:	f8f30de3          	beq	t1,a5,4e44 <__v_printf+0x15e>
    4eae:	06f00793          	li	a5,111
    4eb2:	e4f316e3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4eb6:	47a2                	lw	a5,8(sp)
    4eb8:	2e078363          	beqz	a5,519e <__v_printf+0x4b8>
    4ebc:	03000793          	li	a5,48
    4ec0:	04f106a3          	sb	a5,77(sp)
    4ec4:	4785                	li	a5,1
    4ec6:	c43e                	sw	a5,8(sp)
    4ec8:	4521                	li	a0,8
    4eca:	4781                	li	a5,0
    4ecc:	4281                	li	t0,0
    4ece:	4305                	li	t1,1
    4ed0:	ac15                	j	5104 <__v_printf+0x41e>
    4ed2:	07800793          	li	a5,120
    4ed6:	2af30e63          	beq	t1,a5,5192 <__v_printf+0x4ac>
    4eda:	07a00793          	li	a5,122
    4ede:	ecf308e3          	beq	t1,a5,4dae <__v_printf+0xc8>
    4ee2:	07500793          	li	a5,117
    4ee6:	e0f31ce3          	bne	t1,a5,4cfe <__v_printf+0x18>
    4eea:	4529                	li	a0,10
    4eec:	a475                	j	5198 <__v_printf+0x4b2>
    4eee:	177d                	addi	a4,a4,-1
    4ef0:	0762                	slli	a4,a4,0x18
    4ef2:	8761                	srai	a4,a4,0x18
    4ef4:	bd6d                	j	4dae <__v_printf+0xc8>
    4ef6:	47d2                	lw	a5,20(sp)
    4ef8:	c83a                	sw	a4,16(sp)
    4efa:	46079963          	bnez	a5,536c <__v_printf+0x686>
    4efe:	4629                	li	a2,10
    4f00:	00ac                	addi	a1,sp,72
    4f02:	6b1000ef          	jal	5db2 <strtoul>
    4f06:	04714683          	lbu	a3,71(sp)
    4f0a:	c62a                	sw	a0,12(sp)
    4f0c:	03000793          	li	a5,48
    4f10:	4742                	lw	a4,16(sp)
    4f12:	00f69763          	bne	a3,a5,4f20 <__v_printf+0x23a>
    4f16:	5782                	lw	a5,32(sp)
    4f18:	e781                	bnez	a5,4f20 <__v_printf+0x23a>
    4f1a:	03000793          	li	a5,48
    4f1e:	cc3e                	sw	a5,24(sp)
    4f20:	47a6                	lw	a5,72(sp)
    4f22:	c83e                	sw	a5,16(sp)
    4f24:	b569                	j	4dae <__v_printf+0xc8>
    4f26:	401c                	lw	a5,0(s0)
    4f28:	0411                	addi	s0,s0,4
    4f2a:	c63e                	sw	a5,12(sp)
    4f2c:	b549                	j	4dae <__v_printf+0xc8>
    4f2e:	4542                	lw	a0,16(sp)
    4f30:	4629                	li	a2,10
    4f32:	00ac                	addi	a1,sp,72
    4f34:	ca3a                	sw	a4,20(sp)
    4f36:	4ff000ef          	jal	5c34 <strtol>
    4f3a:	c02a                	sw	a0,0(sp)
    4f3c:	4752                	lw	a4,20(sp)
    4f3e:	00055363          	bgez	a0,4f44 <__v_printf+0x25e>
    4f42:	c002                	sw	zero,0(sp)
    4f44:	47a6                	lw	a5,72(sp)
    4f46:	c83e                	sw	a5,16(sp)
    4f48:	bdf9                	j	4e26 <__v_printf+0x140>
    4f4a:	401c                	lw	a5,0(s0)
    4f4c:	0411                	addi	s0,s0,4
    4f4e:	04f103a3          	sb	a5,71(sp)
    4f52:	b559                	j	4dd8 <__v_printf+0xf2>
    4f54:	5542                	lw	a0,48(sp)
    4f56:	2d7000ef          	jal	5a2c <strerror>
    4f5a:	c4aa                	sw	a0,72(sp)
    4f5c:	c42a                	sw	a0,8(sp)
    4f5e:	2df000ef          	jal	5a3c <strlen>
    4f62:	4722                	lw	a4,8(sp)
    4f64:	40d4                	lw	a3,4(s1)
    4f66:	4090                	lw	a2,0(s1)
    4f68:	85aa                	mv	a1,a0
    4f6a:	c02a                	sw	a0,0(sp)
    4f6c:	853a                	mv	a0,a4
    4f6e:	9682                	jalr	a3
    4f70:	4712                	lw	a4,4(sp)
    4f72:	4782                	lw	a5,0(sp)
    4f74:	97ba                	add	a5,a5,a4
    4f76:	bd8d                	j	4de8 <__v_printf+0x102>
    4f78:	4018                	lw	a4,0(s0)
    4f7a:	00440793          	addi	a5,s0,4
    4f7e:	c721                	beqz	a4,4fc6 <__v_printf+0x2e0>
    4f80:	c4ba                	sw	a4,72(sp)
    4f82:	4526                	lw	a0,72(sp)
    4f84:	cc3e                	sw	a5,24(sp)
    4f86:	2b7000ef          	jal	5a3c <strlen>
    4f8a:	4752                	lw	a4,20(sp)
    4f8c:	832a                	mv	t1,a0
    4f8e:	47e2                	lw	a5,24(sp)
    4f90:	cf1d                	beqz	a4,4fce <__v_printf+0x2e8>
    4f92:	4702                	lw	a4,0(sp)
    4f94:	00a77363          	bgeu	a4,a0,4f9a <__v_printf+0x2b4>
    4f98:	833a                	mv	t1,a4
    4f9a:	843e                	mv	s0,a5
    4f9c:	c002                	sw	zero,0(sp)
    4f9e:	ca02                	sw	zero,20(sp)
    4fa0:	4281                	li	t0,0
    4fa2:	02000793          	li	a5,32
    4fa6:	cc3e                	sw	a5,24(sp)
    4fa8:	47b2                	lw	a5,12(sp)
    4faa:	4702                	lw	a4,0(sp)
    4fac:	46a6                	lw	a3,72(sp)
    4fae:	8fd9                	or	a5,a5,a4
    4fb0:	e39d                	bnez	a5,4fd6 <__v_printf+0x2f0>
    4fb2:	40dc                	lw	a5,4(s1)
    4fb4:	4090                	lw	a2,0(s1)
    4fb6:	859a                	mv	a1,t1
    4fb8:	8536                	mv	a0,a3
    4fba:	c01a                	sw	t1,0(sp)
    4fbc:	9782                	jalr	a5
    4fbe:	4792                	lw	a5,4(sp)
    4fc0:	4302                	lw	t1,0(sp)
    4fc2:	979a                	add	a5,a5,t1
    4fc4:	b515                	j	4de8 <__v_printf+0x102>
    4fc6:	6719                	lui	a4,0x6
    4fc8:	11c70713          	addi	a4,a4,284 # 611c <sg_timer_config+0x18c>
    4fcc:	bf55                	j	4f80 <__v_printf+0x29a>
    4fce:	843e                	mv	s0,a5
    4fd0:	4281                	li	t0,0
    4fd2:	c002                	sw	zero,0(sp)
    4fd4:	b7f9                	j	4fa2 <__v_printf+0x2bc>
    4fd6:	42029563          	bnez	t0,5400 <__v_printf+0x71a>
    4fda:	47a2                	lw	a5,8(sp)
    4fdc:	3a078163          	beqz	a5,537e <__v_printf+0x698>
    4fe0:	47a2                	lw	a5,8(sp)
    4fe2:	00f68733          	add	a4,a3,a5
    4fe6:	c4ba                	sw	a4,72(sp)
    4fe8:	4732                	lw	a4,12(sp)
    4fea:	40f30333          	sub	t1,t1,a5
    4fee:	8f1d                	sub	a4,a4,a5
    4ff0:	c63a                	sw	a4,12(sp)
    4ff2:	5702                	lw	a4,32(sp)
    4ff4:	38070963          	beqz	a4,5386 <__v_printf+0x6a0>
    4ff8:	40d8                	lw	a4,4(s1)
    4ffa:	4090                	lw	a2,0(s1)
    4ffc:	85be                	mv	a1,a5
    4ffe:	8536                	mv	a0,a3
    5000:	ca1a                	sw	t1,20(sp)
    5002:	c43e                	sw	a5,8(sp)
    5004:	9702                	jalr	a4
    5006:	4712                	lw	a4,4(sp)
    5008:	47a2                	lw	a5,8(sp)
    500a:	4352                	lw	t1,20(sp)
    500c:	97ba                	add	a5,a5,a4
    500e:	c23e                	sw	a5,4(sp)
    5010:	4782                	lw	a5,0(sp)
    5012:	03000613          	li	a2,48
    5016:	8526                	mv	a0,s1
    5018:	406785b3          	sub	a1,a5,t1
    501c:	ca1a                	sw	t1,20(sp)
    501e:	31a5                	jal	4c86 <write_pad>
    5020:	4792                	lw	a5,4(sp)
    5022:	4352                	lw	t1,20(sp)
    5024:	40d8                	lw	a4,4(s1)
    5026:	97aa                	add	a5,a5,a0
    5028:	4090                	lw	a2,0(s1)
    502a:	4526                	lw	a0,72(sp)
    502c:	859a                	mv	a1,t1
    502e:	c43e                	sw	a5,8(sp)
    5030:	c21a                	sw	t1,4(sp)
    5032:	9702                	jalr	a4
    5034:	4312                	lw	t1,4(sp)
    5036:	47a2                	lw	a5,8(sp)
    5038:	4582                	lw	a1,0(sp)
    503a:	979a                	add	a5,a5,t1
    503c:	0065f363          	bgeu	a1,t1,5042 <__v_printf+0x35c>
    5040:	859a                	mv	a1,t1
    5042:	c03e                	sw	a5,0(sp)
    5044:	47b2                	lw	a5,12(sp)
    5046:	02000613          	li	a2,32
    504a:	8526                	mv	a0,s1
    504c:	40b785b3          	sub	a1,a5,a1
    5050:	391d                	jal	4c86 <write_pad>
    5052:	4782                	lw	a5,0(sp)
    5054:	97aa                	add	a5,a5,a0
    5056:	bb49                	j	4de8 <__v_printf+0x102>
    5058:	c78d                	beqz	a5,5082 <__v_printf+0x39c>
    505a:	4662                	lw	a2,24(sp)
    505c:	03000713          	li	a4,48
    5060:	02e61163          	bne	a2,a4,5082 <__v_printf+0x39c>
    5064:	40d8                	lw	a4,4(s1)
    5066:	4090                	lw	a2,0(s1)
    5068:	85be                	mv	a1,a5
    506a:	8536                	mv	a0,a3
    506c:	ca1a                	sw	t1,20(sp)
    506e:	c43e                	sw	a5,8(sp)
    5070:	c036                	sw	a3,0(sp)
    5072:	9702                	jalr	a4
    5074:	4712                	lw	a4,4(sp)
    5076:	47a2                	lw	a5,8(sp)
    5078:	4352                	lw	t1,20(sp)
    507a:	4682                	lw	a3,0(sp)
    507c:	97ba                	add	a5,a5,a4
    507e:	c23e                	sw	a5,4(sp)
    5080:	4781                	li	a5,0
    5082:	c43e                	sw	a5,8(sp)
    5084:	47b2                	lw	a5,12(sp)
    5086:	4662                	lw	a2,24(sp)
    5088:	8526                	mv	a0,s1
    508a:	406785b3          	sub	a1,a5,t1
    508e:	c01a                	sw	t1,0(sp)
    5090:	ca36                	sw	a3,20(sp)
    5092:	3ed5                	jal	4c86 <write_pad>
    5094:	4792                	lw	a5,4(sp)
    5096:	4302                	lw	t1,0(sp)
    5098:	00a78733          	add	a4,a5,a0
    509c:	47a2                	lw	a5,8(sp)
    509e:	34078563          	beqz	a5,53e8 <__v_printf+0x702>
    50a2:	46d2                	lw	a3,20(sp)
    50a4:	0044a383          	lw	t2,4(s1)
    50a8:	4090                	lw	a2,0(s1)
    50aa:	85be                	mv	a1,a5
    50ac:	8536                	mv	a0,a3
    50ae:	c41a                	sw	t1,8(sp)
    50b0:	c23a                	sw	a4,4(sp)
    50b2:	c03e                	sw	a5,0(sp)
    50b4:	9382                	jalr	t2
    50b6:	4782                	lw	a5,0(sp)
    50b8:	4712                	lw	a4,4(sp)
    50ba:	4322                	lw	t1,8(sp)
    50bc:	973e                	add	a4,a4,a5
    50be:	a62d                	j	53e8 <__v_printf+0x702>
    50c0:	07800793          	li	a5,120
    50c4:	04f103a3          	sb	a5,71(sp)
    50c8:	4789                	li	a5,2
    50ca:	4705                	li	a4,1
    50cc:	c43e                	sw	a5,8(sp)
    50ce:	04714783          	lbu	a5,71(sp)
    50d2:	fa878793          	addi	a5,a5,-88
    50d6:	0017b793          	seqz	a5,a5
    50da:	46a2                	lw	a3,8(sp)
    50dc:	4301                	li	t1,0
    50de:	ce81                	beqz	a3,50f6 <__v_printf+0x410>
    50e0:	03000693          	li	a3,48
    50e4:	04d106a3          	sb	a3,77(sp)
    50e8:	04714683          	lbu	a3,71(sp)
    50ec:	4309                	li	t1,2
    50ee:	04d10723          	sb	a3,78(sp)
    50f2:	4689                	li	a3,2
    50f4:	c436                	sw	a3,8(sp)
    50f6:	46b2                	lw	a3,12(sp)
    50f8:	4602                	lw	a2,0(sp)
    50fa:	00c6f363          	bgeu	a3,a2,5100 <__v_printf+0x41a>
    50fe:	c632                	sw	a2,12(sp)
    5100:	4541                	li	a0,16
    5102:	4281                	li	t0,0
    5104:	04d10693          	addi	a3,sp,77
    5108:	c4b6                	sw	a3,72(sp)
    510a:	0ae05963          	blez	a4,51bc <__v_printf+0x4d6>
    510e:	4685                	li	a3,1
    5110:	08d70b63          	beq	a4,a3,51a6 <__v_printf+0x4c0>
    5114:	00840393          	addi	t2,s0,8
    5118:	4010                	lw	a2,0(s0)
    511a:	4054                	lw	a3,4(s0)
    511c:	4581                	li	a1,0
    511e:	08028b63          	beqz	t0,51b4 <__v_printf+0x4ce>
    5122:	0006da63          	bgez	a3,5136 <__v_printf+0x450>
    5126:	40c00633          	neg	a2,a2
    512a:	00c03733          	snez	a4,a2
    512e:	40d006b3          	neg	a3,a3
    5132:	8e99                	sub	a3,a3,a4
    5134:	4289                	li	t0,2
    5136:	872a                	mv	a4,a0
    5138:	04d10513          	addi	a0,sp,77
    513c:	951a                	add	a0,a0,t1
    513e:	07b00593          	li	a1,123
    5142:	da1e                	sw	t2,52(sp)
    5144:	d416                	sw	t0,40(sp)
    5146:	d21a                	sw	t1,36(sp)
    5148:	3205                	jal	4a68 <__lltostr>
    514a:	53d2                	lw	t2,52(sp)
    514c:	5312                	lw	t1,36(sp)
    514e:	52a2                	lw	t0,40(sp)
    5150:	841e                	mv	s0,t2
    5152:	4752                	lw	a4,20(sp)
    5154:	47a6                	lw	a5,72(sp)
    5156:	cb55                	beqz	a4,520a <__v_printf+0x524>
    5158:	4705                	li	a4,1
    515a:	0ae51863          	bne	a0,a4,520a <__v_printf+0x524>
    515e:	00678733          	add	a4,a5,t1
    5162:	00074683          	lbu	a3,0(a4)
    5166:	03000713          	li	a4,48
    516a:	0ae69063          	bne	a3,a4,520a <__v_printf+0x524>
    516e:	4702                	lw	a4,0(sp)
    5170:	cf59                	beqz	a4,520e <__v_printf+0x528>
    5172:	4722                	lw	a4,8(sp)
    5174:	c319                	beqz	a4,517a <__v_printf+0x494>
    5176:	c402                	sw	zero,8(sp)
    5178:	4301                	li	t1,0
    517a:	4709                	li	a4,2
    517c:	08e29c63          	bne	t0,a4,5214 <__v_printf+0x52e>
    5180:	fff78713          	addi	a4,a5,-1
    5184:	c4ba                	sw	a4,72(sp)
    5186:	02d00713          	li	a4,45
    518a:	fee78fa3          	sb	a4,-1(a5)
    518e:	0305                	addi	t1,t1,1
    5190:	bd21                	j	4fa8 <__v_printf+0x2c2>
    5192:	4781                	li	a5,0
    5194:	b799                	j	50da <__v_printf+0x3f4>
    5196:	4509                	li	a0,2
    5198:	4781                	li	a5,0
    519a:	4281                	li	t0,0
    519c:	b9e9                	j	4e76 <__v_printf+0x190>
    519e:	4781                	li	a5,0
    51a0:	4281                	li	t0,0
    51a2:	4521                	li	a0,8
    51a4:	b9c9                	j	4e76 <__v_printf+0x190>
    51a6:	00440393          	addi	t2,s0,4
    51aa:	400c                	lw	a1,0(s0)
    51ac:	00029d63          	bnez	t0,51c6 <__v_printf+0x4e0>
    51b0:	4601                	li	a2,0
    51b2:	4681                	li	a3,0
    51b4:	4405                	li	s0,1
    51b6:	f8e440e3          	blt	s0,a4,5136 <__v_printf+0x450>
    51ba:	a01d                	j	51e0 <__v_printf+0x4fa>
    51bc:	00440393          	addi	t2,s0,4
    51c0:	400c                	lw	a1,0(s0)
    51c2:	00028863          	beqz	t0,51d2 <__v_printf+0x4ec>
    51c6:	4285                	li	t0,1
    51c8:	0005d563          	bgez	a1,51d2 <__v_printf+0x4ec>
    51cc:	40b005b3          	neg	a1,a1
    51d0:	4289                	li	t0,2
    51d2:	fc075fe3          	bgez	a4,51b0 <__v_printf+0x4ca>
    51d6:	56fd                	li	a3,-1
    51d8:	02d70663          	beq	a4,a3,5204 <__v_printf+0x51e>
    51dc:	0ff5f593          	zext.b	a1,a1
    51e0:	873e                	mv	a4,a5
    51e2:	04d10793          	addi	a5,sp,77
    51e6:	86aa                	mv	a3,a0
    51e8:	862e                	mv	a2,a1
    51ea:	00678533          	add	a0,a5,t1
    51ee:	07b00593          	li	a1,123
    51f2:	da1e                	sw	t2,52(sp)
    51f4:	d416                	sw	t0,40(sp)
    51f6:	d21a                	sw	t1,36(sp)
    51f8:	3ad9                	jal	4bce <__ltostr>
    51fa:	53d2                	lw	t2,52(sp)
    51fc:	52a2                	lw	t0,40(sp)
    51fe:	5312                	lw	t1,36(sp)
    5200:	841e                	mv	s0,t2
    5202:	bf81                	j	5152 <__v_printf+0x46c>
    5204:	05c2                	slli	a1,a1,0x10
    5206:	81c1                	srli	a1,a1,0x10
    5208:	bfe1                	j	51e0 <__v_printf+0x4fa>
    520a:	932a                	add	t1,t1,a0
    520c:	b7bd                	j	517a <__v_printf+0x494>
    520e:	4301                	li	t1,0
    5210:	c402                	sw	zero,8(sp)
    5212:	b7a5                	j	517a <__v_printf+0x494>
    5214:	d8028ae3          	beqz	t0,4fa8 <__v_printf+0x2c2>
    5218:	4772                	lw	a4,28(sp)
    521a:	ef19                	bnez	a4,5238 <__v_printf+0x552>
    521c:	5732                	lw	a4,44(sp)
    521e:	4281                	li	t0,0
    5220:	d80704e3          	beqz	a4,4fa8 <__v_printf+0x2c2>
    5224:	02000713          	li	a4,32
    5228:	fff78693          	addi	a3,a5,-1
    522c:	c4b6                	sw	a3,72(sp)
    522e:	fee78fa3          	sb	a4,-1(a5)
    5232:	0305                	addi	t1,t1,1
    5234:	4285                	li	t0,1
    5236:	bb8d                	j	4fa8 <__v_printf+0x2c2>
    5238:	02b00713          	li	a4,43
    523c:	b7f5                	j	5228 <__v_printf+0x542>
    523e:	00840793          	addi	a5,s0,8
    5242:	da3e                	sw	a5,52(sp)
    5244:	401c                	lw	a5,0(s0)
    5246:	d23e                	sw	a5,36(sp)
    5248:	405c                	lw	a5,4(s0)
    524a:	d43e                	sw	a5,40(sp)
    524c:	04d10793          	addi	a5,sp,77
    5250:	c4be                	sw	a5,72(sp)
    5252:	47b2                	lw	a5,12(sp)
    5254:	e399                	bnez	a5,525a <__v_printf+0x574>
    5256:	4785                	li	a5,1
    5258:	c63e                	sw	a5,12(sp)
    525a:	47d2                	lw	a5,20(sp)
    525c:	e399                	bnez	a5,5262 <__v_printf+0x57c>
    525e:	4799                	li	a5,6
    5260:	c03e                	sw	a5,0(sp)
    5262:	42f2                	lw	t0,28(sp)
    5264:	00029e63          	bnez	t0,5280 <__v_printf+0x59a>
    5268:	5712                	lw	a4,36(sp)
    526a:	57a2                	lw	a5,40(sp)
    526c:	4601                	li	a2,0
    526e:	4681                	li	a3,0
    5270:	853a                	mv	a0,a4
    5272:	85be                	mv	a1,a5
    5274:	dc1a                	sw	t1,56(sp)
    5276:	a74fc0ef          	jal	14ea <__ledf2>
    527a:	5362                	lw	t1,56(sp)
    527c:	01f55293          	srli	t0,a0,0x1f
    5280:	5412                	lw	s0,36(sp)
    5282:	53a2                	lw	t2,40(sp)
    5284:	4782                	lw	a5,0(sp)
    5286:	4732                	lw	a4,12(sp)
    5288:	07f00693          	li	a3,127
    528c:	04d10613          	addi	a2,sp,77
    5290:	8522                	mv	a0,s0
    5292:	859e                	mv	a1,t2
    5294:	c096                	sw	t0,64(sp)
    5296:	dc1a                	sw	t1,56(sp)
    5298:	ba4ff0ef          	jal	463c <__dtostr>
    529c:	47d2                	lw	a5,20(sp)
    529e:	de2a                	sw	a0,60(sp)
    52a0:	5362                	lw	t1,56(sp)
    52a2:	4286                	lw	t0,64(sp)
    52a4:	cb8d                	beqz	a5,52d6 <__v_printf+0x5f0>
    52a6:	4426                	lw	s0,72(sp)
    52a8:	02e00593          	li	a1,46
    52ac:	dc16                	sw	t0,56(sp)
    52ae:	8522                	mv	a0,s0
    52b0:	ca1a                	sw	t1,20(sp)
    52b2:	245d                	jal	5558 <strchr>
    52b4:	4352                	lw	t1,20(sp)
    52b6:	52e2                	lw	t0,56(sp)
    52b8:	57f2                	lw	a5,60(sp)
    52ba:	c949                	beqz	a0,534c <__v_printf+0x666>
    52bc:	4782                	lw	a5,0(sp)
    52be:	e399                	bnez	a5,52c4 <__v_printf+0x5de>
    52c0:	47a2                	lw	a5,8(sp)
    52c2:	cb81                	beqz	a5,52d2 <__v_printf+0x5ec>
    52c4:	0505                	addi	a0,a0,1
    52c6:	4782                	lw	a5,0(sp)
    52c8:	c789                	beqz	a5,52d2 <__v_printf+0x5ec>
    52ca:	0505                	addi	a0,a0,1
    52cc:	00054783          	lbu	a5,0(a0)
    52d0:	ebb5                	bnez	a5,5344 <__v_printf+0x65e>
    52d2:	00050023          	sb	zero,0(a0)
    52d6:	06700793          	li	a5,103
    52da:	04f31763          	bne	t1,a5,5328 <__v_printf+0x642>
    52de:	4526                	lw	a0,72(sp)
    52e0:	02e00593          	li	a1,46
    52e4:	c416                	sw	t0,8(sp)
    52e6:	2c8d                	jal	5558 <strchr>
    52e8:	842a                	mv	s0,a0
    52ea:	42a2                	lw	t0,8(sp)
    52ec:	cd15                	beqz	a0,5328 <__v_printf+0x642>
    52ee:	06500593          	li	a1,101
    52f2:	249d                	jal	5558 <strchr>
    52f4:	42a2                	lw	t0,8(sp)
    52f6:	85aa                	mv	a1,a0
    52f8:	00044783          	lbu	a5,0(s0)
    52fc:	e7a5                	bnez	a5,5364 <__v_printf+0x67e>
    52fe:	c191                	beqz	a1,5302 <__v_printf+0x61c>
    5300:	842e                	mv	s0,a1
    5302:	03000693          	li	a3,48
    5306:	fff44703          	lbu	a4,-1(s0)
    530a:	fff40513          	addi	a0,s0,-1
    530e:	04d70d63          	beq	a4,a3,5368 <__v_printf+0x682>
    5312:	02e00693          	li	a3,46
    5316:	00d70363          	beq	a4,a3,531c <__v_printf+0x636>
    531a:	8522                	mv	a0,s0
    531c:	00050023          	sb	zero,0(a0)
    5320:	c581                	beqz	a1,5328 <__v_printf+0x642>
    5322:	c416                	sw	t0,8(sp)
    5324:	2635                	jal	5650 <strcpy>
    5326:	42a2                	lw	t0,8(sp)
    5328:	47f2                	lw	a5,28(sp)
    532a:	0e079f63          	bnez	a5,5428 <__v_printf+0x742>
    532e:	57b2                	lw	a5,44(sp)
    5330:	efe9                	bnez	a5,540a <__v_printf+0x724>
    5332:	4526                	lw	a0,72(sp)
    5334:	ce16                	sw	t0,28(sp)
    5336:	2719                	jal	5a3c <strlen>
    5338:	832a                	mv	t1,a0
    533a:	5452                	lw	s0,52(sp)
    533c:	ca02                	sw	zero,20(sp)
    533e:	c402                	sw	zero,8(sp)
    5340:	42f2                	lw	t0,28(sp)
    5342:	b19d                	j	4fa8 <__v_printf+0x2c2>
    5344:	4782                	lw	a5,0(sp)
    5346:	17fd                	addi	a5,a5,-1
    5348:	c03e                	sw	a5,0(sp)
    534a:	bfb5                	j	52c6 <__v_printf+0x5e0>
    534c:	4722                	lw	a4,8(sp)
    534e:	d741                	beqz	a4,52d6 <__v_printf+0x5f0>
    5350:	943e                	add	s0,s0,a5
    5352:	02e00713          	li	a4,46
    5356:	00e40023          	sb	a4,0(s0)
    535a:	4526                	lw	a0,72(sp)
    535c:	953e                	add	a0,a0,a5
    535e:	000500a3          	sb	zero,1(a0)
    5362:	bf95                	j	52d6 <__v_printf+0x5f0>
    5364:	0405                	addi	s0,s0,1
    5366:	bf49                	j	52f8 <__v_printf+0x612>
    5368:	842a                	mv	s0,a0
    536a:	bf71                	j	5306 <__v_printf+0x620>
    536c:	57fd                	li	a5,-1
    536e:	c23e                	sw	a5,4(sp)
    5370:	40de                	lw	ra,212(sp)
    5372:	444e                	lw	s0,208(sp)
    5374:	4512                	lw	a0,4(sp)
    5376:	44be                	lw	s1,204(sp)
    5378:	0d810113          	addi	sp,sp,216
    537c:	8082                	ret
    537e:	5782                	lw	a5,32(sp)
    5380:	c80798e3          	bnez	a5,5010 <__v_printf+0x32a>
    5384:	4781                	li	a5,0
    5386:	4752                	lw	a4,20(sp)
    5388:	cc0708e3          	beqz	a4,5058 <__v_printf+0x372>
    538c:	4582                	lw	a1,0(sp)
    538e:	0065f363          	bgeu	a1,t1,5394 <__v_printf+0x6ae>
    5392:	859a                	mv	a1,t1
    5394:	ca3e                	sw	a5,20(sp)
    5396:	47b2                	lw	a5,12(sp)
    5398:	02000613          	li	a2,32
    539c:	8526                	mv	a0,s1
    539e:	40b785b3          	sub	a1,a5,a1
    53a2:	c41a                	sw	t1,8(sp)
    53a4:	cc36                	sw	a3,24(sp)
    53a6:	30c5                	jal	4c86 <write_pad>
    53a8:	4792                	lw	a5,4(sp)
    53aa:	4322                	lw	t1,8(sp)
    53ac:	00f50733          	add	a4,a0,a5
    53b0:	47d2                	lw	a5,20(sp)
    53b2:	cf99                	beqz	a5,53d0 <__v_printf+0x6ea>
    53b4:	46e2                	lw	a3,24(sp)
    53b6:	0044a383          	lw	t2,4(s1)
    53ba:	4090                	lw	a2,0(s1)
    53bc:	85be                	mv	a1,a5
    53be:	8536                	mv	a0,a3
    53c0:	c61a                	sw	t1,12(sp)
    53c2:	c43a                	sw	a4,8(sp)
    53c4:	c23e                	sw	a5,4(sp)
    53c6:	9382                	jalr	t2
    53c8:	4792                	lw	a5,4(sp)
    53ca:	4722                	lw	a4,8(sp)
    53cc:	4332                	lw	t1,12(sp)
    53ce:	973e                	add	a4,a4,a5
    53d0:	4782                	lw	a5,0(sp)
    53d2:	03000613          	li	a2,48
    53d6:	8526                	mv	a0,s1
    53d8:	406785b3          	sub	a1,a5,t1
    53dc:	c23a                	sw	a4,4(sp)
    53de:	c01a                	sw	t1,0(sp)
    53e0:	305d                	jal	4c86 <write_pad>
    53e2:	4712                	lw	a4,4(sp)
    53e4:	4302                	lw	t1,0(sp)
    53e6:	972a                	add	a4,a4,a0
    53e8:	40dc                	lw	a5,4(s1)
    53ea:	4090                	lw	a2,0(s1)
    53ec:	4526                	lw	a0,72(sp)
    53ee:	859a                	mv	a1,t1
    53f0:	c23a                	sw	a4,4(sp)
    53f2:	c01a                	sw	t1,0(sp)
    53f4:	9782                	jalr	a5
    53f6:	4302                	lw	t1,0(sp)
    53f8:	4712                	lw	a4,4(sp)
    53fa:	006707b3          	add	a5,a4,t1
    53fe:	b2ed                	j	4de8 <__v_printf+0x102>
    5400:	47a2                	lw	a5,8(sp)
    5402:	bc079fe3          	bnez	a5,4fe0 <__v_printf+0x2fa>
    5406:	4785                	li	a5,1
    5408:	bee9                	j	4fe2 <__v_printf+0x2fc>
    540a:	57a2                	lw	a5,40(sp)
    540c:	5712                	lw	a4,36(sp)
    540e:	4601                	li	a2,0
    5410:	85be                	mv	a1,a5
    5412:	4681                	li	a3,0
    5414:	853a                	mv	a0,a4
    5416:	c416                	sw	t0,8(sp)
    5418:	82afc0ef          	jal	1442 <__gedf2>
    541c:	02000793          	li	a5,32
    5420:	42a2                	lw	t0,8(sp)
    5422:	02055163          	bgez	a0,5444 <__v_printf+0x75e>
    5426:	b731                	j	5332 <__v_printf+0x64c>
    5428:	5712                	lw	a4,36(sp)
    542a:	57a2                	lw	a5,40(sp)
    542c:	4601                	li	a2,0
    542e:	4681                	li	a3,0
    5430:	853a                	mv	a0,a4
    5432:	85be                	mv	a1,a5
    5434:	c416                	sw	t0,8(sp)
    5436:	80cfc0ef          	jal	1442 <__gedf2>
    543a:	42a2                	lw	t0,8(sp)
    543c:	ee054be3          	bltz	a0,5332 <__v_printf+0x64c>
    5440:	02b00793          	li	a5,43
    5444:	4726                	lw	a4,72(sp)
    5446:	fff70693          	addi	a3,a4,-1
    544a:	c4b6                	sw	a3,72(sp)
    544c:	fef70fa3          	sb	a5,-1(a4)
    5450:	b5cd                	j	5332 <__v_printf+0x64c>
    5452:	8c071be3          	bnez	a4,4d28 <__v_printf+0x42>
    5456:	47c2                	lw	a5,16(sp)
    5458:	c83e                	sw	a5,16(sp)
    545a:	b055                	j	4cfe <__v_printf+0x18>

0000545c <memmove>:
    545c:	02a5f263          	bgeu	a1,a0,5480 <memmove+0x24>
    5460:	00c58733          	add	a4,a1,a2
    5464:	00e57e63          	bgeu	a0,a4,5480 <memmove+0x24>
    5468:	00c507b3          	add	a5,a0,a2
    546c:	ce79                	beqz	a2,554a <memmove+0xee>
    546e:	fff74683          	lbu	a3,-1(a4)
    5472:	17fd                	addi	a5,a5,-1
    5474:	177d                	addi	a4,a4,-1
    5476:	00d78023          	sb	a3,0(a5)
    547a:	fef51ae3          	bne	a0,a5,546e <memmove+0x12>
    547e:	8082                	ret
    5480:	47bd                	li	a5,15
    5482:	02c7e163          	bltu	a5,a2,54a4 <memmove+0x48>
    5486:	87aa                	mv	a5,a0
    5488:	fff60693          	addi	a3,a2,-1
    548c:	ce5d                	beqz	a2,554a <memmove+0xee>
    548e:	0685                	addi	a3,a3,1
    5490:	96be                	add	a3,a3,a5
    5492:	0005c703          	lbu	a4,0(a1)
    5496:	0785                	addi	a5,a5,1
    5498:	0585                	addi	a1,a1,1
    549a:	fee78fa3          	sb	a4,-1(a5)
    549e:	fed79ae3          	bne	a5,a3,5492 <memmove+0x36>
    54a2:	8082                	ret
    54a4:	00b567b3          	or	a5,a0,a1
    54a8:	8b8d                	andi	a5,a5,3
    54aa:	82ae                	mv	t0,a1
    54ac:	e3c5                	bnez	a5,554c <memmove+0xf0>
    54ae:	ff060793          	addi	a5,a2,-16
    54b2:	ff07f313          	andi	t1,a5,-16
    54b6:	1171                	addi	sp,sp,-4
    54b8:	0341                	addi	t1,t1,16
    54ba:	c022                	sw	s0,0(sp)
    54bc:	932a                	add	t1,t1,a0
    54be:	872a                	mv	a4,a0
    54c0:	4194                	lw	a3,0(a1)
    54c2:	05c1                	addi	a1,a1,16
    54c4:	0741                	addi	a4,a4,16
    54c6:	fed72823          	sw	a3,-16(a4)
    54ca:	ff45a683          	lw	a3,-12(a1)
    54ce:	fed72a23          	sw	a3,-12(a4)
    54d2:	ff85a683          	lw	a3,-8(a1)
    54d6:	fed72c23          	sw	a3,-8(a4)
    54da:	ffc5a683          	lw	a3,-4(a1)
    54de:	fed72e23          	sw	a3,-4(a4)
    54e2:	fc671fe3          	bne	a4,t1,54c0 <memmove+0x64>
    54e6:	9bc1                	andi	a5,a5,-16
    54e8:	00578733          	add	a4,a5,t0
    54ec:	01070593          	addi	a1,a4,16
    54f0:	97aa                	add	a5,a5,a0
    54f2:	00c67313          	andi	t1,a2,12
    54f6:	07c1                	addi	a5,a5,16
    54f8:	842e                	mv	s0,a1
    54fa:	00f67693          	andi	a3,a2,15
    54fe:	04030b63          	beqz	t1,5554 <memmove+0xf8>
    5502:	16f1                	addi	a3,a3,-4
    5504:	9af1                	andi	a3,a3,-4
    5506:	9736                	add	a4,a4,a3
    5508:	0751                	addi	a4,a4,20
    550a:	405502b3          	sub	t0,a0,t0
    550e:	0005a383          	lw	t2,0(a1)
    5512:	00558333          	add	t1,a1,t0
    5516:	0591                	addi	a1,a1,4
    5518:	00732023          	sw	t2,0(t1)
    551c:	fee599e3          	bne	a1,a4,550e <memmove+0xb2>
    5520:	0691                	addi	a3,a3,4
    5522:	008685b3          	add	a1,a3,s0
    5526:	97b6                	add	a5,a5,a3
    5528:	8a0d                	andi	a2,a2,3
    552a:	fff60693          	addi	a3,a2,-1
    552e:	0685                	addi	a3,a3,1
    5530:	96be                	add	a3,a3,a5
    5532:	ca09                	beqz	a2,5544 <memmove+0xe8>
    5534:	0005c703          	lbu	a4,0(a1)
    5538:	0785                	addi	a5,a5,1
    553a:	0585                	addi	a1,a1,1
    553c:	fee78fa3          	sb	a4,-1(a5)
    5540:	fed79ae3          	bne	a5,a3,5534 <memmove+0xd8>
    5544:	4402                	lw	s0,0(sp)
    5546:	0111                	addi	sp,sp,4
    5548:	8082                	ret
    554a:	8082                	ret
    554c:	fff60693          	addi	a3,a2,-1
    5550:	87aa                	mv	a5,a0
    5552:	bf35                	j	548e <memmove+0x32>
    5554:	8636                	mv	a2,a3
    5556:	bfd1                	j	552a <memmove+0xce>

00005558 <strchr>:
    5558:	0ff5f693          	zext.b	a3,a1
    555c:	00357793          	andi	a5,a0,3
    5560:	cec9                	beqz	a3,55fa <strchr+0xa2>
    5562:	cb91                	beqz	a5,5576 <strchr+0x1e>
    5564:	00054783          	lbu	a5,0(a0)
    5568:	c7d9                	beqz	a5,55f6 <strchr+0x9e>
    556a:	08d78763          	beq	a5,a3,55f8 <strchr+0xa0>
    556e:	0505                	addi	a0,a0,1
    5570:	00357793          	andi	a5,a0,3
    5574:	fbe5                	bnez	a5,5564 <strchr+0xc>
    5576:	0ff5f593          	zext.b	a1,a1
    557a:	00859793          	slli	a5,a1,0x8
    557e:	4118                	lw	a4,0(a0)
    5580:	95be                	add	a1,a1,a5
    5582:	01059793          	slli	a5,a1,0x10
    5586:	95be                	add	a1,a1,a5
    5588:	feff0637          	lui	a2,0xfeff0
    558c:	00e5c7b3          	xor	a5,a1,a4
    5590:	eff60613          	addi	a2,a2,-257 # fefefeff <__heap_end+0xdefbfeff>
    5594:	fff7c313          	not	t1,a5
    5598:	00c782b3          	add	t0,a5,a2
    559c:	00c707b3          	add	a5,a4,a2
    55a0:	fff74713          	not	a4,a4
    55a4:	0062f2b3          	and	t0,t0,t1
    55a8:	8ff9                	and	a5,a5,a4
    55aa:	80808337          	lui	t1,0x80808
    55ae:	0057e7b3          	or	a5,a5,t0
    55b2:	08030313          	addi	t1,t1,128 # 80808080 <__heap_end+0x607d8080>
    55b6:	0067f7b3          	and	a5,a5,t1
    55ba:	eb9d                	bnez	a5,55f0 <strchr+0x98>
    55bc:	4158                	lw	a4,4(a0)
    55be:	0511                	addi	a0,a0,4
    55c0:	00b747b3          	xor	a5,a4,a1
    55c4:	fff7c393          	not	t2,a5
    55c8:	00c782b3          	add	t0,a5,a2
    55cc:	00c707b3          	add	a5,a4,a2
    55d0:	fff74713          	not	a4,a4
    55d4:	0053f2b3          	and	t0,t2,t0
    55d8:	8ff9                	and	a5,a5,a4
    55da:	0057e7b3          	or	a5,a5,t0
    55de:	0067f7b3          	and	a5,a5,t1
    55e2:	dfe9                	beqz	a5,55bc <strchr+0x64>
    55e4:	00054783          	lbu	a5,0(a0)
    55e8:	c799                	beqz	a5,55f6 <strchr+0x9e>
    55ea:	06f68163          	beq	a3,a5,564c <strchr+0xf4>
    55ee:	0505                	addi	a0,a0,1
    55f0:	00054783          	lbu	a5,0(a0)
    55f4:	fbfd                	bnez	a5,55ea <strchr+0x92>
    55f6:	4501                	li	a0,0
    55f8:	8082                	ret
    55fa:	cb81                	beqz	a5,560a <strchr+0xb2>
    55fc:	00054783          	lbu	a5,0(a0)
    5600:	dfe5                	beqz	a5,55f8 <strchr+0xa0>
    5602:	0505                	addi	a0,a0,1
    5604:	00357793          	andi	a5,a0,3
    5608:	fbf5                	bnez	a5,55fc <strchr+0xa4>
    560a:	4118                	lw	a4,0(a0)
    560c:	feff0637          	lui	a2,0xfeff0
    5610:	eff60613          	addi	a2,a2,-257 # fefefeff <__heap_end+0xdefbfeff>
    5614:	00c707b3          	add	a5,a4,a2
    5618:	808086b7          	lui	a3,0x80808
    561c:	fff74713          	not	a4,a4
    5620:	8ff9                	and	a5,a5,a4
    5622:	08068693          	addi	a3,a3,128 # 80808080 <__heap_end+0x607d8080>
    5626:	8ff5                	and	a5,a5,a3
    5628:	eb91                	bnez	a5,563c <strchr+0xe4>
    562a:	4158                	lw	a4,4(a0)
    562c:	0511                	addi	a0,a0,4
    562e:	00c707b3          	add	a5,a4,a2
    5632:	fff74713          	not	a4,a4
    5636:	8ff9                	and	a5,a5,a4
    5638:	8ff5                	and	a5,a5,a3
    563a:	dbe5                	beqz	a5,562a <strchr+0xd2>
    563c:	00054783          	lbu	a5,0(a0)
    5640:	dfc5                	beqz	a5,55f8 <strchr+0xa0>
    5642:	00154783          	lbu	a5,1(a0)
    5646:	0505                	addi	a0,a0,1
    5648:	ffed                	bnez	a5,5642 <strchr+0xea>
    564a:	8082                	ret
    564c:	8082                	ret
	...

00005650 <strcpy>:
    5650:	00b567b3          	or	a5,a0,a1
    5654:	8b8d                	andi	a5,a5,3
    5656:	efb9                	bnez	a5,56b4 <strcpy+0x64>
    5658:	4198                	lw	a4,0(a1)
    565a:	7f7f86b7          	lui	a3,0x7f7f8
    565e:	f7f68693          	addi	a3,a3,-129 # 7f7f7f7f <__heap_end+0x5f7c7f7f>
    5662:	00d77333          	and	t1,a4,a3
    5666:	9336                	add	t1,t1,a3
    5668:	00e36333          	or	t1,t1,a4
    566c:	00d36333          	or	t1,t1,a3
    5670:	57fd                	li	a5,-1
    5672:	862a                	mv	a2,a0
    5674:	00f31d63          	bne	t1,a5,568e <strcpy+0x3e>
    5678:	0591                	addi	a1,a1,4
    567a:	c218                	sw	a4,0(a2)
    567c:	4198                	lw	a4,0(a1)
    567e:	0611                	addi	a2,a2,4
    5680:	00d777b3          	and	a5,a4,a3
    5684:	97b6                	add	a5,a5,a3
    5686:	8fd9                	or	a5,a5,a4
    5688:	8fd5                	or	a5,a5,a3
    568a:	fe6787e3          	beq	a5,t1,5678 <strcpy+0x28>
    568e:	0005c783          	lbu	a5,0(a1)
    5692:	0015c703          	lbu	a4,1(a1)
    5696:	0025c683          	lbu	a3,2(a1)
    569a:	00f60023          	sb	a5,0(a2)
    569e:	c799                	beqz	a5,56ac <strcpy+0x5c>
    56a0:	00e600a3          	sb	a4,1(a2)
    56a4:	c701                	beqz	a4,56ac <strcpy+0x5c>
    56a6:	00d60123          	sb	a3,2(a2)
    56aa:	e291                	bnez	a3,56ae <strcpy+0x5e>
    56ac:	8082                	ret
    56ae:	000601a3          	sb	zero,3(a2)
    56b2:	8082                	ret
    56b4:	87aa                	mv	a5,a0
    56b6:	0005c703          	lbu	a4,0(a1)
    56ba:	0785                	addi	a5,a5,1
    56bc:	0585                	addi	a1,a1,1
    56be:	fee78fa3          	sb	a4,-1(a5)
    56c2:	fb75                	bnez	a4,56b6 <strcpy+0x66>
    56c4:	8082                	ret

000056c6 <_strerror_r>:
    56c6:	87ae                	mv	a5,a1
    56c8:	08e00713          	li	a4,142
    56cc:	85b2                	mv	a1,a2
    56ce:	00f76c63          	bltu	a4,a5,56e6 <_strerror_r+0x20>
    56d2:	00001617          	auipc	a2,0x1
    56d6:	1ae60613          	addi	a2,a2,430 # 6880 <pad_line+0x20>
    56da:	00279713          	slli	a4,a5,0x2
    56de:	9732                	add	a4,a4,a2
    56e0:	4318                	lw	a4,0(a4)
    56e2:	9732                	add	a4,a4,a2
    56e4:	8702                	jr	a4
    56e6:	1171                	addi	sp,sp,-4
    56e8:	c006                	sw	ra,0(sp)
    56ea:	32068f63          	beqz	a3,5a28 <_strerror_r+0x362>
    56ee:	8636                	mv	a2,a3
    56f0:	853e                	mv	a0,a5
    56f2:	2dc9                	jal	5dc4 <_user_strerror>
    56f4:	32050563          	beqz	a0,5a1e <_strerror_r+0x358>
    56f8:	4082                	lw	ra,0(sp)
    56fa:	0111                	addi	sp,sp,4
    56fc:	8082                	ret
    56fe:	00001517          	auipc	a0,0x1
    5702:	09a50513          	addi	a0,a0,154 # 6798 <sg_timer_config+0x808>
    5706:	8082                	ret
    5708:	00001517          	auipc	a0,0x1
    570c:	07850513          	addi	a0,a0,120 # 6780 <sg_timer_config+0x7f0>
    5710:	8082                	ret
    5712:	00001517          	auipc	a0,0x1
    5716:	02650513          	addi	a0,a0,38 # 6738 <sg_timer_config+0x7a8>
    571a:	8082                	ret
    571c:	00001517          	auipc	a0,0x1
    5720:	03450513          	addi	a0,a0,52 # 6750 <sg_timer_config+0x7c0>
    5724:	8082                	ret
    5726:	00001517          	auipc	a0,0x1
    572a:	c1650513          	addi	a0,a0,-1002 # 633c <sg_timer_config+0x3ac>
    572e:	8082                	ret
    5730:	00001517          	auipc	a0,0x1
    5734:	fcc50513          	addi	a0,a0,-52 # 66fc <sg_timer_config+0x76c>
    5738:	8082                	ret
    573a:	00001517          	auipc	a0,0x1
    573e:	e3650513          	addi	a0,a0,-458 # 6570 <sg_timer_config+0x5e0>
    5742:	8082                	ret
    5744:	00001517          	auipc	a0,0x1
    5748:	0b450513          	addi	a0,a0,180 # 67f8 <sg_timer_config+0x868>
    574c:	8082                	ret
    574e:	00001517          	auipc	a0,0x1
    5752:	ab650513          	addi	a0,a0,-1354 # 6204 <sg_timer_config+0x274>
    5756:	8082                	ret
    5758:	00001517          	auipc	a0,0x1
    575c:	a7450513          	addi	a0,a0,-1420 # 61cc <sg_timer_config+0x23c>
    5760:	8082                	ret
    5762:	00001517          	auipc	a0,0x1
    5766:	00a50513          	addi	a0,a0,10 # 676c <sg_timer_config+0x7dc>
    576a:	8082                	ret
    576c:	00001517          	auipc	a0,0x1
    5770:	06450513          	addi	a0,a0,100 # 67d0 <sg_timer_config+0x840>
    5774:	8082                	ret
    5776:	00001517          	auipc	a0,0x1
    577a:	d5250513          	addi	a0,a0,-686 # 64c8 <sg_timer_config+0x538>
    577e:	8082                	ret
    5780:	00001517          	auipc	a0,0x1
    5784:	c8050513          	addi	a0,a0,-896 # 6400 <sg_timer_config+0x470>
    5788:	8082                	ret
    578a:	00001517          	auipc	a0,0x1
    578e:	b4a50513          	addi	a0,a0,-1206 # 62d4 <sg_timer_config+0x344>
    5792:	8082                	ret
    5794:	00001517          	auipc	a0,0x1
    5798:	c4050513          	addi	a0,a0,-960 # 63d4 <sg_timer_config+0x444>
    579c:	8082                	ret
    579e:	00001517          	auipc	a0,0x1
    57a2:	b2650513          	addi	a0,a0,-1242 # 62c4 <sg_timer_config+0x334>
    57a6:	8082                	ret
    57a8:	00001517          	auipc	a0,0x1
    57ac:	06450513          	addi	a0,a0,100 # 680c <sg_timer_config+0x87c>
    57b0:	8082                	ret
    57b2:	00001517          	auipc	a0,0x1
    57b6:	b6650513          	addi	a0,a0,-1178 # 6318 <sg_timer_config+0x388>
    57ba:	8082                	ret
    57bc:	00001517          	auipc	a0,0x1
    57c0:	d3050513          	addi	a0,a0,-720 # 64ec <sg_timer_config+0x55c>
    57c4:	8082                	ret
    57c6:	00001517          	auipc	a0,0x1
    57ca:	f4e50513          	addi	a0,a0,-178 # 6714 <sg_timer_config+0x784>
    57ce:	8082                	ret
    57d0:	00001517          	auipc	a0,0x1
    57d4:	f1450513          	addi	a0,a0,-236 # 66e4 <sg_timer_config+0x754>
    57d8:	8082                	ret
    57da:	00001517          	auipc	a0,0x1
    57de:	eda50513          	addi	a0,a0,-294 # 66b4 <sg_timer_config+0x724>
    57e2:	8082                	ret
    57e4:	00001517          	auipc	a0,0x1
    57e8:	eb850513          	addi	a0,a0,-328 # 669c <sg_timer_config+0x70c>
    57ec:	8082                	ret
    57ee:	00001517          	auipc	a0,0x1
    57f2:	e8e50513          	addi	a0,a0,-370 # 667c <sg_timer_config+0x6ec>
    57f6:	8082                	ret
    57f8:	00001517          	auipc	a0,0x1
    57fc:	e6450513          	addi	a0,a0,-412 # 665c <sg_timer_config+0x6cc>
    5800:	8082                	ret
    5802:	00001517          	auipc	a0,0x1
    5806:	e2a50513          	addi	a0,a0,-470 # 662c <sg_timer_config+0x69c>
    580a:	8082                	ret
    580c:	00001517          	auipc	a0,0x1
    5810:	dfc50513          	addi	a0,a0,-516 # 6608 <sg_timer_config+0x678>
    5814:	8082                	ret
    5816:	00001517          	auipc	a0,0x1
    581a:	eb250513          	addi	a0,a0,-334 # 66c8 <sg_timer_config+0x738>
    581e:	8082                	ret
    5820:	00001517          	auipc	a0,0x1
    5824:	f8c50513          	addi	a0,a0,-116 # 67ac <sg_timer_config+0x81c>
    5828:	8082                	ret
    582a:	00001517          	auipc	a0,0x1
    582e:	dc650513          	addi	a0,a0,-570 # 65f0 <sg_timer_config+0x660>
    5832:	8082                	ret
    5834:	00001517          	auipc	a0,0x1
    5838:	da050513          	addi	a0,a0,-608 # 65d4 <sg_timer_config+0x644>
    583c:	8082                	ret
    583e:	00001517          	auipc	a0,0x1
    5842:	d8250513          	addi	a0,a0,-638 # 65c0 <sg_timer_config+0x630>
    5846:	8082                	ret
    5848:	00001517          	auipc	a0,0x1
    584c:	d5c50513          	addi	a0,a0,-676 # 65a4 <sg_timer_config+0x614>
    5850:	8082                	ret
    5852:	00001517          	auipc	a0,0x1
    5856:	d4650513          	addi	a0,a0,-698 # 6598 <sg_timer_config+0x608>
    585a:	8082                	ret
    585c:	00001517          	auipc	a0,0x1
    5860:	d2850513          	addi	a0,a0,-728 # 6584 <sg_timer_config+0x5f4>
    5864:	8082                	ret
    5866:	00001517          	auipc	a0,0x1
    586a:	cfa50513          	addi	a0,a0,-774 # 6560 <sg_timer_config+0x5d0>
    586e:	8082                	ret
    5870:	00001517          	auipc	a0,0x1
    5874:	cd850513          	addi	a0,a0,-808 # 6548 <sg_timer_config+0x5b8>
    5878:	8082                	ret
    587a:	00001517          	auipc	a0,0x1
    587e:	cba50513          	addi	a0,a0,-838 # 6534 <sg_timer_config+0x5a4>
    5882:	8082                	ret
    5884:	00001517          	auipc	a0,0x1
    5888:	c9850513          	addi	a0,a0,-872 # 651c <sg_timer_config+0x58c>
    588c:	8082                	ret
    588e:	00001517          	auipc	a0,0x1
    5892:	d9650513          	addi	a0,a0,-618 # 6624 <sg_timer_config+0x694>
    5896:	8082                	ret
    5898:	00001517          	auipc	a0,0x1
    589c:	c7450513          	addi	a0,a0,-908 # 650c <sg_timer_config+0x57c>
    58a0:	8082                	ret
    58a2:	00001517          	auipc	a0,0x1
    58a6:	c6250513          	addi	a0,a0,-926 # 6504 <sg_timer_config+0x574>
    58aa:	8082                	ret
    58ac:	00001517          	auipc	a0,0x1
    58b0:	c3450513          	addi	a0,a0,-972 # 64e0 <sg_timer_config+0x550>
    58b4:	8082                	ret
    58b6:	00001517          	auipc	a0,0x1
    58ba:	bfe50513          	addi	a0,a0,-1026 # 64b4 <sg_timer_config+0x524>
    58be:	8082                	ret
    58c0:	00001517          	auipc	a0,0x1
    58c4:	bd850513          	addi	a0,a0,-1064 # 6498 <sg_timer_config+0x508>
    58c8:	8082                	ret
    58ca:	00001517          	auipc	a0,0x1
    58ce:	bba50513          	addi	a0,a0,-1094 # 6484 <sg_timer_config+0x4f4>
    58d2:	8082                	ret
    58d4:	00001517          	auipc	a0,0x1
    58d8:	b8050513          	addi	a0,a0,-1152 # 6454 <sg_timer_config+0x4c4>
    58dc:	8082                	ret
    58de:	00001517          	auipc	a0,0x1
    58e2:	b6a50513          	addi	a0,a0,-1174 # 6448 <sg_timer_config+0x4b8>
    58e6:	8082                	ret
    58e8:	00001517          	auipc	a0,0x1
    58ec:	b5050513          	addi	a0,a0,-1200 # 6438 <sg_timer_config+0x4a8>
    58f0:	8082                	ret
    58f2:	00001517          	auipc	a0,0x1
    58f6:	b2e50513          	addi	a0,a0,-1234 # 6420 <sg_timer_config+0x490>
    58fa:	8082                	ret
    58fc:	00001517          	auipc	a0,0x1
    5900:	b1450513          	addi	a0,a0,-1260 # 6410 <sg_timer_config+0x480>
    5904:	8082                	ret
    5906:	00001517          	auipc	a0,0x1
    590a:	ae250513          	addi	a0,a0,-1310 # 63e8 <sg_timer_config+0x458>
    590e:	8082                	ret
    5910:	00001517          	auipc	a0,0x1
    5914:	ab450513          	addi	a0,a0,-1356 # 63c4 <sg_timer_config+0x434>
    5918:	8082                	ret
    591a:	00001517          	auipc	a0,0x1
    591e:	a9a50513          	addi	a0,a0,-1382 # 63b4 <sg_timer_config+0x424>
    5922:	8082                	ret
    5924:	00001517          	auipc	a0,0x1
    5928:	a7850513          	addi	a0,a0,-1416 # 639c <sg_timer_config+0x40c>
    592c:	8082                	ret
    592e:	00001517          	auipc	a0,0x1
    5932:	a4e50513          	addi	a0,a0,-1458 # 637c <sg_timer_config+0x3ec>
    5936:	8082                	ret
    5938:	00001517          	auipc	a0,0x1
    593c:	a2450513          	addi	a0,a0,-1500 # 635c <sg_timer_config+0x3cc>
    5940:	8082                	ret
    5942:	00001517          	auipc	a0,0x1
    5946:	9c250513          	addi	a0,a0,-1598 # 6304 <sg_timer_config+0x374>
    594a:	8082                	ret
    594c:	00001517          	auipc	a0,0x1
    5950:	9a850513          	addi	a0,a0,-1624 # 62f4 <sg_timer_config+0x364>
    5954:	8082                	ret
    5956:	00001517          	auipc	a0,0x1
    595a:	95e50513          	addi	a0,a0,-1698 # 62b4 <sg_timer_config+0x324>
    595e:	8082                	ret
    5960:	00001517          	auipc	a0,0x1
    5964:	94450513          	addi	a0,a0,-1724 # 62a4 <sg_timer_config+0x314>
    5968:	8082                	ret
    596a:	00001517          	auipc	a0,0x1
    596e:	92650513          	addi	a0,a0,-1754 # 6290 <sg_timer_config+0x300>
    5972:	8082                	ret
    5974:	00001517          	auipc	a0,0x1
    5978:	91050513          	addi	a0,a0,-1776 # 6284 <sg_timer_config+0x2f4>
    597c:	8082                	ret
    597e:	00001517          	auipc	a0,0x1
    5982:	8ee50513          	addi	a0,a0,-1810 # 626c <sg_timer_config+0x2dc>
    5986:	8082                	ret
    5988:	00001517          	auipc	a0,0x1
    598c:	8d850513          	addi	a0,a0,-1832 # 6260 <sg_timer_config+0x2d0>
    5990:	8082                	ret
    5992:	00001517          	auipc	a0,0x1
    5996:	8ba50513          	addi	a0,a0,-1862 # 624c <sg_timer_config+0x2bc>
    599a:	8082                	ret
    599c:	00001517          	auipc	a0,0x1
    59a0:	89c50513          	addi	a0,a0,-1892 # 6238 <sg_timer_config+0x2a8>
    59a4:	8082                	ret
    59a6:	00001517          	auipc	a0,0x1
    59aa:	87e50513          	addi	a0,a0,-1922 # 6224 <sg_timer_config+0x294>
    59ae:	8082                	ret
    59b0:	00001517          	auipc	a0,0x1
    59b4:	84850513          	addi	a0,a0,-1976 # 61f8 <sg_timer_config+0x268>
    59b8:	8082                	ret
    59ba:	00001517          	auipc	a0,0x1
    59be:	82e50513          	addi	a0,a0,-2002 # 61e8 <sg_timer_config+0x258>
    59c2:	8082                	ret
    59c4:	00000517          	auipc	a0,0x0
    59c8:	7f450513          	addi	a0,a0,2036 # 61b8 <sg_timer_config+0x228>
    59cc:	8082                	ret
    59ce:	00000517          	auipc	a0,0x0
    59d2:	7d650513          	addi	a0,a0,2006 # 61a4 <sg_timer_config+0x214>
    59d6:	8082                	ret
    59d8:	00000517          	auipc	a0,0x0
    59dc:	7b050513          	addi	a0,a0,1968 # 6188 <sg_timer_config+0x1f8>
    59e0:	8082                	ret
    59e2:	00000517          	auipc	a0,0x0
    59e6:	79a50513          	addi	a0,a0,1946 # 617c <sg_timer_config+0x1ec>
    59ea:	8082                	ret
    59ec:	00000517          	auipc	a0,0x0
    59f0:	77850513          	addi	a0,a0,1912 # 6164 <sg_timer_config+0x1d4>
    59f4:	8082                	ret
    59f6:	00000517          	auipc	a0,0x0
    59fa:	75e50513          	addi	a0,a0,1886 # 6154 <sg_timer_config+0x1c4>
    59fe:	8082                	ret
    5a00:	00000517          	auipc	a0,0x0
    5a04:	73850513          	addi	a0,a0,1848 # 6138 <sg_timer_config+0x1a8>
    5a08:	8082                	ret
    5a0a:	00000517          	auipc	a0,0x0
    5a0e:	72250513          	addi	a0,a0,1826 # 612c <sg_timer_config+0x19c>
    5a12:	8082                	ret
    5a14:	00000517          	auipc	a0,0x0
    5a18:	71050513          	addi	a0,a0,1808 # 6124 <sg_timer_config+0x194>
    5a1c:	8082                	ret
    5a1e:	00000517          	auipc	a0,0x0
    5a22:	68e50513          	addi	a0,a0,1678 # 60ac <sg_timer_config+0x11c>
    5a26:	b9c9                	j	56f8 <_strerror_r+0x32>
    5a28:	86aa                	mv	a3,a0
    5a2a:	b1d1                	j	56ee <_strerror_r+0x28>

00005a2c <strerror>:
    5a2c:	85aa                	mv	a1,a0
    5a2e:	0201a503          	lw	a0,32(gp) # 20000508 <_impure_ptr>
    5a32:	4681                	li	a3,0
    5a34:	4601                	li	a2,0
    5a36:	c91ff06f          	j	56c6 <_strerror_r>
	...

00005a3c <strlen>:
    5a3c:	00357793          	andi	a5,a0,3
    5a40:	872a                	mv	a4,a0
    5a42:	ef9d                	bnez	a5,5a80 <strlen+0x44>
    5a44:	7f7f86b7          	lui	a3,0x7f7f8
    5a48:	f7f68693          	addi	a3,a3,-129 # 7f7f7f7f <__heap_end+0x5f7c7f7f>
    5a4c:	55fd                	li	a1,-1
    5a4e:	4310                	lw	a2,0(a4)
    5a50:	0711                	addi	a4,a4,4
    5a52:	00d677b3          	and	a5,a2,a3
    5a56:	97b6                	add	a5,a5,a3
    5a58:	8fd1                	or	a5,a5,a2
    5a5a:	8fd5                	or	a5,a5,a3
    5a5c:	feb789e3          	beq	a5,a1,5a4e <strlen+0x12>
    5a60:	ffc74683          	lbu	a3,-4(a4)
    5a64:	40a707b3          	sub	a5,a4,a0
    5a68:	ca8d                	beqz	a3,5a9a <strlen+0x5e>
    5a6a:	ffd74683          	lbu	a3,-3(a4)
    5a6e:	c29d                	beqz	a3,5a94 <strlen+0x58>
    5a70:	ffe74503          	lbu	a0,-2(a4)
    5a74:	00a03533          	snez	a0,a0
    5a78:	953e                	add	a0,a0,a5
    5a7a:	1579                	addi	a0,a0,-2
    5a7c:	8082                	ret
    5a7e:	d2f9                	beqz	a3,5a44 <strlen+0x8>
    5a80:	00074783          	lbu	a5,0(a4)
    5a84:	0705                	addi	a4,a4,1
    5a86:	00377693          	andi	a3,a4,3
    5a8a:	fbf5                	bnez	a5,5a7e <strlen+0x42>
    5a8c:	8f09                	sub	a4,a4,a0
    5a8e:	fff70513          	addi	a0,a4,-1
    5a92:	8082                	ret
    5a94:	ffd78513          	addi	a0,a5,-3
    5a98:	8082                	ret
    5a9a:	ffc78513          	addi	a0,a5,-4
    5a9e:	8082                	ret
	...

00005aa2 <_strtol_l.isra.0>:
    5aa2:	fdc10113          	addi	sp,sp,-36
    5aa6:	d006                	sw	ra,32(sp)
    5aa8:	02400793          	li	a5,36
    5aac:	c22a                	sw	a0,4(sp)
    5aae:	c02e                	sw	a1,0(sp)
    5ab0:	0ad7e363          	bltu	a5,a3,5b56 <_strtol_l.isra.0+0xb4>
    5ab4:	cc26                	sw	s1,24(sp)
    5ab6:	4785                	li	a5,1
    5ab8:	84b6                	mv	s1,a3
    5aba:	872e                	mv	a4,a1
    5abc:	00001317          	auipc	t1,0x1
    5ac0:	00130313          	addi	t1,t1,1 # 6abd <_ctype_+0x1>
    5ac4:	08f68863          	beq	a3,a5,5b54 <_strtol_l.isra.0+0xb2>
    5ac8:	ce22                	sw	s0,28(sp)
    5aca:	853a                	mv	a0,a4
    5acc:	00074783          	lbu	a5,0(a4)
    5ad0:	0705                	addi	a4,a4,1
    5ad2:	00f305b3          	add	a1,t1,a5
    5ad6:	0005c583          	lbu	a1,0(a1)
    5ada:	89a1                	andi	a1,a1,8
    5adc:	f5fd                	bnez	a1,5aca <_strtol_l.isra.0+0x28>
    5ade:	02d00593          	li	a1,45
    5ae2:	10b78b63          	beq	a5,a1,5bf8 <_strtol_l.isra.0+0x156>
    5ae6:	02b00593          	li	a1,43
    5aea:	06b78e63          	beq	a5,a1,5b66 <_strtol_l.isra.0+0xc4>
    5aee:	800005b7          	lui	a1,0x80000
    5af2:	15fd                	addi	a1,a1,-1 # 7fffffff <__heap_end+0x5ffcffff>
    5af4:	c62e                	sw	a1,12(sp)
    5af6:	ca02                	sw	zero,20(sp)
    5af8:	e2d1                	bnez	a3,5b7c <_strtol_l.isra.0+0xda>
    5afa:	44a9                	li	s1,10
    5afc:	03000593          	li	a1,48
    5b00:	86a6                	mv	a3,s1
    5b02:	10b78863          	beq	a5,a1,5c12 <_strtol_l.isra.0+0x170>
    5b06:	43b2                	lw	t2,12(sp)
    5b08:	4501                	li	a0,0
    5b0a:	4325                	li	t1,9
    5b0c:	0293f5b3          	remu	a1,t2,s1
    5b10:	4465                	li	s0,25
    5b12:	52fd                	li	t0,-1
    5b14:	c832                	sw	a2,16(sp)
    5b16:	0293d3b3          	divu	t2,t2,s1
    5b1a:	c42e                	sw	a1,8(sp)
    5b1c:	4581                	li	a1,0
    5b1e:	fd078613          	addi	a2,a5,-48
    5b22:	00c37863          	bgeu	t1,a2,5b32 <_strtol_l.isra.0+0x90>
    5b26:	fbf78613          	addi	a2,a5,-65
    5b2a:	06c46f63          	bltu	s0,a2,5ba8 <_strtol_l.isra.0+0x106>
    5b2e:	fc978613          	addi	a2,a5,-55
    5b32:	08d65363          	bge	a2,a3,5bb8 <_strtol_l.isra.0+0x116>
    5b36:	00558b63          	beq	a1,t0,5b4c <_strtol_l.isra.0+0xaa>
    5b3a:	55fd                	li	a1,-1
    5b3c:	00a3e863          	bltu	t2,a0,5b4c <_strtol_l.isra.0+0xaa>
    5b40:	08a38e63          	beq	t2,a0,5bdc <_strtol_l.isra.0+0x13a>
    5b44:	4585                	li	a1,1
    5b46:	02950533          	mul	a0,a0,s1
    5b4a:	9532                	add	a0,a0,a2
    5b4c:	0705                	addi	a4,a4,1
    5b4e:	fff74783          	lbu	a5,-1(a4)
    5b52:	b7f1                	j	5b1e <_strtol_l.isra.0+0x7c>
    5b54:	44e2                	lw	s1,24(sp)
    5b56:	2c8d                	jal	5dc8 <__errno>
    5b58:	47d9                	li	a5,22
    5b5a:	c11c                	sw	a5,0(a0)
    5b5c:	4501                	li	a0,0
    5b5e:	5082                	lw	ra,32(sp)
    5b60:	02410113          	addi	sp,sp,36
    5b64:	8082                	ret
    5b66:	800005b7          	lui	a1,0x80000
    5b6a:	00074783          	lbu	a5,0(a4)
    5b6e:	fff58713          	addi	a4,a1,-1 # 7fffffff <__heap_end+0x5ffcffff>
    5b72:	c63a                	sw	a4,12(sp)
    5b74:	ca02                	sw	zero,20(sp)
    5b76:	00250713          	addi	a4,a0,2
    5b7a:	d2c1                	beqz	a3,5afa <_strtol_l.isra.0+0x58>
    5b7c:	45c1                	li	a1,16
    5b7e:	f8b694e3          	bne	a3,a1,5b06 <_strtol_l.isra.0+0x64>
    5b82:	03000593          	li	a1,48
    5b86:	84b6                	mv	s1,a3
    5b88:	f6b79fe3          	bne	a5,a1,5b06 <_strtol_l.isra.0+0x64>
    5b8c:	00074583          	lbu	a1,0(a4)
    5b90:	05800513          	li	a0,88
    5b94:	0df5f593          	andi	a1,a1,223
    5b98:	f6a597e3          	bne	a1,a0,5b06 <_strtol_l.isra.0+0x64>
    5b9c:	44c1                	li	s1,16
    5b9e:	00174783          	lbu	a5,1(a4)
    5ba2:	86a6                	mv	a3,s1
    5ba4:	0709                	addi	a4,a4,2
    5ba6:	b785                	j	5b06 <_strtol_l.isra.0+0x64>
    5ba8:	f9f78613          	addi	a2,a5,-97
    5bac:	00c46663          	bltu	s0,a2,5bb8 <_strtol_l.isra.0+0x116>
    5bb0:	fa978613          	addi	a2,a5,-87
    5bb4:	f8d641e3          	blt	a2,a3,5b36 <_strtol_l.isra.0+0x94>
    5bb8:	57fd                	li	a5,-1
    5bba:	4642                	lw	a2,16(sp)
    5bbc:	02f58463          	beq	a1,a5,5be4 <_strtol_l.isra.0+0x142>
    5bc0:	47d2                	lw	a5,20(sp)
    5bc2:	c399                	beqz	a5,5bc8 <_strtol_l.isra.0+0x126>
    5bc4:	40a00533          	neg	a0,a0
    5bc8:	c231                	beqz	a2,5c0c <_strtol_l.isra.0+0x16a>
    5bca:	edb9                	bnez	a1,5c28 <_strtol_l.isra.0+0x186>
    5bcc:	4782                	lw	a5,0(sp)
    5bce:	4472                	lw	s0,28(sp)
    5bd0:	5082                	lw	ra,32(sp)
    5bd2:	c21c                	sw	a5,0(a2)
    5bd4:	44e2                	lw	s1,24(sp)
    5bd6:	02410113          	addi	sp,sp,36
    5bda:	8082                	ret
    5bdc:	47a2                	lw	a5,8(sp)
    5bde:	f6c7c7e3          	blt	a5,a2,5b4c <_strtol_l.isra.0+0xaa>
    5be2:	b78d                	j	5b44 <_strtol_l.isra.0+0xa2>
    5be4:	4692                	lw	a3,4(sp)
    5be6:	02200793          	li	a5,34
    5bea:	c29c                	sw	a5,0(a3)
    5bec:	c221                	beqz	a2,5c2c <_strtol_l.isra.0+0x18a>
    5bee:	fff70793          	addi	a5,a4,-1
    5bf2:	4532                	lw	a0,12(sp)
    5bf4:	c03e                	sw	a5,0(sp)
    5bf6:	bfd9                	j	5bcc <_strtol_l.isra.0+0x12a>
    5bf8:	00074783          	lbu	a5,0(a4)
    5bfc:	4585                	li	a1,1
    5bfe:	80000737          	lui	a4,0x80000
    5c02:	c63a                	sw	a4,12(sp)
    5c04:	ca2e                	sw	a1,20(sp)
    5c06:	00250713          	addi	a4,a0,2
    5c0a:	b5fd                	j	5af8 <_strtol_l.isra.0+0x56>
    5c0c:	4472                	lw	s0,28(sp)
    5c0e:	44e2                	lw	s1,24(sp)
    5c10:	b7b9                	j	5b5e <_strtol_l.isra.0+0xbc>
    5c12:	00074683          	lbu	a3,0(a4) # 80000000 <__heap_end+0x5ffd0000>
    5c16:	05800593          	li	a1,88
    5c1a:	0df6f693          	andi	a3,a3,223
    5c1e:	f6b68fe3          	beq	a3,a1,5b9c <_strtol_l.isra.0+0xfa>
    5c22:	44a1                	li	s1,8
    5c24:	86a6                	mv	a3,s1
    5c26:	b5c5                	j	5b06 <_strtol_l.isra.0+0x64>
    5c28:	c62a                	sw	a0,12(sp)
    5c2a:	b7d1                	j	5bee <_strtol_l.isra.0+0x14c>
    5c2c:	4532                	lw	a0,12(sp)
    5c2e:	4472                	lw	s0,28(sp)
    5c30:	44e2                	lw	s1,24(sp)
    5c32:	b735                	j	5b5e <_strtol_l.isra.0+0xbc>

00005c34 <strtol>:
    5c34:	872a                	mv	a4,a0
    5c36:	0201a503          	lw	a0,32(gp) # 20000508 <_impure_ptr>
    5c3a:	87ae                	mv	a5,a1
    5c3c:	86b2                	mv	a3,a2
    5c3e:	85ba                	mv	a1,a4
    5c40:	863e                	mv	a2,a5
    5c42:	e61ff06f          	j	5aa2 <_strtol_l.isra.0>

00005c46 <_strtoul_l.isra.0>:
    5c46:	1111                	addi	sp,sp,-28
    5c48:	cc22                	sw	s0,24(sp)
    5c4a:	ca26                	sw	s1,20(sp)
    5c4c:	872e                	mv	a4,a1
    5c4e:	c22e                	sw	a1,4(sp)
    5c50:	c82a                	sw	a0,16(sp)
    5c52:	00001317          	auipc	t1,0x1
    5c56:	e6b30313          	addi	t1,t1,-405 # 6abd <_ctype_+0x1>
    5c5a:	853a                	mv	a0,a4
    5c5c:	00074783          	lbu	a5,0(a4)
    5c60:	0705                	addi	a4,a4,1
    5c62:	00f305b3          	add	a1,t1,a5
    5c66:	0005c583          	lbu	a1,0(a1)
    5c6a:	89a1                	andi	a1,a1,8
    5c6c:	f5fd                	bnez	a1,5c5a <_strtoul_l.isra.0+0x14>
    5c6e:	02d00593          	li	a1,45
    5c72:	0cb78b63          	beq	a5,a1,5d48 <_strtoul_l.isra.0+0x102>
    5c76:	02b00593          	li	a1,43
    5c7a:	c602                	sw	zero,12(sp)
    5c7c:	06b78b63          	beq	a5,a1,5cf2 <_strtoul_l.isra.0+0xac>
    5c80:	ee91                	bnez	a3,5c9c <_strtoul_l.isra.0+0x56>
    5c82:	03000693          	li	a3,48
    5c86:	0cd78863          	beq	a5,a3,5d56 <_strtoul_l.isra.0+0x110>
    5c8a:	1999a337          	lui	t1,0x1999a
    5c8e:	46a9                	li	a3,10
    5c90:	4595                	li	a1,5
    5c92:	99930313          	addi	t1,t1,-1639 # 19999999 <__ctor_end__+0x19992dd9>
    5c96:	84b6                	mv	s1,a3
    5c98:	c02e                	sw	a1,0(sp)
    5c9a:	a819                	j	5cb0 <_strtoul_l.isra.0+0x6a>
    5c9c:	45c1                	li	a1,16
    5c9e:	0cb68c63          	beq	a3,a1,5d76 <_strtoul_l.isra.0+0x130>
    5ca2:	55fd                	li	a1,-1
    5ca4:	02d5d333          	divu	t1,a1,a3
    5ca8:	84b6                	mv	s1,a3
    5caa:	02d5f5b3          	remu	a1,a1,a3
    5cae:	c02e                	sw	a1,0(sp)
    5cb0:	4581                	li	a1,0
    5cb2:	4501                	li	a0,0
    5cb4:	42a5                	li	t0,9
    5cb6:	4465                	li	s0,25
    5cb8:	53fd                	li	t2,-1
    5cba:	c432                	sw	a2,8(sp)
    5cbc:	fd078613          	addi	a2,a5,-48
    5cc0:	00c2f863          	bgeu	t0,a2,5cd0 <_strtoul_l.isra.0+0x8a>
    5cc4:	fbf78613          	addi	a2,a5,-65
    5cc8:	02c46a63          	bltu	s0,a2,5cfc <_strtoul_l.isra.0+0xb6>
    5ccc:	fc978613          	addi	a2,a5,-55
    5cd0:	02d65e63          	bge	a2,a3,5d0c <_strtoul_l.isra.0+0xc6>
    5cd4:	00758b63          	beq	a1,t2,5cea <_strtoul_l.isra.0+0xa4>
    5cd8:	55fd                	li	a1,-1
    5cda:	00a36863          	bltu	t1,a0,5cea <_strtoul_l.isra.0+0xa4>
    5cde:	04650763          	beq	a0,t1,5d2c <_strtoul_l.isra.0+0xe6>
    5ce2:	02950533          	mul	a0,a0,s1
    5ce6:	4585                	li	a1,1
    5ce8:	9532                	add	a0,a0,a2
    5cea:	0705                	addi	a4,a4,1
    5cec:	fff74783          	lbu	a5,-1(a4)
    5cf0:	b7f1                	j	5cbc <_strtoul_l.isra.0+0x76>
    5cf2:	00074783          	lbu	a5,0(a4)
    5cf6:	00250713          	addi	a4,a0,2
    5cfa:	b759                	j	5c80 <_strtoul_l.isra.0+0x3a>
    5cfc:	f9f78613          	addi	a2,a5,-97
    5d00:	00c46663          	bltu	s0,a2,5d0c <_strtoul_l.isra.0+0xc6>
    5d04:	fa978613          	addi	a2,a5,-87
    5d08:	fcd646e3          	blt	a2,a3,5cd4 <_strtoul_l.isra.0+0x8e>
    5d0c:	57fd                	li	a5,-1
    5d0e:	4622                	lw	a2,8(sp)
    5d10:	02f58263          	beq	a1,a5,5d34 <_strtoul_l.isra.0+0xee>
    5d14:	47b2                	lw	a5,12(sp)
    5d16:	c399                	beqz	a5,5d1c <_strtoul_l.isra.0+0xd6>
    5d18:	40a00533          	neg	a0,a0
    5d1c:	c601                	beqz	a2,5d24 <_strtoul_l.isra.0+0xde>
    5d1e:	e18d                	bnez	a1,5d40 <_strtoul_l.isra.0+0xfa>
    5d20:	4792                	lw	a5,4(sp)
    5d22:	c21c                	sw	a5,0(a2)
    5d24:	4462                	lw	s0,24(sp)
    5d26:	44d2                	lw	s1,20(sp)
    5d28:	0171                	addi	sp,sp,28
    5d2a:	8082                	ret
    5d2c:	4782                	lw	a5,0(sp)
    5d2e:	fac7cee3          	blt	a5,a2,5cea <_strtoul_l.isra.0+0xa4>
    5d32:	bf45                	j	5ce2 <_strtoul_l.isra.0+0x9c>
    5d34:	46c2                	lw	a3,16(sp)
    5d36:	02200793          	li	a5,34
    5d3a:	852e                	mv	a0,a1
    5d3c:	c29c                	sw	a5,0(a3)
    5d3e:	d27d                	beqz	a2,5d24 <_strtoul_l.isra.0+0xde>
    5d40:	fff70793          	addi	a5,a4,-1
    5d44:	c23e                	sw	a5,4(sp)
    5d46:	bfe9                	j	5d20 <_strtoul_l.isra.0+0xda>
    5d48:	00074783          	lbu	a5,0(a4)
    5d4c:	4705                	li	a4,1
    5d4e:	c63a                	sw	a4,12(sp)
    5d50:	00250713          	addi	a4,a0,2
    5d54:	b735                	j	5c80 <_strtoul_l.isra.0+0x3a>
    5d56:	00074683          	lbu	a3,0(a4)
    5d5a:	05800593          	li	a1,88
    5d5e:	0df6f693          	andi	a3,a3,223
    5d62:	02b68d63          	beq	a3,a1,5d9c <_strtoul_l.isra.0+0x156>
    5d66:	20000337          	lui	t1,0x20000
    5d6a:	46a1                	li	a3,8
    5d6c:	459d                	li	a1,7
    5d6e:	137d                	addi	t1,t1,-1 # 1fffffff <__ctor_end__+0x1fff943f>
    5d70:	84b6                	mv	s1,a3
    5d72:	c02e                	sw	a1,0(sp)
    5d74:	bf35                	j	5cb0 <_strtoul_l.isra.0+0x6a>
    5d76:	03000593          	li	a1,48
    5d7a:	00b78963          	beq	a5,a1,5d8c <_strtoul_l.isra.0+0x146>
    5d7e:	10000337          	lui	t1,0x10000
    5d82:	45bd                	li	a1,15
    5d84:	137d                	addi	t1,t1,-1 # fffffff <__ctor_end__+0xfff943f>
    5d86:	c02e                	sw	a1,0(sp)
    5d88:	84b6                	mv	s1,a3
    5d8a:	b71d                	j	5cb0 <_strtoul_l.isra.0+0x6a>
    5d8c:	00074583          	lbu	a1,0(a4)
    5d90:	05800513          	li	a0,88
    5d94:	0df5f593          	andi	a1,a1,223
    5d98:	fea593e3          	bne	a1,a0,5d7e <_strtoul_l.isra.0+0x138>
    5d9c:	10000337          	lui	t1,0x10000
    5da0:	44c1                	li	s1,16
    5da2:	45bd                	li	a1,15
    5da4:	00174783          	lbu	a5,1(a4)
    5da8:	137d                	addi	t1,t1,-1 # fffffff <__ctor_end__+0xfff943f>
    5daa:	86a6                	mv	a3,s1
    5dac:	c02e                	sw	a1,0(sp)
    5dae:	0709                	addi	a4,a4,2
    5db0:	b701                	j	5cb0 <_strtoul_l.isra.0+0x6a>

00005db2 <strtoul>:
    5db2:	872a                	mv	a4,a0
    5db4:	0201a503          	lw	a0,32(gp) # 20000508 <_impure_ptr>
    5db8:	87ae                	mv	a5,a1
    5dba:	86b2                	mv	a3,a2
    5dbc:	85ba                	mv	a1,a4
    5dbe:	863e                	mv	a2,a5
    5dc0:	e87ff06f          	j	5c46 <_strtoul_l.isra.0>

00005dc4 <_user_strerror>:
    5dc4:	4501                	li	a0,0
    5dc6:	8082                	ret

00005dc8 <__errno>:
    5dc8:	0201a503          	lw	a0,32(gp) # 20000508 <_impure_ptr>
    5dcc:	8082                	ret
	...
