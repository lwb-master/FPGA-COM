#include <stdint.h>
#include <MotorCtrl.h>
#include <stdint.h>
#include <MotorCtrl.h>
#include <stdio.h>


//打印命令和打印模式变量
#include <stdint.h>

#define heat_open

uint8_t  CMD_Start = 0;        // 开始打印命令
uint8_t  StopPrint = 0;        // 结束打印命令
uint8_t  PaperFeed = 1;        // 进纸方式
uint16_t SendPage = 0;
uint16_t PaperFeedPre = 0;     // 进纸方式
uint16_t Mode_Finish = 0;      // 参数设置完成标志
uint16_t PrintPage = 0;        // 打印页数
uint8_t  PrintStyle;           // 打印方式：单/双面（当前未使用）
uint8_t  PaperType = 0x38;     // 纸张类型
uint8_t  DataFinsh = 0;        // 打印数据下传完成
uint16_t Printed_Page = 0;     // 已打印页数
uint8_t  TaskStart = 0;        // 作业开始命令
uint8_t  DataReady = 0;        // 打印数据下传完成
uint8_t  DPI_Choose = 0;       // 0:600DPI, 1:1200DPI
uint8_t  Douflag = 1;          // 1:单面, 0:双面
uint8_t  Color_Choose = 0;     // 0:黑白, 1:彩色
uint8_t  ReSet = 0;            // ARM 同步信号
uint8_t  ERROR_CPU = 1;        //ERROR_CPU反馈信号
uint8_t  Heat_Ready=0;   ////加热温度到达信号
uint8_t HV_Ready=0;  //HV高压准备好信号

uint16_t Page_sync_printed = 0;     // 已经发送的pagesync
uint16_t Page_sync_print = 0;     // 需要发送的pagesync

uint16_t Next_Page_Sync_Enable=0;
uint16_t Next_Page_Sync_Timer=0;
uint8_t  T1_RELEASE_HOME=0;
uint8_t  SENS_NIP_HOME=0;

volatile uint32_t time_flag_count=0;
volatile uint32_t time_flag_count_A=0;
volatile uint32_t time_flag_count_B=0;
volatile uint32_t time_flag_count_C=0;



uint32_t  nSENS_FUSER_RELEASE = 0;        // 读打印状态寄存器


volatile uint16_t Stop_HVFlag = 0;     // 关闭高压标志位（EXIT1 上升沿）
volatile uint16_t Stop_MotorFlag = 0;  // 关闭电机标志位（EXIT3 上升沿）

volatile uint8_t PageX_Paper_Arrived = 0;//该变量控制上一页的纸尾彻底离开传感器，才把捕捉锁解开
			// 此时传感器变回高电平，绝对不会发生任何误触发，为下一页的到来腾出位置

uint32_t Second_time = 0;

extern void FEED_Motor_Start();
extern void	FUSER_Motor_Start();
extern void	FUSER_Motor_Stop();
extern void	FEED_Motor_Start();
extern void	FEED_Motor_Stop();
extern void	BLDC_K_Motor_Start();
extern void	BLDC_K_Motor_Stop();
extern void	BLDC_YMC_Motor_Start();
extern void	BLDC_YMC_Motor_Stop();
extern void LSU_Motor_Start();
extern void	LSU_Motor_Stop();
extern void	Clutch_Write(uint32_t OperatingCommand);
extern void delay_1ms();
extern void Delay_ms(uint32_t delay_ms);
extern void Mot_Register_Initial(void);
/* Regi 离合 */
extern uint16_t RegiCL_Open(uint16_t Operating_Command);

extern uint16_t RegiCL_Close(uint16_t Operating_Command);

/* Pickup 离合 */
extern uint16_t PickupCL_Open(uint16_t Operating_Command);
extern uint16_t PickupCL_Close(uint16_t Operating_Command);

/* Fuser 电磁铁 */
extern uint16_t FuserSOL_Open(uint16_t Operating_Command);
extern uint16_t FuserSOL_Close(uint16_t Operating_Command);

/* Nip 离合*/
extern uint16_t NipSOL_Close(uint16_t Operating_Command);
extern uint16_t NipSOL_Open(uint16_t Operating_Command);

/* T1 离合*/
extern uint16_t T1_SOL_Close(uint16_t Operating_Command);
extern uint16_t T1_SOL_Open(uint16_t Operating_Command);

extern uint16_t FAN_SMPS_Open(uint16_t Operating_Command);
extern uint16_t FAN_SMPS_Close(uint16_t Operating_Command);

///////timer
extern int32_t timer_init(uint32_t timer_num ,uint32_t timeout);
extern int32_t timer_stop(uint32_t timer_num);
///初始化函数
extern void Printer_Para_init();
extern void Printer_Var_Init();
extern void PrintHead_PrintMode_Set();
extern void Page_Sync_ON();
extern void SET_PRT_DATA_PARP();


//////寄存器设置
uint16_t Clutch_CtrlREG        = 0x0000; // pickup离合 / regiCL离合 / fuser_sol离合
uint16_t PrintHead_State_REG   = 0x0000; // 打印模块状态读取寄存器
uint16_t DCBeltHeat_Mot_CtrlREG= 0x0204; // 加热、传送带控制寄存器
uint16_t Thermal_CtrlREG       = 0x0000; // 两加热器及两 ADC 控制的 16 位输出控制寄存器
uint16_t PaperPath_SensorREG   = 0x0000; // 纸张通路上敏感元件状态寄存器
uint16_t SideTermACT_VAL       = 0x0000; // 两侧加热器温度采样值
uint16_t CentTermACT_VAL       = 0x0000; // 中间加热器温度采样值

uint16_t ErrorStatusReg        = 0x0000; // 致命性错误寄存器
uint16_t PrintModeReg          = 0x0000; // 打印模式寄存器
uint16_t PrintCtrlReg          = 0x0000; // 打印命令寄存器
uint16_t PrnSensorReg          = 0x0000; // 非致命性错误寄存器
uint16_t ACK_Reg               = 0x0000; // 纸张尺寸 / ARM 握手信号寄存器
uint16_t PaperSizeReg          = 0x0000; // 纸张尺寸寄存器

uint32_t FpgaRdReg             = 0x0000; // 软件和逻辑握手信号寄存器



int32_t temp_HVPS_Ctrol_REG=0;//高压控制临时变量

uint32_t	Status;//

// ================= SENS_Regi =================
volatile uint8_t SENS_Regi[2]    = {1, 1};
volatile uint8_t SENS_RegiHflag = 0;
volatile uint8_t SENS_RegiLflag = 0;

// ================= SENS_Feed =================
volatile uint8_t SENS_Feed[2]    = {1, 1};
volatile uint8_t SENS_FeedHflag = 0;
volatile uint8_t SENS_FeedLflag = 0;
// ================= SENS_Exit =================
volatile uint8_t SENS_Exit[2]    = {1, 1};
volatile uint8_t SENS_ExitHflag = 0;
volatile uint8_t SENS_ExitLflag = 0;

volatile uint8_t SENS_Fuser[2] = {1, 1};
volatile uint8_t SENS_FuserHflag=0;
volatile uint8_t SENS_FuserLflag=0;

volatile uint8_t  PrintStart[2] = {0,0}; //33H RD  PrintHead_State_nRCS  Bit4:Print_Once_Start打印头start信号
volatile uint8_t PrintStartHflag = 0;   //
volatile uint8_t  PrintStartLflag = 0;   //

volatile uint8_t  K_Sync[2] = {0,0}; //33H RD  PrintHead_State_nRCS bit0：PrintPageK_Sync	打印头K同步信号
volatile uint8_t  K_SyncHflag = 0;   //
volatile uint8_t  K_SyncLflag = 0;   //

///测试计数
volatile uint32_t timetest1 = 0;
volatile uint32_t SENS_RegiL_timer1=0;
volatile uint32_t SENS_RegiL_timer2=0;
volatile uint32_t SENS_RegiH_timer=0;
volatile uint32_t K_SyncH_time1=0;
volatile uint32_t SENS_ExitH_timer=0;
volatile uint32_t SENS_RegiL_timer_HV=0;

///////////////// 定时器标志位
volatile uint8_t TimeInitial=0;//定时器开始标志
uint8_t Flag_First_K = 0;      // K 同步信号第一次下降沿

////加热超时标记
 uint8_t heat_is_timeout = 1;


/////上纸时刻

volatile uint32_t  HopCL_StopTime1=340;
volatile uint32_t  NextPaperTime1=1540;//控制首页与第二页之间纸张之间的间隔，目前间隔为200ms  1394   1506  1513 1533
volatile uint32_t  NextPaperTime2=1525;//控制第二页及以后页之间的间隔 200ms  1525
volatile uint16_t  again_paper=0;//上下一张纸标志位

volatile int PageSync_Enable = 0; 
volatile int PageSync_Timer = 0;
uint8_t  fuser_count_flag = 0;  
uint32_t  fuser_count = 0;  
uint8_t  count_over_flag = 0;  

///加热测试信号
	uint8_t count=0;
	uint8_t AVR_flag=0;
	uint32_t AVR_C_DATA=0;
	uint32_t AVR_D_DATA=0;
	uint8_t AVR_DATA_start=0;
	
	
//工程代码


volatile int32_t flag = 0;
uint8_t ret;
int main(void)
{
	
	//测试离合反馈
	
//	FUSER_Motor_Start();
//	Delay_ms(100);
//	FEED_Motor_Start();
//	while (1)
//	{
//		Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);	
//		Delay_ms(1000);
//		Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
//		Delay_ms(100);
//	}
	SET_PRT_DATA_PARP();
	uint32_t state = *RD_State_REG;
//	printf("%d\n", state);
	//初始化：定时器、寄存器初始化 高压初始化/////////////
	timer_init(0, 1000); // 1ms的中断
	Mot_Register_Initial();
	Delay_ms(50);
	*COLOR_CTR_REG = 0b1111;
	
	//////////////////////////////self_check////////////
	///TI NIP之前开启所有的电机  高压复位 启动高压自检
	Delay_ms(2000);
	FEED_Motor_Start();
	Delay_ms(100);
	FUSER_Motor_Start();
	Delay_ms(100);
	BLDC_K_Motor_Start();
	Delay_ms(100);		
	BLDC_YMC_Motor_Start();
	Delay_ms(143);
	Clutch_CtrlREG = FAN_SMPS_Open(Clutch_CtrlREG);
	Delay_ms(150);
    *HVCtrl_REG = 0x0000;//高压模块reset,bit4 复位
    *HVCtrl_PrintPage_REG = 0 ;//打印页数为0
	Delay_ms(20);
	temp_HVPS_Ctrol_REG |= 0x0054; //0b000010000;/reset end,bit2启动高压自检
	*HVCtrl_REG =temp_HVPS_Ctrol_REG;
	Delay_ms(380);//根据原装机时序，高压初始化在T1之前	
	
	///T1_Clutch
	int times=400;
	T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
	if (T1_RELEASE_HOME==1) {
		Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
		while (1) {
			Delay_ms(5);
			if (T1_RELEASE_HOME==0) {
				printf("T1_SENS_RELEASE_HOME OK!\n");
				break;
			}
			else {
				if (times--==0) {
					printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
					break;
				}
			}
		}
	}
	Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
	
	Delay_ms(100);
	
	//NIP
	SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//	
	if (SENS_NIP_HOME==1) {
		Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
		Delay_ms(110);
		Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
		Delay_ms(500);
		if (SENS_NIP_HOME==1) {
			printf("NIP_SENS-timeout!!!\n");
		}
	}
	printf("NIP_SENS-ok!\n");
	
	BLDC_YMC_Motor_Stop();
	Delay_ms(472);
	FEED_Motor_Stop();
	Delay_ms(100);
	BLDC_K_Motor_Stop();
	Delay_ms(100);
	FUSER_Motor_Stop();

////////////////////////selfcheck_over/////////////////////
	/*
	//测试T1与FUSER电机联合  之前的自检过程
	Delay_ms(2000);
	FEED_Motor_Start();
	Delay_ms(100);
	FUSER_Motor_Start();
	Delay_ms(100);
	BLDC_K_Motor_Start();
	Delay_ms(100);		
	BLDC_YMC_Motor_Start();
	Delay_ms(143);
	Clutch_CtrlREG = FAN_SMPS_Open(Clutch_CtrlREG);
	Delay_ms(150);
    *HVCtrl_REG = 0x0000;//高压模块reset,bit4 复位
    *HVCtrl_PrintPage_REG = 0 ;//打印页数为0
	Delay_ms(20);
	temp_HVPS_Ctrol_REG |= 0x0054; //0b000010000;/reset end,bit2启动高压自检
	*HVCtrl_REG =temp_HVPS_Ctrol_REG;
	
	Delay_ms(380);//根据原装机时序，高压初始化在T1之前	
	
	Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
	T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;//

	unsigned int SENS_T1_Count=0;
	uint8_t  SENS_T1_is_timeout=1;
	for (SENS_T1_Count = 0; SENS_T1_Count < 5; SENS_T1_Count++)
	{
		// 读取就绪标志
		T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
				
		if (T1_RELEASE_HOME == 1)
		{
			printf("SENS_T1_HOME==1\n");
			SENS_T1_is_timeout=0;
			break;// 跳出循环，正常向下执行，不关机
		}
		// 未就绪，延时1s再检测下一次
		Delay_ms(1000);
	}

	// 仅超时才执行关机流程
	if (SENS_T1_is_timeout == 1)
	{
		printf("SENS_T1_is_timeout in 1\n");	
		//关加热
		//Heat_Close();
		/*
		Delay_ms(2000);
		//关电机
		All_Motor_Stop();
		//释放fuser电机
		Delay_ms(100);
		fuser_release();
		//continue;
		
	}
	
	//检测到Sens变高后延迟560ms关闭T1
	Delay_ms(560);
	Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
	printf(" T1_SOL_Close\n");
	Delay_ms(970);
	Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
	Delay_ms(110);
	Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
	
	SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//

	unsigned int SENS_NIP_Count=0;
	uint8_t  SENS_NIP_is_timeout=1;
	for (SENS_NIP_Count = 0; SENS_NIP_Count < 5; SENS_NIP_Count++)
	{
			// 读取就绪标志
			SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;
				
			if (SENS_NIP_HOME == 0)
			{
				printf("SENS_NIP_HOME==0\n");
				SENS_NIP_is_timeout=0;
				break;// 跳出循环，正常向下执行，不关机
			}
				// 未就绪，延时1s再检测下一次
			Delay_ms(1000);
	}

	// 仅超时才执行关机流程
	if (SENS_NIP_is_timeout == 1)
	{
		printf("SENS_NIP_is_timeout IN 1\n");	
		//关加热
		//Heat_Close();
		/*
		Delay_ms(2000);
		//关电机
		All_Motor_Stop();
		//释放fuser电机
		Delay_ms(100);
		fuser_release();
		
	}
	Delay_ms(264);
	Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
	Delay_ms(110);
	Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);

	
	////上电电机自检 四个电机都需要自检//////////
	//ret = Power_On_Motor_SelfTest();
	ret = 0;
    if (ret == 0)
    {
        //无故障：写“正常状态”
		//*ErrorCode_REG= 0x0080;
       // FSMC_Write(ErrorCodeReg_Adr, 0x0080);   // 约定：bit7 = OK
       //printf("Power-On Motor Self-Test PASS\r\n");
    }
    else
    {
        //有故障：错误码已在自检中记录 
       // printf("Power-On Motor Self-Test FAIL, Err=0x%02X\r\n", ret);

        //停止所有电机
        All_Motor_Stop();
        return 0;          // 直接终止启动流程
    }
//
//	////自检完成后，关闭所有电机 
	Delay_ms(4000);
	All_Motor_Stop();
 */
   	Delay_ms(2200);//高压自检剩余时间
	//printf("self_check ok!\n");
	
	//////////////////////////作业开始信号读取 此处为while(1)循环，当一次作业完成之后，程序将在此处等待上位机发送的下一次任务
	////////////////////////在while(1)函数内部的最开始地方会有循环读取上位机发送的信号，现在测试时进行了屏蔽。
	while (1) {

		temp_HVPS_Ctrol_REG = 0x0000; //0b000010000;//reset ,
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;
		Delay_ms(100);
			temp_HVPS_Ctrol_REG = 0x0010; //0b000010000;//reset end,
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;

		*THV_EN_DELAY_REG   = 4000000;//高压THV_EN400ms高电平部分时间
		*CH_DELAY_REG=7738000;
		*DEVE_DELAY_REG=3300000;
		
		TimeInitial=0;
		Printer_Para_init();//打印相关变量初始化
		Printer_Var_Init();//打印过程中计数器等进行初始化
		Page_Sync_Close();
		fuser_release();
	
		int32_t num;
		num = *PRINTHEAD_REG;
		///与上位机同步握手信号
		ReSet = (*PrintCtrl_REG & 0x0001) > 0 ? 1 : 0;
		while (ReSet == 0) {
		
			ReSet = (*PrintCtrl_REG & 0x0001) > 0 ? 1 : 0;
		}
		//printf("ACK OK\n");
		
		/////判断参数是否设置成功
		Mode_Finish = (*PrintCtrl_REG & 0x0040) > 0 ? 1 : 0;
		while (Mode_Finish == 0) {
			Mode_Finish = (*PrintCtrl_REG & 0x0040) > 0 ? 1 : 0;
		}
		//printf("Mode_Finish ok\n");
		
		TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;//作业开始命令
		StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;//打印终止命令
		while(TaskStart==0 || StopPrint==1){ ////循环接收打印开始信号
			TaskStart = (*PrintCtrl_REG & 0X0020)>0?1:0;
			StopPrint = (*PrintCtrl_REG & 0x0008)>0?1:0;			

		}
		//printf("TaskStart ok\n");		
	    Color_Choose = (*PrintMode_REG & 0x0040) > 0 ? 1 : 0;
		
/////在打开加热电机之前，打开所有运动所需电机
		
		//PrintPage = 1;//读取潜像页数  第2次
		//*HVCtrl_PrintPage_REG = PrintPage ;

		Delay_ms(20);
		//*HVCtrl_REG = 0b000010000;//reset end
		////over
		///HV waiting
		/*0615暂时先将这段放置开加热之后，防止加热前开高压，飞粉*/
		Delay_ms(20);
		temp_HVPS_Ctrol_REG |= 0x0032 | (Color_Choose? 0x0100:0x0000);//0b100110010;//bit1 startup 启动任务，bit8选择是否彩色打印
      //temp_HVPS_Ctrol_REG |= 0x0032 ;//0b100110010;//bit1 startup 启动任务，bit8选择是否彩色打印	
	    *HVCtrl_REG =temp_HVPS_Ctrol_REG;		
	
		FEED_Motor_Start();
		Delay_ms(100);
		/*0615暂时先将这段放置开加热之后，防止加热前开高压，飞粉*/
		Delay_ms(2000);
		temp_HVPS_Ctrol_REG &= 0xFFDF;//0b100010010;//bit5 低电平有效nfeed_en
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
		
		fuser_clamping();
		Delay_ms(1170);
		FUSER_Motor_Start();
		Delay_ms(100);
		LSU_Motor_Start();
		Delay_ms(100);
		BLDC_K_Motor_Start();
		Delay_ms(100);		
		BLDC_YMC_Motor_Start();
		Delay_ms(100);
		///打开电机后，进行打印头初始化
		PrintHead_Initial();
		Delay_ms(20);
		PrintHead_PrintMode_Set();
		Delay_ms(2930);
		//printf("Motor ok\n");	


//		///打开加热
		#ifdef heat_open
			//AVR_DATA_start=1;
			*ADC_HeaterCtrl_REG=0x0002;//模块初始化
			Heat_Open();
			//printf("Heat_Open\n");
		#endif
		

		//////等待打印开始命令
		CMD_Start = (*PrintCtrl_REG&0X0010)>0?1:0; //作业开始命令
		StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//打印终止命令
		///等待打印开始命令
		while (CMD_Start == 0)
		{
			if (StopPrint == 1)
			{
				break;
			}

			//printf("waiting print!\n");
			CMD_Start  = (*PrintCtrl_REG & 0x0010) ? 1 : 0;
			StopPrint = (*PrintCtrl_REG & 0x0008) ? 1 : 0;
		}
		//printf("CMD_Start ok\n");	
		////如果作业取消则停止打印
		if(StopPrint==1){
			All_Motor_Stop();//关闭所有电机
			Delay_ms(5000);
			//printf("StopPrint==1\n");	
			continue;
		}	
	 	//读取打印页数寄存器
		StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
		DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
		PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
	////20260412 增加页数更新和数据传输结束
		*HVCtrl_PrintPage_REG = PrintPage ;
		
		temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
			
		
		//*HVCtrl_PrintPage_REG = PrintPage ;
		
		//检测是否预热到指定温度
		#ifdef heat_open
			//check_temperature2();
			unsigned int Heat_Count = 0;
    
			for (Heat_Count = 0; Heat_Count < 20; Heat_Count++)
			{
				// 读取就绪标志
				Heat_Ready = (*ERROR_CPU_REG & 0x0001) ? 1 : 0;
        
				if (Heat_Ready == 1)
				{
					heat_is_timeout = 0; // 10s内读到就绪，未超时
					//printf("Heat_Ready\n");	
					break; // 跳出循环，正常向下执行，不关机
				}
				// 未就绪，延时1s再检测下一次
				Delay_ms(1000);
			}

			// 仅超时才执行关机流程
			if (heat_is_timeout == 1)
			{
				printf("heat_is_timeout\n");	
				//关加热
				Heat_Close();
				Delay_ms(5000);
				//关电机
				All_Motor_Stop();
				//释放fuser电机
				Delay_ms(100);
				fuser_release();
				Delay_ms(500);
				//一次作业完成了 给上位机发信号
				//*ErrorCode_REG= 0x0001;///暂时用这个寄存器的bit0位作为和贵圆交互的信号，bit0=1则清除所有寄存器设置。
				Delay_ms(500);
				continue;
			}
		#endif
		
		//*HVCtrl_PrintPage_REG=2;
		//只有当打印页数不为0时，才向下继续运行，才给打印头发送enable信号，以此来保证打印头收到enable之前页数不为0
		while(1){
		
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
			*HVCtrl_PrintPage_REG = PrintPage ;
			if(PrintPage!=0)
				break;
			//printf("printpage is %d\n", PrintPage);
		}

		TimeInitial=1;//打印流程定时器开启  此信号不能过早也不能过晚设置 此时中断开始检测regi sens信号的边沿变化
		Printed_Page = 0;//已经打印的页数
		//测试用，默认单面打印
		Douflag=1;
	
	
		//读取SENS NIP 的值，如果该值为高，则不做任何工作；如果该值为低，则NIP SOL输出一个高脉冲
//		if((*SENS_REG & SENS_NIP_BIT)==0) {
//			Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
//			Delay_ms(150);
//			Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
//		
//		}else {
//		
//		}
		//printf("NipSOL ok\n");	

		///第一页上纸在中断中检测打印头start信号，当检测到上升沿后，打开pickUp_CL离合。
		if(Printed_Page == 0){	
			//该信号测试时由主函数给出，在实际工程中由打印头给出，中断中接收并检测 测试代码
			//PrintStartHflag=1;//模拟打印头start信号，暂时不用这个信号。纸张从纸盒中搓出的行为，在主函数中执行。
			//打印头ON
			//Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
			///T1_Clutch
			
			temp_HVPS_Ctrol_REG |=0x0040; // 0b101010010;//bit6 SYN_HV_EN	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
			times=400;
			T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
			if (T1_RELEASE_HOME==1) {
				Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
				while (1) {
					Delay_ms(5);
					if (T1_RELEASE_HOME==0) {
						printf("T1_SENS_RELEASE_HOME OK!\n");
						break;
					}
					else {
						if (times--==0) {
							printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
							break;
						}
					}
				}
			}
			Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
	
			Delay_ms(100);
	
			//NIP
			SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//	
			if (SENS_NIP_HOME==1) {
				Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
				Delay_ms(110);
				Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
				Delay_ms(500);
				if (SENS_NIP_HOME==1) {
				printf("NIP_SENS-timeout!!!\n");
				}	
			}
			printf("NIP_SENS-ok!\n");
		

			
			
			/*
			T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;//
		
			SENS_T1_Count=0;
			SENS_T1_is_timeout=1;
			for (SENS_T1_Count = 0; SENS_T1_Count < 5; SENS_T1_Count++)
			{
				// 读取就绪标志
				T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
				
				if (T1_RELEASE_HOME == 0)
				{
					printf("SENS_T1_HOME==0\n");
					SENS_T1_is_timeout=0;
					break;// 跳出循环，正常向下执行，不关机
				}
				// 未就绪，延时1s再检测下一次
				Delay_ms(1000);
			}

			// 仅超时才执行关机流程
			if (SENS_T1_is_timeout == 1)
			{
				printf("SENS_T1_is_timeout in 2\n");	
				/*
				//关加热
				Heat_Close();
				Delay_ms(2000);
				//关电机
				All_Motor_Stop();
				//释放fuser电机
				Delay_ms(100);
				fuser_release();
				//continue;
				 
			}
			
			//检测到Sens变低后延迟40ms关闭T1
			Delay_ms(40);
			Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);

			Delay_ms(50);//将NIP的高脉冲移到T1之后，这里大约设置50ms				
			Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
			Delay_ms(150);
			Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
	
			*/
			
			*PRINTHEAD_REG = 0b00110;	//打印头寄存器置初值
			//HV sync
			//*HVCtrl_REG = 0b101010010;//SYN_HV_EN
			Delay_ms(24);//根据原装机信号修改T1延时			
			//Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);		
			Delay_ms(1416);//	1016ms与高压nTHV_EN信号400ms高电平起始对齐,400ms后检测高压反馈信号
	  		HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
			while (HV_Ready == 0) {
		
				HV_Ready = (*STATUS_REG & 0x0010) > 0 ? 1 : 0;
			}
			//printf("HV_Ready=1\n");
			//	Delay_ms(400);
			////页同步信号，1页是1856ms，页和页之间的间隔是200ms 所以页同步信号是2056ms
		////////////////pagesync到pickupcl开启的时间是：3.386s/////////////////////////
			Page_Sync_ON();
			//time_flag_count_A=time_flag_count;
			//printf("Page_Sync_ON send\n");
			PageSync_Enable=1;		
			Delay_ms(2700);//调整这个参数能够 调整图像在纸张上的位置   Y数据到pickup开 //1900  2700
			
		
			Clutch_CtrlREG=PlateSOL_Open(Clutch_CtrlREG);//开plate离合 //从开plate离合到while(!again_paper){}之间的延时总和不能变！
			//printf("PlateSOL_Open\n");
			Delay_ms(160);
			
			Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
			
			////////////////pagesync到pickupcl开启的时间是：3.386s////////////////////////////
		
			//printf("time_flag_count is %d\n",time_flag_count);
			//printf("PickupCL_Open\n");
		
			temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
			
				//*	************20260623 调整DataFinsh与PICKUP时序关系，因为实际DataFinsh完成后才能PICKUP，所以先给高压发送DataFinsh			
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
	
			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
				
			
			
			Delay_ms(320);
		
			temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;		
			Clutch_CtrlREG=PlateSOL_Close(Clutch_CtrlREG);//关plate离合
			//printf("PlateSOL_Close\n");
	
		
								
			while(!again_paper){}	//在中断中完成一页后，200ms后，again paper置1，实现两张纸之间的间隔	
			again_paper=0;				
			//在下一张纸前对打印的页数等数据进行再次读取					
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
	
			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;

	
			//单双面区分
			if(Douflag==1)//1为单面
			{
				SendPage= PrintPage;		
			}else{
				SendPage=(PrintPage+PrintPage%2)/2;		
			}	
			Printed_Page = Printed_Page+1;	//已打印页数加一
			*PrintedPageNum_REG = Printed_Page;//更新已打印页数	
			//printf("Printed_Page=1\n");
		}

		//打印循环，循环从第2张纸开始////////////////
		while(StopPrint==0 && Printed_Page<SendPage){
			printf("now is in while\n");
			//从首页的while(!again_paper){}到第二页的plate离合打开，这之间不能加延时！
			Clutch_CtrlREG=PlateSOL_Open(Clutch_CtrlREG);//plate离合打开
			//printf("PlateSOL_Open\n");
			Delay_ms(160);//160
			Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开取纸离合
			
			temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;
			
			//*	************20260623 调整DataFinsh与PICKUP时序关系，因为实际DataFinsh完成后才能PICKUP，所以先给高压发送DataFinsh			
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数
	
			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
					
			
					
			Delay_ms(320);	
			temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
	
			Clutch_CtrlREG=PlateSOL_Close(Clutch_CtrlREG);//plate离合关闭
			//printf("PlateSOL_Close\n");

			while(!again_paper){}//在中断中完成一页后，200ms后，again paper置1，实现两张纸之间的间隔			
			again_paper=0;		
			StopPrint = (*PrintCtrl_REG&0x0008)>0?1:0;//读取停止打印命令
			DataFinsh = (*PrintCtrl_REG&0X0002)>0?1:0;//打印数据下传完成
			PrintPage = *PrintPage_REG & 0xFFFF;//读取打印页数

			//20260412 增加页数更新和数据传输结束
			*HVCtrl_PrintPage_REG = PrintPage ;
			temp_HVPS_Ctrol_REG|= (StopPrint?0x0008:0x0000) |  DataFinsh?0x8000:0x0000;//数据传输结束判断;//打印停止命令	
			*HVCtrl_REG =temp_HVPS_Ctrol_REG;

			if(Douflag==1)//单面
			{
				SendPage= PrintPage;			
			}else    //双面      
			{
				SendPage=(PrintPage+PrintPage%2)/2;			
			}
			Printed_Page = Printed_Page + 1;//已打印页数加1	
			*PrintedPageNum_REG = Printed_Page;//更新已打印页数	
			//printf("Printed_Page+1\n");
		}
	

		//*ErrorCode_REG= 0x0040;//作业完成后给上位机发送作业结束信号  收到stop信号也发送0040
		//多页打印结束需要增加NIP T1信号
		Delay_ms(300);
		
		///T1_Clutch
		times=400;
		T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
		if (T1_RELEASE_HOME==1) {
			Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
			while (1) {
				Delay_ms(5);
				if (T1_RELEASE_HOME==0) {
					printf("T1_SENS_RELEASE_HOME OK!\n");
					break;
				}
				else {
					if (times--==0) {
						printf("T1_SENS_RELEASE_HOME Timeout!!!\n");
						break;
					}
				}
			}
		}
		Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);	
	
		Delay_ms(100);
	
		//NIP
		SENS_NIP_HOME = (*SENS_REG&0x0008)>0?1:0;//	
		if (SENS_NIP_HOME==1) {
			Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
			Delay_ms(110);
			Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
			Delay_ms(500);
			if (SENS_NIP_HOME==1) {
			printf("NIP_SENS-timeout!!!\n");
			}	
		}
		printf("NIP_SENS-ok!\n");
		
		/*
		Clutch_CtrlREG = T1_SOL_Open(Clutch_CtrlREG);
		Delay_ms(78);
		Clutch_CtrlREG=NipSOL_Open(Clutch_CtrlREG);
		Delay_ms(104);
		Clutch_CtrlREG=NipSOL_Close(Clutch_CtrlREG);
		
		T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;//
	
		SENS_T1_Count=0;
		SENS_T1_is_timeout=1;
		for (SENS_T1_Count = 0; SENS_T1_Count < 5; SENS_T1_Count++)
		{
			// 读取就绪标志
			T1_RELEASE_HOME = (*SENS_REG&0x0010)>0?1:0;
				
			if (T1_RELEASE_HOME == 1)
			{
				printf("SENS_NIP_HOME==1\n");
				SENS_T1_is_timeout=0;
				break;// 跳出循环，正常向下执行，不关机
			}
			// 未就绪，延时1s再检测下一次
			Delay_ms(1000);
		}

		// 仅超时才执行关机流程
		if (SENS_T1_is_timeout == 1)
		{
			printf("SENS_T1_is_timeout in 3\n");	
			//关加热
			/*
			Heat_Close();
			Delay_ms(2000);
			//关电机
			All_Motor_Stop();
			//释放fuser电机
			Delay_ms(100);
			fuser_release();
			//continue;
			 
		}
		
		//检测到Sens变高后延迟448ms关闭T1
		Delay_ms(410);
		Clutch_CtrlREG = T1_SOL_Close(Clutch_CtrlREG);		
	 */
	
			
		while(!Stop_MotorFlag){}		
		Stop_MotorFlag=0;		
		Delay_ms(8000);////经测试，当检测到EXIT的上升沿后，纸只能出来一半,所以延时3S	
		TimeInitial=0;//打印作业定时器关闭
	
	
		//关加热
		Heat_Close();
		//printf("Heat_Close\n");
	
		Delay_ms(5000);
		*HVCtrl_REG = 0x0034;//100111000;//bit3 打印结束HV END//
	    Delay_ms(100);		
		//一次作业完成 给上位机发信号
		//*ErrorCode_REG= 0x0001;///暂时用这个寄存器的bit0位作为和贵圆交互的信号，bit0=1则清除所有寄存器设置。
		temp_HVPS_Ctrol_REG = 0x0000; //0b000010000;//reset ,
	    *HVCtrl_REG =temp_HVPS_Ctrol_REG;

//		temp_HVPS_Ctrol_REG = 0x0010; //0b000010000;//reset end,
//	*HVCtrl_REG =temp_HVPS_Ctrol_REG;			
		All_Motor_Stop();//关闭电机
		//printf("All_Motor_Stop\n");
		//printf("time_flag_count_B- time_flag_count_A=%d\n",time_flag_count_B - time_flag_count_A);
		//printf("time_flag_count_C- time_flag_count_B=%d\n",time_flag_count_C - time_flag_count_B);
		Delay_ms(100);
		fuser_release();
		Clutch_CtrlREG = FAN_SMPS_Close(Clutch_CtrlREG);
		while (1);
	}	
}
