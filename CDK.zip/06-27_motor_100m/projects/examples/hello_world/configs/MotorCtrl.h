#include <stdint.h>
#define WR_RD_BASE  (0x60018000UL)

#define  RD_State_REG   ((volatile uint32_t*)(WR_RD_BASE + 0x20UL))

#define  FEED_WORK_CTRL_REG   ((volatile uint32_t*)(WR_RD_BASE + 0x24UL))
#define  FEED_START_CTRL_REG  ((volatile uint32_t*)(WR_RD_BASE + 0x28UL))
#define  FEED_END_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x2cUL))
#define  FEED_PER_CTRL_REG   	((volatile uint32_t*)(WR_RD_BASE + 0x30UL))
#define  FEED_MOTO_CTRL_REG   ((volatile uint32_t*)(WR_RD_BASE + 0x34UL))
#define  FEED_FRE_DIV_REG   ((volatile uint32_t*)(WR_RD_BASE + 0xECUL))
#define  FEED_High_Time_REG   ((volatile uint32_t*)(WR_RD_BASE + 0xF0UL))


#define FUSER_WORK_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x38UL))
#define FUSER_START_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x3CUL))
#define FUSER_END_CTRL_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x40UL))
#define FUSER_PER_CTRL_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x44UL))
#define FUSER_MOTO_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x48UL))
#define FUSER_FRE_DIV_REG 	((volatile uint32_t*)(WR_RD_BASE + 0xE4UL))
#define FUSER_High_Time_REG 	((volatile uint32_t*)(WR_RD_BASE + 0xE8UL))
#define FUSER_MID_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0xF4UL))
#define FUSER_ST_DELAY_REG 	((volatile uint32_t*)(WR_RD_BASE + 0xF8UL))
#define FUSER_PER_CTRL_REG2 	((volatile uint32_t*)(WR_RD_BASE + 0xFCUL))




#define LSU_WORK_CTRL_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x4CUL))
#define LSU_START_CTRL_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x50UL))
#define LSU_END_CTRL_REG 			((volatile uint32_t*)(WR_RD_BASE + 0x54UL))
#define LSU_PER_CTRL_REG 			((volatile uint32_t*)(WR_RD_BASE + 0x58UL))
#define LSU_MOTO_CTRL_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x5CUL))


#define  BLDC_K_WORK_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x60UL))
#define  BLDC_K_START_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x64UL))
#define  BLDC_K_NO1_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x68UL))
#define  BLDC_K_NO2_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x6CUL))
#define  BLDC_K_PER_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x70UL))
#define  BLDC_K_MOTO_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x74UL))


#define  BLDC_YMC_WORK_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x78UL))
#define  BLDC_YMC_START_CTRL_REG    ((volatile uint32_t*)(WR_RD_BASE + 0x7CUL))
#define  BLDC_YMC_NO1_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x80UL))
#define  BLDC_YMC_NO2_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x84UL))
#define  BLDC_YMC_PER_CTRL_REG  	((volatile uint32_t*)(WR_RD_BASE + 0x88UL))
#define  BLDC_YMC_MOTO_CTRL_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x8CUL))

#define  HYNC_REG 	        ((volatile uint32_t*)(WR_RD_BASE + 0x100UL))
#define  Y_PRT_DATA_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x104UL))
#define  M_PRT_DATA_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x108UL))
#define  C_PRT_DATA_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x10CUL))
#define  K_PRT_DATA_REG 	((volatile uint32_t*)(WR_RD_BASE + 0x110UL))

// 逻辑反馈读寄存器宏定义 (严格对应图 1 的 14 个寄存器)
#define REG_T_KKL         ((volatile float *)(WR_RD_BASE + 0x19CUL))  // T_kkl (0x19C)
#define REG_T_KKR         ((volatile float *)(WR_RD_BASE + 0x1A0UL))  // T_kkr (0x1A0)
#define REG_T_CCL         ((volatile float *)(WR_RD_BASE + 0x1A4UL))  // T_ccl (0x1A4)
#define REG_T_CCR         ((volatile float *)(WR_RD_BASE + 0x1A8UL))  // T_ccr (0x1A8)
#define REG_T_MML         ((volatile float *)(WR_RD_BASE + 0x1ACUL))  // T_mml (0x1AC)
#define REG_T_MMR         ((volatile float *)(WR_RD_BASE + 0x1B0UL))  // T_mmr (0x1B0)
#define REG_T_YYL         ((volatile float *)(WR_RD_BASE + 0x1B4UL))  // T_yyl (0x1B4)
#define REG_T_YYR         ((volatile float *)(WR_RD_BASE + 0x1B8UL))  // T_yyr (0x1B8)

#define REG_T_KCL         ((volatile float *)(WR_RD_BASE + 0x1BCUL))  // T_kcl (0x1BC)
#define REG_T_KCR         ((volatile float *)(WR_RD_BASE + 0x1C0UL))  // T_kcr (0x1C0)
#define REG_T_KML         ((volatile float *)(WR_RD_BASE + 0x1C4UL))  // T_kml (0x1C4)
#define REG_T_KMR         ((volatile float *)(WR_RD_BASE + 0x1C8UL))  // T_kmr (0x1C8)
#define REG_T_KYL         ((volatile float *)(WR_RD_BASE + 0x1CCUL))  // T_kyl (0x1CC)
#define REG_T_KYR         ((volatile float *)(WR_RD_BASE + 0x1D0UL))  // T_kyr (0x1D0)

/* -------- 打印头控制寄存器，地址：0x90n -------- */
/* -------- 打印头控制寄存器，BIT0:RST -------- */
/* -------- 打印头控制寄存器，BIT1:EN -------- */
/* -------- 打印头控制寄存器，BIT2:Print_Enalbe -------- */
/* -------- 打印头控制寄存器，BIT0:INT_MODE -------- */
#define  PRINTHEAD_REG				((volatile uint32_t*)(WR_RD_BASE + 0x90UL))	

#define  CLUTCH_REG					((volatile uint32_t*)(WR_RD_BASE + 0x94UL))

#define  STATUS_REG					((volatile uint32_t*)(WR_RD_BASE + 0x04UL)) ////bit4是高压ready信号
//////rd_reg_01={28'd0,PH_BUSY,bldc_k_flag,bldc_ymc_flag,LSU_flag};
#define ST_LSU_READY        (1U << 0)
#define ST_BLDC_YMC_READY   (1U << 1)
#define ST_BLDC_K_READY     (1U << 2)
#define ST_PH_BUSY          (1U << 3)

///以下寄存器已经修改为准确地址
#define  ErrorCode_REG		((volatile uint32_t*)(WR_RD_BASE + 0xCCUL))///错误代码寄存器 写
#define  PrintCtrl_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x10UL))/// 打印控制寄存器 读
#define  PrintPage_REG      ((volatile uint32_t*)(WR_RD_BASE + 0x08UL))///需打印页数寄存器 读
#define  PrintedPageNum_REG      ((volatile uint32_t*)(WR_RD_BASE + 0xC8UL))/// 已打印页数寄存器 写
#define  PrintMode_REG       ((volatile uint32_t*)(WR_RD_BASE + 0x0CUL))///已打印页数寄存器 写
/////over////

#define  ADC_HeaterCtrl_REG       ((volatile uint32_t*)(WR_RD_BASE + 0xD8UL))///定影控制、ADC模块控制寄存器 ADC:bit0 定影复位：bit1 定影使能：bit2
#define ERROR_CPU_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x18UL))


///和高压同步的寄存器
#define  HVCtrl_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x98UL))//高压控制寄存器   写
// HVCtrl_REG   写寄存器  bit0-休眠 bit1-作业开始 bit2-打印开始 bit3-打印任务结束 pickupCl——bit7   高压同步信号——bit6   feeden——bit5 高压复位信号——bit4
#define  HVCtrl_PrintPage_REG ((volatile uint32_t*)(WR_RD_BASE + 0x9CUL)) //需要告诉高压模块打印页数  写
#define  THV_EN_DELAY_REG ((volatile uint32_t*)(WR_RD_BASE + 0x124UL))
#define  CH_DELAY_REG ((volatile uint32_t*)(WR_RD_BASE + 0x128UL))
#define  DEVE_DELAY_REG ((volatile uint32_t*)(WR_RD_BASE + 0x12CUL))

//激光头寄存器
#define  ByteNum_Per_Line_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xA0UL))//每行有效数据个数
#define  LineNum_Per_Page_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xA4UL))//打印行数
#define  CYC_ST_DATA_K_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xA8UL))//纸张传感器至打印头输出的延时计数值(K_data)
#define  CYC_ST_DATA_Y_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xB4UL))//纸张传感器至打印头输出的延时计数值(Y_data)
#define  CYC_ST_DATA_M_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xB8UL))//纸张传感器至打印头输出的延时计数值(M_data)
#define  CYC_ST_DATA_C_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xBCUL))//纸张传感器至打印头输出的延时计数值(C_data)
#define  PageNum_Per_Job		 ((volatile uint32_t*)(WR_RD_BASE + 0xAcUL))//打印页数

//每一个通道的数据宽度
#define Start_Line_Reg          ((volatile uint32_t*)(WR_RD_BASE + 0xC0UL))
#define End_Line_Reg         ((volatile uint32_t*)(WR_RD_BASE + 0xC4UL))

//颜色控制寄存器
#define  COLOR_CTR_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xB0UL))//打印页数

//延时
#define  COLOR_CTR_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0xB0UL))//打印页数
//与打印头同步信号   读


//PrintStart[1] = (FSMC_Read(0x33)&0X0010)>0?1:0; 打印头寄存器 读
//K_Sync[1] = (FSMC_Read(0x33)&0X0008)>0?1:0; 打印头K同步信号 读

#define ERR_LSU_MOTOR   (1U << 0)
#define ERR_BLDC_YMC    (1U << 1)
#define ERR_BLDC_K      (1U << 2)
#define ERR_FEED_MOTOR  (1U << 3)

//////test reg////
#define  AVR_C_DATA_REG		 ((volatile uint32_t*)(WR_RD_BASE + 0x114UL))
#define  AVR_D_DATA_REG	 ((volatile uint32_t*)(WR_RD_BASE + 0x118UL))




//高压的读控制寄存器（pickup可能需要改变）
//#define  HVPS_WORK_REG 				((volatile uint32_t*)(WR_RD_BASE + 0x08UL))
//#define  HVPS_FEED_EN_REG 			((volatile uint32_t*)(WR_RD_BASE + 0x0cUL))
//#define  HVPS_SYN_EN_REG 			((volatile uint32_t*)(WR_RD_BASE + 0x10UL))
//#define  HVPS_PICKUP_REG 			((volatile uint32_t*)(WR_RD_BASE + 0x14UL))
//#define  HVPS_PRINT_PAGE_REG 		((volatile uint32_t*)(WR_RD_BASE + 0x18UL))

//由低位到高位分别是，SENS_P_Regi,SENS_MP_Feed,Sens_P_Exit消抖之后的result
#define  SENS_REG  					((volatile uint32_t*)(WR_RD_BASE + 0x1cUL))

////复位信号 
#define  Fuser_Count_Enable_REG 		((volatile uint32_t*)(WR_RD_BASE + 0xDCUL))  //bit0
#define  Fuser_Count_Num_REG 		((volatile uint32_t*)(WR_RD_BASE + 0xE0UL))


/* -------- Sensor bit definition -------- */
#define SENS_REGI_BIT   (1U << 0)
#define SENS_FEED_BIT   (1U << 1)
#define SENS_EXIT_BIT   (1U << 2)
#define SENS_NIP_BIT    (1U << 3)
#define SENS_T1_BIT     (1U << 4)
#define SENS_Fuser_Release (1U << 5)
#define  SENS_Fuser_Mort (1U << 6)
#define  Fuser_count_over (1U << 7)

/*------------电机---------------------*/
void	FUSER_Motor_Start();
void    FUSER_Motor_Start_Rev();
void	FUSER_Motor_Stop();
void	FEED_Motor_Start();
void	FEED_Motor_Stop();
void	BLDC_K_Motor_Start();
void	BLDC_K_Motor_Stop();
void	BLDC_YMC_Motor_Start();
void	BLDC_YMC_Motor_Stop();
void    LSU_Motor_Start();
void	LSU_Motor_Stop();
void	Clutch_Write(uint32_t OperatingCommand);
void    delay_1ms();
void    Delay_ms(uint32_t delay_ms);
void    Mot_Register_Initial(void);

/* Regi 离合 */
uint16_t RegiCL_Open(uint16_t Operating_Command);

uint16_t RegiCL_Close(uint16_t Operating_Command);

/* Pickup 离合 */
uint16_t PickupCL_Open(uint16_t Operating_Command);
uint16_t PickupCL_Close(uint16_t Operating_Command);

/* Fuser 电磁铁 */
uint16_t FuserSOL_Open(uint16_t Operating_Command);
uint16_t FuserSOL_Close(uint16_t Operating_Command);

////PlateSOL
uint16_t PlateSOL_Open(uint16_t  Operating_Command);
uint16_t PlateSOL_Close(uint16_t Operating_Command);

//NipSOL
uint16_t NipSOL_Close(uint16_t Operating_Command);
uint16_t NipSOL_Open(uint16_t Operating_Command);

//T1SOL
uint16_t T1_SOL_Open(uint16_t Operating_Command);
uint16_t T1_SOL_Close(uint16_t Operating_Command);

//FAN_SMPS
uint16_t FAN_SMPS_Open(uint16_t Operating_Command);
uint16_t FAN_SMPS_Close(uint16_t Operating_Command);



void All_Motor_Stop(void);

uint8_t Power_On_Motor_SelfTest(void);

void PrintHead_RST_ON();
void PrintHead_INITMODE_ON();
void PrintHead_PRINTMODE_ON();
void PrintHead_Initial();
void PrintHead_PrintMode_Set();
void Page_Sync_ON();
void Page_Sync_Close();
void fuser_release();
void fuser_clamping();
void Heat_Open();
void Heat_Close();
void check_temperature();
void check_temperature2(void);
void SET_PRT_DATA_PARP();
void SET_PRT_DATA_PARP2();
void Color_Separation();