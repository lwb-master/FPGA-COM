#include <stdint.h>
#include <MotorCtrl.H>
#include <stdio.h>
#define ROUND(x)          ((int)((x) >= 0.0f ? ((x) + 0.5f) : ((x) - 0.5f)))
extern uint8_t  CMD_Start;        // 开始打印命令
extern uint8_t  StopPrint;        // 结束打印命令
extern uint8_t  PaperFeed ;        // 进纸方式
extern uint16_t SendPage ;
extern uint16_t PaperFeedPre ;     // 进纸方式
extern uint16_t Mode_Finish ;      // 参数设置完成标志
extern uint16_t PrintPage ;        // 打印页数
extern uint8_t  PrintStyle;           // 打印方式：单/双面（当前未使用）
extern uint8_t  PaperType ;     // 纸张类型
extern uint8_t  DataFinsh ;        // 打印数据下传完成
extern uint16_t Printed_Page;     // 已打印页数
extern uint8_t  TaskStart ;        // 作业开始命令
extern uint8_t  DataReady ;        // 打印数据下传完成
extern uint8_t  DPI_Choose ;       // 0:600DPI, 1:1200DPI
extern uint8_t  Douflag ;          // 0:单面, 1:双面
extern uint8_t  Color_Choose;     // 0:黑白, 1:彩色
extern uint8_t  ReSet;            // ARM 同步信号
extern uint8_t  ERROR_CPU;        //ERROR_CPU反馈信号
extern volatile uint16_t  again_paper;//上下一张纸标志位
////加热超时标记
extern uint8_t heat_is_timeout;

extern volatile uint16_t Page_sync_printed;     // 已经发送的pagesync
extern volatile uint16_t Page_sync_print;     // 需要发送的pagesync
extern volatile uint16_t Next_Page_Sync_Enable;
extern volatile uint16_t Next_Page_Sync_Timer;
//////寄存器设置
extern uint16_t Clutch_CtrlREG; // pickup离合 / regiCL离合 / fuser_sol离合
extern uint16_t PrintHead_State_REG; // 打印模块状态读取寄存器
extern uint16_t DCBeltHeat_Mot_CtrlREG; // 加热、传送带控制寄存器
extern uint16_t Thermal_CtrlREG; // 两加热器及两 ADC 控制的 16 位输出控制寄存器
extern uint16_t PaperPath_SensorREG; // 纸张通路上敏感元件状态寄存器
extern uint16_t SideTermACT_VAL; // 两侧加热器温度采样值
extern uint16_t CentTermACT_VAL; // 中间加热器温度采样值

extern uint16_t ErrorStatusReg; // 致命性错误寄存器
extern uint16_t PrintModeReg; // 打印模式寄存器
extern uint16_t PrintCtrlReg; // 打印命令寄存器
extern uint16_t PrnSensorReg  ; // 非致命性错误寄存器
extern uint16_t ACK_Reg     ; // 纸张尺寸 / ARM 握手信号寄存器
extern uint16_t PaperSizeReg ; // 纸张尺寸寄存器

extern uint32_t FpgaRdReg ; // 软件和逻辑握手信号寄存器

extern uint8_t Heat_Ready;  //HV高压准备好信号
extern uint8_t HV_Ready;


/* ================= SENS_Regi ================= */
extern volatile uint8_t SENS_Regi[2];
extern volatile uint8_t SENS_RegiHflag;
extern volatile uint8_t SENS_RegiLflag;

/* ================= SENS_Feed ================= */
extern volatile uint8_t SENS_Feed[2];
extern volatile uint8_t SENS_FeedHflag;
extern volatile uint8_t SENS_FeedLflag;

/* ================= SENS_Exit ================= */
extern volatile uint8_t SENS_Exit[2];
extern volatile uint8_t SENS_ExitHflag;
extern volatile uint8_t SENS_ExitLflag;

/* ================= PrintStart ================= */
extern volatile uint8_t  PrintStart[2];
extern volatile uint8_t  PrintStartHflag;
extern volatile uint8_t  PrintStartLflag;

/* ================= K_Sync ================= */
extern volatile uint8_t  K_Sync[2];
extern volatile uint8_t  K_SyncHflag;
extern volatile uint8_t  K_SyncLflag;

/* ================= Test / Debug ================= */
extern volatile uint32_t timetest1;
extern volatile uint32_t SENS_RegiL_timer1;
extern volatile uint32_t SENS_RegiL_timer2;
extern volatile uint32_t SENS_RegiH_timer;
extern volatile uint32_t K_SyncH_time1;

/* ================= Timer Flags ================= */
extern volatile uint8_t  TimeInitial;
extern uint8_t           Flag_First_K;

/* ================= Paper Timing ================= */
extern volatile uint32_t PaperTime;
extern volatile uint32_t HopCL_StopTime1;
extern volatile uint32_t NextPaperTime;

extern volatile uint16_t  Stop_MotorFlag;///关闭电机标志位，EXIT3上升沿关闭
extern volatile uint16_t Stop_HVFlag ;  // 关闭电机标志位（EXIT3 上升沿）
extern uint8_t  count_over_flag ;  
extern uint32_t  nSENS_FUSER_RELEASE ;        // 读打印状态寄存器


extern uint8_t AVR_DATA_start;


extern  int32_t temp_HVPS_Ctrol_REG;//高压控制临时变量

extern volatile uint8_t PageX_Paper_Arrived;
/* =========================
 * 内部静态函数声明
 * ========================= */
static uint8_t Wait_Motor_Ready(uint32_t mask, uint32_t timeout_ms);


extern uint16_t Clutch_CtrlREG;

void    SET_PRT_DATA_PARP ()
{
	*HYNC_REG          =    3963;
//	*Y_PRT_DATA_REG    =    1354;///1515+46   正值方向向右，负值方向向左 1400-46  
//	*M_PRT_DATA_REG    =    1337;
//	*C_PRT_DATA_REG    =    1531;
//	*K_PRT_DATA_REG    =    1602;  //1602-46
	
	*Y_PRT_DATA_REG    =    1440;///1515+46   正值方向向右，负值方向向左 1400-46   1442
	*M_PRT_DATA_REG    =    1420;//正值向右，负值向左1430
	*C_PRT_DATA_REG    =    1629;//蓝的方向是反的，正值向左，负值向右1636
	*K_PRT_DATA_REG    =    1602;  //1602-46
	
}


void	FUSER_Motor_Start()
{
	
	
//	*FUSER_WORK_CTRL_REG 		= 0b000011;
//	
//	//StepMotor_Singlesssss
//	*FUSER_WORK_CTRL_REG        = 0b100000;
//	Delay_ms(50);
//	*FUSER_MOTO_CTRL_REG	 	= 0b000011;
//	Delay_ms(200);
//	*FUSER_WORK_CTRL_REG        = 0b000000;
//	
//	
//	*FUSER_START_CTRL_REG 	= 40000;
//	*FUSER_END_CTRL_REG 		= 9072;//1.1kHz//9090
//	*FUSER_PER_CTRL_REG			= 130;//300
//	*FUSER_WORK_CTRL_REG 		= 0b001100;

	//电机开始阶段，占空比48%，持续时间89.8ms
	*FUSER_WORK_CTRL_REG        = 0b000011;//整个电机复位
	*FUSER_MOTO_CTRL_REG        = 0b000011;//dir正转
	*FUSER_WORK_CTRL_REG        = 0b100000;//单脉冲使能
	*FUSER_FRE_DIV_REG          = 2200;
	*FUSER_High_Time_REG        = 1060;   //48%占空比
	Delay_ms(90);
	//占空比变成89%之后，持续时间112ms，开始电机启动
	*FUSER_High_Time_REG        = 1960;   //89%占空比
	Delay_ms(112);     
//	*FUSER_START_CTRL_REG 	= 40000;
//	*FUSER_WORK_CTRL_REG 		= 0b001100;
//	*FUSER_PER_CTRL_REG			= 108;//300
//	*FUSER_END_CTRL_REG         = 20000;//500Hz
//	Delay_ms(2456);//加速到500Hz需要556ms，之后要等1900ms
//	*FUSER_WORK_CTRL_REG        = 0b000100;//整个电机复位
//	*FUSER_START_CTRL_REG 	= 20000;
//	*FUSER_WORK_CTRL_REG 		= 0b001100;
//	*FUSER_END_CTRL_REG 		= 9040;//1.1kHz  9072
//	*FUSER_PER_CTRL_REG			= 23;//300

	//两段加速过程
    *FUSER_START_CTRL_REG       = 400000;//250Hz
	*FUSER_MID_CTRL_REG         = 200000;//500Hz
	*FUSER_PER_CTRL_REG         = 1080;  //第一段的加速度1-185
	*FUSER_ST_DELAY_REG         = 190000000; //延时1900ms 
	*FUSER_END_CTRL_REG         = 90722; //1.1kHz
	*FUSER_PER_CTRL_REG2        = 230;    //第二段加速度1134 -1609
	*FUSER_WORK_CTRL_REG        = 0b001100;
	
	
}
void	FUSER_Motor_Start_Rev()///fuser电机反转
{
//	*FUSER_WORK_CTRL_REG 		= 0b0011;
//	
//	//StepMotor_Single
//	*FUSER_WORK_CTRL_REG        = 0b100000;
//	Delay_ms(50);
//	*FUSER_MOTO_CTRL_REG	 	= 0b0001;////bit1是方向;
//	Delay_ms(200);
//	*FUSER_WORK_CTRL_REG        = 0b000000;
//	
//	*FUSER_START_CTRL_REG 	= 40000;
//	*FUSER_END_CTRL_REG 		= 16666;//600Hz
//	*FUSER_PER_CTRL_REG			= 300;
//	*FUSER_WORK_CTRL_REG 		= 0b1100;

	//电机开始阶段，占空比48%，持续时间89.8ms
	*FUSER_WORK_CTRL_REG        = 0b000011;//整个电机复位
	*FUSER_MOTO_CTRL_REG        = 0b000001;//dir反转
	*FUSER_WORK_CTRL_REG        = 0b100000;//单脉冲使能
	*FUSER_FRE_DIV_REG          = 2420;
	*FUSER_High_Time_REG        = 1060;   //48%占空比
	Delay_ms(90);
	//占空比变成89%之后，持续时间112ms，开始电机启动
	*FUSER_High_Time_REG        = 1960;   //89%占空比
	Delay_ms(112);     
	
	
//	*FUSER_START_CTRL_REG 	= 40000;
//	*FUSER_END_CTRL_REG 		= 16666;//600Hz
//	*FUSER_PER_CTRL_REG			= 458;//300
//	*FUSER_WORK_CTRL_REG 		= 0b001100;

	//一段加速过程
	*FUSER_START_CTRL_REG       = 400000;//250Hz
	*FUSER_MID_CTRL_REG         = 166667;//600Hz
	*FUSER_PER_CTRL_REG         = 4580;
	*FUSER_ST_DELAY_REG         = 0; //延时
	*FUSER_END_CTRL_REG         = 166667;
	*FUSER_PER_CTRL_REG2        = 0;   
	*FUSER_WORK_CTRL_REG        = 0b001100;
}

void	FUSER_Motor_Stop()
{
	*FUSER_WORK_CTRL_REG 		= 0b0011;
	*FUSER_FRE_DIV_REG          = 0;
	*FUSER_High_Time_REG        = 0;
	*FUSER_START_CTRL_REG 	    = 0;
	*FUSER_END_CTRL_REG 		= 0;
	*FUSER_PER_CTRL_REG			= 0;
}

void	FEED_Motor_Start()
{
	*FEED_WORK_CTRL_REG 		= 0b0011;
	
	*FEED_FRE_DIV_REG          = 2200;
	*FEED_High_Time_REG        = 1760;
	//StepMotor_Single
	*FEED_WORK_CTRL_REG        = 0b100000;
	Delay_ms(200);
	*FEED_WORK_CTRL_REG        = 0b000000;
	
	*FEED_MOTO_CTRL_REG 		= 0b0011;
	*FEED_START_CTRL_REG 		= 389100;//257Hz
	*FEED_END_CTRL_REG 			= 94690;//1.06kHz 9469
	*FEED_PER_CTRL_REG 			= 450;
	*FEED_WORK_CTRL_REG 		= 0b1100;
}

void	FEED_Motor_Stop()
{
	*FEED_WORK_CTRL_REG 		= 0b0011;
	*FEED_FRE_DIV_REG          = 0;
	*FEED_High_Time_REG        = 0;
}

void	BLDC_K_Motor_Start()
{
	*BLDC_K_WORK_CTRL_REG = 0b1010011;//第5、第4位分别为0，1，表示加速到第一个加速段
	*BLDC_K_MOTO_CTRL_REG = 0b1;
	*BLDC_K_START_CTRL_REG = 216450;//初始频率462Hz
	*BLDC_K_NO1_CTRL_REG = 51540;//最终频率1.94kHz
	*BLDC_K_NO2_CTRL_REG = 219780;
	*BLDC_K_PER_CTRL_REG = 1000;
	*BLDC_K_WORK_CTRL_REG = 0b1011100;
}

void	BLDC_K_Motor_Stop()
{
	*BLDC_K_WORK_CTRL_REG = 0b1010011;
}

void	BLDC_YMC_Motor_Start()
{
	*BLDC_YMC_WORK_CTRL_REG = 0b1010011;
	*BLDC_YMC_MOTO_CTRL_REG = 0b1;
	*BLDC_YMC_START_CTRL_REG = 216450;//10989
	*BLDC_YMC_NO1_CTRL_REG = 51540;
	*BLDC_YMC_NO2_CTRL_REG = 219780;
	*BLDC_YMC_PER_CTRL_REG = 1000;
	*BLDC_YMC_WORK_CTRL_REG = 0b1011100;
}

void	BLDC_YMC_Motor_Stop()
{
	*BLDC_YMC_WORK_CTRL_REG = 0b1010011;
}

void	LSU_Motor_Start()
{
	*LSU_WORK_CTRL_REG = 0b00011;
	*LSU_START_CTRL_REG = 23294;
	*LSU_END_CTRL_REG = 23294;
	*LSU_PER_CTRL_REG = 23294;
	*LSU_MOTO_CTRL_REG = 0b0010;
	*LSU_WORK_CTRL_REG = 0b01100;
}

void	LSU_Motor_Stop()
{
	*LSU_WORK_CTRL_REG = 0b00011;
}

void	Clutch_Write(uint32_t OperatingCommand)
{
	*CLUTCH_REG = OperatingCommand;
}

void    delay_1ms()
{
	for (volatile uint32_t i = 0; i < 5548; i++);
}

void Delay_ms(uint32_t delay_ms)
{
    while (delay_ms--)
    {
        delay_1ms();
    }
}
////对齐离合打开 bit0=1
uint16_t RegiCL_Open(uint16_t Operating_Command){
	uint16_t Intermed_Var;
	Intermed_Var=Operating_Command|0X0001;
	*CLUTCH_REG = Intermed_Var;
	return Intermed_Var;
}
////对齐离合关闭 bit0=0
uint16_t RegiCL_Close(uint16_t Operating_Command){
	uint16_t Intermed_Var;
	Intermed_Var=Operating_Command&0XFFFE;
	*CLUTCH_REG = Intermed_Var;
	return Intermed_Var;
}

//// 拾纸离合打开 bit1 = 1
uint16_t PickupCL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0002;
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

//// 拾纸离合关闭 bit1 = 0
uint16_t PickupCL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFFD;   // 清 bit1
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}


//// 定影电磁铁打开 bit2 = 1
uint16_t FuserSOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0004;
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

//// 定影电磁铁关闭 bit2 = 0
uint16_t FuserSOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFFB;   // 清 bit2
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

/////CST_PALTE_SOL离合打开  bit3=1
uint16_t PlateSOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0008; ///bit3置1
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}


////CST_PALTE_SOL离合关闭   bit3=0
uint16_t PlateSOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFF7;   // 清 bit3
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

/////NIP离合打开  bit4=1
uint16_t NipSOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0010; ///bit4置1
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}


////NIP离合关闭   bit4=0
uint16_t NipSOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFEF;   // 清 bit4
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

/////T1离合打开  bit5=1
uint16_t T1_SOL_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0020; ///bit5置1
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}


////T1离合关闭   bit5=0
uint16_t T1_SOL_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFDF;   // 清 bit5
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

/////风扇打开  bit6=1
uint16_t FAN_SMPS_Open(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command | 0x0040; ///bit6置1
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

/////风扇打开  bit6=0
uint16_t FAN_SMPS_Close(uint16_t Operating_Command)
{
    uint16_t Intermed_Var;
    Intermed_Var = Operating_Command & 0xFFBF; ///bit6置0
    *CLUTCH_REG = Intermed_Var;
    return Intermed_Var;
}

void Mot_Register_Initial(void){
	//各寄存器复位 
	Clutch_CtrlREG=0X0000;//离合控制
	//离合、电机控制初始化
     *CLUTCH_REG = Clutch_CtrlREG;//离合
  
}


void All_Motor_Stop(void)
{
    FEED_Motor_Stop();
	Delay_ms(200);
	FUSER_Motor_Stop();
	Delay_ms(200);
	LSU_Motor_Stop();
	Delay_ms(200);
	BLDC_K_Motor_Stop();
	Delay_ms(200);
	BLDC_YMC_Motor_Stop();
    
}

static uint8_t Wait_Motor_Ready(uint32_t mask, uint32_t timeout_ms)
{
    uint32_t cnt = 0;

    while (cnt < timeout_ms)
    {
        if ( (*STATUS_REG & mask) != 0 )
            return 1;   // ready 成功

        Delay_ms(1);
        cnt++;
    }

    return 0;           // 超时失败
}

uint8_t Power_On_Motor_SelfTest(void)
{
    uint8_t Error_flag = 0;

    /* =========================
     * 1. BLDC_YMC 电机自检
     * ========================= */
    BLDC_YMC_Motor_Start();
    Delay_ms(50);

    if (!Wait_Motor_Ready(ST_BLDC_YMC_READY, 300))
    {
        Error_flag |= ERR_BLDC_YMC;
        BLDC_YMC_Motor_Stop();
        //printf("BLDC_YMC Motor Self-Test FAIL\r\n");
    }
    else
    {
        //printf("BLDC_YMC Motor OK\r\n");
    }

    BLDC_YMC_Motor_Stop();
    Delay_ms(20);

    /* =========================
     * 2. BLDC_K 电机自检
     * ========================= */
    BLDC_K_Motor_Start();
    Delay_ms(50);

    if (!Wait_Motor_Ready(ST_BLDC_K_READY, 300))
    {
        Error_flag |= ERR_BLDC_K;
        BLDC_K_Motor_Stop();
		//printf("BLDC_K Motor Self-Test FAIL\r\n");
    }
    else
    {
        //printf("BLDC_K Motor OK\r\n");
    }

    BLDC_K_Motor_Stop();
    Delay_ms(20);

    /* =========================
     * 3. LSU 电机自检
     * ========================= */
    LSU_Motor_Start();
    Delay_ms(20);

    if (!Wait_Motor_Ready(ST_LSU_READY, 200))
    {
        Error_flag |= ERR_LSU_MOTOR;
        LSU_Motor_Stop();
        //printf("LSU Motor Self-Test FAIL\r\n");
    }
    else
    {
        //printf("LSU Motor OK\r\n");
    }

    LSU_Motor_Stop();
    Delay_ms(20);

    /* =========================
     * 4. FEED 电机自检
     *   （无 ready 位，仅做动作确认）
     * ========================= */
    FEED_Motor_Start();
    Delay_ms(100);
    FEED_Motor_Stop();

    //printf("FEED Motor Action Checked\r\n");

    return Error_flag;
}

////////////////////////////////////////////////////打印机状态信号初始化/////////////////////////////////////////////////////
void Printer_Para_init()
{
    //PaperFeed     = 1;//进纸方式 纸盘进纸
    Printed_Page  = 0;//当前已打印页数寄存器	
	PageX_Paper_Arrived = 0;
    *PrintedPageNum_REG = Printed_Page;//更新已打印页数
    PrintPage 	  = 0;//打印页数寄存器
	Mode_Finish = 0;//参数设置完成标志
    CMD_Start 	  = 0;//打印开始命令
    StopPrint 	  = 0;//停止打印命令
    TaskStart 	  = 0; //作业开始命令
	again_paper   = 0;
	
    ErrorStatusReg = 0X0080;//错误寄存器1    先置0080 ，然后自检，自检出错则	强制停止
	*ErrorCode_REG = ErrorStatusReg;//初始化错误寄存器
	
    PrintModeReg   = 0X0000;//打印模式寄存器
	Clutch_CtrlREG = 0X0000;
	
    PrintCtrlReg   = 0X0000;//命令控制寄存器
	Page_sync_printed = 0;
	
    //PrnSensorReg   = FSMC_Read(0x2D);//纸张传感器寄存器(卡纸)
	
	//FSMC_Write(0x32,0x8000);  ///打印头逻辑复位信号 bit15=1
	
	//////////////时间变量初试化/////////////
}

////////////////////////////////////////打印过程的计数器、变量初始化 每打印一张都需要进行初始化///////////////////////////////////////
void Printer_Var_Init(){
//走纸过程中计数器、标志位、变量初始化

	SENS_RegiHflag = 0;
    SENS_RegiLflag = 0;

    SENS_FeedHflag = 0;
    SENS_FeedLflag = 0;

    SENS_ExitHflag = 0;
    SENS_ExitLflag = 0;

    PrintStartHflag = 0;
    PrintStartLflag = 0;

    K_SyncHflag = 0;
    K_SyncLflag = 0;
	
	Stop_MotorFlag=0;
	
	//计数器清零
	timetest1 =0;
	SENS_RegiL_timer1=0;
	SENS_RegiL_timer2=0;
	SENS_RegiH_timer=0;
	K_SyncH_time1=0;
	
	CMD_Start = 0;        // 开始打印命令
  StopPrint = 0;        // 结束打印命令
  PaperFeed = 1;        // 进纸方式
 SendPage = 0;
 PaperFeedPre = 0;     // 进纸方式
 Mode_Finish = 0;      // 参数设置完成标志
 PrintPage = 0;        // 打印页数
  //PrintStyle;           // 打印方式：单/双面（当前未使用）
  PaperType = 0x38;     // 纸张类型
  DataFinsh = 0;        // 打印数据下传完成
 Printed_Page = 0;     // 已打印页数
  TaskStart = 0;        // 作业开始命令
  DataReady = 0;        // 打印数据下传完成
  DPI_Choose = 0;       // 0:600DPI, 1:1200DPI
  Douflag = 1;          // 1:单面, 0:双面
  Color_Choose = 0;     // 0:黑白, 1:彩色
  ReSet = 0;            // ARM 同步信号
   ERROR_CPU = 1;   
  Heat_Ready=0; 
  HV_Ready = 0; 
  heat_is_timeout = 1;///超时初始值为1

  again_paper=0;

	Page_sync_printed = 0;     // 已经发送的pagesync
 Page_sync_print = 0;     // 需要发送的pagesync 


	Next_Page_Sync_Enable=0;
	Next_Page_Sync_Timer=0;
 nSENS_FUSER_RELEASE = 0;
 Stop_HVFlag = 0;

 


}

void PrintHead_RST_ON()
{
	*PRINTHEAD_REG = 0x00000001;
}

void PrintHead_INITMODE_ON()
{
	*PRINTHEAD_REG = 0x0000000A;
}

void PrintHead_PRINTMODE_ON()
{
	*PRINTHEAD_REG = 0x00000006;
}

void PrintHead_Initial()
{
	//初始化定义行数据、行数、以及纸张到激光头的时间
	*ByteNum_Per_Line_REG = 620;
	*LineNum_Per_Page_REG = 7016;
	*PageNum_Per_Job      = 1;
	
//*CYC_ST_DATA_Y_REG      = 0;
	//*CYC_ST_DATA_M_REG      = 13134372;  //70mm对应13134372 
	//*CYC_ST_DATA_C_REG      = 26268744;
	//*CYC_ST_DATA_K_REG      = 39403116;
	
	
	*CYC_ST_DATA_Y_REG      = 0;
	*CYC_ST_DATA_M_REG      = 13322005;  //70mm对应13134372 
	*CYC_ST_DATA_C_REG      = 26475140;
	*CYC_ST_DATA_K_REG      = 39684565;


//	*CYC_ST_DATA_K_REG      = 0;
//	*CYC_ST_DATA_Y_REG      = 0;
//	*CYC_ST_DATA_M_REG      = 0;
//	*CYC_ST_DATA_C_REG      = 0;
	
	
	*Start_Line_Reg         = 0;
	*End_Line_Reg           = 200;
	
	*PRINTHEAD_REG = 0b00001;	//RST PH Module
//	LSU_Motor_Start();
	while((*STATUS_REG)&0b0001)	;
	Delay_ms(20);
	*PRINTHEAD_REG = 0b00010;	//RST PH Module
	delay_1ms();
	*PRINTHEAD_REG = 0b01010;	//RST PH Module
}

void PrintHead_PrintMode_Set()
{
	*PRINTHEAD_REG = 0b00110;
}

void Page_Sync_ON()
{
	//*PRINTHEAD_REG = 0b00110;
	//Delay_ms(20);
	*PRINTHEAD_REG = 0b10110;
}

void Page_Sync_Close()
{	
	*PRINTHEAD_REG = 0b00110;
}

void fuser_release(){///fuser电机释放
	
	*Fuser_Count_Num_REG 	=110;
	Delay_ms(10);
	nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
	FUSER_Motor_Start_Rev();
	//Delay_ms(5);
	while (nSENS_FUSER_RELEASE==0) {
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
		if (nSENS_FUSER_RELEASE==1) {///变高后跳出
			break;
		}
	}
	while (nSENS_FUSER_RELEASE==0x0020) {
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
		if (nSENS_FUSER_RELEASE==0) {
			*Fuser_Count_Enable_REG=0x0001;
			break;							
		}
		
	}
		///运行110		
			
	count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
	while (count_over_flag == 0) {
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
	}			
	FUSER_Motor_Stop();
	*Fuser_Count_Enable_REG = 0x0000;
	*Fuser_Count_Num_REG 	=0;
}

void fuser_clamping(){///fuser电机压紧
	
	
	*Fuser_Count_Num_REG 	=46;//48		
	Delay_ms(10);
	nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
	FUSER_Motor_Start_Rev();
	//持续检测传感器 
	while (nSENS_FUSER_RELEASE==0) {
		nSENS_FUSER_RELEASE = *SENS_REG & SENS_Fuser_Release;
		if (nSENS_FUSER_RELEASE==0x0020) {///变高后跳出
			*Fuser_Count_Enable_REG=0x0001;
			break;
		}
	}
	///运行48步
//	*Fuser_Count_Reset_REG = 0b1;
//	*Fuser_Count_Num_REG 	=48;			
	count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
	while (count_over_flag == 0) {
		count_over_flag = (*SENS_REG & 0x0080) > 0 ? 1 : 0;
	}			
	FUSER_Motor_Stop();
	*Fuser_Count_Enable_REG = 0x0000;
	*Fuser_Count_Num_REG 	=0;	
}

void Heat_Open(){
		
		Delay_ms(100);
		*ADC_HeaterCtrl_REG=0x0001;//ADC复位  定影复位
		AVR_DATA_start=1;
		Delay_ms(300);

		*ADC_HeaterCtrl_REG = 0b1001;///定影模块使能 bit3=1
		while (ERROR_CPU == 1) 
		{
			ERROR_CPU = (*ERROR_CPU_REG & 0x0002) ? 1 : 0;
			if (ERROR_CPU == 0) 
			{
				*ADC_HeaterCtrl_REG = 0b1101;
				break;
			}				
		}
}
void Heat_Close(){
	*ADC_HeaterCtrl_REG = 0b0101;
	while (ERROR_CPU == 0)
	{
		ERROR_CPU = (*ERROR_CPU_REG & 0x0002) ? 1 : 0;
		if (ERROR_CPU == 1)
		{
			*ADC_HeaterCtrl_REG = 0b0001;
			break;
		}
	}
}


void check_temperature(){
	unsigned int Heat_Count=0;
	Heat_Ready= (*ERROR_CPU_REG & 0x0001) ? 1 : 0;
	while (Heat_Ready==0) {
			
			Heat_Ready= (*ERROR_CPU_REG & 0x0001) ? 1 : 0;
			Heat_Count++;
			if (Heat_Count>=1000) {
				///关加热
				Heat_Close();
				Delay_ms(5000);
				//关电机
				All_Motor_Stop();//关闭电机
				//释放fuser电机
				Delay_ms(100);
				fuser_release();
				return;
			}
		}
}

void check_temperature2(void)
{
    unsigned int Heat_Count = 0;
    
    for (Heat_Count = 0; Heat_Count < 9; Heat_Count++)
    {
        // 读取就绪标志
        Heat_Ready = (*ERROR_CPU_REG & 0x0001) ? 1 : 0;
        
        if (Heat_Ready == 1)
        {
            heat_is_timeout = 0; // 5s内读到就绪，未超时
            break; // 跳出循环，正常向下执行，不关机
        }
        // 未就绪，延时1s再检测下一次
        Delay_ms(1000);
    }

    // 仅超时才执行关机流程
    if (heat_is_timeout == 1)
    {
        //关加热
        Heat_Close();
        Delay_ms(5000);
        //关电机
        All_Motor_Stop();
        //释放fuser电机
        Delay_ms(100);
        fuser_release();
				
    }
    // 未超时：直接结束函数，不执行任何关机操作

}
	

void SET_PRT_DATA_PARP2(void)
{
    //除数定值
    float CONVERT_FACTOR = 23294.0f; 

    // 如除数意外为 0，直接退出，防止除零死机
    if (CONVERT_FACTOR == 0.0f) return; 

    // C的 X 和 Y 偏差脉冲
    int32_t offset_c_x = ROUND( (*REG_T_KKR - *REG_T_CCR) / CONVERT_FACTOR ); // T_kkr - T_ccr
    int32_t offset_c_y = ROUND( (*REG_T_KCR - *REG_T_KCL) / CONVERT_FACTOR ); // T_kcr - T_kcl

    // M的 X 和 Y 偏差脉冲
    int32_t offset_m_x = ROUND( (*REG_T_KKR - *REG_T_MMR) / CONVERT_FACTOR ); // T_kkr - T_mmr
    int32_t offset_m_y = ROUND( (*REG_T_KMR - *REG_T_KML) / CONVERT_FACTOR ); // T_kmr - T_kml

    // Y 的 X 和 Y 偏差脉冲
    int32_t offset_y_x = ROUND( (*REG_T_KKR - *REG_T_YYR) / CONVERT_FACTOR ); // T_kkr - T_yyr
    int32_t offset_y_y = ROUND( (*REG_T_KYR - *REG_T_KYL) / CONVERT_FACTOR ); // T_kyr - T_kyl


    int32_t final_y = 1400 + offset_y_x;
    int32_t final_m = 1337 + offset_m_x;
    int32_t final_c = 1531 + offset_c_x;

    // 寄存器安全限幅保护：防止计算越界
    if(final_y < 0) final_y = 0; else if(final_y > 65535) final_y = 65535;
    if(final_m < 0) final_m = 0; else if(final_m > 65535) final_m = 65535;
    if(final_c < 0) final_c = 0; else if(final_c > 65535) final_c = 65535;

	
    // 写入真实的物理目标寄存器
    *HYNC_REG         = 3963;
    *Y_PRT_DATA_REG   = (uint32_t)final_y;
    *M_PRT_DATA_REG   = (uint32_t)final_m;
    *C_PRT_DATA_REG   = (uint32_t)final_c;
    *K_PRT_DATA_REG   = 1602;
}

void Color_Separation(){
	//启动电机
	FEED_Motor_Start();
	Delay_ms(200);	
	fuser_clamping();
	Delay_ms(1170);
	FUSER_Motor_Start();
	Delay_ms(100);
	LSU_Motor_Start();
	Delay_ms(100);
	BLDC_K_Motor_Start();
	Delay_ms(100);		
	BLDC_YMC_Motor_Start();
	
	*HVCtrl_PrintPage_REG = 1 ;//打印页数发给高压
	//发套色指令
		temp_HVPS_Ctrol_REG |= 0x0040;//bit6 SYN_HV_EN，bit9 发送套色指令给高压，并启动高压
		*HVCtrl_REG =temp_HVPS_Ctrol_REG;

	//启动高压
	
	//等待打图像的Ready信号
	unsigned int ACR_Ready_Count = 0;
	uint8_t ACR_Ready_timeout = 1;
	uint8_t ACR_Ready=0;
	for (ACR_Ready_Count = 0; ACR_Ready_Count < 5; ACR_Ready_Count++)
		{
			// 读取就绪标志
			ACR_Ready = (*STATUS_REG & 0x0020) ? 1 : 0;
        
			if (ACR_Ready == 1)
			{
				ACR_Ready_timeout = 0; // 5s内读到就绪，未超时
				printf("ACR_Ready\n");	
				break; // 跳出循环，正常向下执行，不关机
			}
			// 未就绪，延时1s再检测下一次
			Delay_ms(1000);
		}

		// 仅超时才执行关机流程
		if (ACR_Ready_timeout == 1)
		{
			printf("ACR_is_timeout\n");	
			//关加热
			//Heat_Close();
			Delay_ms(5000);
			//关电机
			All_Motor_Stop();
			//释放fuser电机
			Delay_ms(100);
			fuser_release();
			Delay_ms(500);
			return;
    } 
	//发pagesync
	Page_Sync_ON();
	//延迟1.8s
	Delay_ms(1800);
	//等待参数
	unsigned int AcrPara_Ready_Count = 0;
	uint8_t AcrPara_Ready_timeout = 1;
	uint8_t AcrPara_Ready=0;
	for (AcrPara_Ready_Count = 0; AcrPara_Ready_Count < 5; AcrPara_Ready_Count++)
		{
			// 读取就绪标志
			AcrPara_Ready = (*STATUS_REG & 0x0040) ? 1 : 0;
        
			if (AcrPara_Ready == 1)
			{
				AcrPara_Ready_timeout = 0; // 5s内读到就绪，未超时
				printf("AcrPara_Ready\n");	
				break; // 跳出循环，正常向下执行，不关机
			}
			// 未就绪，延时1s再检测下一次
			Delay_ms(1000);
		}

		// 仅超时才执行关机流程
		if (AcrPara_Ready_timeout == 1)
		{
			printf("AcrPara_is_timeout\n");	
			//关加热
			//Heat_Close();
			Delay_ms(5000);
			//关电机
			All_Motor_Stop();
			//释放fuser电机
			Delay_ms(100);
			fuser_release();
			Delay_ms(500);
			return;
    } 
	//公式计算 赋值
	SET_PRT_DATA_PARP2();
	
}
