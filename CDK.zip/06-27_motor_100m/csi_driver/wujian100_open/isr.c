/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */


/******************************************************************************
 * @file     isr.c
 * @brief    source file for the interrupt server route
 * @version  V1.0
 * @date     02. June 2019
 ******************************************************************************/
#include <drv_common.h>
#include <csi_config.h>
#include "soc.h"
#include "MotorCtrl.h"
#include <stdio.h>

#ifndef CONFIG_KERNEL_NONE
#include <csi_kernel.h>
#endif

extern void wj_oip_timer_irqhandler(int32_t idx);
extern void wj_oip_gpio_irqhandler(int32_t idx);
extern void systick_handler(void);
extern void xPortSysTickHandler(void);
extern void OSTimeTick(void);
extern void wj_pwm_irqhandler(int32_t idx);
extern void wj_rtc_irqhandler(int32_t idx);
extern void wj_usi_irqhandler(int32_t idx);
extern void wj_oip_wdt_irqhandler(int32_t idx);
extern void wj_dma_irqhandler(int32_t idx);

#define  ATTRIBUTE_ISR

#define readl(addr) \
    ({ unsigned int __v = (*(volatile unsigned int *) (addr)); __v; })

#ifndef CONFIG_KERNEL_NONE
#define  CSI_INTRPT_ENTER() csi_kernel_intrpt_enter()
#define  CSI_INTRPT_EXIT()  csi_kernel_intrpt_exit()
#else
#define  CSI_INTRPT_ENTER()
#define  CSI_INTRPT_EXIT()
#endif



// ================= SENS_Regi =================
extern volatile uint8_t SENS_Regi[2];
extern volatile uint8_t SENS_RegiHflag;
extern volatile uint8_t SENS_RegiLflag;

// ================= SENS_Feed =================
extern volatile uint8_t SENS_Feed[2];
extern volatile uint8_t SENS_FeedHflag;
extern volatile uint8_t SENS_FeedLflag;

// ================= SENS_Exit =================
extern volatile uint8_t SENS_Exit[2];
extern volatile uint8_t SENS_ExitHflag;
extern volatile uint8_t SENS_ExitLflag;


// ================= SENS_Fuser =================
extern volatile uint8_t SENS_Fuser[2];
extern volatile uint8_t SENS_FuserHflag;
extern volatile uint8_t SENS_FuserLflag;



extern volatile uint8_t  PrintStart[2] ; //33H RD  PrintHead_State_nRCS  Bit4:Print_Once_Start打印头start信号
extern volatile uint8_t PrintStartHflag ;   //
extern volatile uint8_t  PrintStartLflag ;   //

extern volatile uint8_t   K_Sync[2] ; //33H RD  PrintHead_State_nRCS bit0：PrintPageK_Sync	打印头K同步信号
extern volatile uint8_t   K_SyncHflag ;   //
extern volatile uint8_t   K_SyncLflag ;   //

extern volatile uint32_t time_flag_count;
extern volatile uint32_t time_flag_count_A;
extern volatile uint32_t time_flag_count_B;
extern volatile uint32_t time_flag_count_C;



/* Regi 离合 */
extern uint16_t RegiCL_Open(uint16_t Operating_Command);
extern uint16_t RegiCL_Close(uint16_t Operating_Command);

/* Pickup 离合 */
extern uint16_t PickupCL_Open(uint16_t Operating_Command);
extern uint16_t PickupCL_Close(uint16_t Operating_Command);

/* Fuser 电磁铁 */
extern uint16_t FuserSOL_Open(uint16_t Operating_Command);
extern uint16_t FuserSOL_Close(uint16_t Operating_Command);

extern volatile uint8_t TimeInitial;//定时器开启标志
//////寄存器设置
extern uint16_t Clutch_CtrlREG;//pickup离合 regiCL离合 fuser_sol离合
///测试计数
extern volatile uint32_t timetest1;
extern volatile uint32_t SENS_RegiL_timer1;
extern volatile uint32_t SENS_RegiL_timer2;
extern volatile uint32_t SENS_RegiH_timer;
extern volatile uint32_t K_SyncH_time1;
extern volatile uint32_t SENS_ExitH_timer;
/////hv
extern volatile uint32_t SENS_RegiL_timer_HV;
extern int32_t temp_HVPS_Ctrol_REG;//高压控制临时变量

extern uint16_t Printed_Page ;//已打印页数
extern uint8_t Oddflag;//奇偶判断
extern uint8_t Oddcountflag;//奇偶判断后计数标志
extern uint32_t Oddcount;//奇偶判断后计数
extern uint8_t  Douflag;//0是单面打印，1是双面打印
extern uint8_t  StopPrint;

///上纸时刻
extern volatile uint32_t  PaperTime;
extern volatile uint32_t  HopCL_StopTime1;
extern volatile uint32_t  NextPaperTime1;//控制首页与第二页之间纸张之间的间隔，目前间隔为200ms
extern volatile uint32_t  NextPaperTime2;//控制第二页及以后页之间的间隔
extern volatile uint16_t  again_paper;
extern volatile uint16_t  Stop_MotorFlag;///关闭电机标志位，EXIT3上升沿关闭

extern volatile int PageSync_Enable; 
extern volatile int PageSync_Timer;
extern volatile uint16_t Next_Page_Sync_Enable;
extern volatile uint16_t Next_Page_Sync_Timer;
extern volatile uint16_t Page_sync_printed;     // 已经发送的pagesync
extern volatile uint16_t Page_sync_print;     // 需要发送的pagesync
extern volatile uint8_t  DataFinsh;
uint8_t  time1=0;
uint8_t  time2=0;
uint8_t  time3=0;

extern uint8_t  fuser_count_flag;  

extern uint32_t  fuser_count ;  
extern uint8_t  count_over_flag ;  

extern uint8_t count;
extern uint8_t AVR_flag;	
extern uint32_t AVR_C_DATA;
extern uint32_t AVR_D_DATA;
extern uint8_t AVR_DATA_start;




ATTRIBUTE_ISR void CORET_IRQHandler(void)
{
#ifndef CONFIG_KERNEL_FREERTOS
    CSI_INTRPT_ENTER();
#endif

    readl(0xE000E010);

#if defined(CONFIG_KERNEL_RHINO)
    systick_handler();
#elif defined(CONFIG_KERNEL_FREERTOS)
    xPortSysTickHandler();
#elif defined(CONFIG_KERNEL_UCOS)
    OSTimeTick();
#endif

#ifndef CONFIG_KERNEL_FREERTOS
    CSI_INTRPT_EXIT();
#endif
}

extern int32_t flag;
// interrupt handler process for timer0~4
ATTRIBUTE_ISR void TIM0_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    //wj_oip_timer_irqhandler(0);
	/**
	 *  1us ---- 20ns  ---- 10 intructions
	 *  reload 1us 
	 * **/
	// timer0 1us process instructions
	//
	/*
	if (AVR_DATA_start==1) {
		count++;
		if (count>=10) {
			AVR_flag=1;
		}
		if (AVR_flag==1) {
		///读
		
			AVR_C_DATA = *AVR_C_DATA_REG;
			//time1++;
			AVR_D_DATA = *AVR_D_DATA_REG;
			//printf("time1=%d\n",time1);			
			printf("AVR_C_DATA %d  AVR_D_DATA%d\n",AVR_C_DATA,AVR_D_DATA);
			
			count=0;
			AVR_flag=0;
			
		}
	}
	 */
	
	time_flag_count++;
	
	
	
	
	if(TimeInitial==1){
		
		///中断事件
		//三个传感器
		//SENS_Regi   SENS_REG[0]
		//SENS_Feed   SENS_REG[1]
		//SENS_Exit   SENS_REG[2]
		//三个离合
		//pickupCL  Cluth_REG[1]
		//RegiCL    Cluth_REG[0]
		//Fuser_SOL Cluth_REG[2]
		//flag++;
		/////////////////////////////////// SENS_Regi /////////////////////////////////////////////
		SENS_Regi[0] = SENS_Regi[1];
		SENS_Regi[1] = ((*SENS_REG & SENS_REGI_BIT) > 0) ? 1 : 0;

		if (SENS_Regi[0] == 1 && SENS_Regi[1] == 0)
		{
			SENS_RegiLflag = 1;
		}
		else if (SENS_Regi[0] == 0 && SENS_Regi[1] == 1)
		{
			SENS_RegiHflag = 1;
		}
		
		///////////////////////////////////// SENS_Feed /////////////////////////////////////////////
		SENS_Feed[0] = SENS_Feed[1];
		SENS_Feed[1] = ((*SENS_REG & SENS_FEED_BIT) > 0) ? 1 : 0;

		if (SENS_Feed[0] == 1 && SENS_Feed[1] == 0)
		{
			SENS_FeedLflag = 1;
		}
		else if (SENS_Feed[0] == 0 && SENS_Feed[1] == 1)
		{
			SENS_FeedHflag = 1;
		}
		
		///////////////////////////////////// SENS_Exit /////////////////////////////////////////////
		SENS_Exit[0] = SENS_Exit[1];
		SENS_Exit[1] = ((*SENS_REG & SENS_EXIT_BIT) > 0) ? 1 : 0;

		if (SENS_Exit[0] == 1 && SENS_Exit[1] == 0)
		{
			SENS_ExitLflag = 1;
		}
		else if (SENS_Exit[0] == 0 && SENS_Exit[1] == 1)
		{
			SENS_ExitHflag = 1;
			
		}
		////////fuser_step_sens
//		SENS_Fuser[0] = SENS_Fuser[1];
//		SENS_Fuser[1] = ((*SENS_REG & SENS_Fuser_Mort) > 0) ? 1 : 0;
//
//		if (SENS_Fuser[0] == 1 && SENS_Fuser[1] == 0)
//		{
//			SENS_FuserLflag = 1;
//		}
//		else if (SENS_Fuser[0] == 0 && SENS_Fuser[1] == 1)
//		{
//			SENS_FuserHflag = 1;
//			
//		}
//		
//		if (fuser_count_flag ==1) {
//			if (SENS_FuserHflag==1) {
//				fuser_count++;
//				SENS_FuserHflag=0;
//			}
//			if (fuser_count==110) {
//				fuser_count_flag=0;
//				count_over_flag=1;
//			}
//		}
		
		
		//Page_SYNC 脉宽控制逻辑 ---
		if (PageSync_Enable == 1) {
			PageSync_Timer++;    
    // 满 10ms 后拉低信号并停止计时
			if (PageSync_Timer >= 10) { 
				Page_Sync_Close();   // 拉低 Page_SYNC 信号
				PageSync_Enable = 0; //关闭 Enable
				PageSync_Timer = 0;  // 计数器清零
				Page_sync_printed++; 
				Page_sync_print = *PrintPage_REG & 0x000F;
				StopPrint = (*PrintCtrl_REG & 0x0008) > 0 ? 1 : 0;
				Next_Page_Sync_Enable=1;
			}
		} else {
    // --- 如果 PageSync_Enable 为 0 (空闲状态) ---
			Page_Sync_Close(); 
			PageSync_Timer = 0; 
		}
		
	if (Page_sync_printed==1) {
		if (Next_Page_Sync_Enable==1) {
			Next_Page_Sync_Timer++;
		}
		if (Next_Page_Sync_Timer==2016) {
			if (Page_sync_printed < Page_sync_print){
				Page_Sync_ON();      // 提前开启下一页的信号
				PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
				Next_Page_Sync_Timer = 0;  // 清零，准备算10ms
				Next_Page_Sync_Enable=0;
			}
		}	
	}	
	
		
		
		//////////////////打印头start信号//////////暂时先不读取，在main函数中直接置PrintStartHflag = 1;	
			
//            PrintStart[0] = PrintStart[1];
//            //PrintStart[1] = (FSMC_Read(0x33)&0X0010)>0?1:0; 读打印头发送的开始信号
//            if(PrintStart[0]==1 && PrintStart[1]==0) {
//               PrintStartLflag = 1;        
//			}else if(PrintStart[0]==0 && PrintStart[1]==1){	
//				PrintStartHflag = 1;	
//			}
		//////////////////打印头K同步信号 
			 
//            K_Sync[0] = K_Sync[1];
//            K_Sync[1] = (FSMC_Read(0x33)&0X0001)>0?1:0;///K
//			// K_Sync[1] = (FSMC_Read(0x33)&0X0008)>0?1:0;///Y
//            if(K_Sync[0]==1 && K_Sync[1]==0) {
//				timetest4++;//测试变量
//				if(Flag_First_K == 0){
//				K_SyncLflag = 1;  				
//				Flag_First_K ++;////置1					
//				}              		
//			}else if(K_Sync[0]==0 && K_Sync[1]==1){
//				K_SyncHflag = 1;
//			
//			}			
		
		
	
		/////////////开始动作//////////
		
/////////////regCL关的时间////////////如果未来能够使得两个电机速度一样 就可以由传感器上升沿关闭对齐离合
		
		if(SENS_RegiHflag==1){
				//printf("SENS_RegiHflag==1\n");	
				SENS_RegiH_timer++;
										
			}
			if(SENS_RegiH_timer==18){	//检测到sens_regi上升沿后18ms，关闭regcl			
					
				Clutch_CtrlREG=RegiCL_Close(Clutch_CtrlREG);//关regi离合
				//printf("RegiCL_Close\n");			
				SENS_RegiHflag=0;	
				SENS_RegiH_timer = 0;			
				
			}

			if(SENS_ExitHflag==1){
				//printf("SENS_ExitHflag==1\n");
				SENS_ExitH_timer++;
			
			}
			if(SENS_ExitH_timer==200){
				Stop_MotorFlag=1;
				SENS_ExitH_timer=0;
				SENS_ExitHflag=0;
			}

		if(Printed_Page==0){//打印第一页时 

			if(SENS_RegiLflag==1){
				//temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
				//*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
				//printf("SENS_RegiLflag==1\n");
				SENS_RegiL_timer1++;
			} 
			if (SENS_RegiL_timer1 == 43) { 
//				if (Page_sync_printed < Page_sync_print) {
//					Page_Sync_ON();      // 提前开启下一页的信号
//					//printf("Page_Sync_ON\n");
//					PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
//					PageSync_Timer = 0;  // 清零，准备算10ms
//				}
				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关pickup离合

			}
			if(SENS_RegiL_timer1==158){
				time1=1;
				Clutch_CtrlREG=RegiCL_Open(Clutch_CtrlREG);//开对齐离合
				Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
				time_flag_count_C=time_flag_count;
				//printf("RegiCL_Open\n");
			}
			
			if(SENS_RegiL_timer1==188){
				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关pickup离合
				//printf("PickupCL_Close\n");
				//temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
				//*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
				time2=1;
			}
			if (SENS_RegiL_timer1 == 840) { //859  图发早一点，在纸张上向上调整
				if ((Page_sync_printed < Page_sync_print)&&(Page_sync_printed>=2)) {
					Page_Sync_ON();      // 提前开启下一页的信号
					
					PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
					PageSync_Timer = 0;  // 清零，准备算10ms
				}
			}
			if (SENS_RegiL_timer1==NextPaperTime1) {///该值为已经测试好的值
				again_paper=1;
				SENS_RegiL_timer1=0;
				SENS_RegiLflag=0;
			
			}
		}
		if (Printed_Page > 0) {
			if(SENS_RegiLflag == 1){
				//temp_HVPS_Ctrol_REG|= 0x0080;//0b111010010;//bit7 PICK_UP	
				//*HVCtrl_REG =temp_HVPS_Ctrol_REG;	
				//printf("SENS_RegiLflag == 1\n");
				SENS_RegiL_timer2++;									
				}
			if (SENS_RegiL_timer2 == 43) { 

				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关pickup离合

			}
			if (SENS_RegiL_timer2==158) {
				Clutch_CtrlREG=RegiCL_Open(Clutch_CtrlREG);//开对齐离合
				Clutch_CtrlREG=PickupCL_Open(Clutch_CtrlREG);//开pickup离合
				//printf("RegiCL_Open\n");		
			
			}
			if (SENS_RegiL_timer2==188) {
				Clutch_CtrlREG=PickupCL_Close(Clutch_CtrlREG);//关进纸离合	
				//printf("PickupCL_Close\n");	
				//temp_HVPS_Ctrol_REG &=0xFF7F ;//0b101010010;//bit PICK_UP
				//*HVCtrl_REG =temp_HVPS_Ctrol_REG;
			
			}
			if (SENS_RegiL_timer2 == 830) { ///859 840
				if ((Page_sync_printed < Page_sync_print)&&(Page_sync_printed>=2)) {
					Page_Sync_ON();      // 提前开启下一页的信号
					//printf("Page_Sync_ON\n");
					PageSync_Enable = 1; // 启动 PageSync 计时器来控制 10ms 脉宽
					PageSync_Timer = 0;  // 清零，准备算10ms
				}
			}
			if (SENS_RegiL_timer2==NextPaperTime2) {///该值为已经测试好的值
				again_paper=1;
				SENS_RegiL_timer2=0;
				SENS_RegiLflag=0;	
			
			}		
			
		}
	}
	// clear interrupt Timer1_int_clr
	*((volatile uint32_t *)(0x50000000 + 0x0c));  // tim0
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM1_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    //wj_oip_timer_irqhandler(1);
	/*
	 * 
	 * 
	 * 
	 * 
	 */

 
	*((volatile uint32_t *)(0x60000000 + 0x0c));  // tim1
    CSI_INTRPT_EXIT();
}
ATTRIBUTE_ISR void TIM2_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    //wj_oip_timer_irqhandler(2);
	/*
	 * 
	 * 
	 * 
	 * 
	 */
	 
	 
	 
	 
	 
	*((volatile uint32_t *)(0x50000400 + 0x0c));  // tim2
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM3_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    //wj_oip_timer_irqhandler(3);
	/*
	 * 
	 * 
	 * 
	 * 
	 */
	
	*((volatile uint32_t *)(0x60000400 + 0x0c));  // tim3
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM4_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(4);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM5_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(5);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM6_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(6);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM7_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(7);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM8_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(8);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM9_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(9);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM10_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(10);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM11_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(11);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM12_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(12);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM13_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(13);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM14_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(14);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void TIM15_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_timer_irqhandler(15);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void PWM_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_pwm_irqhandler(0);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void RTC_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_rtc_irqhandler(0);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void USI0_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_usi_irqhandler(0);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void USI1_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_usi_irqhandler(1);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void USI2_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_usi_irqhandler(2);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void WDT_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_wdt_irqhandler(0);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void DMAC0_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_dma_irqhandler(0);
    CSI_INTRPT_EXIT();
}

ATTRIBUTE_ISR void GPIO0_IRQHandler(void)
{
    CSI_INTRPT_ENTER();
    wj_oip_gpio_irqhandler(0);
    CSI_INTRPT_EXIT();
}
