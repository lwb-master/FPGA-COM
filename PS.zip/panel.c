/*
 * panel.c - 串口面板显示库实现
 *
 * 内部包含：串口操作、显示协议、按键解析、IP 编辑器、状态机
 * 对外暴露：panel_init / panel_close / panel_set_ip / panel_get_ip / panel_run
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <stdint.h>

#include "panel.h"

/* ================================================================
 * 内部常量
 * ================================================================ */

#define SERIAL_DEVICE       "/dev/ttyS1"
#define SERIAL_BAUDRATE     B9600

#define DISPLAY_WIDTH       32
#define FRAME_HEADER0       0x11
#define FRAME_HEADER1       0xA1
#define FRAME_HEADER2       0x21
#define FRAME_SIZE          (DISPLAY_WIDTH + 4)

#define LCD_CHAR_SPACE      0x20
#define LCD_CHAR_CURSOR     0x5F    /* '_' */
#define LCD_CHAR_DOT        0x2E    /* '.' */

/* "就绪" 的硬件字符 ROM 编码 */
#define READY_CHAR0         0xE1
#define READY_CHAR1         0xC1
#define READY_CHAR2         0xF3
#define READY_CHAR3         0xA5

/* 按键协议常量 */
#define KEY_SUFFIX          0xAF

/* 功能键码 */
#define KEY_CODE_ECO        0x55
#define KEY_CODE_COPY       0x56
#define KEY_CODE_CCPWR      0x78
#define KEY_CODE_OK         0x75
#define KEY_CODE_UP         0x45
#define KEY_CODE_DOWN       0x46
#define KEY_CODE_LEFT       0x47
#define KEY_CODE_RIGHT      0x48
#define KEY_CODE_1          0x15
#define KEY_CODE_2          0x25
#define KEY_CODE_3          0x35
#define KEY_CODE_4          0x16
#define KEY_CODE_5          0x26
#define KEY_CODE_6          0x36
#define KEY_CODE_7          0x17
#define KEY_CODE_8          0x27
#define KEY_CODE_9          0x37
#define KEY_CODE_STAR       0x18
#define KEY_CODE_0          0x28
#define KEY_CODE_HASH       0x38

/* ================================================================
 * 内部枚举与结构
 * ================================================================ */

typedef enum {
    KEY_NONE = 0,
    KEY_ECO, KEY_COPY, KEY_CIRCLE_CROSS,
    KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6,
    KEY_7, KEY_8, KEY_9, KEY_STAR, KEY_0, KEY_HASH,
    KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_OK,
    KEY_UNKNOWN
} KeyCode;

typedef enum {
    STATE_IDLE,
    STATE_IP_SETTING
} AppState;

typedef struct {
    unsigned int octets[4];
    int          cursor;
} IpEditor;

typedef struct {
    int          fd;
    AppState     state;
    IpEditor     editor;
    uint8_t      saved_ip[4];
    int          cursor_visible;
    int          blink_tick;
    int          idle_refresh_tick;  /* IDLE 状态刷新计数 */
    volatile int running;
} AppContext;

/* ================================================================
 * 全局上下文（模块私有）
 * ================================================================ */
static AppContext g_ctx;
static int g_initialized = 0;

/* ================================================================
 * 按键码查找表
 * ================================================================ */

typedef struct {
    uint8_t code;
    KeyCode key;
} KeyMapEntry;

static const KeyMapEntry key_map[] = {
    { KEY_CODE_ECO,      KEY_ECO           },
    { KEY_CODE_COPY,     KEY_COPY          },
    { KEY_CODE_CCPWR,    KEY_CIRCLE_CROSS  },
    { KEY_CODE_1,        KEY_1             },
    { KEY_CODE_2,        KEY_2             },
    { KEY_CODE_3,        KEY_3             },
    { KEY_CODE_4,        KEY_4             },
    { KEY_CODE_5,        KEY_5             },
    { KEY_CODE_6,        KEY_6             },
    { KEY_CODE_7,        KEY_7             },
    { KEY_CODE_8,        KEY_8             },
    { KEY_CODE_9,        KEY_9             },
    { KEY_CODE_STAR,     KEY_STAR          },
    { KEY_CODE_0,        KEY_0             },
    { KEY_CODE_HASH,     KEY_HASH          },
    { KEY_CODE_UP,       KEY_UP            },
    { KEY_CODE_DOWN,     KEY_DOWN          },
    { KEY_CODE_LEFT,     KEY_LEFT          },
    { KEY_CODE_RIGHT,    KEY_RIGHT         },
    { KEY_CODE_OK,       KEY_OK            },
};
static const int key_map_size =
    (int)(sizeof(key_map) / sizeof(key_map[0]));

/* ================================================================
 * 内部函数声明
 * ================================================================ */
static int      serial_open(const char *device);
static void     serial_close(int fd);
static int      serial_config(int fd);
static int      serial_writen(int fd, const void *buf, size_t n);
static KeyCode  keypad_decode(uint8_t code);
static int      keypad_is_digit(KeyCode k);
static int      keypad_digit_value(KeyCode k);
static const char *keypad_name(KeyCode k);
static uint8_t  display_checksum(const uint8_t data[DISPLAY_WIDTH]);
static int      display_send(int fd, const uint8_t data[DISPLAY_WIDTH]);
static void     display_build_ready(uint8_t data[DISPLAY_WIDTH]);
static void     ip_editor_init(IpEditor *ed, unsigned int o0, unsigned int o1,
                               unsigned int o2, unsigned int o3);
static void     ip_editor_gen_display(const IpEditor *ed,
                                      uint8_t data[DISPLAY_WIDTH],
                                      int show_cursor);
static int      ip_editor_handle_digit(IpEditor *ed, int digit);
static void     ip_editor_move_left(IpEditor *ed);
static void     ip_editor_move_right(IpEditor *ed);
static void     ip_editor_get_ip(const IpEditor *ed, uint8_t ip[4]);
static void     dispatch_key(AppContext *ctx, KeyCode key);
static void     signal_handler(int sig);

/* ================================================================
 * 串口操作
 * ================================================================ */

static int serial_open(const char *device)
{
    int fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd < 0) {
        perror("Cannot open serial port");
        return -1;
    }
    if (fcntl(fd, F_SETFL, 0) < 0) {
        perror("fcntl failed");
        close(fd);
        return -1;
    }
    if (0 == isatty(fd)) {
        fprintf(stderr, "Error: %s is not a terminal device\n", device);
        close(fd);
        return -1;
    }
    return fd;
}

static void serial_close(int fd)
{
    if (fd >= 0) close(fd);
}

static int serial_config(int fd)
{
    struct termios options;
    if (tcgetattr(fd, &options) != 0) {
        perror("tcgetattr failed");
        return -1;
    }
    cfsetispeed(&options, B9600);
    cfsetospeed(&options, B9600);
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    options.c_cflag &= ~PARENB;
    options.c_iflag &= ~INPCK;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CRTSCTS;
    options.c_iflag &= ~(IXON | IXOFF | IXANY);
    options.c_iflag &= ~(INLCR | IGNCR | ICRNL);
    options.c_oflag &= ~OPOST;
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    options.c_cc[VMIN]  = 0;
    options.c_cc[VTIME] = 1;
    tcflush(fd, TCIFLUSH);
    if (tcsetattr(fd, TCSANOW, &options) != 0) {
        perror("tcsetattr failed");
        return -1;
    }
    return 0;
}

static int serial_writen(int fd, const void *buf, size_t n)
{
    size_t total = 0;
    const char *ptr = (const char *)buf;
    while (total < n) {
        ssize_t written = write(fd, ptr + total, n - total);
        if (written < 0) {
            if (errno == EINTR) continue;
            perror("serial write failed");
            tcflush(fd, TCOFLUSH);
            return -1;
        }
        total += (size_t)written;
    }
    return (int)total;
}

/* ================================================================
 * 按键解析
 * ================================================================ */

static KeyCode keypad_decode(uint8_t code)
{
    int i;
    for (i = 0; i < key_map_size; i++) {
        if (key_map[i].code == code)
            return key_map[i].key;
    }
    return KEY_UNKNOWN;
}

static int keypad_is_digit(KeyCode k)
{
    return (k >= KEY_1 && k <= KEY_9) || (k == KEY_0);
}

static int keypad_digit_value(KeyCode k)
{
    if (k >= KEY_1 && k <= KEY_9) return (int)(k - KEY_1) + 1;
    if (k == KEY_0) return 0;
    return -1;
}

static const char *keypad_name(KeyCode k)
{
    static const char *names[] = {
        "NONE","ECO","COPY","CC/PWR",
        "1","2","3","4","5","6","7","8","9",
        "*","0","#",
        "UP","DOWN","LEFT","RIGHT","OK",
        "UNKNOWN"
    };
    if (k < 0 || k > KEY_UNKNOWN) return "INVALID";
    return names[k];
}

/* ================================================================
 * 显示协议
 * ================================================================ */

static uint8_t display_checksum(const uint8_t data[DISPLAY_WIDTH])
{
    int i;
    uint8_t cs = FRAME_HEADER1 ^ FRAME_HEADER2;
    for (i = 0; i < DISPLAY_WIDTH; i++) cs ^= data[i];
    return cs;
}

static void display_build_ready(uint8_t data[DISPLAY_WIDTH])
{
    memset(data, LCD_CHAR_SPACE, DISPLAY_WIDTH);
    data[0] = READY_CHAR0;
    data[1] = READY_CHAR1;
    data[2] = READY_CHAR2;
    data[3] = READY_CHAR3;
}

static int display_send(int fd, const uint8_t data[DISPLAY_WIDTH])
{
    uint8_t frame[FRAME_SIZE];
    frame[0] = FRAME_HEADER0;
    frame[1] = FRAME_HEADER1;
    frame[2] = FRAME_HEADER2;
    memcpy(&frame[3], data, DISPLAY_WIDTH);
    frame[FRAME_SIZE - 1] = display_checksum(data);
    return serial_writen(fd, frame, FRAME_SIZE);
}

/* ================================================================
 * IP 编辑器（内部，用于硬件面板交互）
 * ================================================================ */

static void ip_editor_init(IpEditor *ed, unsigned int o0, unsigned int o1,
                           unsigned int o2, unsigned int o3)
{
    ed->octets[0] = o0;
    ed->octets[1] = o1;
    ed->octets[2] = o2;
    ed->octets[3] = o3;
    ed->cursor = 0;
}

/*
 * 生成供硬件显示用的 32 字节数据
 * 格式: "XXX.XXX.XXX.XXX"（固定 3 位补零），左对齐，剩余空格填充
 * show_cursor != 0 时用 '_' 替换光标位置字符
 */
static void ip_editor_gen_display(const IpEditor *ed,
                                  uint8_t data[DISPLAY_WIDTH],
                                  int show_cursor)
{
    int i, pos;
    memset(data, LCD_CHAR_SPACE, DISPLAY_WIDTH);
    pos = 0;
    for (i = 0; i < 4; i++) {
        unsigned int v = ed->octets[i];
        if (i > 0) data[pos++] = LCD_CHAR_DOT;
        data[pos++] = (uint8_t)('0' + (v / 100));
        data[pos++] = (uint8_t)('0' + ((v / 10) % 10));
        data[pos++] = (uint8_t)('0' + (v % 10));
    }
    if (show_cursor && ed->cursor >= 0 && ed->cursor < 12) {
        int dp = ed->cursor + (ed->cursor / 3);
        data[dp] = LCD_CHAR_CURSOR;
    }
}

static int ip_editor_handle_digit(IpEditor *ed, int digit)
{
    int octet_idx, pos_in_octet;
    unsigned int old_val, new_val;
    if (digit < 0 || digit > 9) return 0;
    if (ed->cursor < 0 || ed->cursor >= 12) return 0;

    octet_idx    = ed->cursor / 3;
    pos_in_octet = ed->cursor % 3;
    old_val      = ed->octets[octet_idx];

    switch (pos_in_octet) {
    case 0:
        new_val = (unsigned int)(digit * 100 + (old_val % 100));
        break;
    case 1:
        new_val = (unsigned int)((old_val / 100) * 100
                                  + digit * 10 + (old_val % 10));
        break;
    case 2:
        new_val = (unsigned int)((old_val / 10) * 10 + digit);
        break;
    default:
        return 0;
    }
    ed->octets[octet_idx] = new_val;
    if (ed->cursor < 11) ed->cursor++;
    return 1;
}

/* 光标左移（循环：最左侧 → 最右侧） */
static void ip_editor_move_left(IpEditor *ed)
{
    if (ed->cursor > 0)
        ed->cursor--;
    else
        ed->cursor = 11;   /* 循环到末尾 */
}

/* 光标右移（循环：最右侧 → 最左侧） */
static void ip_editor_move_right(IpEditor *ed)
{
    if (ed->cursor < 11)
        ed->cursor++;
    else
        ed->cursor = 0;    /* 循环到开头 */
}

static void ip_editor_get_ip(const IpEditor *ed, uint8_t ip[4])
{
    int i;
    for (i = 0; i < 4; i++) {
        unsigned int v = ed->octets[i];
        ip[i] = (v > 255) ? 255 : (uint8_t)v;
    }
}

/* ================================================================
 * 状态机
 * ================================================================ */

static void dispatch_key(AppContext *ctx, KeyCode key)
{
    if (key == KEY_NONE || key == KEY_UNKNOWN) return;

    switch (ctx->state) {

    case STATE_IDLE:
        if (key == KEY_COPY) {
            ctx->state = STATE_IP_SETTING;
            ctx->editor.cursor = 0;
            ctx->cursor_visible = 1;
            ctx->blink_tick = 0;
            {
                uint8_t data[DISPLAY_WIDTH];
                ip_editor_gen_display(&ctx->editor, data, 1);
                display_send(ctx->fd, data);
            }
            printf("[INFO] Enter IP setting mode: %d.%d.%d.%d\n",
                   ctx->editor.octets[0], ctx->editor.octets[1],
                   ctx->editor.octets[2], ctx->editor.octets[3]);
        }
        break;

    case STATE_IP_SETTING:
        if (keypad_is_digit(key)) {
            int d = keypad_digit_value(key);
            if (ip_editor_handle_digit(&ctx->editor, d)) {
                uint8_t data[DISPLAY_WIDTH];
                ctx->cursor_visible = 1;
                ctx->blink_tick = 0;
                ip_editor_gen_display(&ctx->editor, data, 1);
                display_send(ctx->fd, data);
            }
        } else if (key == KEY_LEFT) {
            ip_editor_move_left(&ctx->editor);
            {
                uint8_t data[DISPLAY_WIDTH];
                ctx->cursor_visible = 1;
                ctx->blink_tick = 0;
                ip_editor_gen_display(&ctx->editor, data, 1);
                display_send(ctx->fd, data);
            }
        } else if (key == KEY_RIGHT) {
            ip_editor_move_right(&ctx->editor);
            {
                uint8_t data[DISPLAY_WIDTH];
                ctx->cursor_visible = 1;
                ctx->blink_tick = 0;
                ip_editor_gen_display(&ctx->editor, data, 1);
                display_send(ctx->fd, data);
            }
        } else if (key == KEY_OK) {
            ip_editor_get_ip(&ctx->editor, ctx->saved_ip);
            printf("[INFO] IP saved: %d.%d.%d.%d\n",
                   ctx->saved_ip[0], ctx->saved_ip[1],
                   ctx->saved_ip[2], ctx->saved_ip[3]);
            ctx->state = STATE_IDLE;
            ctx->idle_refresh_tick = 0;
            {
                uint8_t data[DISPLAY_WIDTH];
                display_build_ready(data);
                display_send(ctx->fd, data);
            }
        } else if (key == KEY_ECO) {
            ip_editor_init(&ctx->editor,
                           ctx->saved_ip[0], ctx->saved_ip[1],
                           ctx->saved_ip[2], ctx->saved_ip[3]);
            printf("[INFO] IP edit cancelled, restored to: %d.%d.%d.%d\n",
                   ctx->saved_ip[0], ctx->saved_ip[1],
                   ctx->saved_ip[2], ctx->saved_ip[3]);
            ctx->state = STATE_IDLE;
            ctx->idle_refresh_tick = 0;
            {
                uint8_t data[DISPLAY_WIDTH];
                display_build_ready(data);
                display_send(ctx->fd, data);
            }
        }
        break;
    }
}

/* ================================================================
 * 信号处理
 * ================================================================ */

static void signal_handler(int sig)
{
    (void)sig;
    g_ctx.running = 0;
}

/* ================================================================
 * 公开 API
 * ================================================================ */

/*
 * 初始化 GPIO 引脚，启动按键模块硬件
 * 等价于：
 *   echo 426 > /sys/class/gpio/export
 *   echo high > /sys/class/gpio/gpio426/direction
 *   echo 427 > /sys/class/gpio/export
 *   echo high > /sys/class/gpio/gpio427/direction
 *   echo 428 > /sys/class/gpio/export
 *   echo high > /sys/class/gpio/gpio428/direction
 */
int panel_gpio_init(void)
{
    static const int gpios[] = { 426, 427, 428 };
    static const int n_gpios = sizeof(gpios) / sizeof(gpios[0]);
    int i;

    for (i = 0; i < n_gpios; i++) {
        char path[64];
        FILE *fp;

        /* 导出 GPIO */
        fp = fopen("/sys/class/gpio/export", "w");
        if (!fp) {
            perror("gpio export open failed");
            return -1;
        }
        fprintf(fp, "%d", gpios[i]);
        fclose(fp);

        /*
         * 短暂等待 sysfs 创建 gpioN 目录。
         * 如果 GPIO 已导出，export 写入会返回 "Device or resource busy"
         * 但不会影响后续操作。
         */
        usleep(50000);  /* 50ms */

        /* 设置方向为输出高电平 */
        snprintf(path, sizeof(path),
                 "/sys/class/gpio/gpio%d/direction", gpios[i]);
        fp = fopen(path, "w");
        if (!fp) {
            fprintf(stderr,
                    "gpio%d direction open failed (maybe already exported?)\n",
                    gpios[i]);
            /*
             * 如果 direction 文件不存在，可能是 GPIO 已被导出但 sysfs
             * 路径尚未就绪。再等一会后重试一次。
             */
            usleep(100000);  /* 100ms */
            fp = fopen(path, "w");
            if (!fp) {
                perror("gpio direction open retry failed");
                return -1;
            }
        }
        fprintf(fp, "high");
        fclose(fp);

        printf("[INFO] GPIO %d exported and set to high\n", gpios[i]);
    }

    printf("[INFO] GPIO initialization complete.\n");
    return 0;
}

int panel_init(const char *device)
{
    const char *dev = device ? device : SERIAL_DEVICE;
    int fd;
    uint8_t data[DISPLAY_WIDTH];

    if (g_initialized) {
        fprintf(stderr, "panel already initialized\n");
        return -1;
    }

    printf("=== Panel Display Library ===\n");
    printf("Serial device: %s @ 9600 8N1\n\n", dev);

    fd = serial_open(dev);
    if (fd < 0) return -1;

    if (serial_config(fd) != 0) {
        serial_close(fd);
        return -1;
    }

    /* XOR 自检 */
    display_build_ready(data);
    {
        uint8_t cs = display_checksum(data);
        if (cs == 0xF6) {
            printf("[INFO] XOR checksum self-test passed (0xF6).\n");
        } else {
            fprintf(stderr,
                    "WARNING: XOR checksum mismatch! "
                    "Expected 0xF6, got 0x%02X.\n", cs);
        }
    }

    /* 初始化上下文 */
    memset(&g_ctx, 0, sizeof(g_ctx));
    g_ctx.fd             = fd;
    g_ctx.state          = STATE_IDLE;
    g_ctx.running         = 1;
    g_ctx.cursor_visible  = 1;
    g_ctx.blink_tick      = 0;
    g_ctx.saved_ip[0]     = 192;
    g_ctx.saved_ip[1]     = 168;
    g_ctx.saved_ip[2]     = 1;
    g_ctx.saved_ip[3]     = 1;
    ip_editor_init(&g_ctx.editor, 192, 168, 1, 1);

    /* 发送初始就绪画面 */
    display_send(fd, data);
    printf("[INFO] Sent ready display.\n");

    /* 安装信号处理 */
    {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_handler = signal_handler;
        sa.sa_flags   = 0;
        sigemptyset(&sa.sa_mask);
        sigaction(SIGINT,  &sa, NULL);
        sigaction(SIGTERM, &sa, NULL);
        sigaction(SIGQUIT, &sa, NULL);
    }

    g_initialized = 1;
    printf("[INFO] Panel initialized successfully.\n\n");
    return 0;
}

void panel_close(void)
{
    if (!g_initialized) return;
    g_ctx.running = 0;
    serial_close(g_ctx.fd);
    g_initialized = 0;
    printf("[INFO] Panel closed.\n");
}

/*
 * 设置 IP 地址
 * 解析 "xxx.xxx.xxx.xxx" 格式字符串，更新内部存储和编辑器
 * 若当前处于 IP_SETTING 状态，同步刷新硬件显示
 */
int panel_set_ip(const char *ip_str)
{
    unsigned int o[4];
    int n;

    if (!ip_str || !g_initialized) return -1;

    n = sscanf(ip_str, "%u.%u.%u.%u", &o[0], &o[1], &o[2], &o[3]);
    if (n != 4) {
        fprintf(stderr, "panel_set_ip: invalid format '%s'\n", ip_str);
        return -1;
    }

    /* 范围检查 */
    {
        int i;
        for (i = 0; i < 4; i++) {
            if (o[i] > 255) {
                fprintf(stderr,
                        "panel_set_ip: octet %d out of range (%u > 255)\n",
                        i + 1, o[i]);
                return -1;
            }
        }
    }

    /* 更新保存的 IP */
    g_ctx.saved_ip[0] = (uint8_t)o[0];
    g_ctx.saved_ip[1] = (uint8_t)o[1];
    g_ctx.saved_ip[2] = (uint8_t)o[2];
    g_ctx.saved_ip[3] = (uint8_t)o[3];

    /* 同步更新编辑器 */
    ip_editor_init(&g_ctx.editor, o[0], o[1], o[2], o[3]);

    /* 若当前在 IP 编辑模式，刷新硬件显示 */
    if (g_ctx.state == STATE_IP_SETTING) {
        uint8_t data[DISPLAY_WIDTH];
        g_ctx.cursor_visible = 1;
        g_ctx.blink_tick = 0;
        ip_editor_gen_display(&g_ctx.editor, data, 1);
        display_send(g_ctx.fd, data);
    }

    printf("[INFO] IP set to %u.%u.%u.%u\n", o[0], o[1], o[2], o[3]);
    return 0;
}

/*
 * 获取当前 IP 地址
 * 输出格式 "xxx.xxx.xxx.xxx"，无前导零（如 "192.168.1.1"）
 */
const char *panel_get_ip(char *buf, size_t size)
{
    if (!buf || size < 16 || !g_initialized) return NULL;

    snprintf(buf, size, "%u.%u.%u.%u",
             g_ctx.saved_ip[0], g_ctx.saved_ip[1],
             g_ctx.saved_ip[2], g_ctx.saved_ip[3]);
    return buf;
}

/*
 * 运行主事件循环（阻塞）
 * 处理串口按键输入，驱动面板状态机
 */
void panel_run(void)
{
    uint8_t data[DISPLAY_WIDTH];

    g_ctx.idle_refresh_tick = 0;   /* 初始化 IDLE 刷新计数器 */

    if (!g_initialized) {
        fprintf(stderr, "panel_run: not initialized\n");
        return;
    }

    printf("[INFO] Entering main loop. Press Ctrl+C to exit.\n\n");

    while (g_ctx.running) {
        fd_set         rfds;
        struct timeval tv;
        int            ret;

        FD_ZERO(&rfds);
        FD_SET(g_ctx.fd, &rfds);
        tv.tv_sec  = 0;
        tv.tv_usec = 100000;   /* 100ms */

        ret = select(g_ctx.fd + 1, &rfds, NULL, NULL, &tv);

        if (ret < 0) {
            if (errno == EINTR) continue;
            perror("select error");
            break;
        }

        if (ret > 0 && FD_ISSET(g_ctx.fd, &rfds)) {
            /*
             * 排空读取：循环读取直到没有数据为止，
             * 确保按键码不会因为缓冲区太小而被延迟处理。
             */
            int drain_rounds = 0;
            while (drain_rounds < 8) {  /* 最多 8 轮，防止死循环 */
                uint8_t buf[256];
                ssize_t n;

                /*
                 * 首轮直接读，后续轮次用 10ms 短超时判断
                 * 是否还有残留数据。
                 */
                if (drain_rounds > 0) {
                    fd_set         rrds;
                    struct timeval stv;
                    FD_ZERO(&rrds);
                    FD_SET(g_ctx.fd, &rrds);
                    stv.tv_sec  = 0;
                    stv.tv_usec = 10000;  /* 10ms */
                    if (select(g_ctx.fd + 1, &rrds, NULL, NULL, &stv) <= 0)
                        break;  /* 无更多数据 */
                }

                n = read(g_ctx.fd, buf, sizeof(buf));
                if (n <= 0) {
                    if (n < 0 && errno != EINTR && errno != EAGAIN) {
                        perror("read error");
                    }
                    break;
                }

                /* 单字节按键解析 */
                int j;
                for (j = 0; j < n; j++) {
                    uint8_t b = buf[j];
                    if (b == KEY_SUFFIX) continue;  /* 按键松开 */

                    KeyCode key = keypad_decode(b);
                    if (key != KEY_NONE && key != KEY_UNKNOWN) {
                        printf("[KEY] %s (code=0x%02X)\n",
                            keypad_name(key), b);
                        dispatch_key(&g_ctx, key);
                    }
                    /* 其他字节（心跳 0xB0 等）静默忽略 */
                }
                drain_rounds++;
            }
        } else {
            /* ---- 超时处理 ---- */
            g_ctx.blink_tick++;

            /* 光标闪烁：每 500ms 切换 */
            if (g_ctx.blink_tick >= 5) {
                g_ctx.blink_tick = 0;

                if (g_ctx.state == STATE_IP_SETTING) {
                    g_ctx.cursor_visible = !g_ctx.cursor_visible;
                    ip_editor_gen_display(&g_ctx.editor, data,
                                          g_ctx.cursor_visible);
                    display_send(g_ctx.fd, data);
                }
            }

            /* IDLE 状态定期刷新：每 3 秒重发"就绪"，防止显示退化 */
            g_ctx.idle_refresh_tick++;
            if (g_ctx.state == STATE_IDLE && g_ctx.idle_refresh_tick >= 30) {
                g_ctx.idle_refresh_tick = 0;
                display_build_ready(data);
                display_send(g_ctx.fd, data);
            }
        }
    }

    printf("\n[INFO] Event loop exited.\n");
}
