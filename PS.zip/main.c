#include "ddr_reg_mgr.h"
#include "pattern_page.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

static const char *file_array[4] = {
    "Y.dat",   // 第0个元素
    "M.dat",   // 第1个元素
    "C.dat",   // 第2个元素
    "K.dat"    // 第3个元素
};

static void ps_write_file(const char *filename, ChannelId ch) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        perror("fopen");
        exit(1);
    }
    
    uint64_t data;
    size_t read_bytes;

    while (1) {
        // 读取8字节（64bit）
        read_bytes = fread(&data, 1, sizeof(uint64_t), fp);

        if (read_bytes == 0) break;

        // 不足8字节补0
        if (read_bytes < sizeof(uint64_t)) {
            memset(((uint8_t*)&data) + read_bytes, 0,
                   sizeof(uint64_t) - read_bytes);
        }

        write_to_channel(ch, data);
    }
    fclose(fp);
}

static void ps_write(const char **files){
    for(int i =0;i < 4;i++){
        ps_write_file(files[i], i);
    }
}

int main(int argc, char *argv[])
{
    init_once();

    int start_lx = atoi(argv[1]);
    int start_rx = atoi(argv[2]);

    color_test(start_lx, start_rx);

    while(1){
        init_one_task();

        uint32_t p = 0;
        printf("Enter the number of pages to print:\n");
        scanf("%u",&p); 
        // 初始化PL
        set_reg(CONTROL_REG, 0);

        // ===============================================
        set_reg(PAGE_NUM_REG, 0);
        set_reg(PRN_CMD_REG, 0x00000001);//bit0 置1
        usleep(1000);
        set_reg(PMODE_REG,   0x00000440);//bit6 置1，彩印

        // ===============================================
        printf("System initialized.\n");
        
        set_reg(PRN_CMD_REG, 0x00000070);//bit4 置1，打印开始

        // ===============================================
        for(int i = 0;i < p; i++) {
            ps_write(file_array);
            set_reg(PAGE_NUM_REG, i + 1);
            change_all_blocks();
            printf("Write Done: Page %d\n", i + 1);
        }
        while(get_reg(STATUS_REG) == 0)
            ;
        set_reg(PRN_CMD_REG,    0x00000072);
    }
    unmap_all();

    return 0;
}