/*
 * main.c - 面板库使用示例
 
 * 运行: ./panel_demo                  # 使用默认 /dev/ttyS1
 *       ./panel_demo /dev/ttyUSB0     # 指定串口设备
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include "panel.h"

int main(int argc, char **argv)
{
    const char *device = (argc > 1) ? argv[1] : NULL;

    /* ---- 1. 初始化 GPIO（按键模块硬件） ---- */
    if (panel_gpio_init() != 0) {
        fprintf(stderr, "GPIO init failed, keypad may not work.\n");
        /* 非致命错误，继续执行 */
    }

    /* ---- 2. 初始化面板 ---- */
    if (panel_init(device) != 0) {
        fprintf(stderr, "Failed to initialize panel.\n");
        return EXIT_FAILURE;
    }

    /*
     * ---- 2. 可选：通过 API 预设 IP ----
     * 取消注释以下代码即可在启动时设置 IP。
     * 注意：不要在 panel_init 和 panel_run 之间使用 printf，
     * 以免输出被串口硬件模块误解析为显示指令。
     */
    /* panel_set_ip("10.0.0.55"); */

    /* ---- 3. 进入硬件交互主循环 ---- */
    panel_run();

    /* ---- 4. 清理 ---- */
    panel_close();
    return EXIT_SUCCESS;
}
