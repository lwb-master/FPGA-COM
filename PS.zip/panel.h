/*
 * panel.h - 串口面板显示库（对外交付接口）
 *
 * 提供两个核心接口：
 *   panel_set_ip()  - 设置 IP 地址（字符串输入）
 *   panel_get_ip()  - 获取当前 IP 地址（字符串输出，无补零）
 *
 * 同时保留完整的硬件面板交互功能（按键驱动 IP 编辑）。
 */

#ifndef PANEL_H_INCLUDED
#define PANEL_H_INCLUDED

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * 生命周期
 * ================================================================ */

/*
 * 初始化面板
 *   device: 串口设备路径（如 "/dev/ttyS1"），传 NULL 使用默认值
 *   返回 0 成功，-1 失败
 */
int panel_init(const char *device);

/*
 * 关闭面板，释放资源
 */
void panel_close(void);

/* ================================================================
 * 对外接口
 * ================================================================ */

/*
 * 初始化 GPIO 引脚，启动按键模块硬件
 * 导出 GPIO 426/427/428 并设为输出高电平。
 * 在 panel_init() 之前调用。
 *   返回 0 成功，-1 失败
 */
int panel_gpio_init(void);

/*
 * 设置 IP 地址
 *   ip_str: IP 字符串，格式 "xxx.xxx.xxx.xxx"（如 "192.168.1.1"）
 *   各段范围 0-255，不足 3 位无需补零
 *   返回 0 成功，-1 格式错误
 */
int panel_set_ip(const char *ip_str);

/*
 * 获取当前 IP 地址
 *   buf:  输出缓冲区
 *   size: 缓冲区大小（建议 >= 16）
 *   返回格式化字符串 "xxx.xxx.xxx.xxx"（无补零，如 "192.168.1.1"）
 *   返回 buf 指针，失败返回 NULL
 */
const char *panel_get_ip(char *buf, size_t size);

/* ================================================================
 * 事件循环（可选）
 * ================================================================ */

/*
 * 运行主事件循环（阻塞）
 * 处理硬件按键输入，驱动面板状态机。
 * 若不需硬件交互，可不调用此函数。
 */
void panel_run(void);

#ifdef __cplusplus
}
#endif

#endif /* PANEL_H_INCLUDED */
