#include "ddr_reg_mgr.h"
#include "pattern_page.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

// 致命错误处理宏
#define FATAL                                                    \
    do                                                           \
    {                                                            \
        fprintf(stderr, "Error at line %d, file %s (%d) [%s]\n", \
                __LINE__, __FILE__, errno, strerror(errno));     \
        exit(1);                                                 \
    } while (0)

typedef enum
{
    BLOCK_A = 0,
    BLOCK_B,
    BLOCK_MAX
} BlockId; // 乒乓块ID枚举

typedef struct
{
    volatile uint64_t *block_addr[BLOCK_MAX]; // 指向当前通道A/B块的虚拟地址
    uint32_t write_offset;                    // 当前块的已写入偏移量
} ChannelManager;                             // 通道内存管理结构体，跟踪写入状态

void *g_reg_base = NULL; // 交互寄存器基地址
void *g_ddr_base = NULL; // 数据存储基地址
void *g_test_base = NULL;  // 套色测试数据生成基地址

static int mem_fd = -1;
static uint32_t ddr_flag = 0;                 // DDR块标记flag
static ChannelManager g_mgr[CHANNEL_MAX];     // 通道管理实例
static BlockId current_write_block = BLOCK_A; // 初始默认写块A
static bool g_ch_ready[CHANNEL_MAX] = {false, false, false, false};

static void init_channel_manager(void)
{
    current_write_block = BLOCK_A;

    for (int ch = 0; ch < CHANNEL_MAX; ch++)
    {
        size_t offset = (size_t)ch * CHANNEL_MEM_SIZE;

        g_mgr[ch].block_addr[BLOCK_A] =
            (volatile uint64_t *)(g_ddr_base + offset);

        g_mgr[ch].block_addr[BLOCK_B] =
            (volatile uint64_t *)(g_ddr_base + offset + BLOCK_MEM_SIZE);

        g_mgr[ch].write_offset = 0;
        g_ch_ready[ch] = false;
    }
}

void init_once()
{
    if ((mem_fd = open("/dev/mem", O_RDWR | O_SYNC)) == -1)
        FATAL;
    // 映射物理地址到虚拟地址
    g_reg_base = mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE,
                      MAP_SHARED, mem_fd, REG_BASE_ADDR & ~MAP_MASK);
    g_ddr_base = mmap(0, TOTAL_MEM_SIZE, PROT_READ | PROT_WRITE,
                      MAP_SHARED, mem_fd, DDR_BASE_ADDR & ~MAP_MASK);
    g_test_base = mmap(0, TEST_SIZE, PROT_READ | PROT_WRITE,
                     MAP_SHARED, mem_fd, TEST_OFFSET & ~MAP_MASK);

    // 初始化通道管理器实例
}

void init_one_task()
{
    ddr_flag = 1;
    init_channel_manager();
}

void unmap_all(void)
{
    if (g_reg_base)
    {
        munmap(g_reg_base, MAP_SIZE);
        g_reg_base = NULL;
    }
    if (g_ddr_base)
    {
        munmap(g_ddr_base, TOTAL_MEM_SIZE);
        g_ddr_base = NULL;
    }
    if (g_test_base)
    {
        munmap(g_test_base, TEST_SIZE);
        g_ddr_base = NULL;
    }

    close(mem_fd);
}

void change_all_blocks(void)
{
    while (1)
    {
        int temp = get_reg(STATUS_REG) | ddr_flag; // 第一次写数据不需要等待PL，后续写数据阻塞等待PL读完1页数据
        if (temp != 0)
        {
            break;
        }
    }

    if (ddr_flag != 0)
    {
        ddr_flag = 0;
        set_reg(CONTROL_REG, 0x0F); // 第一次写入一页数据后启动数据管理的PL逻辑
    }
    else
    {
        set_reg(CONTROL_REG, 0xFF);      // 后续写入数据之前须和PL握手
        while (get_reg(STATUS_REG) == 1) // 确定PL读到握手信号
            ;
        set_reg(CONTROL_REG, 0x0F); // 复位握手信号
    }
    BlockId old_block = current_write_block;
    current_write_block = (old_block == BLOCK_A) ? BLOCK_B : BLOCK_A;

    for (int ch = 0; ch < CHANNEL_MAX; ch++)
    {
        g_ch_ready[ch] = false;
        g_mgr[ch].write_offset = 0;
    }
}

uint8_t write_to_channel(ChannelId ch, uint64_t data)
{
    if (g_ch_ready[ch])
        return 0;

    BlockId blk = current_write_block;
    volatile uint64_t *addr = g_mgr[ch].block_addr[blk] +
                              (g_mgr[ch].write_offset / sizeof(uint64_t));

    *addr = data;
    g_mgr[ch].write_offset += 8;

    if (g_mgr[ch].write_offset >= BLOCK_MEM_SIZE)
    {
        g_ch_ready[ch] = true;
    }

    return 1;
}

void write_fifo(const void *data_buf, uint32_t BytesPerPage, ChannelId ch)
{
    if (data_buf == NULL || BytesPerPage == 0)
    {
        return;
    }
    const uint8_t *buf = (const uint8_t *)data_buf;
    uint64_t data;
    const uint32_t bits_64 = sizeof(uint64_t);

    while (BytesPerPage > 0)
    {
        memset(&data, 0, sizeof(data));
        uint32_t read_len = (BytesPerPage >= bits_64) ? bits_64 : BytesPerPage;
        memcpy(&data, buf, read_len);

        write_to_channel(ch, data);

        buf += read_len;
        BytesPerPage -= read_len;
    }
}

static uint8_t reverse_byte(uint8_t byte)
{
    uint8_t res = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
        res <<= 1;
        res |= (byte & 1);
        byte >>= 1;
    }
    return res;
}

void write_fifo_mirror(const void *data_buf, uint32_t BytesPerPage, ChannelId ch, uint32_t BytesPerLine)
{
    if (data_buf == NULL || BytesPerPage == 0 || BytesPerLine == 0)
    {
        return;
    }

    const uint8_t *buf = (const uint8_t *)data_buf;
    const uint32_t bits_64 = sizeof(uint64_t);
    uint64_t data;

    while (BytesPerPage > 0)
    {
        uint32_t line_len = (BytesPerPage >= BytesPerLine) ? BytesPerLine : BytesPerLine;
        uint8_t line_mirror[BytesPerLine];

        for (uint32_t i = 0; i < line_len; i++)
        {
            uint8_t src_byte = buf[line_len - 1 - i];
            line_mirror[i] = reverse_byte(src_byte);
        }

        uint32_t offset = 0;
        while (offset < line_len)
        {
            memset(&data, 0, sizeof(data));
            uint32_t read_len = ((line_len - offset) >= bits_64) ? bits_64 : (line_len - offset);
            memcpy(&data, line_mirror + offset, read_len);

            write_to_channel(ch, data);

            offset += read_len;
        }

        buf += line_len;
        BytesPerPage -= line_len;
    }
}

void color_test(int start_lx, int start_rx)
{
    printf("[Color Test]: Starting...\n");
    init_one_task();

    // 从套色数据的基地址g_test_base开始，大小为TEST_SIZE的块全部写0
    uint64_t *temp = (uint64_t *)g_test_base;
    for (int i = 0; i < TEST_SIZE / sizeof(uint64_t); i++)
    {
        temp[i] = 0;
    }

    pattern0_group_par.hbar_par.start_lx = start_lx;
    pattern0_group_par.hbar_par.start_rx = start_rx;
    pattern0_group_par.sbar_par.start_lx = start_lx;
    pattern0_group_par.sbar_par.start_rx = start_rx;

    set_reg(CONTROL_REG, 0);
    set_reg(PAGE_NUM_REG, 0);

    set_reg(PAGE_SIZE_REG, 4377984);
    set_reg(LINEBYTES_REG, 620);
    set_reg(PAGEH_REG_WORD, 7016);

    int reg = get_reg(PRN_CMD_REG);
    reg |= 0x00000001;
    set_reg(PRN_CMD_REG, reg);
    usleep(1000);
    reg &= 0xFFFFFFFE;
    set_reg(PRN_CMD_REG, reg);

    // 生成套色数据
    make_pattern((char *)g_test_base);

    // CK两个通道的数据需要做镜像，数据位置为g_test_base加TEST_SIZE / 4的偏移
    write_fifo((void *)g_test_base, 4377984, 0);
    write_fifo((void *)g_test_base, 4377984, 1);
    write_fifo((void *)(g_test_base + TEST_SIZE / 4), 4377984, 2);
    write_fifo((void *)(g_test_base + TEST_SIZE / 4), 4377984, 3);
    set_reg(PAGE_NUM_REG, 1);

    change_all_blocks();//这个函数会启动数据管理的逻辑

    printf("[Color Test]: Data write done...\n");

    reg = get_reg(PMODE_REG);
    reg |= 0x00008000;
    set_reg(PMODE_REG, reg);
    
    while( (get_reg(HW_STATUS_REG) & 0x00000200) == 0 )
    reg &= 0xFFFF7FFF;
    set_reg(PMODE_REG, reg);
    printf("[Color Test]: Ended...\n");
}