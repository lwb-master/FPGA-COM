#ifndef DDR_REG_MGR_H
#define DDR_REG_MGR_H

#include <stdint.h>
#include <stdbool.h>

// 控制寄存器
#define STATUS_REG 0                // PL侧    //R
#define CONTROL_REG 1               // PL侧控制信号    //W
#define PAGES_PRINTED_REG 2         // 已打印页数      //R
#define HW_STATUS_REG 3             // 故障代码        //R
#define PAPER_STATUS_REG 4          // 纸张状态        //R
#define HW_SENSOR_REG 5             // 传感器状态      //R
#define LINEBYTES_REG 6             // 行字节数        //W
#define PAGEH_REG_WORD 7            // 页高\行数       //W
#define PAGE_NUM_REG 8              // 打印页数        //W
#define PMODE_REG 9                 // 打印模式        //W
#define PRN_CMD_REG 10              // 打印命令        //W
#define HW_TRAY12_PAPER_SIZE_REG 11 // 纸板1 2纸张尺寸 //R
#define PAGE_SIZE_REG 12            // 单页数据大小(单位bit）//W
#define COLOR_READ 13               // 套色功能        //R
#define COLOR_WRITE 14              // 套色功能        //W

#define MAP_SIZE 4096           // Linux内存管理最小单位
#define MAP_MASK (MAP_SIZE - 1) // 0xFFF

#define CHANNEL_BytesPerPage 4              // 4个数据通道（C/M/Y/K）
#define BLOCK_BytesPerPage 2                // 2个乒乓块（A/B）
#define BLOCK_MEM_SIZE 0x500000             // 乒乓块内存
#define CHANNEL_MEM_SIZE BLOCK_MEM_SIZE * 2 // 通道内存
#define TOTAL_MEM_SIZE CHANNEL_MEM_SIZE * 4 // 总内存

#define DDR_BASE_ADDR 0x10000000 // DDR物理基地址
#define REG_BASE_ADDR 0x80000000 // PL寄存器物理基地址

#define TEST_OFFSET 0X20000000           // 套色测试数据基地址
#define TEST_SIZE   BLOCK_MEM_SIZE * 4   // 套色数据生成大小

typedef enum
{
    CHANNEL_Y = 0,
    CHANNEL_M,
    CHANNEL_C,
    CHANNEL_K,
    CHANNEL_MAX
} ChannelId; // 通道ID枚举

extern void *g_reg_base; // 交互寄存器基地址
extern void *g_ddr_base; // 数据存储基地址
extern void *g_test_base;  // 套色测试数据生成基地址

// 写寄存器
static inline void set_reg(int reg_idx, uint32_t val)
{
    *((volatile uint32_t *)(g_reg_base + reg_idx * 4)) = val;
}

// 读寄存器
static inline uint32_t get_reg(int reg_idx)
{
    return *((volatile uint32_t *)(g_reg_base + reg_idx * 4));
}

// 程序开始时执行
void init_once(void);

// 一次打印任务开始时执行
void init_one_task(void);

// 释放申请的所有映射地址，防止内存泄漏
void unmap_all(void);

// 切换所有通道的读写块
void change_all_blocks(void);

uint8_t write_to_channel(ChannelId ch, uint64_t data);

// 写某个通道的FIFO，函数会从data_buf开始，读BytesPerPage，写到通道ch
void write_fifo(const void *data_buf, uint32_t BytesPerPage, ChannelId ch);

void write_fifo_mirror(const void *data_buf, uint32_t BytesPerPage, ChannelId ch, uint32_t BytesPerLine);

void color_test(int start_lx, int start_rx);

#endif
