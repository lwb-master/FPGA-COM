module top( 
    inout               PAD_JTAG_TCLK        ,
    inout               PAD_JTAG_TMS         ,
    inout               PAD_MCURST           ,
    input               clk                  ,
    input               ADC_RIGHT_CTDP_OP    ,
    input               ADC_RIGHT_CTDP_ON    ,
    input               ADC_LEFT_CTDP_OP     ,
    input               ADC_LEFT_CTDP_ON     ,
    input               ADC_ACR_RIGHT_P      ,
    input               ADC_ACR_RIGHT_N      ,
    input               ADC_ACR_LEFT_P       ,
    input               ADC_ACR_LEFT_N       ,
    input               ADC_RIGHT_CTDS_OP    ,
    input               ADC_RIGHT_CTDS_ON    ,
    input               ADC_LEFT_CTDS_OP     ,
    input               ADC_LEFT_CTDS_ON     ,
    input               ADC_FUSER_PB4_P      ,
    input               ADC_FUSER_PB4_N      ,
    input               ADC_FUSER_PB3_P      ,
    input               ADC_FUSER_PB3_N      ,
    output              nSleep_Power         ,
    output              nCrum_Power          ,
    output              nCover_Open          ,
    output              EN_3V3               ,
    output              EN_24V               ,
    output   [110:80]   tt                   ,
    inout               B34_L14_N            ,
    inout               B34_L14_P            ,
    output              B34_L5_P

);

wire  [31:0]    rd_reg_01;       //synthesis keep
wire            PH_BUSY;         //synthesis keep
wire  [31:0]    rd_reg_02;       //synthesis keep
wire  [31:0]    rd_reg_03;       //synthesis keep
wire  [31:0]    rd_reg_04;       //synthesis keep
wire  [31:0]    rd_reg_05;       //synthesis keep
wire  [31:0]    rd_reg_06;       //synthesis keep
wire  [31:0]    SENS_REG;        //synthesis keep
wire  [31:0]    rd_reg_08;       //synthesis keep
wire  [31:0]    rd_reg_09;   //synthesis keep
wire  [31:0]    rd_reg_10;   //synthesis keep
wire  [31:0]    rd_reg_11;   //synthesis keep
wire  [31:0]    rd_reg_12;   //synthesis keep
wire  [31:0]    rd_reg_13;   //synthesis keep
wire  [31:0]    rd_reg_14;   //synthesis keep
wire  [31:0]    rd_reg_15;   //synthesis keep
wire  [31:0]    rd_reg_16;   //synthesis keep
wire  [31:0]    rd_reg_17;   //synthesis keep
wire  [31:0]    rd_reg_18;   //synthesis keep
wire  [31:0]    rd_reg_19;   //synthesis keep
wire  [31:0]    rd_reg_20;   //synthesis keep
wire  [31:0]    rd_reg_21;   //synthesis keep
wire  [31:0]    rd_reg_22;   //synthesis keep
wire  [31:0]    rd_reg_23;   //synthesis keep
wire  [31:0]    rd_reg_24;   //synthesis keep
wire  [31:0]    rd_reg_25;   //synthesis keep
wire  [31:0]    rd_reg_26;   //synthesis keep
wire  [31:0]    rd_reg_27;   //synthesis keep
wire  [31:0]    rd_reg_28;   //synthesis keep
wire  [31:0]    rd_reg_29;   //synthesis keep
wire  [31:0]    rd_reg_30;   //synthesis keep
wire  [31:0]    rd_reg_31;   //synthesis keep
wire  [31:0]    rd_reg_32;   //synthesis keep
wire  [31:0]    rd_reg_33;   //synthesis keep
wire  [31:0]    rd_reg_34;   //synthesis keep
wire  [31:0]    rd_reg_35;   //synthesis keep

wire  [31:0]    wr_reg_01;       //synthesis keep
wire  [31:0]    wr_reg_02;       //synthesis keep
wire  [31:0]    wr_reg_03;       //synthesis keep
wire  [31:0]    wr_reg_04;       //synthesis keep
wire  [31:0]    wr_reg_05;       //synthesis keep
wire  [31:0]    wr_reg_06;       //synthesis keep
wire  [31:0]    wr_reg_07;    //synthesis keep
wire  [31:0]    wr_reg_08;    //synthesis keep
wire  [31:0]    wr_reg_09;    //synthesis keep
wire  [31:0]    wr_reg_10;    //synthesis keep
wire  [31:0]    wr_reg_11;    //synthesis keep
wire  [31:0]    wr_reg_12;    //synthesis keep
wire  [31:0]    wr_reg_13;    //synthesis keep
wire  [31:0]    wr_reg_14;    //synthesis keep
wire  [31:0]    wr_reg_15;    //synthesis keep
wire  [31:0]    wr_reg_16;    //synthesis keep
wire  [31:0]    wr_reg_17;    //synthesis keep
wire  [31:0]    wr_reg_18;    //synthesis keep
wire  [31:0]    wr_reg_19;    //synthesis keep
wire  [31:0]    wr_reg_20;    //synthesis keep
wire  [31:0]    wr_reg_21;    //synthesis keep
wire  [31:0]    wr_reg_22;    //synthesis keep
wire  [31:0]    wr_reg_23;    //synthesis keep
wire  [31:0]    wr_reg_24;    //synthesis keep
wire  [31:0]    wr_reg_25;    //synthesis keep
wire  [31:0]    wr_reg_26;    //synthesis keep
wire  [31:0]    wr_reg_27;    //synthesis keep
wire  [31:0]    wr_reg_28;    //synthesis keep
wire  [31:0]    Cluth_Reg;    //synthesis keep
wire  [31:0]    wr_reg_30;    //synthesis keep
wire  [31:0]    wr_reg_31;    //synthesis keep
wire  [31:0]    wr_reg_32;      // 测试占用 //synthesis keep
wire  [31:0]    wr_reg_33;      // 测试占用 //synthesis keep
wire  [31:0]    wr_reg_34;              //synthesis keep
wire  [31:0]    wr_reg_35;      // 测试占用 //synthesis keep
wire  [31:0]    color_clr_reg;          //synthesis keep
wire  [31:0]    wr_reg_37;         //synthesis keep      
wire  [31:0]    wr_reg_38;         //synthesis keep      
wire  [31:0]    wr_reg_39;         //synthesis keep      
wire  [31:0]    wr_reg_40;         //synthesis keep      
wire  [31:0]    wr_reg_41;         //synthesis keep      
wire  [31:0]    wr_reg_42;         //synthesis keep      
wire  [31:0]    wr_reg_43;         //synthesis keep      
wire  [31:0]    wr_reg_44;         //synthesis keep      
wire  [31:0]    wr_reg_45;         //synthesis keep      
wire  [31:0]    wr_reg_46;         //synthesis keep      
wire  [31:0]    wr_reg_47;         //synthesis keep      
wire  [31:0]    wr_reg_48; //synthesis keep
wire  [31:0]    wr_reg_49; //synthesis keep
wire  [31:0]    wr_reg_50; //synthesis keep
wire  [31:0]    wr_reg_51; //synthesis keep
wire  [31:0]    wr_reg_52; //synthesis keep
wire  [31:0]    wr_reg_53; //synthesis keep
wire  [31:0]    wr_reg_54; //synthesis keep
wire  [31:0]    wr_reg_55; //synthesis keep
wire  [31:0]    wr_reg_56; //synthesis keep
wire  [31:0]    wr_reg_57; //synthesis keep
wire  [31:0]    wr_reg_58; //synthesis keep
wire  [31:0]    wr_reg_59; //synthesis keep
wire  [31:0]    wr_reg_60; //synthesis keep
wire  [31:0]    wr_reg_61; //synthesis keep
wire  [31:0]    wr_reg_62; //synthesis keep
wire  [31:0]    wr_reg_63; //synthesis keep
wire  [31:0]    wr_reg_64; //synthesis keep
wire  [31:0]    wr_reg_65; //synthesis keep
wire  [31:0]    wr_reg_66; //synthesis keep
wire  [31:0]    wr_reg_67; //synthesis keep
wire  [31:0]    wr_reg_68; //synthesis keep
wire  [31:0]    wr_reg_69; //synthesis keep
wire  [31:0]    wr_reg_70; //synthesis keep
wire  [31:0]    wr_reg_71; //synthesis keep
wire  [31:0]    wr_reg_72; //synthesis keep
wire  [31:0]    wr_reg_73; //synthesis keep
wire  [31:0]    wr_reg_74; //synthesis keep
wire  [31:0]    wr_reg_75; //synthesis keep
wire  [31:0]    wr_reg_76; //synthesis keep
wire  [31:0]    wr_reg_77; //synthesis keep
wire  [31:0]    wr_reg_78; //synthesis keep
wire  [31:0]    wr_reg_79; //synthesis keep
wire  [31:0]    wr_reg_80; //synthesis keep
wire  [31:0]    wr_reg_81; //synthesis keep
wire  [31:0]    wr_reg_82; //synthesis keep
wire  [31:0]    wr_reg_83; //synthesis keep
wire  [31:0]    wr_reg_84; //synthesis keep
wire  [31:0]    wr_reg_85; //synthesis keep
wire  [31:0]    wr_reg_86; //synthesis keep
wire  [31:0]    wr_reg_87; //synthesis keep
wire  [31:0]    wr_reg_88; //synthesis keep
wire  [31:0]    wr_reg_89; //synthesis keep
wire  [31:0]    wr_reg_90; //synthesis keep
wire  [31:0]    wr_reg_91; //synthesis keep
wire  [31:0]    wr_reg_92; //synthesis keep


  PowerOn_Initial x_PowerOn_Initial (
      .nSleep_Power(nSleep_Power),
      .nCrum_Power (nCrum_Power),
      .nCover_Open (nCover_Open),
      .EN_3V3      (EN_3V3),
      .EN_24V      (EN_24V)
  );

wujian100_open_fpga_top inst_wujian100_open_fpga_top(
    .PIN_EHS(clk),
    .PAD_JTAG_TCLK(PAD_JTAG_TCLK),
    .PAD_JTAG_TMS(PAD_JTAG_TMS),
    .PAD_MCURST(PAD_MCURST),
    .sys_clk_p(sys_clk_p),
    .rd_reg_01(rd_reg_01),
    .rd_reg_02(reg_8),
    .rd_reg_03(reg_9),
    .rd_reg_04(reg_10),
    .rd_reg_05(reg_11),
    .rd_reg_06(rd_reg_06),
    .rd_reg_07(SENS_REG),
    .rd_reg_08(rd_reg_08),
    .rd_reg_09(rd_reg_09),
    .rd_reg_10(rd_reg_10),
    .wr_reg_01(wr_reg_01),
    .wr_reg_02(wr_reg_02),
    .wr_reg_03(wr_reg_03),
    .wr_reg_04(wr_reg_04),
    .wr_reg_05(wr_reg_05),
    .wr_reg_06(wr_reg_06),
    .wr_reg_07(wr_reg_07),
    .wr_reg_08(wr_reg_08),
    .wr_reg_09(wr_reg_09),
    .wr_reg_10(wr_reg_10),
    .wr_reg_11(wr_reg_11),
    .wr_reg_12(wr_reg_12),
    .wr_reg_13(wr_reg_13),
    .wr_reg_14(wr_reg_14),
    .wr_reg_15(wr_reg_15),
    .wr_reg_16(wr_reg_16),
    .wr_reg_17(wr_reg_17),
    .wr_reg_18(wr_reg_18),
    .wr_reg_19(wr_reg_19),
    .wr_reg_20(wr_reg_20),
    .wr_reg_21(wr_reg_21),
    .wr_reg_22(wr_reg_22),
    .wr_reg_23(wr_reg_23),
    .wr_reg_24(wr_reg_24),
    .wr_reg_25(wr_reg_25),
    .wr_reg_26(wr_reg_26),
    .wr_reg_27(wr_reg_27),
    .wr_reg_28(wr_reg_28),
    .wr_reg_29(Cluth_Reg),
    .wr_reg_30(wr_reg_30),
    .wr_reg_31(wr_reg_31),
    .wr_reg_32(wr_reg_32),
    .wr_reg_33(wr_reg_33),
    .wr_reg_34(wr_reg_34),
    .wr_reg_35(wr_reg_35),
    .wr_reg_36(color_clr_reg),
    .wr_reg_37(wr_reg_37),
    .wr_reg_38(wr_reg_38),
    .wr_reg_39(wr_reg_39),
    .wr_reg_40(wr_reg_40),
    .wr_reg_41(wr_reg_41),
    .wr_reg_42(wr_reg_42),
    .wr_reg_43(wr_reg_43),
    .wr_reg_44(wr_reg_44),
    .wr_reg_45(wr_reg_45),
    .wr_reg_46(wr_reg_46),
    .wr_reg_47(wr_reg_47),
    .wr_reg_48(wr_reg_48),
    .wr_reg_49(wr_reg_49),
    .wr_reg_50(wr_reg_50),
    .wr_reg_51(wr_reg_51),
    .wr_reg_52(wr_reg_52),
    .wr_reg_53(wr_reg_53),
    .wr_reg_54(wr_reg_54),
    .wr_reg_55(wr_reg_55),
    .wr_reg_56(wr_reg_56),
    .wr_reg_57(wr_reg_57),
    .wr_reg_58(wr_reg_58),
    .wr_reg_59(wr_reg_59),
    .wr_reg_60(wr_reg_60),
            .wr_reg_61          (wr_reg_61),
    .wr_reg_62          (wr_reg_62),
    .wr_reg_63          (wr_reg_63),
    .wr_reg_64          (wr_reg_64),
    .wr_reg_65          (wr_reg_65),
    .wr_reg_66          (wr_reg_66),
    .wr_reg_67          (wr_reg_67),
    .wr_reg_68          (wr_reg_68),
    .wr_reg_69          (wr_reg_69),
    .wr_reg_70          (wr_reg_70),
    .wr_reg_71          (wr_reg_71),
    .wr_reg_72          (wr_reg_72),
    .wr_reg_73          (wr_reg_73),
    .wr_reg_74          (wr_reg_74),
    .wr_reg_75          (wr_reg_75),
    .wr_reg_76          (wr_reg_76),
    .wr_reg_77          (wr_reg_77),
    .wr_reg_78          (wr_reg_78),
    .wr_reg_79          (wr_reg_79),
    .wr_reg_80          (wr_reg_80),
    .wr_reg_81          (wr_reg_81),
    .wr_reg_82          (wr_reg_82),
    .wr_reg_83          (wr_reg_83),
    .wr_reg_84          (wr_reg_84),
    .wr_reg_85          (wr_reg_85),
    .wr_reg_86          (wr_reg_86),
    .wr_reg_87          (wr_reg_87),
    .wr_reg_88          (wr_reg_88),
    .wr_reg_89          (wr_reg_89),
    .wr_reg_90          (wr_reg_90),
    .wr_reg_91          (wr_reg_91),
    .wr_reg_92          (wr_reg_92),
        .rd_reg_11          (rd_reg_11),
    .rd_reg_12          (rd_reg_12),
    .rd_reg_13          (rd_reg_13),
    .rd_reg_14          (rd_reg_14),
    .rd_reg_15          (rd_reg_15),
    .rd_reg_16          (rd_reg_16),
    .rd_reg_17          (rd_reg_17),
    .rd_reg_18          (rd_reg_18),
    .rd_reg_19          (rd_reg_19),
    .rd_reg_20          (rd_reg_20),
    .rd_reg_21          (rd_reg_21),
    .rd_reg_22          (rd_reg_22),
    .rd_reg_23          (rd_reg_23),
    .rd_reg_24          (rd_reg_24),
    .rd_reg_25          (rd_reg_25),
    .rd_reg_26          (rd_reg_26),
    .rd_reg_27          (rd_reg_27),
    .rd_reg_28          (rd_reg_28),
    .rd_reg_29          (rd_reg_29),
    .rd_reg_30          (rd_reg_30),
    .rd_reg_31          (rd_reg_31),
    .rd_reg_32          (rd_reg_32),
    .rd_reg_33          (rd_reg_33),
    .rd_reg_34          (rd_reg_34),
    .rd_reg_35          (rd_reg_35)
);

wire adc_clk;
wire clk_100M;
wire clk_60M;
wire lock;
wire rst_n;
wire RST_FUSER;  //synthesis keep
wire EN_FUSER;  //synthesis keep
wire AC_EN_FUSER;  //synthesis keep
wire ram_rst;
wire update;  //systhesis keep
wire Data_valid;  //systhesis keep
wire [11:0] ch0_data;  //systhesis keep
wire [11:0] ch1_data;  //systhesis keep
wire [11:0] ch2_data;  //systhesis keep
wire [11:0] ch3_data;  //systhesis keep
wire [11:0] ch4_data;  //systhesis keep
wire [11:0] ch5_data;  //systhesis keep
wire [11:0] ch6_data;  //systhesis keep
wire [11:0] ch7_data;  //systhesis keep
(*keep*)wire [7:0] recv_data;//systhesis keep
(*keep*)wire recv_valid;//systhesis keep
(*keep*)wire [7:0] recv2_data;//systhesis keep
(*keep*)wire recv2_valid;//systhesis keep
(*keep*)wire send_valid;//systhesis keep
(*keep*)wire [7:0] send_data;//systhesis keep
(*keep*)wire send_ready;//systhesis keep
(*keep*)wire send2_valid;//systhesis keep

reg [63:0] bug_di;//systhesis keep
reg bug_we;//systhesis keep
wire aempty;//systhesis keep
wire [ 7:0] send2_data = (recv2_data >= 8'h61 && recv2_data <= 8'h7A) ? (recv_data - 8'h20) : recv_data;   // lowercase -> uppercase
reg [31:0] cnt_10ms;
wire        nFUSER_Ready;  //synthesis keep
wire [19:0] AVR_C_DATA;  //synthesis keep
wire [19:0] AVR_D_DATA;  //synthesis keep
wire        ST0;  //synthesis keep
wire [ 1:0] ADC_ST;  //synthesis keep
wire        nRelay_AC_ON_T102;  //synthesis keep
wire        nFUSER_EN_T91;  //synthesis keep


  clk_wiz_0 clk_wiz_0_inst (
      .clk0_out(adc_clk),
      .clk1_out(clk_100M),
      .clk2_out(clk_60M),
      .lock    (lock),
      .refclk  (clk),
      .reset   (1'b0)
  );
    VPI_0 VPI_0_inst (
      .clk(adc_clk),
      .outprobe0(rst_n),
      .outprobe1(RST_FUSER),
      .outprobe2(EN_FUSER),
      .outprobe3(AC_EN_FUSER),
      .outprobe4(ram_rst)
  );


  Fuser_Ctrl u_Fuser_Ctrl (
      .CLK         (adc_clk),
      .RST         (RST_FUSER),
      .EN          (EN_FUSER),
      .AC_EN       (AC_EN_FUSER),
      .NCTH_C_in   (ch7_data),
      .NCTH_D_in   (ch6_data),
      .AVR_C_DATA  (AVR_C_DATA),
      .AVR_D_DATA  (AVR_D_DATA),
      .ST0         (ST0),
      .ADC_ST      (ADC_ST),
      .Data_valid  (update),
      .nRelay_AC_ON(nRelay_AC_ON_T102),
      .nFUSER_EN   (nFUSER_EN_T91),
      .nFUSER_Ready(nFUSER_Ready),
      .FUSER_ERROR (FUSER_ERROR),
      .FUSER_OFF   (FUSER_OFF)
  );

  always @(posedge adc_clk) begin
    
        bug_we <= 1'b0;   // 默认拉低，只产生一个周期脉冲

        if (cnt_10ms == 32'd99999) begin
            cnt_10ms <= 32'd0;
            bug_we   <= 1'b1;          // 每10ms拉高一个adc_clk周期
            bug_di   <= 64'hAA00_0000_0000_0055;  // 测试数据
        end
        else begin
            cnt_10ms <= cnt_10ms + 32'd1;
        end
end

  Soft_FIFO_0 Soft_FIFO_0 (
      .clkw(adc_clk),  //clkw
      .wrst(!rst_n),

      .we(bug_we),
      .di(bug_di),

      .clkr(clk60mhz),
      .rrst(!rst_n),
      .re(!aempty),
      .dout(send_data),
      .valid(send_valid),

      .empty_flag(),  //empty_flag
      .aempty(aempty),  //
      .full_flag(),  //full_flag
      .afull(),  //afull

      .overflow(),  //overflow
      .underflow(),  //underflow
      .wr_success(),  //wr_success
      .rdusedw(),  //rdusedw
      .wrusedw(),  //wrusedw
      .wr_rst_done(),  //wr_rst_done
      .rd_rst_done()  //rd_rst_done
  );



  adc_8ch_top u_adc_8ch_top (
      .clk  (adc_clk),
      .rst_n(rst_n),
      .start(1'b1),

      // .bug_we(bug_we),
      // .bug_di(bug_di),

      .Data_valid(Data_valid),
      .update    (update),
      .ch0_data  (ch0_data),
      .ch1_data  (ch1_data),
      .ch2_data  (ch2_data),
      .ch3_data  (ch3_data),
      .ch4_data  (ch4_data),
      .ch5_data  (ch5_data),
      .ch6_data  (ch6_data),
      .ch7_data  (ch7_data),

      .vauxp_11(ADC_RIGHT_CTDP_OP),
      .vauxn_11(ADC_RIGHT_CTDP_ON),
      // .vauxp_2            (test_T9),
      // .vauxn_2            (ADC_RIGHT_CTDP_ON),
      .vauxp_5 (ADC_LEFT_CTDP_OP),
      .vauxn_5 (ADC_LEFT_CTDP_ON),
      .vauxp_9 (ADC_ACR_RIGHT_P),
      .vauxn_9 (ADC_ACR_RIGHT_N),
      .vauxp_6 (ADC_ACR_LEFT_P),
      .vauxn_6 (ADC_ACR_LEFT_N),
      .vauxp_7 (ADC_RIGHT_CTDS_OP),
      .vauxn_7 (ADC_RIGHT_CTDS_ON),
      .vauxp_14(ADC_LEFT_CTDS_OP),
      .vauxn_14(ADC_LEFT_CTDS_ON),
      .vauxp_12(ADC_FUSER_PB4_P),
      .vauxn_12(ADC_FUSER_PB4_N),
      .vauxn_13(ADC_FUSER_PB3_N),
      .vauxp_13(ADC_FUSER_PB3_P)     //B21
      // .vauxp_5 (test_T52)//B21
  );

    usb_serial2_top #(
      .DEBUG                      ("FALSE"               ) // If you want to see the debug info of USB device core, set this parameter to "TRUE"
  ) u_usb_serial2 (
      .rstn(lock),  //pl_lock to pll_lock, modify
      .clk(clk_60M),
      // USB signals
      .usb_dp_pull(B34_L5_P),
      .usb_dp(B34_L14_P),
      .usb_dn(B34_L14_N),
      // USB reset output
      .usb_rstn                   (                      ),// 1: connected , 0: disconnected (when USB cable unplug, or when system reset (rstn=0))
      // CDC receive data (host-to-device)
      .recv1_data(recv_data),  // received data byte
      .recv1_valid(recv_valid),  // when recv_valid=1 pulses, a data byte is received on recv_data
      // CDC send data (device-to-host)
      .send1_data(send_data),  // 
      .send1_valid(send_valid),  // connect recv_valid to send_valid to achieve loopback 
      .send1_ready(send_ready ),// ignore send_ready, ignore the situation that the send buffer is full (send_ready=0). So here it will lose data when you send a large amount of data
      // CDC receive data (host-to-device)
      .recv2_data(recv2_data),  // received data byte
      .recv2_valid(recv2_valid),  // when recv_valid=1 pulses, a data byte is received on recv_data
      // CDC send data (device-to-host)
      .send2_data(send2_data),  // connect recv_data to send_data to achieve loopback 
      .send2_valid(send2_valid),  // connect recv_valid to send_valid to achieve loopback 
      .send2_ready                (                      ),// ignore send_ready, ignore the situation that the send buffer is full (send_ready=0). So here it will lose data when you send a large amount of data
      // debug output info, only for USB developers, can be ignored for normally use
      .debug_en(),
      .debug_data(),
      .debug_uart_tx()  //
  );



endmodule
