`timescale 1ns/1ps

// ================================================================
// ADC -> FIFO -> UART TX
//
// Function:
//   On adc_update pulse, latch 8 channels of 12-bit ADC data.
//   Send one ASCII frame through UART every SEND_EVERY_N_UPDATE updates:
//
//   C0=ABC C1=123 C2=456 C3=789 C4=000 C5=FFF C6=800 C7=055\r\n
//
// UART format:
//   57600 bps by default, 8 data bits, no parity, 1 stop bit.
//
// Required existing modules:
//   uart_tx.v
//   uart_tx_ctl.v
//   uart_baud_gen.v
//   asyn_fifo.v
// ================================================================

module adc_uart_reader #(
    parameter BAUD_RATE            = 115200,
    parameter UART_CLOCK_RATE      = 10_000_000,
    // UART bandwidth is limited. For debug, do not send every ADC update.
    // If adc_update is about 50k~90kHz, 1000 gives about 50~90 frames/s.
    parameter SEND_EVERY_N_UPDATE  = 1000,
    parameter FIFO_ADDR_WIDTH      = 9,
    parameter FIFO_DATA_DEEPTH     = 512
)(
    input              adc_clk,
    input              uart_clk,
    input              rst_n,        // active LOW reset

    input              adc_update,   // one-clock pulse in adc_clk domain
    input      [11:0]  adc_ch0,
    input      [11:0]  adc_ch1,
    input      [11:0]  adc_ch2,
    input      [11:0]  adc_ch3,
    input      [11:0]  adc_ch4,
    input      [11:0]  adc_ch5,
    input      [11:0]  adc_ch6,
    input      [11:0]  adc_ch7,

    output             uart_txd,
    output             fifo_full,
    output             fifo_empty,
    output             fifo_prog_full
);

localparam FRAME_BYTES = 57;   // C0=xxx ... C7=xxx + CR + LF

// ------------------------------------------------------------
// ADC write-side logic
// ------------------------------------------------------------
reg adc_update_d;
wire adc_update_rise;

assign adc_update_rise = adc_update & ~adc_update_d;

always @(posedge adc_clk or negedge rst_n) begin
    if (!rst_n)
        adc_update_d <= 1'b0;
    else
        adc_update_d <= adc_update;
end

reg [31:0] update_cnt;
reg [11:0] ch0_r, ch1_r, ch2_r, ch3_r;
reg [11:0] ch4_r, ch5_r, ch6_r, ch7_r;

reg [6:0]  wr_idx;
reg        sending;
reg [7:0]  fifo_din;
reg        fifo_wr_en;

wire fifo_wr_allow;
assign fifo_wr_allow = ~fifo_full & ~fifo_prog_full;

// 4-bit value to ASCII hex char
function [7:0] hex_char;
    input [3:0] data;
    begin
        case (data)
            4'h0: hex_char = "0";
            4'h1: hex_char = "1";
            4'h2: hex_char = "2";
            4'h3: hex_char = "3";
            4'h4: hex_char = "4";
            4'h5: hex_char = "5";
            4'h6: hex_char = "6";
            4'h7: hex_char = "7";
            4'h8: hex_char = "8";
            4'h9: hex_char = "9";
            4'hA: hex_char = "A";
            4'hB: hex_char = "B";
            4'hC: hex_char = "C";
            4'hD: hex_char = "D";
            4'hE: hex_char = "E";
            4'hF: hex_char = "F";
        endcase
    end
endfunction

function [7:0] frame_byte;
    input [6:0] idx;
    begin
        case (idx)
            7'd0 : frame_byte = "C";
            7'd1 : frame_byte = "0";
            7'd2 : frame_byte = "=";
            7'd3 : frame_byte = hex_char(ch0_r[11:8]);
            7'd4 : frame_byte = hex_char(ch0_r[7:4]);
            7'd5 : frame_byte = hex_char(ch0_r[3:0]);
            7'd6 : frame_byte = " ";

            7'd7 : frame_byte = "C";
            7'd8 : frame_byte = "1";
            7'd9 : frame_byte = "=";
            7'd10: frame_byte = hex_char(ch1_r[11:8]);
            7'd11: frame_byte = hex_char(ch1_r[7:4]);
            7'd12: frame_byte = hex_char(ch1_r[3:0]);
            7'd13: frame_byte = " ";

            7'd14: frame_byte = "C";
            7'd15: frame_byte = "2";
            7'd16: frame_byte = "=";
            7'd17: frame_byte = hex_char(ch2_r[11:8]);
            7'd18: frame_byte = hex_char(ch2_r[7:4]);
            7'd19: frame_byte = hex_char(ch2_r[3:0]);
            7'd20: frame_byte = " ";

            7'd21: frame_byte = "C";
            7'd22: frame_byte = "3";
            7'd23: frame_byte = "=";
            7'd24: frame_byte = hex_char(ch3_r[11:8]);
            7'd25: frame_byte = hex_char(ch3_r[7:4]);
            7'd26: frame_byte = hex_char(ch3_r[3:0]);
            7'd27: frame_byte = " ";

            7'd28: frame_byte = "C";
            7'd29: frame_byte = "4";
            7'd30: frame_byte = "=";
            7'd31: frame_byte = hex_char(ch4_r[11:8]);
            7'd32: frame_byte = hex_char(ch4_r[7:4]);
            7'd33: frame_byte = hex_char(ch4_r[3:0]);
            7'd34: frame_byte = " ";

            7'd35: frame_byte = "C";
            7'd36: frame_byte = "5";
            7'd37: frame_byte = "=";
            7'd38: frame_byte = hex_char(ch5_r[11:8]);
            7'd39: frame_byte = hex_char(ch5_r[7:4]);
            7'd40: frame_byte = hex_char(ch5_r[3:0]);
            7'd41: frame_byte = " ";

            7'd42: frame_byte = "C";
            7'd43: frame_byte = "6";
            7'd44: frame_byte = "=";
            7'd45: frame_byte = hex_char(ch6_r[11:8]);
            7'd46: frame_byte = hex_char(ch6_r[7:4]);
            7'd47: frame_byte = hex_char(ch6_r[3:0]);
            7'd48: frame_byte = " ";

            7'd49: frame_byte = "C";
            7'd50: frame_byte = "7";
            7'd51: frame_byte = "=";
            7'd52: frame_byte = hex_char(ch7_r[11:8]);
            7'd53: frame_byte = hex_char(ch7_r[7:4]);
            7'd54: frame_byte = hex_char(ch7_r[3:0]);
            7'd55: frame_byte = 8'h0D;   // CR
            7'd56: frame_byte = 8'h0A;   // LF
            default: frame_byte = 8'h0A;
        endcase
    end
endfunction

always @(posedge adc_clk or negedge rst_n) begin
    if (!rst_n) begin
        update_cnt <= 32'd0;
        ch0_r <= 12'd0;
        ch1_r <= 12'd0;
        ch2_r <= 12'd0;
        ch3_r <= 12'd0;
        ch4_r <= 12'd0;
        ch5_r <= 12'd0;
        ch6_r <= 12'd0;
        ch7_r <= 12'd0;
        wr_idx <= 7'd0;
        sending <= 1'b0;
        fifo_din <= 8'd0;
        fifo_wr_en <= 1'b0;
    end else begin
        fifo_wr_en <= 1'b0;

        if (sending) begin
            if (fifo_wr_allow) begin
                fifo_din   <= frame_byte(wr_idx);
                fifo_wr_en <= 1'b1;

                if (wr_idx == FRAME_BYTES - 1) begin
                    wr_idx  <= 7'd0;
                    sending <= 1'b0;
                end else begin
                    wr_idx <= wr_idx + 1'b1;
                end
            end
        end else begin
            if (adc_update_rise) begin
                if (update_cnt >= SEND_EVERY_N_UPDATE - 1) begin
                    update_cnt <= 32'd0;

                    // Latch one complete ADC sample frame
                    ch0_r <= adc_ch0;
                    ch1_r <= adc_ch1;
                    ch2_r <= adc_ch2;
                    ch3_r <= adc_ch3;
                    ch4_r <= adc_ch4;
                    ch5_r <= adc_ch5;
                    ch6_r <= adc_ch6;
                    ch7_r <= adc_ch7;

                    // Start one UART frame only when FIFO has space
                    if (fifo_wr_allow) begin
                        sending <= 1'b1;
                        wr_idx  <= 7'd0;
                    end
                end else begin
                    update_cnt <= update_cnt + 1'b1;
                end
            end
        end
    end
end

// ------------------------------------------------------------
// Async FIFO: ADC clock domain -> UART clock domain
// ------------------------------------------------------------
wire [7:0] fifo_dout;
wire       fifo_rd_en;
wire       fifo_prog_empty;

// Keep enough margin for at least one ASCII frame.
localparam [FIFO_ADDR_WIDTH-1:0] PROG_FULL_THRESH  = FIFO_DATA_DEEPTH - 64;
localparam [FIFO_ADDR_WIDTH-1:0] PROG_EMPTY_THRESH = 1;

asyn_fifo #(
    .DATA_WIDTH  (8),
    .DATA_DEEPTH (FIFO_DATA_DEEPTH),
    .ADDR_WIDTH  (FIFO_ADDR_WIDTH)
) u_adc_uart_fifo (
    .wr_clk           (adc_clk),
    .wr_rst_n         (rst_n),
    .rd_clk           (uart_clk),
    .rd_rst_n         (rst_n),
    .din              (fifo_din),
    .wr_en            (fifo_wr_en & fifo_wr_allow),
    .rd_en            (fifo_rd_en & ~fifo_empty),
    .dout             (fifo_dout),
    .full             (fifo_full),
    .prog_full        (fifo_prog_full),
    .empty            (fifo_empty),
    .prog_empty       (fifo_prog_empty),
    .prog_full_thresh (PROG_FULL_THRESH),
    .prog_empty_thresh(PROG_EMPTY_THRESH)
);

// ------------------------------------------------------------
// UART transmitter
// ------------------------------------------------------------
uart_tx #(
    .BAUD_RATE  (BAUD_RATE),
    .CLOCK_RATE (UART_CLOCK_RATE)
) u_uart_tx (
    .clk_tx            (uart_clk),
    .rst_clk_tx        (~rst_n),
    .char_fifo_empty   (fifo_empty),
    .char_fifo_dout    (fifo_dout),
    .char_fifo_rd_en   (fifo_rd_en),
    .txd_tx            (uart_txd)
);

endmodule
