module PowerOn_Initial(
                        nSleep_Power,           //FPGA Pin:AB20
                        nCrum_Power,            //FPGA Pin:Y19
                        nCover_Open,            //FPGA Pin:L17
                        EN_3V3,                //FPGA Pin:M16
                        EN_24V                 //FPGA Pin:U6
                                                 );

output  nSleep_Power;
output  nCrum_Power;
output  nCover_Open;
output  EN_3V3;
output  EN_24V;

assign  nSleep_Power    =   1'b1;
assign  nCrum_Power     =   1'b1;
assign  EN_3V3          =   1'b0;
assign  nCover_Open     =   1'b1;
assign  EN_24V          =   1'b1;

endmodule
