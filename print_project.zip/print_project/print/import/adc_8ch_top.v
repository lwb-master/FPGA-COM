`timescale 1ns / 1ps

module adc_8ch_top (
    (*keep*) input wire clk,
    (*keep*) input wire rst_n,
    (*keep*) input wire start,

    // output bug_we,
    // output [63:0] bug_di,


    input wire vauxp_5,
    input wire vauxn_5,
    input wire vauxp_6,
    input wire vauxn_6,
    input wire vauxp_7,
    input wire vauxn_7,
    input wire vauxp_9,
    input wire vauxn_9,
    input wire vauxp_11,
    input wire vauxn_11,
    input wire vauxp_12,
    input wire vauxn_12,
    input wire vauxp_13,
    input wire vauxn_13,
    input wire vauxp_14,
    input wire vauxn_14,

    (*keep*) output reg [11:0] ch0_data,
    (*keep*) output reg [11:0] ch1_data,
    (*keep*) output reg [11:0] ch2_data,
    (*keep*) output reg [11:0] ch3_data,
    (*keep*) output reg [11:0] ch4_data,
    (*keep*) output reg [11:0] ch5_data,
    (*keep*) output reg [11:0] ch6_data,
    (*keep*) output reg [11:0] ch7_data,

    (*keep*) output wire [95:0] adc_data_all,
    (*keep*) output reg         Data_valid,
    (*keep*) output reg         update,
    (*keep*) output reg         busy,
    (*keep*) output reg         init_done,

    // 调试信号
    (*keep*) output wire        adc_eoc_dbg,
    (*keep*) output wire [11:0] adc_pob_dbg,
    (*keep*) output wire        adc_busy_dbg,
    (*keep*) output wire [ 2:0] adc_channel_dbg,
    (*keep*) output reg         adc_soc_dbg,
    (*keep*) output reg  [ 2:0] adc_sel_channel_dbg,
    (*keep*) output reg  [ 2:0] cur_ch_dbg,
    (*keep*) output reg  [ 5:0] state_dbg,

    (*keep*) output wire eoc_rise_dbg,
    (*keep*) output wire eoc_sample_dbg
);

  (*keep*)reg         adc_soc;
  (*keep*)reg         adc_sel_diff;
  (*keep*)reg  [ 1:0] adc_sel_res;
  (*keep*)reg         adc_sel_ref;
  (*keep*)reg  [ 2:0] adc_enctr;
  (*keep*)reg  [ 2:0] adc_sel_channel;
  (*keep*)reg         adc_enable;
  (*keep*)reg         adc_dislvl;
  (*keep*)reg  [ 4:0] adc_channel_sel_0;
  (*keep*)reg  [ 4:0] adc_channel_sel_1;
  (*keep*)reg  [ 4:0] adc_channel_sel_2;
  (*keep*)reg  [ 4:0] adc_channel_sel_3;
  (*keep*)reg  [ 4:0] adc_channel_sel_4;
  (*keep*)reg  [ 4:0] adc_channel_sel_5;
  (*keep*)reg  [ 4:0] adc_channel_sel_6;
  (*keep*)reg  [ 4:0] adc_channel_sel_7;
  (*keep*)reg         adc_channel_en;
  (*keep*)reg         adc_pl_reset_n;

  (*keep*)wire [11:0] adc_pob;
  (*keep*)wire        adc_eoc;
  (*keep*)wire        adc_busy;
  (*keep*)wire [ 2:0] adc_channel;
  // (*keep*)reg         update;

  assign adc_data_all = {
    ch7_data, ch6_data, ch5_data, ch4_data, ch3_data, ch2_data, ch1_data, ch0_data
  };

  assign adc_eoc_dbg = adc_eoc;
  assign adc_pob_dbg = adc_pob;
  assign adc_busy_dbg = adc_busy;
  assign adc_channel_dbg = adc_channel;

  localparam integer RESET_LOW_CYCLES = 2;  // >=10ns
  localparam integer REF_WAIT_CYCLES = 50;  // 5us @10MHz
  localparam integer CH_SETTLE_CYCLES = 8;  // 切换通道后等待
  localparam integer SOC_HIGH_CYCLES = 1;  // soc 单拍
  localparam integer SOC_GAP_CYCLES = 2;  // soc 拉低后保护
  localparam integer SAMPLE_WAIT_CYCLES = 1;  // eoc同步上升后再等1拍采样

  (*keep*) reg eoc_ff1, eoc_ff2, eoc_ff3;
  (*keep*)reg  eoc_rise_d1;

  (*keep*)wire eoc_rise;
  (*keep*)wire eoc_sample;

  assign eoc_rise       = eoc_ff2 & ~eoc_ff3;  // 同步后的上升沿
  assign eoc_sample     = eoc_rise_d1;  // 再延后一拍作为采样触发
  assign eoc_rise_dbg   = eoc_rise;
  assign eoc_sample_dbg = eoc_sample;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      eoc_ff1     <= 1'b0;
      eoc_ff2     <= 1'b0;
      eoc_ff3     <= 1'b0;
      eoc_rise_d1 <= 1'b0;
    end else begin
      eoc_ff1     <= adc_eoc;
      eoc_ff2     <= eoc_ff1;
      eoc_ff3     <= eoc_ff2;
      eoc_rise_d1 <= eoc_rise;
    end
  end

  //--------------------------------------------------------------------------
  // 状态机
  //--------------------------------------------------------------------------
  reg [ 5:0] state;
  reg [15:0] wait_cnt;
  reg [ 2:0] cur_ch;
  reg        start_latched;

  localparam S_PWR_IDLE = 6'd0;
  localparam S_EN_HIGH = 6'd1;
  localparam S_RST_LOW = 6'd2;
  localparam S_RST_RELEASE = 6'd3;
  localparam S_DUMMY_SOC_H = 6'd4;
  localparam S_DUMMY_SOC_L = 6'd5;
  localparam S_REF_WAIT = 6'd6;
  localparam S_IDLE = 6'd7;
  localparam S_SET_CH = 6'd8;
  localparam S_WAIT_CH = 6'd9;
  localparam S_SOC_H = 6'd10;
  localparam S_SOC_L = 6'd11;
  localparam S_WAIT_EOC_RISE = 6'd12;
  localparam S_WAIT_SAMPLE = 6'd13;
  localparam S_STORE = 6'd14;
  localparam S_NEXT = 6'd15;

  //--------------------------------------------------------------------------
  // ADC IP
  //--------------------------------------------------------------------------
  adc_wiz_0 u_ADCF9F0D0P0_0 (
      .adc_soc          (adc_soc),
      .adc_sel_diff     (adc_sel_diff),
      .adc_sel_res      (adc_sel_res),
      .adc_sel_ref      (adc_sel_ref),
      .adc_enctr        (adc_enctr),
      .adc_sel_channel  (adc_sel_channel),
      .adc_enable       (adc_enable),
      .adc_dislvl       (adc_dislvl),
      .adc_channel_sel_0(adc_channel_sel_0),
      .adc_channel_sel_1(adc_channel_sel_1),
      .adc_channel_sel_2(adc_channel_sel_2),
      .adc_channel_sel_3(adc_channel_sel_3),
      .adc_channel_sel_4(adc_channel_sel_4),
      .adc_channel_sel_5(adc_channel_sel_5),
      .adc_channel_sel_6(adc_channel_sel_6),
      .adc_channel_sel_7(adc_channel_sel_7),
      .adc_channel_en   (adc_channel_en),
      .adc_pob          (adc_pob),
      .adc_pl_reset_n   (adc_pl_reset_n),
      .adc_pl_clk       (clk),

      .vauxp_5 (vauxp_5),
      .vauxn_5 (vauxn_5),
      .vauxp_6 (vauxp_6),
      .vauxn_6 (vauxn_6),
      .vauxp_7 (vauxp_7),
      .vauxn_7 (vauxn_7),
      .vauxp_9 (vauxp_9),
      .vauxn_9 (vauxn_9),
      .vauxp_11(vauxp_11),
      .vauxn_11(vauxn_11),
      .vauxp_12(vauxp_12),
      .vauxn_12(vauxn_12),
      .vauxp_13(vauxp_13),
      .vauxn_13(vauxn_13),
      .vauxp_14(vauxp_14),
      .vauxn_14(vauxn_14),

      .adc_eoc    (adc_eoc),
      .adc_busy   (adc_busy),
      .adc_channel(adc_channel)
  );

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // 固定配置
      adc_sel_diff        <= 1'b0;  // 单端
      adc_sel_res         <= 2'b11;  // 12bit
      adc_sel_ref         <= 1'b1;  // 内部参考 1.2V
      adc_enctr           <= 3'b000;
      adc_dislvl          <= 1'b0;
      adc_channel_en      <= 1'b1;

      // 8逻辑通道 -> 真实模拟通道
      adc_channel_sel_0   <= 5'd11;
      adc_channel_sel_1   <= 5'd5;
      adc_channel_sel_2   <= 5'd9;
      adc_channel_sel_3   <= 5'd6;
      adc_channel_sel_4   <= 5'd7;
      adc_channel_sel_5   <= 5'd14;
      adc_channel_sel_6   <= 5'd12;
      adc_channel_sel_7   <= 5'd13;

      adc_enable          <= 1'b0;
      adc_soc             <= 1'b0;
      adc_pl_reset_n      <= 1'b1;
      adc_sel_channel     <= 3'd0;

      ch0_data            <= 12'd0;
      ch1_data            <= 12'd0;
      ch2_data            <= 12'd0;
      ch3_data            <= 12'd0;
      ch4_data            <= 12'd0;
      ch5_data            <= 12'd0;
      ch6_data            <= 12'd0;
      ch7_data            <= 12'd0;

      update              <= 1'b0;
      busy                <= 1'b0;
      init_done           <= 1'b0;
      wait_cnt            <= 16'd0;
      state               <= S_PWR_IDLE;
      cur_ch              <= 3'd0;
      start_latched       <= 1'b0;

      adc_soc_dbg         <= 1'b0;
      adc_sel_channel_dbg <= 3'd0;
      cur_ch_dbg          <= 3'd0;
      state_dbg           <= S_PWR_IDLE;
    end else begin
      update              <= 1'b0;

      adc_soc_dbg         <= adc_soc;
      adc_sel_channel_dbg <= adc_sel_channel;
      cur_ch_dbg          <= cur_ch;
      state_dbg           <= state;

      case (state)
        // 上电启动
        S_PWR_IDLE: begin
          adc_enable     <= 1'b0;
          adc_soc        <= 1'b0;
          adc_pl_reset_n <= 1'b1;
          busy           <= 1'b0;
          init_done      <= 1'b0;
          wait_cnt       <= 16'd0;
          cur_ch         <= 3'd0;
          start_latched  <= 1'b0;
          state          <= S_EN_HIGH;
        end

        S_EN_HIGH: begin
          adc_enable     <= 1'b1;
          adc_soc        <= 1'b0;
          adc_pl_reset_n <= 1'b1;
          wait_cnt       <= 16'd0;
          state          <= S_RST_LOW;
        end

        S_RST_LOW: begin
          adc_pl_reset_n <= 1'b0;
          adc_soc        <= 1'b0;
          if (wait_cnt >= RESET_LOW_CYCLES - 1) begin
            wait_cnt <= 16'd0;
            state    <= S_RST_RELEASE;
          end else begin
            wait_cnt <= wait_cnt + 1'b1;
          end
        end

        S_RST_RELEASE: begin
          adc_pl_reset_n <= 1'b1;
          adc_soc        <= 1'b0;
          wait_cnt       <= 16'd0;
          state          <= S_DUMMY_SOC_H;
        end

        // 虚拟转换
        S_DUMMY_SOC_H: begin
          adc_soc  <= 1'b1;
          wait_cnt <= 16'd0;
          state    <= S_DUMMY_SOC_L;
        end

        S_DUMMY_SOC_L: begin
          adc_soc <= 1'b0;
          if (wait_cnt >= SOC_GAP_CYCLES - 1) begin
            wait_cnt <= 16'd0;
            state    <= S_REF_WAIT;
          end else begin
            wait_cnt <= wait_cnt + 1'b1;
          end
        end

        // 内部参考等待 5us
        S_REF_WAIT: begin
          adc_soc <= 1'b0;
          if (wait_cnt >= REF_WAIT_CYCLES - 1) begin
            init_done <= 1'b1;
            wait_cnt  <= 16'd0;
            state     <= S_IDLE;
          end else begin
            wait_cnt <= wait_cnt + 1'b1;
          end
        end

        S_IDLE: begin
          adc_soc <= 1'b0;
          busy    <= 1'b0;
          if (start && init_done) begin
            busy          <= 1'b1;
            start_latched <= 1'b1;
            cur_ch        <= 3'd0;
            state         <= S_SET_CH;
          end
        end

        // 设置当前通道
        S_SET_CH: begin
          adc_soc         <= 1'b0;
          adc_sel_channel <= cur_ch;
          wait_cnt        <= 16'd0;
          state           <= S_WAIT_CH;
        end

        // 等待通道稳定
        S_WAIT_CH: begin
          adc_soc <= 1'b0;
          if (wait_cnt >= CH_SETTLE_CYCLES - 1) begin
            wait_cnt <= 16'd0;
            state    <= S_SOC_H;
          end else begin
            wait_cnt <= wait_cnt + 1'b1;
          end
        end

        // SOC 单拍
        S_SOC_H: begin
          adc_soc  <= 1'b1;
          wait_cnt <= 16'd0;
          state    <= S_SOC_L;
        end

        S_SOC_L: begin
          adc_soc <= 1'b0;
          if (wait_cnt >= SOC_GAP_CYCLES - 1) begin
            wait_cnt <= 16'd0;
            state    <= S_WAIT_EOC_RISE;
          end else begin
            wait_cnt <= wait_cnt + 1'b1;
          end
        end

        // 只等 eoc 的同步上升沿
        S_WAIT_EOC_RISE: begin
          adc_soc <= 1'b0;
          if (eoc_rise) begin
            wait_cnt <= 16'd0;
            state    <= S_WAIT_SAMPLE;
          end
        end

        // eoc 上升后再等一拍采样 pob
        S_WAIT_SAMPLE: begin
          adc_soc <= 1'b0;
          if (wait_cnt >= SAMPLE_WAIT_CYCLES - 1) begin
            wait_cnt <= 16'd0;
            state    <= S_STORE;
          end else begin
            wait_cnt <= wait_cnt + 1'b1;
          end
        end

        // 按当前 cur_ch 存数
        S_STORE: begin
          adc_soc <= 1'b0;
          case (cur_ch)
            3'd0: ch0_data <= adc_pob;
            3'd1: ch1_data <= adc_pob;
            3'd2: ch2_data <= adc_pob;
            3'd3: ch3_data <= adc_pob;
            3'd4: ch4_data <= adc_pob;
            3'd5: ch5_data <= adc_pob;
            3'd6: ch6_data <= adc_pob;
            3'd7: ch7_data <= adc_pob;
            default: ;
          endcase
          state <= S_NEXT;
        end

        S_NEXT: begin
          adc_soc <= 1'b0;
          if (cur_ch == 3'd7) begin
            update <= 1'b1;
            cur_ch <= 3'd0;
            if (!start) begin
              busy          <= 1'b0;
              start_latched <= 1'b0;
              state         <= S_IDLE;
            end else begin
              state <= S_SET_CH;
            end
          end else begin
            cur_ch <= cur_ch + 1'b1;
            state  <= S_SET_CH;
          end
        end

        default: begin
          adc_soc <= 1'b0;
          state   <= S_PWR_IDLE;
        end
      endcase
    end
  end

  wire update_fire;  //synthesis keep
  assign update_fire = (state == S_NEXT) && (cur_ch == 3'd7);

  reg [4:0] update_cnt;  //synthesis keep

endmodule
