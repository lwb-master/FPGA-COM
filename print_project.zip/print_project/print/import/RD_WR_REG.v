module rd_wr_reg_top(
    gpio0_etb_trig,
    gpio_ext_porta,
    gpio_intr_flag,
    gpio_intrclk_en,
    gpio_porta_ddr,
    gpio_porta_dr,
    paddr,
    pclk,
    pclk_intr,
    penable,
    pprot,
    prdata,
    presetn,
    psel,
    pwdata,
    pwrite,
    tipc_gpio0_trust,
    rd_reg_01,
    rd_reg_02,
    rd_reg_03,
    rd_reg_04,
    rd_reg_05,
    rd_reg_06,
    rd_reg_07,
    rd_reg_08,
    rd_reg_09,
    rd_reg_10,
    rd_reg_11,
    rd_reg_12,
    rd_reg_13,
    rd_reg_14,
    rd_reg_15,
    rd_reg_16,
    rd_reg_17,
    rd_reg_18,
    rd_reg_19,
    rd_reg_20,
    rd_reg_21,
    rd_reg_22,
    rd_reg_23,
    rd_reg_24,
    rd_reg_25,
    rd_reg_26,
    rd_reg_27,
    rd_reg_28,
    rd_reg_29,
    rd_reg_30,
    rd_reg_31,
    rd_reg_32,
    rd_reg_33,
    rd_reg_34,
    rd_reg_35,
    wr_reg_01,
    wr_reg_02,
    wr_reg_03,
    wr_reg_04,
    wr_reg_05,
    wr_reg_06,
    wr_reg_07,
    wr_reg_08,
    wr_reg_09,
    wr_reg_10,
    wr_reg_11,
    wr_reg_12,
    wr_reg_13,
    wr_reg_14,
    wr_reg_15,
    wr_reg_16,
    wr_reg_17,
    wr_reg_18,
    wr_reg_19,
    wr_reg_20,
    wr_reg_21,
    wr_reg_22,
    wr_reg_23,
    wr_reg_24,
    wr_reg_25,
    wr_reg_26,
    wr_reg_27,
    wr_reg_28,
    wr_reg_29,
    wr_reg_30,
    wr_reg_31,
    wr_reg_32,
    wr_reg_33,
    wr_reg_34,
    wr_reg_35,
    wr_reg_36,
    wr_reg_37,
    wr_reg_38,
    wr_reg_39,
    wr_reg_40,
    wr_reg_41,
    wr_reg_42,
    wr_reg_43,
    wr_reg_44,
    wr_reg_45,
    wr_reg_46,
    wr_reg_47,
    wr_reg_48,
    wr_reg_49,
    wr_reg_50,
    wr_reg_51,
    wr_reg_52,
    wr_reg_53,
    wr_reg_54,
    wr_reg_55,
    wr_reg_56,
    wr_reg_57,
    wr_reg_58,
    wr_reg_59,
    wr_reg_60,
    wr_reg_61,
    wr_reg_62,
    wr_reg_63,
    wr_reg_64,
    wr_reg_65,
    wr_reg_66,
    wr_reg_67,
    wr_reg_68,
    wr_reg_69,
    wr_reg_70,
    wr_reg_71,
    wr_reg_72,
    wr_reg_73,
    wr_reg_74,
    wr_reg_75,
    wr_reg_76,
    wr_reg_77,
    wr_reg_78,
    wr_reg_79,
    wr_reg_80,
    wr_reg_81,
    wr_reg_82,
    wr_reg_83,
    wr_reg_84,
    wr_reg_85,
    wr_reg_86,
    wr_reg_87,
    wr_reg_88,
    wr_reg_89,
    wr_reg_90,
    wr_reg_91,
    wr_reg_92
);


input [31:0] rd_reg_11;//synthesis keep
input [31:0] rd_reg_12;//synthesis keep
input [31:0] rd_reg_13;//synthesis keep
input [31:0] rd_reg_14;//synthesis keep
input [31:0] rd_reg_15;//synthesis keep
input [31:0] rd_reg_16;//synthesis keep
input [31:0] rd_reg_17;//synthesis keep
input [31:0] rd_reg_18;//synthesis keep
input [31:0] rd_reg_19;//synthesis keep
input [31:0] rd_reg_20;//synthesis keep
input [31:0] rd_reg_21;//synthesis keep
input [31:0] rd_reg_22;//synthesis keep
input [31:0] rd_reg_23;//synthesis keep
input [31:0] rd_reg_24;//synthesis keep
input [31:0] rd_reg_25;//synthesis keep
input [31:0] rd_reg_26;//synthesis keep
input [31:0] rd_reg_27;//synthesis keep
input [31:0] rd_reg_28;//synthesis keep
input [31:0] rd_reg_29;//synthesis keep
input [31:0] rd_reg_30;//synthesis keep
input [31:0] rd_reg_31;//synthesis keep
input [31:0] rd_reg_32;//synthesis keep
input [31:0] rd_reg_33;//synthesis keep
input [31:0] rd_reg_34;//synthesis keep
input [31:0] rd_reg_35;//synthesis keep
output [31:0] wr_reg_61;//synthesis keep
output [31:0] wr_reg_62;//synthesis keep
output [31:0] wr_reg_63;//synthesis keep
output [31:0] wr_reg_64;//synthesis keep
output [31:0] wr_reg_65;//synthesis keep
output [31:0] wr_reg_66;//synthesis keep
output [31:0] wr_reg_67;//synthesis keep
output [31:0] wr_reg_68;//synthesis keep
output [31:0] wr_reg_69;//synthesis keep
output [31:0] wr_reg_70;//synthesis keep
output [31:0] wr_reg_71;//synthesis keep
output [31:0] wr_reg_72;//synthesis keep
output [31:0] wr_reg_73;//synthesis keep
output [31:0] wr_reg_74;//synthesis keep
output [31:0] wr_reg_75;//synthesis keep
output [31:0] wr_reg_76;//synthesis keep
output [31:0] wr_reg_77;//synthesis keep
output [31:0] wr_reg_78;//synthesis keep
output [31:0] wr_reg_79;//synthesis keep
output [31:0] wr_reg_80;//synthesis keep
output [31:0] wr_reg_81;//synthesis keep
output [31:0] wr_reg_82;//synthesis keep
output [31:0] wr_reg_83;//synthesis keep
output [31:0] wr_reg_84;//synthesis keep
output [31:0] wr_reg_85;//synthesis keep
output [31:0] wr_reg_86;//synthesis keep
output [31:0] wr_reg_87;//synthesis keep
output [31:0] wr_reg_88;//synthesis keep
output [31:0] wr_reg_89;//synthesis keep
output [31:0] wr_reg_90;//synthesis keep
output [31:0] wr_reg_91;//synthesis keep
output [31:0] wr_reg_92;//synthesis keep

input   [31:0]  gpio_ext_porta;  
input   [31:0]  paddr;           
input           pclk;            
input           pclk_intr;       
input           penable;         
input   [2 :0]  pprot;           
input           presetn;         
input           psel;            
input   [31:0]  pwdata;          
input           pwrite;          
input           tipc_gpio0_trust; 
output  [31:0]  gpio0_etb_trig;  
output          gpio_intr_flag;  
output          gpio_intrclk_en; 
output  [31:0]  gpio_porta_ddr;  
output  [31:0]  gpio_porta_dr;   
output  [31:0]  prdata;
input  [31:0]  rd_reg_01;
input  [31:0]  rd_reg_02;
input  [31:0]  rd_reg_03;
input  [31:0]  rd_reg_04;
input  [31:0]  rd_reg_05;
input  [31:0]  rd_reg_06;
input  [31:0]  rd_reg_07;
input  [31:0]  rd_reg_08;
input  [31:0]  rd_reg_09;
input  [31:0]  rd_reg_10;
output  [31:0]  wr_reg_01;
output  [31:0]  wr_reg_02;
output  [31:0]  wr_reg_03;
output  [31:0]  wr_reg_04;
output  [31:0]  wr_reg_05;
output  [31:0]  wr_reg_06;
output  [31:0]  wr_reg_07;
output  [31:0]  wr_reg_08;
output  [31:0]  wr_reg_09;
output  [31:0]  wr_reg_10;
output  [31:0]  wr_reg_11;
output  [31:0]  wr_reg_12;
output  [31:0]  wr_reg_13;
output  [31:0]  wr_reg_14;
output  [31:0]  wr_reg_15;
output  [31:0]  wr_reg_16;
output  [31:0]  wr_reg_17;
output  [31:0]  wr_reg_18;
output  [31:0]  wr_reg_19;
output  [31:0]  wr_reg_20;
output  [31:0]  wr_reg_21;
output  [31:0]  wr_reg_22;
output  [31:0]  wr_reg_23;
output  [31:0]  wr_reg_24;
output  [31:0]  wr_reg_25;
output  [31:0]  wr_reg_26;
output  [31:0]  wr_reg_27;
output  [31:0]  wr_reg_28;
output  [31:0]  wr_reg_29;
output  [31:0]  wr_reg_30;
output  [31:0]  wr_reg_31;
output  [31:0]  wr_reg_32;
output  [31:0]  wr_reg_33;
output  [31:0]  wr_reg_34;
output  [31:0]  wr_reg_35;
output  [31:0]  wr_reg_36;
output  [31:0]  wr_reg_37;
output  [31:0]  wr_reg_38;
output  [31:0]  wr_reg_39;
output  [31:0]  wr_reg_40;
output  [31:0]  wr_reg_41;
output  [31:0]  wr_reg_42;
output  [31:0]  wr_reg_43;
output  [31:0]  wr_reg_44;
output  [31:0]  wr_reg_45;
output  [31:0]  wr_reg_46;
output  [31:0]  wr_reg_47;
output  [31:0]  wr_reg_48;
output  [31:0]  wr_reg_49;
output  [31:0]  wr_reg_50;
output  [31:0]  wr_reg_51;
output  [31:0]  wr_reg_52;
output  [31:0]  wr_reg_53;
output  [31:0]  wr_reg_54;
output  [31:0]  wr_reg_55;
output  [31:0]  wr_reg_56;
output  [31:0]  wr_reg_57;
output  [31:0]  wr_reg_58;
output  [31:0]  wr_reg_59;
output  [31:0]  wr_reg_60;

wire     [31:0]  rd_reg_01;//synthesis keep
wire     [31:0]  rd_reg_02;//synthesis keep
wire     [31:0]  rd_reg_03;//synthesis keep
wire     [31:0]  rd_reg_04;//synthesis keep
wire     [31:0]  rd_reg_05;//synthesis keep
wire     [31:0]  rd_reg_06;//synthesis keep
wire     [31:0]  rd_reg_07;//synthesis keep
wire     [31:0]  rd_reg_08;//synthesis keep
wire     [31:0]  rd_reg_09;//synthesis keep
wire     [31:0]  rd_reg_10;//synthesis keep
wire     [31:0]  rd_reg_11;//synthesis keep
wire     [31:0]  rd_reg_12;//synthesis keep
wire     [31:0]  rd_reg_13;//synthesis keep
wire     [31:0]  rd_reg_14;//synthesis keep
wire     [31:0]  rd_reg_15;//synthesis keep
wire     [31:0]  rd_reg_16;//synthesis keep
wire     [31:0]  rd_reg_17;//synthesis keep
wire     [31:0]  rd_reg_18;//synthesis keep
wire     [31:0]  rd_reg_19;//synthesis keep
wire     [31:0]  rd_reg_20;//synthesis keep
wire     [31:0]  rd_reg_21;//synthesis keep
wire     [31:0]  rd_reg_22;//synthesis keep
wire     [31:0]  rd_reg_23;//synthesis keep
wire     [31:0]  rd_reg_24;//synthesis keep
wire     [31:0]  rd_reg_25;//synthesis keep
wire     [31:0]  rd_reg_26;//synthesis keep
wire     [31:0]  rd_reg_27;//synthesis keep
wire     [31:0]  rd_reg_28;//synthesis keep
wire     [31:0]  rd_reg_29;//synthesis keep
wire     [31:0]  rd_reg_30;//synthesis keep
wire     [31:0]  rd_reg_31;//synthesis keep
wire     [31:0]  rd_reg_32;//synthesis keep
wire     [31:0]  rd_reg_33;//synthesis keep
wire     [31:0]  rd_reg_34;//synthesis keep
wire     [31:0]  rd_reg_35;//synthesis keep


reg      [31:0]  wr_reg_01;//synthesis keep
reg      [31:0]  wr_reg_02;//synthesis keep
reg      [31:0]  wr_reg_03;//synthesis keep
reg      [31:0]  wr_reg_04;//synthesis keep
reg      [31:0]  wr_reg_05;//synthesis keep
reg      [31:0]  wr_reg_06;//synthesis keep
reg      [31:0]  wr_reg_07;//synthesis keep
reg      [31:0]  wr_reg_08;//synthesis keep
reg      [31:0]  wr_reg_09;//synthesis keep
reg      [31:0]  wr_reg_10;//synthesis keep
reg      [31:0]  wr_reg_11;//synthesis keep
reg      [31:0]  wr_reg_12;//synthesis keep
reg      [31:0]  wr_reg_13;//synthesis keep
reg      [31:0]  wr_reg_14;//synthesis keep
reg      [31:0]  wr_reg_15;//synthesis keep
reg      [31:0]  wr_reg_16;//synthesis keep
reg      [31:0]  wr_reg_17;//synthesis keep
reg      [31:0]  wr_reg_18;//synthesis keep
reg      [31:0]  wr_reg_19;//synthesis keep
reg      [31:0]  wr_reg_20;//synthesis keep
reg      [31:0]  wr_reg_21;//synthesis keep
reg      [31:0]  wr_reg_22;//synthesis keep
reg      [31:0]  wr_reg_23;//synthesis keep
reg      [31:0]  wr_reg_24;//synthesis keep
reg      [31:0]  wr_reg_25;//synthesis keep
reg      [31:0]  wr_reg_26;//synthesis keep
reg      [31:0]  wr_reg_27;//synthesis keep
reg      [31:0]  wr_reg_28;//synthesis keep
reg      [31:0]  wr_reg_29;//synthesis keep
reg      [31:0]  wr_reg_30;//synthesis keep
reg      [31:0]  wr_reg_31;//synthesis keep
reg      [31:0]  wr_reg_32;//synthesis keep
reg      [31:0]  wr_reg_33;//synthesis keep
reg      [31:0]  wr_reg_34;//synthesis keep
reg      [31:0]  wr_reg_35;//synthesis keep
reg      [31:0]  wr_reg_36;//synthesis keep
reg      [31:0]  wr_reg_37;//synthesis keep
reg      [31:0]  wr_reg_38;//synthesis keep
reg      [31:0]  wr_reg_39;//synthesis keep
reg      [31:0]  wr_reg_40;//synthesis keep
reg      [31:0]  wr_reg_41;//synthesis keep
reg      [31:0]  wr_reg_42;//synthesis keep
reg      [31:0]  wr_reg_43;//synthesis keep
reg      [31:0]  wr_reg_44;//synthesis keep
reg      [31:0]  wr_reg_45;//synthesis keep
reg      [31:0]  wr_reg_46;//synthesis keep
reg      [31:0]  wr_reg_47;//synthesis keep
reg      [31:0]  wr_reg_48;//synthesis keep
reg      [31:0]  wr_reg_49;//synthesis keep
reg      [31:0]  wr_reg_50;//synthesis keep
reg      [31:0]  wr_reg_51;//synthesis keep
reg      [31:0]  wr_reg_52;//synthesis keep
reg      [31:0]  wr_reg_53;//synthesis keep
reg      [31:0]  wr_reg_54;//synthesis keep 
reg      [31:0]  wr_reg_55;//synthesis keep
reg      [31:0]  wr_reg_56;//synthesis keep
reg      [31:0]  wr_reg_57;//synthesis keep
reg      [31:0]  wr_reg_58;//synthesis keep
reg      [31:0]  wr_reg_59;//synthesis keep
reg      [31:0]  wr_reg_60;//synthesis keep
reg      [31:0]  wr_reg_61;//synthesis keep
reg      [31:0]  wr_reg_62;//synthesis keep
reg      [31:0]  wr_reg_63;//synthesis keep
reg      [31:0]  wr_reg_64;//synthesis keep
reg      [31:0]  wr_reg_65;//synthesis keep
reg      [31:0]  wr_reg_66;//synthesis keep
reg      [31:0]  wr_reg_67;//synthesis keep
reg      [31:0]  wr_reg_68;//synthesis keep
reg      [31:0]  wr_reg_69;//synthesis keep
reg      [31:0]  wr_reg_70;//synthesis keep
reg      [31:0]  wr_reg_71;//synthesis keep
reg      [31:0]  wr_reg_72;//synthesis keep
reg      [31:0]  wr_reg_73;//synthesis keep
reg      [31:0]  wr_reg_74;//synthesis keep
reg      [31:0]  wr_reg_75;//synthesis keep
reg      [31:0]  wr_reg_76;//synthesis keep
reg      [31:0]  wr_reg_77;//synthesis keep
reg      [31:0]  wr_reg_78;//synthesis keep
reg      [31:0]  wr_reg_79;//synthesis keep
reg      [31:0]  wr_reg_80;//synthesis keep
reg      [31:0]  wr_reg_81;//synthesis keep
reg      [31:0]  wr_reg_82;//synthesis keep
reg      [31:0]  wr_reg_83;//synthesis keep
reg      [31:0]  wr_reg_84;//synthesis keep
reg      [31:0]  wr_reg_85;//synthesis keep
reg      [31:0]  wr_reg_86;//synthesis keep
reg      [31:0]  wr_reg_87;//synthesis keep
reg      [31:0]  wr_reg_88;//synthesis keep
reg      [31:0]  wr_reg_89;//synthesis keep
reg      [31:0]  wr_reg_90;//synthesis keep
reg      [31:0]  wr_reg_91;//synthesis keep
reg      [31:0]  wr_reg_92;//synthesis keep

localparam  REG_RD_01 = 7'b0000001,
            REG_RD_02 = 7'b0000010,
            REG_RD_03 = 7'b0000011,
            REG_RD_04 = 7'b0000100,
            REG_RD_05 = 7'b0000101,
            REG_RD_06 = 7'b0000110,
            REG_RD_07 = 7'b0000111,
            REG_RD_08 = 7'b0001000;
localparam  REG_WR_01 = 7'b0001001,
            REG_WR_02 = 7'b0001010,
            REG_WR_03 = 7'b0001011,
            REG_WR_04 = 7'b0001100,
            REG_WR_05 = 7'b0001101,
            REG_WR_06 = 7'b0001110,
            REG_WR_07 = 7'b0001111,
            REG_WR_08 = 7'b0010000,
            REG_WR_09 = 7'b0010001,
            REG_WR_10 = 7'b0010010,
            REG_WR_11 = 7'b0010011,
            REG_WR_12 = 7'b0010100,
            REG_WR_13 = 7'b0010101,
            REG_WR_14 = 7'b0010110,
            REG_WR_15 = 7'b0010111,
            REG_WR_16 = 7'b0011000,
            REG_WR_17 = 7'b0011001,
            REG_WR_18 = 7'b0011010,
            REG_WR_19 = 7'b0011011,
            REG_WR_20 = 7'b0011100,
            REG_WR_21 = 7'b0011101,
            REG_WR_22 = 7'b0011110,
            REG_WR_23 = 7'b0011111,
            REG_WR_24 = 7'b0100000,
            REG_WR_25 = 7'b0100001,
            REG_WR_26 = 7'b0100010,
            REG_WR_27 = 7'b0100011,
            REG_WR_28 = 7'b0100100,
            REG_WR_29 = 7'b0100101,
            REG_WR_30 = 7'b0100110,
            REG_WR_31 = 7'b0100111,
            REG_WR_32 = 7'b0101000,
            REG_WR_33 = 7'b0101001,
            REG_WR_34 = 7'b0101010,
            REG_WR_35 = 7'b0101011,
            REG_WR_36 = 7'b0101100,
            REG_WR_37 = 7'b0101101,
            REG_WR_38 = 7'b0101110,
            REG_WR_39 = 7'b0101111,
            REG_WR_40 = 7'b0110000,
            REG_WR_41 = 7'b0110001,
            REG_WR_42 = 7'b0110010,
            REG_WR_43 = 7'b0110011,
            REG_WR_44 = 7'b0110100,
            REG_WR_45 = 7'b0110101,
            REG_WR_46 = 7'b0110110,
            REG_WR_47 = 7'b0110111,
            REG_WR_48 = 7'b0111000,
            REG_WR_49 = 7'b0111001,
            REG_WR_50 = 7'b0111010,
            REG_WR_51 = 7'b0111011,
            REG_WR_52 = 7'b0111100,
            REG_WR_53 = 7'b0111101,
            REG_WR_54 = 7'b0111110,
            REG_WR_55 = 7'b0111111,
            REG_WR_56 = 7'b1000000,
            REG_WR_57 = 7'b1000001,
            REG_WR_58 = 7'b1000010,
            REG_WR_59 = 7'b1000011,
            REG_WR_60 = 7'b1000100;
localparam  REG_RD_09 = 7'b1000101,
            REG_RD_10 = 7'b1000110;


localparam  REG_WR_61 = 7'b1000111,
            REG_WR_62 = 7'b1001000,
            REG_WR_63 = 7'b1001001,
            REG_WR_64 = 7'b1001010,
            REG_WR_65 = 7'b1001011,
            REG_WR_66 = 7'b1001100,
            REG_WR_67 = 7'b1001101,
            REG_WR_68 = 7'b1001110,
            REG_WR_69 = 7'b1001111,
            REG_WR_70 = 7'b1010000,
            REG_WR_71 = 7'b1010001,
            REG_WR_72 = 7'b1010010,
            REG_WR_73 = 7'b1010011,
            REG_WR_74 = 7'b1010100,
            REG_WR_75 = 7'b1010101,
            REG_WR_76 = 7'b1010110,
            REG_WR_77 = 7'b1010111,
            REG_WR_78 = 7'b1011000,
            REG_WR_79 = 7'b1011001,
            REG_WR_80 = 7'b1011010,
            REG_WR_81 = 7'b1011011,
            REG_WR_82 = 7'b1011100,
            REG_WR_83 = 7'b1011101,
            REG_WR_84 = 7'b1011110,
            REG_WR_85 = 7'b1011111,
            REG_WR_86 = 7'b1100000,
            REG_WR_87 = 7'b1100001,
            REG_WR_88 = 7'b1100010,
            REG_WR_89 = 7'b1100011,
            REG_WR_90 = 7'b1100100,
            REG_WR_91 = 7'b1100101,
            REG_WR_92 = 7'b1100110;


localparam  REG_RD_11 = 7'b1100111,
            REG_RD_12 = 7'b1101000,
            REG_RD_13 = 7'b1101001,
            REG_RD_14 = 7'b1101010,
            REG_RD_15 = 7'b1101011,
            REG_RD_16 = 7'b1101100,
            REG_RD_17 = 7'b1101101,
            REG_RD_18 = 7'b1101110,
            REG_RD_19 = 7'b1101111,
            REG_RD_20 = 7'b1110000,
            REG_RD_21 = 7'b1110001,
            REG_RD_22 = 7'b1110010,
            REG_RD_23 = 7'b1110011,
            REG_RD_24 = 7'b1110100,
            REG_RD_25 = 7'b1110101,
            REG_RD_26 = 7'b1110110,
            REG_RD_27 = 7'b1110111,
            REG_RD_28 = 7'b1111000,
            REG_RD_29 = 7'b1111001,
            REG_RD_30 = 7'b1111010,
            REG_RD_31 = 7'b1111011,
            REG_RD_32 = 7'b1111100,
            REG_RD_33 = 7'b1111101,
            REG_RD_34 = 7'b1111110,
            REG_RD_35 = 7'b1111111;




//读寄存器的读功能，将寄存器中的值读到APB总线上
assign prdata = (paddr[8:2] == REG_RD_01) ? rd_reg_01 :
                 (paddr[8:2] == REG_RD_02) ? rd_reg_02 :
                 (paddr[8:2] == REG_RD_03) ? rd_reg_03 :
                 (paddr[8:2] == REG_RD_04) ? rd_reg_04 :
                 (paddr[8:2] == REG_RD_05) ? rd_reg_05 :
                 (paddr[8:2] == REG_RD_06) ? rd_reg_06 :
                 (paddr[8:2] == REG_RD_07) ? rd_reg_07 :
                 (paddr[8:2] == REG_RD_08) ? rd_reg_08 :
                 (paddr[8:2] == REG_RD_09) ? rd_reg_09 :
                 (paddr[8:2] == REG_RD_10) ? rd_reg_10 :
                 (paddr[8:2] == REG_RD_11) ? rd_reg_11 :
                 (paddr[8:2] == REG_RD_12) ? rd_reg_12 :
                 (paddr[8:2] == REG_RD_13) ? rd_reg_13 :
                 (paddr[8:2] == REG_RD_14) ? rd_reg_14 :
                 (paddr[8:2] == REG_RD_15) ? rd_reg_15 :
                 (paddr[8:2] == REG_RD_16) ? rd_reg_16 :
                 (paddr[8:2] == REG_RD_17) ? rd_reg_17 :
                 (paddr[8:2] == REG_RD_18) ? rd_reg_18 :
                 (paddr[8:2] == REG_RD_19) ? rd_reg_19 :
                 (paddr[8:2] == REG_RD_20) ? rd_reg_20 :
                 (paddr[8:2] == REG_RD_21) ? rd_reg_21 :
                 (paddr[8:2] == REG_RD_22) ? rd_reg_22 :
                 (paddr[8:2] == REG_RD_23) ? rd_reg_23 :
                 (paddr[8:2] == REG_RD_24) ? rd_reg_24 :
                 (paddr[8:2] == REG_RD_25) ? rd_reg_25 :
                 (paddr[8:2] == REG_RD_26) ? rd_reg_26 :
                 (paddr[8:2] == REG_RD_27) ? rd_reg_27 :
                 (paddr[8:2] == REG_RD_28) ? rd_reg_28 :
                 (paddr[8:2] == REG_RD_29) ? rd_reg_29 :
                 (paddr[8:2] == REG_RD_30) ? rd_reg_30 :
                 (paddr[8:2] == REG_RD_31) ? rd_reg_31 :
                 (paddr[8:2] == REG_RD_32) ? rd_reg_32 :
                 (paddr[8:2] == REG_RD_33) ? rd_reg_33 :
                 (paddr[8:2] == REG_RD_34) ? rd_reg_34 :
                 (paddr[8:2] == REG_RD_35) ? rd_reg_35 :
                 32'b0;
//写寄存器的写功能
always@(posedge pclk or negedge presetn) begin
    if (presetn == 1'b0) begin
        wr_reg_01 <= 32'b0;
        wr_reg_02 <= 32'b0;
        wr_reg_03 <= 32'b0;
        wr_reg_04 <= 32'b0;
        wr_reg_05 <= 32'b0;
        wr_reg_06 <= 32'b0;
        wr_reg_07 <= 32'b0;
        wr_reg_08 <= 32'b0;
        wr_reg_09 <= 32'b0;
        wr_reg_10 <= 32'b0;
        wr_reg_11 <= 32'b0;
        wr_reg_12 <= 32'b0;
        wr_reg_13 <= 32'b0;
        wr_reg_14 <= 32'b0;
        wr_reg_15 <= 32'b0;
        wr_reg_16 <= 32'b0;
        wr_reg_17 <= 32'b0;
        wr_reg_18 <= 32'b0;
        wr_reg_19 <= 32'b0;
        wr_reg_20 <= 32'b0;
        wr_reg_21 <= 32'b0;
        wr_reg_22 <= 32'b0;
        wr_reg_23 <= 32'b0;
        wr_reg_24 <= 32'b0;
        wr_reg_25 <= 32'b0;
        wr_reg_26 <= 32'b0;
        wr_reg_27 <= 32'b0;
        wr_reg_28 <= 32'b0;
        wr_reg_29 <= 32'b0;
        wr_reg_30 <= 32'b0;
        wr_reg_31 <= 32'b0;
        wr_reg_32 <= 32'b0;
        wr_reg_33 <= 32'b0;
        wr_reg_34 <= 32'b0;
        wr_reg_35 <= 32'b0;
        wr_reg_36 <= 32'b0;
        wr_reg_37 <= 32'b0;
        wr_reg_38 <= 32'b0;
        wr_reg_39 <= 32'b0;
        wr_reg_40 <= 32'b0;
        wr_reg_41 <= 32'b0;
        wr_reg_42 <= 32'b0;
        wr_reg_43 <= 32'b0;
        wr_reg_44 <= 32'b0;
        wr_reg_45 <= 32'b0;
        wr_reg_46 <= 32'b0;
        wr_reg_47 <= 32'b0;
        wr_reg_48 <= 32'b0;
        wr_reg_49 <= 32'b0;
        wr_reg_50 <= 32'b0;
        wr_reg_51 <= 32'b0;
        wr_reg_52 <= 32'b0;
        wr_reg_53 <= 32'b0;
        wr_reg_54 <= 32'b0;
        wr_reg_55 <= 32'b0;
        wr_reg_56 <= 32'b0;
        wr_reg_57 <= 32'b0;
        wr_reg_58 <= 32'b0;
        wr_reg_59 <= 32'b0;
        wr_reg_60 <= 32'b0;
        wr_reg_61 <= 32'b0;
        wr_reg_62 <= 32'b0;
        wr_reg_63 <= 32'b0;
        wr_reg_64 <= 32'b0;
        wr_reg_65 <= 32'b0;
        wr_reg_66 <= 32'b0;
        wr_reg_67 <= 32'b0;
        wr_reg_68 <= 32'b0;
        wr_reg_69 <= 32'b0;
        wr_reg_70 <= 32'b0;
        wr_reg_71 <= 32'b0;
        wr_reg_72 <= 32'b0;
        wr_reg_73 <= 32'b0;
        wr_reg_74 <= 32'b0;
        wr_reg_75 <= 32'b0;
        wr_reg_76 <= 32'b0;
        wr_reg_77 <= 32'b0;
        wr_reg_78 <= 32'b0;
        wr_reg_79 <= 32'b0;
        wr_reg_80 <= 32'b0;
        wr_reg_81 <= 32'b0;
        wr_reg_82 <= 32'b0;
        wr_reg_83 <= 32'b0;
        wr_reg_84 <= 32'b0;
        wr_reg_85 <= 32'b0;
        wr_reg_86 <= 32'b0;
        wr_reg_87 <= 32'b0;
        wr_reg_88 <= 32'b0;
        wr_reg_89 <= 32'b0;
        wr_reg_90 <= 32'b0;
        wr_reg_91 <= 32'b0;
        wr_reg_92 <= 32'b0;
    end
    else if((pwrite == 1'b1) && (psel == 1'b1) && (penable == 1'b1)) begin
        case (paddr[8:2])
            REG_WR_01: wr_reg_01 <= pwdata;
            REG_WR_02: wr_reg_02 <= pwdata;
            REG_WR_03: wr_reg_03 <= pwdata;
            REG_WR_04: wr_reg_04 <= pwdata;
            REG_WR_05: wr_reg_05 <= pwdata;
            REG_WR_06: wr_reg_06 <= pwdata;
            REG_WR_07: wr_reg_07 <= pwdata;
            REG_WR_08: wr_reg_08 <= pwdata;
            REG_WR_09: wr_reg_09 <= pwdata;
            REG_WR_10: wr_reg_10 <= pwdata;
            REG_WR_11: wr_reg_11 <= pwdata;
            REG_WR_12: wr_reg_12 <= pwdata;
            REG_WR_13: wr_reg_13 <= pwdata;
            REG_WR_14: wr_reg_14 <= pwdata;
            REG_WR_15: wr_reg_15 <= pwdata;
            REG_WR_16: wr_reg_16 <= pwdata;
            REG_WR_17: wr_reg_17 <= pwdata;
            REG_WR_18: wr_reg_18 <= pwdata;
            REG_WR_19: wr_reg_19 <= pwdata;
            REG_WR_20: wr_reg_20 <= pwdata;
            REG_WR_21: wr_reg_21 <= pwdata;
            REG_WR_22: wr_reg_22 <= pwdata;
            REG_WR_23: wr_reg_23 <= pwdata;
            REG_WR_24: wr_reg_24 <= pwdata;
            REG_WR_25: wr_reg_25 <= pwdata;
            REG_WR_26: wr_reg_26 <= pwdata;
            REG_WR_27: wr_reg_27 <= pwdata;
            REG_WR_28: wr_reg_28 <= pwdata;
            REG_WR_29: wr_reg_29 <= pwdata;
            REG_WR_30: wr_reg_30 <= pwdata;
            REG_WR_31: wr_reg_31 <= pwdata;
            REG_WR_32: wr_reg_32 <= pwdata;
            REG_WR_33: wr_reg_33 <= pwdata;
            REG_WR_34: wr_reg_34 <= pwdata;
            REG_WR_35: wr_reg_35 <= pwdata;
            REG_WR_36: wr_reg_36 <= pwdata;
            REG_WR_37: wr_reg_37 <= pwdata;
            REG_WR_38: wr_reg_38 <= pwdata;
            REG_WR_39: wr_reg_39 <= pwdata;
            REG_WR_40: wr_reg_40 <= pwdata;
            REG_WR_41: wr_reg_41 <= pwdata;
            REG_WR_42: wr_reg_42 <= pwdata;
            REG_WR_43: wr_reg_43 <= pwdata;
            REG_WR_44: wr_reg_44 <= pwdata;
            REG_WR_45: wr_reg_45 <= pwdata;
            REG_WR_46: wr_reg_46 <= pwdata;
            REG_WR_47: wr_reg_47 <= pwdata;
            REG_WR_48: wr_reg_48 <= pwdata;
            REG_WR_49: wr_reg_49 <= pwdata;
            REG_WR_50: wr_reg_50 <= pwdata;
            REG_WR_51: wr_reg_51 <= pwdata;
            REG_WR_52: wr_reg_52 <= pwdata;
            REG_WR_53: wr_reg_53 <= pwdata;
            REG_WR_54: wr_reg_54 <= pwdata;
            REG_WR_55: wr_reg_55 <= pwdata;
            REG_WR_56: wr_reg_56 <= pwdata;
            REG_WR_57: wr_reg_57 <= pwdata;
            REG_WR_58: wr_reg_58 <= pwdata;
            REG_WR_59: wr_reg_59 <= pwdata;
            REG_WR_60: wr_reg_60 <= pwdata;
            REG_WR_61: wr_reg_61 <= pwdata;
            REG_WR_62: wr_reg_62 <= pwdata;
            REG_WR_63: wr_reg_63 <= pwdata;
            REG_WR_64: wr_reg_64 <= pwdata;
            REG_WR_65: wr_reg_65 <= pwdata;
            REG_WR_66: wr_reg_66 <= pwdata;
            REG_WR_67: wr_reg_67 <= pwdata;
            REG_WR_68: wr_reg_68 <= pwdata;
            REG_WR_69: wr_reg_69 <= pwdata;
            REG_WR_70: wr_reg_70 <= pwdata;
            REG_WR_71: wr_reg_71 <= pwdata;
            REG_WR_72: wr_reg_72 <= pwdata;
            REG_WR_73: wr_reg_73 <= pwdata;
            REG_WR_74: wr_reg_74 <= pwdata;
            REG_WR_75: wr_reg_75 <= pwdata;
            REG_WR_76: wr_reg_76 <= pwdata;
            REG_WR_77: wr_reg_77 <= pwdata;
            REG_WR_78: wr_reg_78 <= pwdata;
            REG_WR_79: wr_reg_79 <= pwdata;
            REG_WR_80: wr_reg_80 <= pwdata;
            REG_WR_81: wr_reg_81 <= pwdata;
            REG_WR_82: wr_reg_82 <= pwdata;
            REG_WR_83: wr_reg_83 <= pwdata;
            REG_WR_84: wr_reg_84 <= pwdata;
            REG_WR_85: wr_reg_85 <= pwdata;
            REG_WR_86: wr_reg_86 <= pwdata;
            REG_WR_87: wr_reg_87 <= pwdata;
            REG_WR_88: wr_reg_88 <= pwdata;
            REG_WR_89: wr_reg_89 <= pwdata;
            REG_WR_90: wr_reg_90 <= pwdata;
            REG_WR_91: wr_reg_91 <= pwdata;
            REG_WR_92: wr_reg_92 <= pwdata;
        endcase
    end
end




endmodule
