module Fuser_Ctrl(  RST,
                    CLK,
                    EN,
                    AC_EN,
                    NCTH_C_in,
                    NCTH_D_in,
                    AVR_C_DATA,
                    AVR_D_DATA,
                    ST0,
                    ADC_ST,
                    Data_valid,
                    nRelay_AC_ON,
                    nFUSER_EN,
                    nFUSER_Ready,
                    FUSER_ERROR,
                    FUSER_OFF                    
                    );

(*keep*)input   RST;//synthesis keep
(*keep*)input   CLK;//synthesis keep
(*keep*)input   EN;//synthesis keep
(*keep*)input   AC_EN;//synthesis keep
(*keep*)input   [11:0]NCTH_C_in;//synthesis keep
(*keep*)input   [11:0]NCTH_D_in;//synthesis keep
(*keep*)input   Data_valid;//synthesis keep

(*keep*)output  reg nRelay_AC_ON;//synthesis keep
(*keep*)output  reg nFUSER_EN;//synthesis keep
(*keep*)output  reg nFUSER_Ready;//synthesis keep
(*keep*)output  reg FUSER_ERROR;//synthesis keep
(*keep*)output  reg FUSER_OFF;//synthesis keep

//测试
(*keep*)output  reg [11:0] AVR_C_DATA;//synthesis keep
(*keep*)output  reg [11:0] AVR_D_DATA;//synthesis keep
(*keep*)output  reg [1:0]  ADC_ST;//synthesis keep
(*keep*)output  wire        ST0        ;//synthesis keep
reg [3:0]ST;//synthesis keep
reg	[31:0]Delay_CNT;//synthesis keep
reg	[31:0]Delay_SET;//synthesis keep
reg	Delay_EN,	TimeOut_Flag;//synthesis keep
reg [11:0]TN_DATA,TO_DATA,TR_DATA;//synthesis keep

assign ST0 = ST[0];

reg     AVR_EN;//synthesis keep
reg     [7:0]AVR_CNT;//synthesis keep
reg     [19:0]AVR_NCTH_C;//synthesis keep
reg     [19:0]AVR_NCTH_D;//synthesis keep
reg     AVR_Finish;//synthesis keep
always@(posedge CLK)    //计算采样值的平均值，
begin
    if(RST)
    begin
        AVR_CNT<=8'd0;
        AVR_NCTH_C<=20'd0;
        AVR_NCTH_D<=20'd0;
        AVR_Finish<=1'b0;
    end
    else
    begin
        if(AVR_EN)
        begin
           if((AVR_CNT<8'd16)&&Data_valid)
           begin
                AVR_NCTH_C<=AVR_NCTH_C+NCTH_C_in;
                AVR_NCTH_D<=AVR_NCTH_D+NCTH_D_in;
                AVR_CNT<=AVR_CNT+8'd1;
                AVR_Finish<=1'b0;
           end
           else
           begin
                if(AVR_CNT==8'd16)
                begin
                    AVR_CNT<=8'd0;
                    AVR_NCTH_C<={4'b0000,AVR_NCTH_C[19:4]};//   16次平均值
                    AVR_NCTH_D<={4'b0000,AVR_NCTH_D[19:4]};//   16次平均值
                    AVR_Finish<=1'b1;
                end
           end 
        end
        else
        begin
            AVR_CNT<=8'd0;
            AVR_NCTH_C<=20'd0;
            AVR_NCTH_D<=20'd0;
            AVR_Finish<=1'b0;
        end 
    end
end

reg [11:0] NCTH_C_Data;//synthesis keep
reg [11:0] NCTH_C_Pre_Data;//synthesis keep
reg [11:0] NCTH_D_Data;//synthesis keep
reg [11:0] NCTH_D_Pre_Data;//synthesis keep
reg [11:0] NCTH_OV_Data;//synthesis keep
reg [11:0] NCTH_OV_Pre_Data;//synthesis keep
reg [11:0] NCTH_RCV_Data;//synthesis keep
reg [11:0] NCTH_RCV_Pre_Data;//synthesis keep

reg [10:0] D_RATIO,OV_RATIO,RCV_RATIO;//synthesis keep
reg NCTH_C_Index_EN;//synthesis keep
reg NCTH_C_Index_Finish;//synthesis keep
always@(posedge CLK)
begin
    if(RST)
    begin
        NCTH_C_Data<=12'd0;
        NCTH_C_Pre_Data<=12'd0;
        NCTH_D_Data<=12'd0;
        NCTH_D_Pre_Data<=12'd0;
        NCTH_OV_Data<=12'd0;
        NCTH_OV_Pre_Data<=12'd0;
        NCTH_RCV_Data<=12'd0;
        NCTH_RCV_Pre_Data<=12'd0;
        NCTH_C_Index_Finish<=1'b0;
    end
    else
    begin
        if(NCTH_C_Index_EN)
        begin
            //TN_DATA<=NCTH_D_Pre_Data-((NCTH_D_Pre_Data-NCTH_D_Data)*(NCTH_C_Pre_Data-AVR_C_DATA)/(NCTH_C_Pre_Data-NCTH_C_Data));
            //TO_DATA<=NCTH_OV_Pre_Data-((NCTH_OV_Pre_Data-NCTH_OV_Data)*(NCTH_C_Pre_Data-AVR_C_DATA)/(NCTH_C_Pre_Data-NCTH_C_Data));
            //TR_DATA<=NCTH_RCV_Pre_Data-((NCTH_RCV_Pre_Data-NCTH_RCV_Data)*(NCTH_C_Pre_Data-AVR_C_DATA)/(NCTH_C_Pre_Data-NCTH_C_Data));
            
            //D_RATIO<=(NCTH_D_Pre_Data-NCTH_D_Data)/(NCTH_C_Pre_Data-NCTH_C_Data)
            //OV_RATIO<=(NCTH_OV_Pre_Data-NCTH_OV_Data)/(NCTH_C_Pre_Data-NCTH_C_Data)
            //RCV_RATIO<=(NCTH_RCV_Pre_Data-NCTH_RCV_Data)/(NCTH_C_Pre_Data-NCTH_C_Data)
            if(AVR_C_DATA>20'd3296)
                begin
                   NCTH_C_Data<=12'd3296;
                   NCTH_C_Pre_Data<=12'd3296; 
                   NCTH_D_Data<=12'd3250;
                   NCTH_D_Pre_Data<=12'd3250;
                   NCTH_OV_Data<=12'd3246;
                   NCTH_OV_Pre_Data<=12'd3246;
                   NCTH_RCV_Data<=12'd3259;
                   NCTH_RCV_Pre_Data<=12'd3259;
                   D_RATIO<=11'd0;
                   OV_RATIO<=11'd0;
                   RCV_RATIO<=11'd0;
                end
                else if(AVR_C_DATA>20'd3233)
                begin
                   NCTH_C_Data<=12'd3233;
                   NCTH_C_Pre_Data<=12'd3296;
                   NCTH_D_Data<=12'd3167;
                   NCTH_D_Pre_Data<=12'd3250;
                   NCTH_OV_Data<=12'd3163;
                   NCTH_OV_Pre_Data<=12'd3246;
                   NCTH_RCV_Data<=12'd3180;
                   NCTH_RCV_Pre_Data<=12'd3259;
                   D_RATIO<=11'd1349;
                   OV_RATIO<=11'd1349;
                   RCV_RATIO<=11'd1284;  
                end
                else if(AVR_C_DATA>20'd3140)
                begin
                   NCTH_C_Data<=12'd3140;
                   NCTH_C_Pre_Data<=12'd3233; 
                   NCTH_D_Data<=12'd3054;
                   NCTH_D_Pre_Data<=12'd3167;
                   NCTH_OV_Data<=12'd3047;
                   NCTH_OV_Pre_Data<=12'd3163;
                   NCTH_RCV_Data<=12'd3074;
                   NCTH_RCV_Pre_Data<=12'd3180; 
                   D_RATIO<=11'd1244;
                   OV_RATIO<=11'd1277;
                   RCV_RATIO<=11'd1167;  
                end
                else if(AVR_C_DATA>20'd3011)
                begin
                   NCTH_C_Data<=12'd3011;
                   NCTH_C_Pre_Data<=12'd3140; 
                   NCTH_D_Data<=12'd2902;
                   NCTH_D_Pre_Data<=12'd3054;
                   NCTH_OV_Data<=12'd2895;
                   NCTH_OV_Pre_Data<=12'd3047;
                   NCTH_RCV_Data<=12'd2925;
                   NCTH_RCV_Pre_Data<=12'd3074;
                   D_RATIO<=11'd1207;
                   OV_RATIO<=11'd1207;
                   RCV_RATIO<=11'd1183;
                end
                else if(AVR_C_DATA>20'd2842)
                begin
                   NCTH_C_Data<=12'd2842;
                   NCTH_C_Pre_Data<=12'd3011; 
                   NCTH_D_Data<=12'd2710;
                   NCTH_D_Pre_Data<=12'd2902;
                   NCTH_OV_Data<=12'd2703;
                   NCTH_OV_Pre_Data<=12'd2895;
                   NCTH_RCV_Data<=12'd2739;
                   NCTH_RCV_Pre_Data<=12'd2925;
                   D_RATIO<=11'd1163;
                   OV_RATIO<=11'd1163;
                   RCV_RATIO<=11'd1127;
                end 
                else if(AVR_C_DATA>20'd2627)
                begin
                   NCTH_C_Data<=12'd2627;
                   NCTH_C_Pre_Data<=12'd2842;
                   NCTH_D_Data<=12'd2484;
                   NCTH_D_Pre_Data<=12'd2710; 
                   NCTH_OV_Data<=12'd2474;
                   NCTH_OV_Pre_Data<=12'd2703;
                   NCTH_RCV_Data<=12'd2517;
                   NCTH_RCV_Pre_Data<=12'd2739;
                   D_RATIO<=11'd1076;
                   OV_RATIO<=11'd1091;
                   RCV_RATIO<=11'd1057;
                end 
                else if(AVR_C_DATA>20'd2382)
                begin
                   NCTH_C_Data<=12'd2382;
                   NCTH_C_Pre_Data<=12'd2627;
                   NCTH_D_Data<=12'd2233;
                   NCTH_D_Pre_Data<=12'd2484;
                   NCTH_OV_Data<=12'd2223;
                   NCTH_OV_Pre_Data<=12'd2474;
                   NCTH_RCV_Data<=12'd2243;
                   NCTH_RCV_Pre_Data<=12'd2517; 
                   D_RATIO<=11'd1049;
                   OV_RATIO<=11'd1049;
                   RCV_RATIO<=11'd1145;
                end 
                else if(AVR_C_DATA>20'd2097)
                begin
                   NCTH_C_Data<=12'd2097;
                   NCTH_C_Pre_Data<=12'd2382; 
                   NCTH_D_Data<=12'd1968;
                   NCTH_D_Pre_Data<=12'd2233;
                   NCTH_OV_Data<=12'd1954;
                   NCTH_OV_Pre_Data<=12'd2223;
                   NCTH_RCV_Data<=12'd2001;
                   NCTH_RCV_Pre_Data<=12'd2243;
                   D_RATIO<=11'd952;
                   OV_RATIO<=11'd967;
                   RCV_RATIO<=11'd870;
                end 
                else if(AVR_C_DATA>20'd1832)
                begin
                   NCTH_C_Data<=12'd1832;
                   NCTH_C_Pre_Data<=12'd2097; 
                   NCTH_D_Data<=12'd1703;
                   NCTH_D_Pre_Data<=12'd1968;
                   NCTH_OV_Data<=12'd1693;
                   NCTH_OV_Pre_Data<=12'd1954;
                   NCTH_RCV_Data<=12'd1732;
                   NCTH_RCV_Pre_Data<=12'd2001;
                   D_RATIO<=11'd1024;
                   OV_RATIO<=11'd1009;
                   RCV_RATIO<=11'd1039;
                end 
                else if(AVR_C_DATA>20'd1560)
                begin
                   NCTH_C_Data<=12'd1560;
                   NCTH_C_Pre_Data<=12'd1832; 
                   NCTH_D_Data<=12'd1451;
                   NCTH_D_Pre_Data<=12'd1703;
                   NCTH_OV_Data<=12'd1441;
                   NCTH_OV_Pre_Data<=12'd1693;
                   NCTH_RCV_Data<=12'd1477;
                   NCTH_RCV_Pre_Data<=12'd1732;
                   D_RATIO<=11'd949;
                   OV_RATIO<=11'd949;
                   RCV_RATIO<=11'd960;
                end
                else if(AVR_C_DATA>20'd1308)
                begin
                   NCTH_C_Data<=12'd1308;
                   NCTH_C_Pre_Data<=12'd1560;
                   NCTH_D_Data<=12'd1222;
                   NCTH_D_Pre_Data<=12'd1451;
                   NCTH_OV_Data<=12'd1212;
                   NCTH_OV_Pre_Data<=12'd1441;
                   NCTH_RCV_Data<=12'd1245;
                   NCTH_RCV_Pre_Data<=12'd1477; 
                   D_RATIO<=11'd931;
                   OV_RATIO<=11'd931;
                   RCV_RATIO<=11'd943;
                end 
                else if(AVR_C_DATA>20'd1086)
                begin
                   NCTH_C_Data<=12'd1086;
                   NCTH_C_Pre_Data<=12'd1308;
                   NCTH_D_Data<=12'd1020;
                   NCTH_D_Pre_Data<=12'd1222; 
                   NCTH_OV_Data<=12'd1010;
                   NCTH_OV_Pre_Data<=12'd1212;
                   NCTH_RCV_Data<=12'd1040;
                   NCTH_RCV_Pre_Data<=12'd1245;
                   D_RATIO<=11'd932;
                   OV_RATIO<=11'd932;
                   RCV_RATIO<=11'd946;
                end 
                else if(AVR_C_DATA>20'd898)
                begin
                   NCTH_C_Data<=12'd898;
                   NCTH_C_Pre_Data<=12'd1086; 
                   NCTH_D_Data<=12'd845;
                   NCTH_D_Pre_Data<=12'd1020;
                   NCTH_OV_Data<=12'd838;
                   NCTH_OV_Pre_Data<=12'd1010;
                   NCTH_RCV_Data<=12'd861;
                   NCTH_RCV_Pre_Data<=12'd1040;
                   D_RATIO<=11'd953;
                   OV_RATIO<=11'd937;
                   RCV_RATIO<=11'd975;
                end 
                else if(AVR_C_DATA>20'd735)
                begin
                   NCTH_C_Data<=12'd735;
                   NCTH_C_Pre_Data<=12'd898; 
                   NCTH_D_Data<=12'd699;
                   NCTH_D_Pre_Data<=12'd845;
                   NCTH_OV_Data<=12'd696;
                   NCTH_OV_Pre_Data<=12'd838;
                   NCTH_RCV_Data<=12'd712;
                   NCTH_RCV_Pre_Data<=12'd861;
                   D_RATIO<=11'd917;
                   OV_RATIO<=11'd892;
                   RCV_RATIO<=11'd936;
                end 
                else if(AVR_C_DATA>20'd603)
                begin
                   NCTH_C_Data<=12'd603;
                   NCTH_C_Pre_Data<=12'd735; 
                   NCTH_D_Data<=12'd580;
                   NCTH_D_Pre_Data<=12'd699;
                   NCTH_OV_Data<=12'd576;
                   NCTH_OV_Pre_Data<=12'd696;
                   NCTH_RCV_Data<=12'd590;
                   NCTH_RCV_Pre_Data<=12'd712;
                   D_RATIO<=11'd923;
                   OV_RATIO<=11'd931;
                   RCV_RATIO<=11'd946;
                end  
                else if(AVR_C_DATA>20'd497)
                begin
                   NCTH_C_Data<=12'd497;
                   NCTH_C_Pre_Data<=12'd603; 
                   NCTH_D_Data<=12'd480;
                   NCTH_D_Pre_Data<=12'd580;
                   NCTH_OV_Data<=12'd477;
                   NCTH_OV_Pre_Data<=12'd576;
                   NCTH_RCV_Data<=12'd487;
                   NCTH_RCV_Pre_Data<=12'd590;
                   D_RATIO<=11'd966;
                   OV_RATIO<=11'd956;
                   RCV_RATIO<=11'd995;
                end  
                else
                begin
                   NCTH_C_Data<=12'd497;
                   NCTH_C_Pre_Data<=12'd497;
                   NCTH_D_Data<=12'd480;
                   NCTH_D_Pre_Data<=12'd480;
                   NCTH_OV_Data<=12'd477;
                   NCTH_OV_Pre_Data<=12'd477;
                   NCTH_RCV_Data<=12'd487;
                   NCTH_RCV_Pre_Data<=12'd487; 
                   D_RATIO<=11'd0;
                   OV_RATIO<=11'd0;
                   RCV_RATIO<=11'd0;
                end
                
                NCTH_C_Index_Finish<=1'b1;
        end
        else
        begin
            NCTH_C_Data<=12'd0;
            NCTH_C_Pre_Data<=12'd0;
            NCTH_D_Data<=12'd0;
            NCTH_D_Pre_Data<=12'd0;
            NCTH_OV_Data<=12'd0;
            NCTH_OV_Pre_Data<=12'd0;
            NCTH_RCV_Data<=12'd0;
            NCTH_RCV_Pre_Data<=12'd0;
            NCTH_C_Index_Finish<=1'b0;
            D_RATIO<=11'd0;
            OV_RATIO<=11'd0;
            RCV_RATIO<=11'd0;
        end 
    end 
end

////////////////////数值计算单元IP/////////////////
reg [11:0]DSP_A;//synthesis keep
reg [10:0]DSP_Y;//synthesis keep
wire [22:0]DSP_P;//synthesis keep
DSP_0   DSP_0               //进行(A-B)*Y的计算
                (
                  .CLK(CLK),
                  .A(DSP_A),
                  .Y(DSP_Y),
                  .P(DSP_P)
                );
/////////////////温度控制主程序//////////////

always@(posedge CLK)
begin
    if(RST)
    begin
        ST<=4'd1;
        // nRelay_AC_ON<=1'b1;
        nFUSER_EN<=1'b1;
        nFUSER_Ready<=1'b0;
        FUSER_ERROR<=1'b0;
        FUSER_OFF<=1'b1;
        Delay_EN<=1'b0;
        Delay_SET<=32'd0;
        AVR_C_DATA<=12'd0;
        AVR_D_DATA<=12'd0;
        NCTH_C_Index_EN<=1'b0;
        AVR_EN<=1'b0;
        TN_DATA<=12'd0;
        TO_DATA<=12'd0;
        TR_DATA<=12'd0;
        DSP_A<=12'd0;
        DSP_Y<=11'd0;
    end
    else
    begin
        if(EN)
        begin
            case(ST)
            4'd1:                   //打开定影加热，延时1ms
            begin
                // nRelay_AC_ON<=1'b0;
                nFUSER_EN<=1'b0;
                FUSER_OFF<=1'b0;
                NCTH_C_Index_EN<=1'b0;
                AVR_EN<=1'b0;
                if(TimeOut_Flag)
				begin
					Delay_EN<=1'b0;
					Delay_SET<=32'd0;
                    ST<=4'd2;										
				end
				else
				begin
					Delay_EN<=1'b1;
					Delay_SET<=32'd10000;    //延时1ms
				end
            end
            4'd2:
            begin
                if(AVR_Finish)
                begin
                    ST<=4'd3;       //
                    AVR_C_DATA<=AVR_NCTH_C[11:0];
                    AVR_D_DATA<=AVR_NCTH_D[11:0];
                    AVR_EN<=1'b0; 
                end
                else
                begin
                    AVR_EN<=1'b1;   //使能采样值求平均
                    NCTH_C_Index_EN<=1'b0;  //均值计算过程中，关闭查表
                end
            end
            4'd3:
            begin
                if((AVR_C_DATA>12'd3385)||(AVR_D_DATA>12'd3385))    //定影器低温或温控电路故障
                begin
                    FUSER_ERROR<=1'b1;
                    // nRelay_AC_ON<=1'b1;
                    FUSER_OFF<=1'b1;
                    nFUSER_EN<=1'b1;
                    ST<=4'd11;
                end
                else
                begin
                    NCTH_C_Index_EN<=1'b1;
                end
                if(NCTH_C_Index_Finish)
                begin
                    ST<=4'd4;
                end
            end
            4'd4:
            begin
                ST<=4'd5;
                if(NCTH_C_Pre_Data>NCTH_C_Data)
                begin
                    DSP_A<=NCTH_C_Pre_Data-AVR_C_DATA;
                    DSP_Y<=D_RATIO;
                end
                else
                begin
                    TN_DATA<=12'hFFF;
                end    
            end
            4'd5:
            begin
                ST<=4'd6;
                if(NCTH_C_Pre_Data>NCTH_C_Data)
                begin
                    TN_DATA<=NCTH_D_Pre_Data-DSP_P[21:10];//TN_DATA<=NCTH_D_Pre_Data-(D_RATIO*(NCTH_C_Pre_Data-AVR_C_DATA));
                    DSP_A<=NCTH_C_Pre_Data-AVR_C_DATA;
                    DSP_Y<=OV_RATIO;
                                      
                end
                else
                begin
                    TO_DATA<=12'hFFF;
                end    
            end
            4'd6:
            begin
                ST<=4'd7;
                if(NCTH_C_Pre_Data>NCTH_C_Data)
                begin
                    TO_DATA<=NCTH_OV_Pre_Data-DSP_P[21:10];//TO_DATA<=NCTH_OV_Pre_Data-(OV_RATIO*(NCTH_C_Pre_Data-AVR_C_DATA));
                    DSP_A<=NCTH_C_Pre_Data-AVR_C_DATA;
                    DSP_Y<=RCV_RATIO;                
                end
                else
                begin
                    TR_DATA<=12'hFFF;
                end    
            end
            4'd7:
            begin
                TR_DATA<=NCTH_RCV_Pre_Data-DSP_P[21:10];//TR_DATA<=NCTH_RCV_Pre_Data-(RCV_RATIO*(NCTH_C_Pre_Data-AVR_C_DATA));
                ST<=4'd8;
            end
            4'd8:
            begin
                if(AVR_D_DATA<TN_DATA)
                begin
                    FUSER_OFF<=1'b1;
                    nFUSER_EN<=1'b1;
                    nFUSER_Ready<=1'b1;
                end
                if(TimeOut_Flag)
				begin
					Delay_EN<=1'b0;
					Delay_SET<=32'd0;
                    ST<=4'd9;										
				end
				else
				begin
					Delay_EN<=1'b1;
					Delay_SET<=32'd100000;    //延时1ms
				end
                
            end
            4'd9:
            begin
                if(AVR_D_DATA<TO_DATA)
                begin
                    nFUSER_EN<=1'b1;
                    FUSER_ERROR<=1'b1;
                end
                if(TimeOut_Flag)
				begin
					Delay_EN<=1'b0;
					Delay_SET<=32'd0;
                    ST<=4'd10;										
				end
				else
				begin
					Delay_EN<=1'b1;
					Delay_SET<=32'd100000;    //延时1ms
				end
            end
            4'd10:
            begin
                
                if(TR_DATA<AVR_D_DATA)
                begin
                    FUSER_OFF<=1'b0;
                    nFUSER_EN<=1'b0;
                end
                ST<=4'd2;
            end
            4'd11:
            begin
                // ST<=4'd9;
                if(TimeOut_Flag)
				begin
					Delay_EN<=1'b0;
					Delay_SET<=32'd0;
                    ST<=4'd2;										
				end
				else
				begin
					Delay_EN<=1'b1;
					Delay_SET<=32'd10000;    //延时1ms
				end
            end
            default:
            begin
                ST<=4'd1;
                // nRelay_AC_ON<=1'b1;
                nFUSER_EN<=1'b1;
                nFUSER_Ready<=1'b0;
                FUSER_ERROR<=1'b0;
                FUSER_OFF<=1'b1;
                Delay_EN<=1'b0;
                Delay_SET<=32'd0;
                AVR_C_DATA<=12'd0;
                AVR_D_DATA<=12'd0;
                NCTH_C_Index_EN<=1'b0;
                AVR_EN<=1'b0;
                TN_DATA<=12'd0;
                TO_DATA<=12'd0;
                TR_DATA<=12'd0;
                DSP_A<=12'd0;
                DSP_Y<=11'd0;
            end
            endcase
        end
        else
        begin
            ST<=4'd1;
            // nRelay_AC_ON<=1'b1;
            nFUSER_EN<=1'b1;
            nFUSER_Ready<=1'b0;
            FUSER_ERROR<=1'b0;
            FUSER_OFF<=1'b1;
            Delay_EN<=1'b0;
            Delay_SET<=32'd0;
            AVR_C_DATA<=12'd0;
            AVR_D_DATA<=12'd0;
            NCTH_C_Index_EN<=1'b0;
            AVR_EN<=1'b0;
            TN_DATA<=12'd0;
            TO_DATA<=12'd0;
            TR_DATA<=12'd0;
            DSP_A<=12'd0;
            DSP_Y<=11'd0;
        end
    end
end 
	///////延时进程////////
always	@(posedge	CLK)
begin
	if(RST)
	begin
		TimeOut_Flag<=1'b0;
		Delay_CNT<=32'd0;
	end
	else
	begin
		if(Delay_EN)
		begin
				
			if(	Delay_CNT	<	Delay_SET	)
            begin
				TimeOut_Flag<=1'b0;
                Delay_CNT<=Delay_CNT+32'd1;
            end
            else
            begin
                TimeOut_Flag<=1'b1;
                Delay_CNT<=32'd0;
            end    
		end
		else
		begin
			Delay_CNT<=32'd0;
			TimeOut_Flag<=1'b0;
		end
	end
end      

///////nRelay_AC_ON的控制进程////////
always @(posedge  CLK ) begin
    if (RST) begin
        nRelay_AC_ON<=1'b1;
    end
    else begin
        if (AC_EN) begin
            if((AVR_C_DATA>12'd3385)||(AVR_D_DATA>12'd3385)) begin
                    nRelay_AC_ON<=1'b1;
            end else begin
                nRelay_AC_ON <= 1'b0;
            end
        end 
        else begin
            nRelay_AC_ON<=1'b1;
        end
    end
end

endmodule
