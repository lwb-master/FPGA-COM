`timescale 1ns/1ns

module DR1_ADC_adc_wiz_0 #(
	//-----------adc configuration 0 -----------------//
	parameter	PHY_EXTERNAL_MUX_GAP	=	4'B0000		,
	parameter	REG_ADC_SOC_SEL			=	1'B0		,
	parameter	REG_ADC_SOC				=	1'b0		,
	parameter	ANALOG_MUX_EN			=	1'B1		,
	parameter	PHY_EXTERNAL_MUX		=	1'B0		,
	parameter	DIFF_ENABLE				=	1'B0		,
	parameter	RES_SEL					=	2'B11		,
	parameter	REF_SEL					=	1'B1		,
	//-----------adc configuration 1 -----------------//
	parameter	INTER_ERROR_MASK		=	1'B0		,	
	parameter	INTER_LTH_MASK			=	1'B0		,
	parameter	INTER_GTH_MASK			=	1'B0		,
	parameter	INTER_DONE_MASK			=	1'B0		,
	//-----------adc configuration 2 -----------------//
	parameter	ADC_CLK_DIV				=	8'h00		,
	parameter	ADC_CLK_GATE			=	1'B0		,
	parameter	ADC_CLK_SEL				=	2'B00		,
	parameter	REG_ADC_DISLVL			=	1'B0		,
	parameter	REG_ADC_ENABLE			=	1'B1		,
	//-----------adc configuration 3 -----------------//
	parameter	EXTERNAL_CHANNEL_SEL	=	3'B000		,
	parameter	CHANNEL_SEL				=	3'B000		,	
	parameter	MODE_SEL				=	3'B000		,
	//-----------adc threshold value -----------------//
	parameter	CHANNEL0_LOWER			=	12'D0		,
	parameter	CHANNEL0_UPPER			=	12'HFFF		,
	parameter	CHANNEL1_LOWER			=	12'D0		,
	parameter	CHANNEL1_UPPER			=	12'HFFF		,
	parameter	CHANNEL2_LOWER			=	12'D0		,
	parameter	CHANNEL2_UPPER			=	12'HFFF		,
	parameter	CHANNEL3_LOWER			=	12'D0		,
	parameter	CHANNEL3_UPPER			=	12'HFFF		,
	parameter	CHANNEL4_LOWER			=	12'D0		,
	parameter	CHANNEL4_UPPER			=	12'HFFF		,
	parameter	CHANNEL5_LOWER			=	12'D0		,
	parameter	CHANNEL5_UPPER			=	12'HFFF		,
	parameter	CHANNEL6_LOWER			=	12'D0		,
	parameter	CHANNEL6_UPPER			=	12'HFFF		,
	parameter	CHANNEL7_LOWER			=	12'D0		,
	parameter	CHANNEL7_UPPER			=	12'HFFF		,
	//-----------adc channel sel -----------------//
	parameter	CHANNEL0_SEL			=	5'D0		,
	parameter	CHANNEL1_SEL			=	5'D0		,
	parameter	CHANNEL2_SEL			=	5'D0		,
	parameter	CHANNEL3_SEL			=	5'D0		,
	parameter	CHANNEL4_SEL			=	5'D0		,
	parameter	CHANNEL5_SEL			=	5'D0		,
	parameter	CHANNEL6_SEL			=	5'D0		,
	parameter	CHANNEL7_SEL			=	5'D0		,

	parameter	ADC_NON_FABRIC_MODE		=	1'b0		,

	parameter	FILE_PATH				= "./"			,
	parameter	CHANGE_CLK				= 1				
)
(
	input  wire			adc_pl_pclk			,
    input  wire			adc_pl_prst_n		,
    input  wire	[7:0]	adc_pl_paddr		,
    input  wire			adc_pl_psel			,
    input  wire			adc_pl_penable		,
    input  wire			adc_pl_pwrite		,
    input  wire	[15:0]	adc_pl_pwdata		,
    output wire [15:0]	adc_pl_prdata		,
    output wire			adc_pl_pready		,
	output wire			adc_interrupt_pl	,
	output wire	[2:0]	adc_muxaddr			,
	input  wire			adc_soc				,
	input  wire			adc_sel_diff		,
	input  wire [1:0]	adc_sel_res			,
	input  wire			adc_sel_ref			,
	input  wire [2:0]	adc_enctr			,
	input  wire [2:0]	adc_sel_channel		,
	input  wire			adc_enable			,
	input  wire			adc_dislvl			,

	input  wire [4:0]	adc_channel_sel_0	,
	input  wire [4:0]	adc_channel_sel_1	,
	input  wire [4:0]	adc_channel_sel_2	,
	input  wire [4:0]	adc_channel_sel_3	,
	input  wire [4:0]	adc_channel_sel_4	,
	input  wire [4:0]	adc_channel_sel_5	,
	input  wire [4:0]	adc_channel_sel_6	,
	input  wire [4:0]	adc_channel_sel_7	,
	input  wire			adc_channel_en		,

	output wire			adc_sob				,
	output wire	[11:0]	adc_pob				,

	input  wire			adc_pl_reset_n		,
	input  wire			adc_pl_clk			,
	
	input  wire         vauxp_0				, 
    input  wire         vauxn_0				,
	input  wire         vauxp_1				, 
    input  wire         vauxn_1				,
	input  wire         vauxp_2				, 
    input  wire         vauxn_2				,
	input  wire         vauxp_3				, 
    input  wire         vauxn_3				,
	input  wire         vauxp_4				, 
    input  wire         vauxn_4				,
	input  wire         vauxp_5				, 
    input  wire         vauxn_5				,
	input  wire         vauxp_6				, 
    input  wire         vauxn_6				,
	input  wire         vauxp_7				, 
    input  wire         vauxn_7				,
	input  wire         vauxp_8				, 
    input  wire         vauxn_8				,
	input  wire         vauxp_9				, 
    input  wire         vauxn_9				,
	input  wire         vauxp_10			, 
    input  wire         vauxn_10			,
	input  wire         vauxp_11			, 
    input  wire         vauxn_11			,
	input  wire         vauxp_12			, 
    input  wire         vauxn_12			,
	input  wire         vauxp_13			, 
    input  wire         vauxn_13			,
	input  wire         vauxp_14			, 
    input  wire         vauxn_14			,
	input  wire         vauxp_15			, 
    input  wire         vauxn_15			,

	output wire			adc_eoc				,
	output wire			adc_eos				,
	output wire			adc_busy			,
	output wire [2:0]	adc_channel			
);

wire			adc_vauxp1	;
wire			adc_vauxn1	;
wire			adc_vauxp2	;
wire			adc_vauxn2	;
wire			adc_vauxp3	;
wire			adc_vauxn3	;
wire			adc_vauxp4	;
wire			adc_vauxn4	;
wire			adc_vauxp5	;
wire			adc_vauxn5	;
wire			adc_vauxp6	;
wire			adc_vauxn6	;
wire			adc_vauxp7	;
wire			adc_vauxn7	;
wire			adc_vauxp8	;
wire			adc_vauxn8	;
wire			adc_vauxp9	;
wire			adc_vauxn9	;
wire			adc_vauxp10	;
wire			adc_vauxn10	;
wire			adc_vauxp11	;
wire			adc_vauxn11	;
wire			adc_vauxp12	;
wire			adc_vauxn12	;
wire			adc_vauxp13	;
wire			adc_vauxn13	;
wire			adc_vauxp14	;
wire			adc_vauxn14	;
wire			adc_vauxp15	;
wire			adc_vauxn15	;

reg [1:0]	state			;
reg [1:0]	next_state		;

localparam	IDLE	= 2'B00	,
			START	= 2'b01	,
			WAIT	= 2'b11	,
			FINISH	= 2'b10	;



	assign adc_vauxp0 = 0;
	assign adc_vauxn0 = 0;




	assign adc_vauxp1 = 0;
	assign adc_vauxn1 = 0;




	assign adc_vauxp2 = 0;
	assign adc_vauxn2 = 0;




	assign adc_vauxp3 = 0;
	assign adc_vauxn3 = 0;




	assign adc_vauxp4 = 0;
	assign adc_vauxn4 = 0;



	assign adc_vauxp5 = vauxp_5;
	assign adc_vauxn5 = vauxn_5;




	assign adc_vauxp6 = vauxp_6;
	assign adc_vauxn6 = vauxn_6;




	assign adc_vauxp7 = vauxp_7;
	assign adc_vauxn7 = vauxn_7;





	assign adc_vauxp8 = 0;
	assign adc_vauxn8 = 0;



	assign adc_vauxp9 = vauxp_9;
	assign adc_vauxn9 = vauxn_9;





	assign adc_vauxp10 = 0;
	assign adc_vauxn10 = 0;



	assign adc_vauxp11 = vauxp_11;
	assign adc_vauxn11 = vauxn_11;




	assign adc_vauxp12 = vauxp_12;
	assign adc_vauxn12 = vauxn_12;




	assign adc_vauxp13 = vauxp_13;
	assign adc_vauxn13 = vauxn_13;




	assign adc_vauxp14 = vauxp_14;
	assign adc_vauxn14 = vauxn_14;





	assign adc_vauxp15 = 0;
	assign adc_vauxn15 = 0;





	reg			pib_soc				;
	reg			pib_sel_diff		;
	reg [1:0]	pib_sel_res			;
	reg			pib_sel_ref			;
	reg [2:0]	pib_enctr			;
	reg [2:0]	pib_sel_channel		;
	reg			pib_enable			;
	reg			pib_dislvl			;
	reg [4:0]	pib_channel_sel_0	;
	reg [4:0]	pib_channel_sel_1	;
	reg [4:0]	pib_channel_sel_2	;
	reg [4:0]	pib_channel_sel_3	;
	reg [4:0]	pib_channel_sel_4	;
	reg [4:0]	pib_channel_sel_5	;
	reg [4:0]	pib_channel_sel_6	;
	reg [4:0]	pib_channel_sel_7	;
	reg			pib_channel_en		;
	
	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			state <= IDLE;
		else
			state <= next_state;
	end

	always@(*)
	begin
		case(state)
			IDLE	:
				next_state = START;
			START	:
				next_state = FINISH;
			FINISH	:
				next_state = FINISH;
			default	:
				next_state = IDLE;
		endcase
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_soc <= 1'b0;
		else if(state == FINISH)
			pib_soc <= adc_soc;
		else if(state == START)
			pib_soc <= 1'b0;
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_sel_diff <= 1'b1;
		else if(state == FINISH)
			pib_sel_diff <= adc_sel_diff;
		else if(state == START)
			pib_sel_diff <= DIFF_ENABLE[0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_sel_res <= 2'd1;
		else if(state == FINISH)
			pib_sel_res <= adc_sel_res;
		else if(state == START)
			pib_sel_res <= RES_SEL[1:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_sel_ref <= 1'b1;
		else if(state == FINISH)
			pib_sel_ref <= adc_sel_ref;
		else if(state == START)
			pib_sel_ref <= REF_SEL[0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_enctr <= 3'd1;
		else if(state == FINISH)
			pib_enctr <= adc_enctr;
		else if(state == START)
			pib_enctr <= 3'D0;
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_sel_channel <= 3'd1;
		else if(state == FINISH)
			pib_sel_channel <= adc_sel_channel;
		else if(state == START)
			pib_sel_channel <= CHANNEL_SEL[2:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_enable <= 1'b1;
		else if(state == FINISH)
			pib_enable <= adc_enable;
		else if(state == START)
			pib_enable <= REG_ADC_ENABLE[0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_dislvl <= 1'b1;
		else if(state == FINISH)
			pib_dislvl <= adc_dislvl;
		else if(state == START)
			pib_dislvl <= REG_ADC_DISLVL[0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_0 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_0 <= adc_channel_sel_0;
		else if(state == START)
			pib_channel_sel_0 <= CHANNEL0_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_1 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_1 <= adc_channel_sel_1;
		else if(state == START)
			pib_channel_sel_1 <= CHANNEL1_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_2 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_2 <= adc_channel_sel_2;
		else if(state == START)
			pib_channel_sel_2 <= CHANNEL2_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_3 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_3 <= adc_channel_sel_3;
		else if(state == START)
			pib_channel_sel_3 <= CHANNEL3_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_4 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_4 <= adc_channel_sel_4;
		else if(state == START)
			pib_channel_sel_4 <= CHANNEL4_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_5 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_5 <= adc_channel_sel_5;
		else if(state == START)
			pib_channel_sel_5 <= CHANNEL5_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_6 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_6 <= adc_channel_sel_6;
		else if(state == START)
			pib_channel_sel_6 <= CHANNEL6_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_sel_7 <= 5'd1;
		else if(state == FINISH)
			pib_channel_sel_7 <= adc_channel_sel_7;
		else if(state == START)
			pib_channel_sel_7 <= CHANNEL7_SEL[4:0];
	end

	always@(posedge adc_pl_clk or negedge adc_pl_reset_n)
	begin
		if(adc_pl_reset_n == 1'b0)
			pib_channel_en <= 1'b1;
		else if(state == FINISH)
			pib_channel_en <= adc_channel_en;
	end



DR1_PHY_ADC #(
	.FILE_PATH			(FILE_PATH			),
	.CHANGE_CLK			(CHANGE_CLK			)
) DR1_PHY_ADC_inst(



	.adc_pl_pclk		(1'b0				),
	.adc_pl_prst_n		(1'b0				),
	.adc_pl_paddr		(8'h00				),
	.adc_pl_psel		(1'b0				),
	.adc_pl_penable		(1'b0				),
	.adc_pl_pwrite		(1'b0				),
	.adc_pl_pwdata		(16'h0000			),
	.adc_pl_prdata		(					),
	.adc_pl_pready		(					),

	.adc_soc			(pib_soc			),
	.adc_non_fabric_mode(ADC_NON_FABRIC_MODE[0]),
	.adc_sel_res		(pib_sel_res		),
	.adc_sel_diff		(pib_sel_diff		),
	.adc_sel_channel	(pib_sel_channel	),
	.adc_sel_ref		(pib_sel_ref		),
	.adc_enable			(pib_enable			),
	.adc_dislvl			(pib_dislvl			),
	.adc_enctr			(pib_enctr			),
	.adc_channel_sel_0	(pib_channel_sel_0	),
	.adc_channel_sel_1	(pib_channel_sel_1	),
	.adc_channel_sel_2	(pib_channel_sel_2	),
	.adc_channel_sel_3	(pib_channel_sel_3	),
	.adc_channel_sel_4	(pib_channel_sel_4	),
	.adc_channel_sel_5	(pib_channel_sel_5	),
	.adc_channel_sel_6	(pib_channel_sel_6	),
	.adc_channel_sel_7	(pib_channel_sel_7	),
	.adc_channel_en		(pib_channel_en		),
	 
	
	.adc_pob			(adc_pob			),
	


	.adc_pl_clk			(adc_pl_clk			),


	.adc_pl_reset_n		(adc_pl_reset_n		),

	.adc_eoc			(adc_eoc			),
	.adc_eos			(adc_eos			),
	.adc_busy			(adc_busy			),
	
	.adc_vauxp_0		(adc_vauxp0			),
	.adc_vauxn_0		(adc_vauxn0			),
	.adc_vauxp_1		(adc_vauxp1			),
	.adc_vauxn_1		(adc_vauxn1			),
	.adc_vauxp_2		(adc_vauxp2			),
	.adc_vauxn_2		(adc_vauxn2			),
	.adc_vauxp_3		(adc_vauxp3			),
	.adc_vauxn_3		(adc_vauxn3			),
	.adc_vauxp_4		(adc_vauxp4			),
	.adc_vauxn_4		(adc_vauxn4			),
	.adc_vauxp_5		(adc_vauxp5			),
	.adc_vauxn_5		(adc_vauxn5			),
	.adc_vauxp_6		(adc_vauxp6			),
	.adc_vauxn_6		(adc_vauxn6			),
	.adc_vauxp_7		(adc_vauxp7			),
	.adc_vauxn_7		(adc_vauxn7			),
	.adc_vauxp_8		(adc_vauxp8			),
	.adc_vauxn_8		(adc_vauxn8			),
	.adc_vauxp_9		(adc_vauxp9			),
	.adc_vauxn_9		(adc_vauxn9			),
	.adc_vauxp_10		(adc_vauxp10		),
	.adc_vauxn_10		(adc_vauxn10		),
	.adc_vauxp_11		(adc_vauxp11		),
	.adc_vauxn_11		(adc_vauxn11		),
	.adc_vauxp_12		(adc_vauxp12		),
	.adc_vauxn_12		(adc_vauxn12		),
	.adc_vauxp_13		(adc_vauxp13		),
	.adc_vauxn_13		(adc_vauxn13		),
	.adc_vauxp_14		(adc_vauxp14		),
	.adc_vauxn_14		(adc_vauxn14		),
	.adc_vauxp_15		(adc_vauxp15		),
	.adc_vauxn_15		(adc_vauxn15		)
);

endmodule 



