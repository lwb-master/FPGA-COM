/************************************************************\
**	Copyright (c) 2012-2026 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Gen time	:	Jun 14 2026 00:41:23
**	IpTool version	:	2026.01(189136 2026/01/26)
**	App version	:	6.2.2(build number:190657)
**	Ip Version	:	1.0
\************************************************************/
`timescale 1ns/1ns
module adc_wiz_0
(
  input                         adc_soc,
  input                         adc_sel_diff,
  input   [1:0]                 adc_sel_res,
  input                         adc_sel_ref,
  input   [2:0]                 adc_enctr,
  input   [2:0]                 adc_sel_channel,
  input                         adc_enable,
  input                         adc_dislvl,
  input   [4:0]                 adc_channel_sel_0,
  input   [4:0]                 adc_channel_sel_1,
  input   [4:0]                 adc_channel_sel_2,
  input   [4:0]                 adc_channel_sel_3,
  input   [4:0]                 adc_channel_sel_4,
  input   [4:0]                 adc_channel_sel_5,
  input   [4:0]                 adc_channel_sel_6,
  input   [4:0]                 adc_channel_sel_7,
  input                         adc_channel_en,
  output  [11:0]                adc_pob,
  input                         adc_pl_reset_n,
  input                         adc_pl_clk,
  input                         vauxp_5,
  input                         vauxn_5,
  input                         vauxp_6,
  input                         vauxn_6,
  input                         vauxp_7,
  input                         vauxn_7,
  input                         vauxp_9,
  input                         vauxn_9,
  input                         vauxp_11,
  input                         vauxn_11,
  input                         vauxp_12,
  input                         vauxn_12,
  input                         vauxp_13,
  input                         vauxn_13,
  input                         vauxp_14,
  input                         vauxn_14,
  output                        adc_eoc,
  output                        adc_busy,
  output  [2:0]                 adc_channel
);

  DR1_ADC_adc_wiz_0
  #(
      .ANALOG_MUX_EN(0),
      .DIFF_ENABLE(0),
      .RES_SEL(3),
      .REF_SEL(1),
      .ADC_CLK_DIV(0),
      .ADC_CLK_GATE(1),
      .ADC_CLK_SEL(2),
      .REG_ADC_DISLVL(0),
      .REG_ADC_ENABLE(1),
      .EXTERNAL_CHANNEL_SEL(0),
      .CHANNEL_SEL(7),
      .MODE_SEL(3),
      .CHANNEL0_SEL(11),
      .CHANNEL1_SEL(5),
      .CHANNEL2_SEL(9),
      .CHANNEL3_SEL(6),
      .CHANNEL4_SEL(7),
      .CHANNEL5_SEL(14),
      .CHANNEL6_SEL(12),
      .CHANNEL7_SEL(13),
      .ADC_NON_FABRIC_MODE(0),
      .FILE_PATH("./"),
      .CHANGE_CLK(1)
  )DR1_ADC_Inst
  (
      .adc_soc(adc_soc),
      .adc_sel_diff(adc_sel_diff),
      .adc_sel_res(adc_sel_res),
      .adc_sel_ref(adc_sel_ref),
      .adc_enctr(adc_enctr),
      .adc_sel_channel(adc_sel_channel),
      .adc_enable(adc_enable),
      .adc_dislvl(adc_dislvl),
      .adc_channel_sel_0(adc_channel_sel_0),
      .adc_channel_sel_1(adc_channel_sel_1),
      .adc_channel_sel_2(adc_channel_sel_2),
      .adc_channel_sel_3(adc_channel_sel_3),
      .adc_channel_sel_4(adc_channel_sel_4),
      .adc_channel_sel_5(adc_channel_sel_5),
      .adc_channel_sel_6(adc_channel_sel_6),
      .adc_channel_sel_7(adc_channel_sel_7),
      .adc_channel_en(adc_channel_en),
      .adc_pob(adc_pob),
      .adc_pl_reset_n(adc_pl_reset_n),
      .adc_pl_clk(adc_pl_clk),
      .vauxp_5(vauxp_5),
      .vauxn_5(vauxn_5),
      .vauxp_6(vauxp_6),
      .vauxn_6(vauxn_6),
      .vauxp_7(vauxp_7),
      .vauxn_7(vauxn_7),
      .vauxp_9(vauxp_9),
      .vauxn_9(vauxn_9),
      .vauxp_11(vauxp_11),
      .vauxn_11(vauxn_11),
      .vauxp_12(vauxp_12),
      .vauxn_12(vauxn_12),
      .vauxp_13(vauxp_13),
      .vauxn_13(vauxn_13),
      .vauxp_14(vauxp_14),
      .vauxn_14(vauxn_14),
      .adc_eoc(adc_eoc),
      .adc_busy(adc_busy),
      .adc_channel(adc_channel)
  );
endmodule
