/************************************************************\
**	Copyright (c) 2012-2026 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Gen time	:	Jun 14 2026 00:39:22
**	IpTool version	:	2026.01(189136 2026/01/26)
**	App version	:	6.2.2(build number:190657)
**	Ip Version	:	2.0
\************************************************************/
`timescale 1ns / 1ns
module DSP_0
(
  input                         CLK,
  input   [11:0]                A,
  input   [10:0]                Y,
  output  [22:0]                P
);

  dsp_macro_0_DSP_0
  #(
      .REGISTER7(0),
      .REGISTER8(1),
      .REGISTER11(1),
      .REGISTER12(0),
      .REGISTER13(1),
      .REGISTER14(1),
      .REGISTER15(1),
      .REGISTER24(1),
      .A_INPUT_TYPE("UNSIGNED"),
      .Y_INPUT_TYPE("UNSIGNED"),
      .A_INPUT_WIDTH(12),
      .Y_INPUT_WIDTH(11),
      .P_OUTPUT_WIDTH(23),
      .USER_CTRL0(30'b100000000000000010010000001110)
  )dsp_macro_0_Inst
  (
      .CLK(CLK),
      .A(A),
      .Y(Y),
      .P(P)
  );
endmodule
