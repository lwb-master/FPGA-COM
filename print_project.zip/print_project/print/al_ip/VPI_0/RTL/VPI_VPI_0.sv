    
// synthesis syn_black_box
module VPI_VPI_0 (  
    output [0:0] outprobe0, 
    output [0:0] outprobe1, 
    output [0:0] outprobe2, 
    output [0:0] outprobe3, 
    output [0:0] outprobe4, 
    input	clk
);
    localparam string IP_TYPE = "VPI";
    
    localparam VPI_OUTPUT_BUS_NUM = 5;
	localparam VPI_BUS_DOUT_NUM = 5;
	localparam integer VPI_BUS_DOUT_WIDTH[0:4] = {1,1,1,1,1};

    parameter VPI_OUTPUT_INIT_VAL = 5'b00000;
endmodule

