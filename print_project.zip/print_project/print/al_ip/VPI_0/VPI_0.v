/************************************************************\
**	Copyright (c) 2012-2026 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Gen time	:	Jun 14 2026 00:43:44
**	IpTool version	:	2026.01(189136 2026/01/26)
**	App version	:	6.2.2(build number:190657)
**	Ip Version	:	1.0
\************************************************************/
`timescale 1ns/1ns
module VPI_0
(
  input                         clk,
  output  [0:0]                 outprobe0,
  output  [0:0]                 outprobe1,
  output  [0:0]                 outprobe2,
  output  [0:0]                 outprobe3,
  output  [0:0]                 outprobe4
);

  VPI_VPI_0  VPI_Inst
  (
      .clk(clk),
      .outprobe0(outprobe0),
      .outprobe1(outprobe1),
      .outprobe2(outprobe2),
      .outprobe3(outprobe3),
      .outprobe4(outprobe4)
  );
endmodule
