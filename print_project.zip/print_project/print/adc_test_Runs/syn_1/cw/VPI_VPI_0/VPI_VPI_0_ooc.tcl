import_device dr1_90.db -package DR1M90GEG484
set_param flow ooc_flow on
read_verilog -file "VPI_VPI_0_vpiInst.sv"
optimize_rtl
map_macro
map
pack
report_area -file VPI_VPI_0_gate.area
export_db -mode ooc "VPI_VPI_0_ooc.db"
