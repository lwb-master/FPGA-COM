source "D:/software/TD_6.2.2/cw/atpl/templa.tcl"
set fd [open "D:/software/TD_6.2.2/cw/atpl/vpi_ip.atpl" r]
set tmpl [read $fd]
close $fd
set parser [::tmpl_parser::tmpl_parser $tmpl]

set ComponentName     VPI_VPI_0
set input_bus_num     0
set output_bus_num    5
set bus_din_width     {}
set bus_dout_width    { 1 1 1 1 1 }
set bus_dout_init_val 5'b00000
set fp [open "cw/VPI_VPI_0/VPI_VPI_0_vpiInst.sv" w+]
puts $fp [eval $parser]
close $fp
