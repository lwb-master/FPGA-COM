              
module VPI_VPI_0 ( 
	output [0:0] outprobe0, 
	output [0:0] outprobe1, 
	output [0:0] outprobe2, 
	output [0:0] outprobe3, 
	output [0:0] outprobe4, 

	input	clk
);

    
	localparam VPI_OUTPUT_BUS_NUM = 5;
	localparam VPI_BUS_DOUT_NUM = 5;
	localparam integer VPI_BUS_DOUT_WIDTH[0:4] = {1,1,1,1,1};
	localparam integer VPI_BUS_DOUT_POS[0:4] = {0,1,2,3,4};
	localparam integer VPI_BUS_CTRL_POS[0:4] = {0,19,38,57,76};

	parameter VPI_BUS_CTRL_LEN = 95;
	parameter VPI_BUS_STAT_LEN = 2;
	parameter VPI_OUTPUT_INIT_VAL = 5'b00000;

	wire vpi_behavior;
	wire vpi_rst;
	wire [94 : 0]  vpi_control;
	wire [0 : 0]  vpi_status;

    	top_vpi_hub #(
		.VPI_OUTPUT_BUS_NUM(VPI_OUTPUT_BUS_NUM),
		.VPI_BUS_DOUT_NUM(VPI_BUS_DOUT_NUM),
		.VPI_BUS_DOUT_WIDTH(VPI_BUS_DOUT_WIDTH),
		.VPI_BUS_DOUT_POS(VPI_BUS_DOUT_POS),
		.VPI_BUS_CTRL_POS(VPI_BUS_CTRL_POS)
	)
    	wrapper_vpi_top (
		.vpi_rst(vpi_rst),
		.vpi_control(vpi_control),
		.vpi_status(),
		.vpi_clk(clk),
		.vpi_behavior_clr(),
		.vpi_bus_din(),
		.vpi_bus_dout({outprobe0,outprobe1,outprobe2,outprobe3,outprobe4})
    	);

   	AL_LOGIC_DEBUGHUB #(
		.CTRL_LEN(VPI_BUS_CTRL_LEN),
		.STAT_LEN(VPI_BUS_STAT_LEN),
		.PWR_ON_CTRL(VPI_OUTPUT_INIT_VAL)
   	)
    	wrapper_debughub(
		.clk(clk),
		.control(vpi_control),
		.status(),
		.rst(vpi_rst),
		.behavior_clr()
    	);

endmodule


