@echo off

rem Tcl script created by Tang Dynasty 6.2.2 190657
rem Copyright (c) 2012-2026 Anlogic Inc.

set HD_SDIR=%~dp0
cd /d "%HD_SDIR%"
D:/software/TD_6.2.2/bin/td_commands_prompt.exe D:\software\TD_6.2.2\scripts/DefaultFlow.tcl
pause
