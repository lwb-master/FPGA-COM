/*
Copyright (c) 2019 Alibaba Group Holding Limited

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
module aou_top(
  apb1_gpio_psel_s5,
  apb1_pmu_psel_s15,
  apb1_rtc_psel_s6,
  apb1_xx_paddr,
  apb1_xx_penable,
  apb1_xx_pprot,
  apb1_xx_pwdata,
  apb1_xx_pwrite,
  cpu_pmu_dfs_ack,
  cpu_pmu_sleep_b,
  dft_clk,
  ehs_pmu_clk,
  els_pmu_clk,
  gpio_apb1_prdata,
  gpio_ioctl_porta_dr,
  gpio_wic_intr,
  ioctl_gpio_ext_porta,
  pad_core_clk,
  pad_core_ctim_refclk,
  pad_core_rst_b,
  pad_gpio_ien,
  pad_gpio_oen,
  pad_mcurst_b,
  pmu_apb0_pclk_en,
  pmu_apb0_s3clk,
  pmu_apb0_s3rst_b,
  pmu_apb1_pclk_en,
  pmu_apb1_prdata,
  pmu_apb1_s3clk,
  pmu_apb1_s3rst_b,
  pmu_cpu_dfs_req,
  pmu_dmac0_hclk,
  pmu_dmac0_hrst_b,
  pmu_dmemdummy0_hclk,
  pmu_dmemdummy0_hrst_b,
  pmu_dummy0_hclk,
  pmu_dummy0_hrst_b,
  pmu_dummy0_s3clk,
  pmu_dummy0_s3rst_b,
  pmu_dummy1_hclk,
  pmu_dummy1_hrst_b,
  pmu_dummy1_p0clk,
  pmu_dummy1_p0rst_b,
  pmu_dummy1_p1clk,
  pmu_dummy1_p1rst_b,
  pmu_dummy1_s3clk,
  pmu_dummy1_s3rst_b,
  pmu_dummy2_hclk,
  pmu_dummy2_hrst_b,
  pmu_dummy2_p0clk,
  pmu_dummy2_p0rst_b,
  pmu_dummy2_p1clk,
  pmu_dummy2_p1rst_b,
  pmu_dummy2_s3clk,
  pmu_dummy2_s3rst_b,
  pmu_dummy3_hclk,
  pmu_dummy3_hrst_b,
  pmu_dummy3_p0clk,
  pmu_dummy3_p0rst_b,
  pmu_dummy3_p1clk,
  pmu_dummy3_p1rst_b,
  pmu_dummy3_s3clk,
  pmu_dummy3_s3rst_b,
  pmu_dummy4_p0clk,
  pmu_dummy4_p0rst_b,
  pmu_dummy4_p1clk,
  pmu_dummy4_p1rst_b,
  pmu_dummy5_p0clk,
  pmu_dummy5_p0rst_b,
  pmu_dummy5_p1clk,
  pmu_dummy5_p1rst_b,
  pmu_dummy6_p1clk,
  pmu_dummy6_p1rst_b,
  pmu_dummy7_p0clk,
  pmu_dummy7_p0rst_b,
  pmu_dummy7_p1clk,
  pmu_dummy7_p1rst_b,
  pmu_dummy8_p0clk,
  pmu_dummy8_p0rst_b,
  pmu_dummy8_p1clk,
  pmu_dummy8_p1rst_b,
  pmu_dummy9_p0clk,
  pmu_dummy9_p0rst_b,
  pmu_hmain0_hclk,
  pmu_hmain0_hrst_b,
  pmu_imemdummy0_hclk,
  pmu_imemdummy0_hrst_b,
  pmu_lsbus_hclk,
  pmu_lsbus_hrst_b,
  pmu_mdummy0_hclk,
  pmu_mdummy0_hrst_b,
  pmu_mdummy1_hclk,
  pmu_mdummy1_hrst_b,
  pmu_mdummy2_hclk,
  pmu_mdummy2_hrst_b,
  pmu_pwm_p0clk,
  pmu_pwm_p0rst_b,
  pmu_smc_hclk,
  pmu_smc_hrst_b,
  pmu_sub3_s3clk,
  pmu_sub3_s3rst_b,
  pmu_tim0_p0clk,
  pmu_tim0_p0rst_b,
  pmu_tim1_p1clk,
  pmu_tim1_p1rst_b,
  pmu_tim2_p0clk,
  pmu_tim2_p0rst_b,
  pmu_tim3_p1clk,
  pmu_tim3_p1rst_b,
  pmu_tim4_p0clk,
  pmu_tim4_p0rst_b,
  pmu_tim5_p1clk,
  pmu_tim5_p1rst_b,
  pmu_tim6_p0clk,
  pmu_tim6_p0rst_b,
  pmu_tim7_p1clk,
  pmu_tim7_p1rst_b,
  pmu_usi0_p0clk,
  pmu_usi0_p0rst_b,
  pmu_usi1_p1clk,
  pmu_usi1_p1rst_b,
  pmu_usi2_p0clk,
  pmu_usi2_p0rst_b,
  pmu_wdt_p0clk,
  pmu_wdt_p0rst_b,
  pmu_wic_intr,
  rtc_apb1_prdata,
  rtc_wic_intr,
  test_mode,
  wdt_pmu_rst_b,
    rd_reg_01,
    rd_reg_02,
    rd_reg_03,
    rd_reg_04,
    rd_reg_05,
    rd_reg_06,
    rd_reg_07,
    rd_reg_08,
    rd_reg_09,
    rd_reg_10,
    rd_reg_11,
    rd_reg_12,
    rd_reg_13,
    rd_reg_14,
    rd_reg_15,
    rd_reg_16,
    rd_reg_17,
    rd_reg_18,
    rd_reg_19,
    rd_reg_20,
    rd_reg_21,
    rd_reg_22,
    rd_reg_23,
    rd_reg_24,
    rd_reg_25,
    rd_reg_26,
    rd_reg_27,
    rd_reg_28,
    rd_reg_29,
    rd_reg_30,
    rd_reg_31,
    rd_reg_32,
    rd_reg_33,
    rd_reg_34,
    rd_reg_35,
    wr_reg_01,
    wr_reg_02,
    wr_reg_03,
    wr_reg_04,
    wr_reg_05,
    wr_reg_06,
    wr_reg_07,
    wr_reg_08,
    wr_reg_09,
    wr_reg_10,
    wr_reg_11,
    wr_reg_12,
    wr_reg_13,
    wr_reg_14,
    wr_reg_15,
    wr_reg_16,
    wr_reg_17,
    wr_reg_18,
    wr_reg_19,
    wr_reg_20,
    wr_reg_21,
    wr_reg_22,
    wr_reg_23,
    wr_reg_24,
    wr_reg_25,
    wr_reg_26,
    wr_reg_27,
    wr_reg_28,
    wr_reg_29,
    wr_reg_30,
    wr_reg_31,
    wr_reg_32,
    wr_reg_33,
    wr_reg_34,
    wr_reg_35,
    wr_reg_36,
    wr_reg_37,
    wr_reg_38,
    wr_reg_39,
    wr_reg_40,
    wr_reg_41,
    wr_reg_42,
    wr_reg_43,
    wr_reg_44,
    wr_reg_45,
    wr_reg_46,
    wr_reg_47,
    wr_reg_48,
    wr_reg_49,
    wr_reg_50,
    wr_reg_51,
    wr_reg_52,
    wr_reg_53,
    wr_reg_54,
    wr_reg_55,
    wr_reg_56,
    wr_reg_57,
    wr_reg_58,
    wr_reg_59,
    wr_reg_60,
        wr_reg_61,
    wr_reg_62,
    wr_reg_63,
    wr_reg_64,
    wr_reg_65,
    wr_reg_66,
    wr_reg_67,
    wr_reg_68,
    wr_reg_69,
    wr_reg_70,
    wr_reg_71,
    wr_reg_72,
    wr_reg_73,
    wr_reg_74,
    wr_reg_75,
    wr_reg_76,
    wr_reg_77,
    wr_reg_78,
    wr_reg_79,
    wr_reg_80,
    wr_reg_81,
    wr_reg_82,
    wr_reg_83,
    wr_reg_84,
    wr_reg_85,
    wr_reg_86,
    wr_reg_87,
    wr_reg_88,
    wr_reg_89,
    wr_reg_90,
    wr_reg_91,
    wr_reg_92
);

input [31:0] rd_reg_11;//synthesis keep
input [31:0] rd_reg_12;//synthesis keep
input [31:0] rd_reg_13;//synthesis keep
input [31:0] rd_reg_14;//synthesis keep
input [31:0] rd_reg_15;//synthesis keep
input [31:0] rd_reg_16;//synthesis keep
input [31:0] rd_reg_17;//synthesis keep
input [31:0] rd_reg_18;//synthesis keep
input [31:0] rd_reg_19;//synthesis keep
input [31:0] rd_reg_20;//synthesis keep
input [31:0] rd_reg_21;//synthesis keep
input [31:0] rd_reg_22;//synthesis keep
input [31:0] rd_reg_23;//synthesis keep
input [31:0] rd_reg_24;//synthesis keep
input [31:0] rd_reg_25;//synthesis keep
input [31:0] rd_reg_26;//synthesis keep
input [31:0] rd_reg_27;//synthesis keep
input [31:0] rd_reg_28;//synthesis keep
input [31:0] rd_reg_29;//synthesis keep
input [31:0] rd_reg_30;//synthesis keep
input [31:0] rd_reg_31;//synthesis keep
input [31:0] rd_reg_32;//synthesis keep
input [31:0] rd_reg_33;//synthesis keep
input [31:0] rd_reg_34;//synthesis keep
input [31:0] rd_reg_35;//synthesis keep
output [31:0] wr_reg_61;//synthesis keep
output [31:0] wr_reg_62;//synthesis keep
output [31:0] wr_reg_63;//synthesis keep
output [31:0] wr_reg_64;//synthesis keep
output [31:0] wr_reg_65;//synthesis keep
output [31:0] wr_reg_66;//synthesis keep
output [31:0] wr_reg_67;//synthesis keep
output [31:0] wr_reg_68;//synthesis keep
output [31:0] wr_reg_69;//synthesis keep
output [31:0] wr_reg_70;//synthesis keep
output [31:0] wr_reg_71;//synthesis keep
output [31:0] wr_reg_72;//synthesis keep
output [31:0] wr_reg_73;//synthesis keep
output [31:0] wr_reg_74;//synthesis keep
output [31:0] wr_reg_75;//synthesis keep
output [31:0] wr_reg_76;//synthesis keep
output [31:0] wr_reg_77;//synthesis keep
output [31:0] wr_reg_78;//synthesis keep
output [31:0] wr_reg_79;//synthesis keep
output [31:0] wr_reg_80;//synthesis keep
output [31:0] wr_reg_81;//synthesis keep
output [31:0] wr_reg_82;//synthesis keep
output [31:0] wr_reg_83;//synthesis keep
output [31:0] wr_reg_84;//synthesis keep
output [31:0] wr_reg_85;//synthesis keep
output [31:0] wr_reg_86;//synthesis keep
output [31:0] wr_reg_87;//synthesis keep
output [31:0] wr_reg_88;//synthesis keep
output [31:0] wr_reg_89;//synthesis keep
output [31:0] wr_reg_90;//synthesis keep
output [31:0] wr_reg_91;//synthesis keep
output [31:0] wr_reg_92;//synthesis keep

input  [31:0]  rd_reg_01;
input  [31:0]  rd_reg_02;
input  [31:0]  rd_reg_03;
input  [31:0]  rd_reg_04;
input  [31:0]  rd_reg_05;
input  [31:0]  rd_reg_06;
input  [31:0]  rd_reg_07;
input  [31:0]  rd_reg_08;
input  [31:0]  rd_reg_09;
input  [31:0]  rd_reg_10;
output  [31:0]  wr_reg_01;
output  [31:0]  wr_reg_02;
output  [31:0]  wr_reg_03;
output  [31:0]  wr_reg_04;
output  [31:0]  wr_reg_05;
output  [31:0]  wr_reg_06;
output  [31:0]  wr_reg_07;
output  [31:0]  wr_reg_08;
output  [31:0]  wr_reg_09;
output  [31:0]  wr_reg_10;
output  [31:0]  wr_reg_11;
output  [31:0]  wr_reg_12;
output  [31:0]  wr_reg_13;
output  [31:0]  wr_reg_14;
output  [31:0]  wr_reg_15;
output  [31:0]  wr_reg_16;
output  [31:0]  wr_reg_17;
output  [31:0]  wr_reg_18;
output  [31:0]  wr_reg_19;
output  [31:0]  wr_reg_20;
output  [31:0]  wr_reg_21;
output  [31:0]  wr_reg_22;
output  [31:0]  wr_reg_23;
output  [31:0]  wr_reg_24;
output  [31:0]  wr_reg_25;
output  [31:0]  wr_reg_26;
output  [31:0]  wr_reg_27;
output  [31:0]  wr_reg_28;
output  [31:0]  wr_reg_29;
output  [31:0]  wr_reg_30;
output  [31:0]  wr_reg_31;
output  [31:0]  wr_reg_32;
output  [31:0]  wr_reg_33;
output  [31:0]  wr_reg_34;
output  [31:0]  wr_reg_35;
output  [31:0]  wr_reg_36;
output  [31:0]  wr_reg_37;
output  [31:0]  wr_reg_38;
output  [31:0]  wr_reg_39;
output  [31:0]  wr_reg_40;
output  [31:0]  wr_reg_41;
output  [31:0]  wr_reg_42;
output  [31:0]  wr_reg_43;
output  [31:0]  wr_reg_44;
output  [31:0]  wr_reg_45;
output  [31:0]  wr_reg_46;
output  [31:0]  wr_reg_47;
output  [31:0]  wr_reg_48;
output  [31:0]  wr_reg_49;
output  [31:0]  wr_reg_50;
output  [31:0]  wr_reg_51;
output  [31:0]  wr_reg_52;
output  [31:0]  wr_reg_53;
output  [31:0]  wr_reg_54;
output  [31:0]  wr_reg_55;
output  [31:0]  wr_reg_56;
output  [31:0]  wr_reg_57;
output  [31:0]  wr_reg_58;
output  [31:0]  wr_reg_59;
output  [31:0]  wr_reg_60;

input           apb1_gpio_psel_s5;    
input           apb1_pmu_psel_s15;    
input           apb1_rtc_psel_s6;     
input   [31:0]  apb1_xx_paddr;        
input           apb1_xx_penable;      
input   [2 :0]  apb1_xx_pprot;        
input   [31:0]  apb1_xx_pwdata;       
input           apb1_xx_pwrite;       
input           cpu_pmu_dfs_ack;      
input           cpu_pmu_sleep_b;      
input           ehs_pmu_clk;          
input           els_pmu_clk;          
input   [31:0]  ioctl_gpio_ext_porta; 
input           pad_mcurst_b;         
input           test_mode;            
input           wdt_pmu_rst_b;        
output          dft_clk;              
output  [31:0]  gpio_apb1_prdata;     
output  [31:0]  gpio_ioctl_porta_dr;  
output          gpio_wic_intr;        
output          pad_core_clk;         
output          pad_core_ctim_refclk; 
output          pad_core_rst_b;       
output  [31:0]  pad_gpio_ien;         
output  [31:0]  pad_gpio_oen;         
output          pmu_apb0_pclk_en;     
output          pmu_apb0_s3clk;       
output          pmu_apb0_s3rst_b;     
output          pmu_apb1_pclk_en;     
output  [31:0]  pmu_apb1_prdata;      
output          pmu_apb1_s3clk;       
output          pmu_apb1_s3rst_b;     
output          pmu_cpu_dfs_req;      
output          pmu_dmac0_hclk;       
output          pmu_dmac0_hrst_b;     
output          pmu_dmemdummy0_hclk;  
output          pmu_dmemdummy0_hrst_b; 
output          pmu_dummy0_hclk;      
output          pmu_dummy0_hrst_b;    
output          pmu_dummy0_s3clk;     
output          pmu_dummy0_s3rst_b;   
output          pmu_dummy1_hclk;      
output          pmu_dummy1_hrst_b;    
output          pmu_dummy1_p0clk;     
output          pmu_dummy1_p0rst_b;   
output          pmu_dummy1_p1clk;     
output          pmu_dummy1_p1rst_b;   
output          pmu_dummy1_s3clk;     
output          pmu_dummy1_s3rst_b;   
output          pmu_dummy2_hclk;      
output          pmu_dummy2_hrst_b;    
output          pmu_dummy2_p0clk;     
output          pmu_dummy2_p0rst_b;   
output          pmu_dummy2_p1clk;     
output          pmu_dummy2_p1rst_b;   
output          pmu_dummy2_s3clk;     
output          pmu_dummy2_s3rst_b;   
output          pmu_dummy3_hclk;      
output          pmu_dummy3_hrst_b;    
output          pmu_dummy3_p0clk;     
output          pmu_dummy3_p0rst_b;   
output          pmu_dummy3_p1clk;     
output          pmu_dummy3_p1rst_b;   
output          pmu_dummy3_s3clk;     
output          pmu_dummy3_s3rst_b;   
output          pmu_dummy4_p0clk;     
output          pmu_dummy4_p0rst_b;   
output          pmu_dummy4_p1clk;     
output          pmu_dummy4_p1rst_b;   
output          pmu_dummy5_p0clk;     
output          pmu_dummy5_p0rst_b;   
output          pmu_dummy5_p1clk;     
output          pmu_dummy5_p1rst_b;   
output          pmu_dummy6_p1clk;     
output          pmu_dummy6_p1rst_b;   
output          pmu_dummy7_p0clk;     
output          pmu_dummy7_p0rst_b;   
output          pmu_dummy7_p1clk;     
output          pmu_dummy7_p1rst_b;   
output          pmu_dummy8_p0clk;     
output          pmu_dummy8_p0rst_b;   
output          pmu_dummy8_p1clk;     
output          pmu_dummy8_p1rst_b;   
output          pmu_dummy9_p0clk;     
output          pmu_dummy9_p0rst_b;   
output          pmu_hmain0_hclk;      
output          pmu_hmain0_hrst_b;    
output          pmu_imemdummy0_hclk;  
output          pmu_imemdummy0_hrst_b; 
output          pmu_lsbus_hclk;       
output          pmu_lsbus_hrst_b;     
output          pmu_mdummy0_hclk;     
output          pmu_mdummy0_hrst_b;   
output          pmu_mdummy1_hclk;     
output          pmu_mdummy1_hrst_b;   
output          pmu_mdummy2_hclk;     
output          pmu_mdummy2_hrst_b;   
output          pmu_pwm_p0clk;        
output          pmu_pwm_p0rst_b;      
output          pmu_smc_hclk;         
output          pmu_smc_hrst_b;       
output          pmu_sub3_s3clk;       
output          pmu_sub3_s3rst_b;     
output          pmu_tim0_p0clk;       
output          pmu_tim0_p0rst_b;     
output          pmu_tim1_p1clk;       
output          pmu_tim1_p1rst_b;     
output          pmu_tim2_p0clk;       
output          pmu_tim2_p0rst_b;     
output          pmu_tim3_p1clk;       
output          pmu_tim3_p1rst_b;     
output          pmu_tim4_p0clk;       
output          pmu_tim4_p0rst_b;     
output          pmu_tim5_p1clk;       
output          pmu_tim5_p1rst_b;     
output          pmu_tim6_p0clk;       
output          pmu_tim6_p0rst_b;     
output          pmu_tim7_p1clk;       
output          pmu_tim7_p1rst_b;     
output          pmu_usi0_p0clk;       
output          pmu_usi0_p0rst_b;     
output          pmu_usi1_p1clk;       
output          pmu_usi1_p1rst_b;     
output          pmu_usi2_p0clk;       
output          pmu_usi2_p0rst_b;     
output          pmu_wdt_p0clk;        
output          pmu_wdt_p0rst_b;      
output          pmu_wic_intr;         
output  [31:0]  rtc_apb1_prdata;      
output          rtc_wic_intr;  

wire    [31:0]  apb1_gpio_paddr;      
wire            apb1_gpio_penable;    
wire            apb1_gpio_psel_s5;    
wire    [31:0]  apb1_gpio_pwdata;     
wire            apb1_gpio_pwrite;     
wire    [31:0]  apb1_pmu_paddr;       
wire            apb1_pmu_penable;     
wire            apb1_pmu_psel_s15;    
wire    [31:0]  apb1_pmu_pwdata;      
wire            apb1_pmu_pwrite;      
wire    [31:0]  apb1_rtc_paddr;       
wire            apb1_rtc_penable;     
wire            apb1_rtc_psel_s6;     
wire    [31:0]  apb1_rtc_pwdata;      
wire            apb1_rtc_pwrite;      
wire    [31:0]  apb1_xx_paddr;        
wire            apb1_xx_penable;      
wire    [2 :0]  apb1_xx_pprot;        
wire    [31:0]  apb1_xx_pwdata;       
wire            apb1_xx_pwrite;       
wire            cpu_pmu_dfs_ack;      
wire            cpu_pmu_sleep_b;      
wire            dft_clk;              
wire            ehs_pmu_clk;          
wire            els_pmu_clk;          
wire    [31:0]  gpio0_etb_trig;       
wire    [31:0]  gpio_apb1_prdata;     
wire            gpio_gpio_intrclk_en; 
wire    [31:0]  gpio_ioctl_porta_ddr; 
wire    [31:0]  gpio_ioctl_porta_dr;  
wire            gpio_wic_intr;        
wire    [31:0]  ioctl_gpio_ext_porta; 
wire            pad_core_clk;         
wire            pad_core_ctim_refclk; 
wire            pad_core_rst_b;       
wire    [31:0]  pad_gpio_ien;         
wire    [31:0]  pad_gpio_oen;         
wire            pad_mcurst_b;         
wire            pmu_apb0_pclk_en;     
wire            pmu_apb0_s3clk;       
wire            pmu_apb0_s3rst_b;     
wire            pmu_apb1_pclk_en;     
wire    [31:0]  pmu_apb1_prdata;      
wire            pmu_apb1_s3clk;       
wire            pmu_apb1_s3rst_b;     
wire            pmu_cpu_dfs_req;      
wire            pmu_dmac0_hclk;       
wire            pmu_dmac0_hrst_b;     
wire            pmu_dmemdummy0_hclk;  
wire            pmu_dmemdummy0_hrst_b; 
wire            pmu_dummy0_hclk;      
wire            pmu_dummy0_hrst_b;    
wire            pmu_dummy0_s3clk;     
wire            pmu_dummy0_s3rst_b;   
wire            pmu_dummy1_hclk;      
wire            pmu_dummy1_hrst_b;    
wire            pmu_dummy1_p0clk;     
wire            pmu_dummy1_p0rst_b;   
wire            pmu_dummy1_p1clk;     
wire            pmu_dummy1_p1rst_b;   
wire            pmu_dummy1_s3clk;     
wire            pmu_dummy1_s3rst_b;   
wire            pmu_dummy2_hclk;      
wire            pmu_dummy2_hrst_b;    
wire            pmu_dummy2_p0clk;     
wire            pmu_dummy2_p0rst_b;   
wire            pmu_dummy2_p1clk;     
wire            pmu_dummy2_p1rst_b;   
wire            pmu_dummy2_s3clk;     
wire            pmu_dummy2_s3rst_b;   
wire            pmu_dummy3_hclk;      
wire            pmu_dummy3_hrst_b;    
wire            pmu_dummy3_p0clk;     
wire            pmu_dummy3_p0rst_b;   
wire            pmu_dummy3_p1clk;     
wire            pmu_dummy3_p1rst_b;   
wire            pmu_dummy3_s3clk;     
wire            pmu_dummy3_s3rst_b;   
wire            pmu_dummy4_p0clk;     
wire            pmu_dummy4_p0rst_b;   
wire            pmu_dummy4_p1clk;     
wire            pmu_dummy4_p1rst_b;   
wire            pmu_dummy5_p0clk;     
wire            pmu_dummy5_p0rst_b;   
wire            pmu_dummy5_p1clk;     
wire            pmu_dummy5_p1rst_b;   
wire            pmu_dummy6_p1clk;     
wire            pmu_dummy6_p1rst_b;   
wire            pmu_dummy7_p0clk;     
wire            pmu_dummy7_p0rst_b;   
wire            pmu_dummy7_p1clk;     
wire            pmu_dummy7_p1rst_b;   
wire            pmu_dummy8_p0clk;     
wire            pmu_dummy8_p0rst_b;   
wire            pmu_dummy8_p1clk;     
wire            pmu_dummy8_p1rst_b;   
wire            pmu_dummy9_p0clk;     
wire            pmu_dummy9_p0rst_b;   
wire            pmu_gpio_p1clk;       
wire            pmu_gpio_p1rst_b;     
wire            pmu_hmain0_hclk;      
wire            pmu_hmain0_hrst_b;    
wire            pmu_imemdummy0_hclk;  
wire            pmu_imemdummy0_hrst_b; 
wire            pmu_lsbus_hclk;       
wire            pmu_lsbus_hrst_b;     
wire            pmu_mdummy0_hclk;     
wire            pmu_mdummy0_hrst_b;   
wire            pmu_mdummy1_hclk;     
wire            pmu_mdummy1_hrst_b;   
wire            pmu_mdummy2_hclk;     
wire            pmu_mdummy2_hrst_b;   
wire            pmu_pwm_p0clk;        
wire            pmu_pwm_p0rst_b;      
wire            pmu_rtc_clk;          
wire            pmu_rtc_p1clk;        
wire            pmu_rtc_p1rst_b;      
wire            pmu_smc_hclk;         
wire            pmu_smc_hrst_b;       
wire            pmu_sub3_s3clk;       
wire            pmu_sub3_s3rst_b;     
wire            pmu_tim0_p0clk;       
wire            pmu_tim0_p0rst_b;     
wire            pmu_tim1_p1clk;       
wire            pmu_tim1_p1rst_b;     
wire            pmu_tim2_p0clk;       
wire            pmu_tim2_p0rst_b;     
wire            pmu_tim3_p1clk;       
wire            pmu_tim3_p1rst_b;     
wire            pmu_tim4_p0clk;       
wire            pmu_tim4_p0rst_b;     
wire            pmu_tim5_p1clk;       
wire            pmu_tim5_p1rst_b;     
wire            pmu_tim6_p0clk;       
wire            pmu_tim6_p0rst_b;     
wire            pmu_tim7_p1clk;       
wire            pmu_tim7_p1rst_b;     
wire            pmu_usi0_p0clk;       
wire            pmu_usi0_p0rst_b;     
wire            pmu_usi1_p1clk;       
wire            pmu_usi1_p1rst_b;     
wire            pmu_usi2_p0clk;       
wire            pmu_usi2_p0rst_b;     
wire            pmu_wdt_p0clk;        
wire            pmu_wdt_p0rst_b;      
wire            pmu_wic_intr;         
wire    [31:0]  rtc_apb1_prdata;      
wire            rtc_etb_trig;         
wire            rtc_wic_intr;         
wire            test_mode;            
wire            tipc_gpio0_trust;     
wire            tipc_rtc0_trust;      
wire            wdt_pmu_rst_b;        
pmu_dummy_top  x_pmu_top (
  .cpu_pmu_dfs_ack       (cpu_pmu_dfs_ack      ),
  .cpu_pmu_sleep_b       (cpu_pmu_sleep_b      ),
  .dft_clk               (dft_clk              ),
  .ehs_pmu_clk           (ehs_pmu_clk          ),
  .els_pmu_clk           (els_pmu_clk          ),
  .pad_core_clk          (pad_core_clk         ),
  .pad_core_ctim_refclk  (pad_core_ctim_refclk ),
  .pad_core_rst_b        (pad_core_rst_b       ),
  .pad_mcurst_b          (pad_mcurst_b         ),
  .paddr                 (apb1_pmu_paddr       ),
  .penable               (apb1_pmu_penable     ),
  .pmu_apb0_pclk_en      (pmu_apb0_pclk_en     ),
  .pmu_apb0_s3clk        (pmu_apb0_s3clk       ),
  .pmu_apb0_s3rst_b      (pmu_apb0_s3rst_b     ),
  .pmu_apb1_pclk_en      (pmu_apb1_pclk_en     ),
  .pmu_apb1_s3clk        (pmu_apb1_s3clk       ),
  .pmu_apb1_s3rst_b      (pmu_apb1_s3rst_b     ),
  .pmu_cpu_dfs_req       (pmu_cpu_dfs_req      ),
  .pmu_dmac0_hclk        (pmu_dmac0_hclk       ),
  .pmu_dmac0_hrst_b      (pmu_dmac0_hrst_b     ),
  .pmu_dmemdummy0_hclk   (pmu_dmemdummy0_hclk  ),
  .pmu_dmemdummy0_hrst_b (pmu_dmemdummy0_hrst_b),
  .pmu_dummy0_hclk       (pmu_dummy0_hclk      ),
  .pmu_dummy0_hrst_b     (pmu_dummy0_hrst_b    ),
  .pmu_dummy0_s3clk      (pmu_dummy0_s3clk     ),
  .pmu_dummy0_s3rst_b    (pmu_dummy0_s3rst_b   ),
  .pmu_dummy1_hclk       (pmu_dummy1_hclk      ),
  .pmu_dummy1_hrst_b     (pmu_dummy1_hrst_b    ),
  .pmu_dummy1_p0clk      (pmu_dummy1_p0clk     ),
  .pmu_dummy1_p0rst_b    (pmu_dummy1_p0rst_b   ),
  .pmu_dummy1_p1clk      (pmu_dummy1_p1clk     ),
  .pmu_dummy1_p1rst_b    (pmu_dummy1_p1rst_b   ),
  .pmu_dummy1_s3clk      (pmu_dummy1_s3clk     ),
  .pmu_dummy1_s3rst_b    (pmu_dummy1_s3rst_b   ),
  .pmu_dummy2_hclk       (pmu_dummy2_hclk      ),
  .pmu_dummy2_hrst_b     (pmu_dummy2_hrst_b    ),
  .pmu_dummy2_p0clk      (pmu_dummy2_p0clk     ),
  .pmu_dummy2_p0rst_b    (pmu_dummy2_p0rst_b   ),
  .pmu_dummy2_p1clk      (pmu_dummy2_p1clk     ),
  .pmu_dummy2_p1rst_b    (pmu_dummy2_p1rst_b   ),
  .pmu_dummy2_s3clk      (pmu_dummy2_s3clk     ),
  .pmu_dummy2_s3rst_b    (pmu_dummy2_s3rst_b   ),
  .pmu_dummy3_hclk       (pmu_dummy3_hclk      ),
  .pmu_dummy3_hrst_b     (pmu_dummy3_hrst_b    ),
  .pmu_dummy3_p0clk      (pmu_dummy3_p0clk     ),
  .pmu_dummy3_p0rst_b    (pmu_dummy3_p0rst_b   ),
  .pmu_dummy3_p1clk      (pmu_dummy3_p1clk     ),
  .pmu_dummy3_p1rst_b    (pmu_dummy3_p1rst_b   ),
  .pmu_dummy3_s3clk      (pmu_dummy3_s3clk     ),
  .pmu_dummy3_s3rst_b    (pmu_dummy3_s3rst_b   ),
  .pmu_dummy4_p0clk      (pmu_dummy4_p0clk     ),
  .pmu_dummy4_p0rst_b    (pmu_dummy4_p0rst_b   ),
  .pmu_dummy4_p1clk      (pmu_dummy4_p1clk     ),
  .pmu_dummy4_p1rst_b    (pmu_dummy4_p1rst_b   ),
  .pmu_dummy5_p0clk      (pmu_dummy5_p0clk     ),
  .pmu_dummy5_p0rst_b    (pmu_dummy5_p0rst_b   ),
  .pmu_dummy5_p1clk      (pmu_dummy5_p1clk     ),
  .pmu_dummy5_p1rst_b    (pmu_dummy5_p1rst_b   ),
  .pmu_dummy6_p1clk      (pmu_dummy6_p1clk     ),
  .pmu_dummy6_p1rst_b    (pmu_dummy6_p1rst_b   ),
  .pmu_dummy7_p0clk      (pmu_dummy7_p0clk     ),
  .pmu_dummy7_p0rst_b    (pmu_dummy7_p0rst_b   ),
  .pmu_dummy7_p1clk      (pmu_dummy7_p1clk     ),
  .pmu_dummy7_p1rst_b    (pmu_dummy7_p1rst_b   ),
  .pmu_dummy8_p0clk      (pmu_dummy8_p0clk     ),
  .pmu_dummy8_p0rst_b    (pmu_dummy8_p0rst_b   ),
  .pmu_dummy8_p1clk      (pmu_dummy8_p1clk     ),
  .pmu_dummy8_p1rst_b    (pmu_dummy8_p1rst_b   ),
  .pmu_dummy9_p0clk      (pmu_dummy9_p0clk     ),
  .pmu_dummy9_p0rst_b    (pmu_dummy9_p0rst_b   ),
  .pmu_gpio_p1clk        (pmu_gpio_p1clk       ),
  .pmu_gpio_p1rst_b      (pmu_gpio_p1rst_b     ),
  .pmu_hmain0_hclk       (pmu_hmain0_hclk      ),
  .pmu_hmain0_hrst_b     (pmu_hmain0_hrst_b    ),
  .pmu_imemdummy0_hclk   (pmu_imemdummy0_hclk  ),
  .pmu_imemdummy0_hrst_b (pmu_imemdummy0_hrst_b),
  .pmu_lsbus_hclk        (pmu_lsbus_hclk       ),
  .pmu_lsbus_hrst_b      (pmu_lsbus_hrst_b     ),
  .pmu_mdummy0_hclk      (pmu_mdummy0_hclk     ),
  .pmu_mdummy0_hrst_b    (pmu_mdummy0_hrst_b   ),
  .pmu_mdummy1_hclk      (pmu_mdummy1_hclk     ),
  .pmu_mdummy1_hrst_b    (pmu_mdummy1_hrst_b   ),
  .pmu_mdummy2_hclk      (pmu_mdummy2_hclk     ),
  .pmu_mdummy2_hrst_b    (pmu_mdummy2_hrst_b   ),
  .pmu_pwm_p0clk         (pmu_pwm_p0clk        ),
  .pmu_pwm_p0rst_b       (pmu_pwm_p0rst_b      ),
  .pmu_rtc_clk           (pmu_rtc_clk          ),
  .pmu_rtc_p1clk         (pmu_rtc_p1clk        ),
  .pmu_rtc_p1rst_b       (pmu_rtc_p1rst_b      ),
  .pmu_smc_hclk          (pmu_smc_hclk         ),
  .pmu_smc_hrst_b        (pmu_smc_hrst_b       ),
  .pmu_sub3_s3clk        (pmu_sub3_s3clk       ),
  .pmu_sub3_s3rst_b      (pmu_sub3_s3rst_b     ),
  .pmu_tim0_p0clk        (pmu_tim0_p0clk       ),
  .pmu_tim0_p0rst_b      (pmu_tim0_p0rst_b     ),
  .pmu_tim1_p1clk        (pmu_tim1_p1clk       ),
  .pmu_tim1_p1rst_b      (pmu_tim1_p1rst_b     ),
  .pmu_tim2_p0clk        (pmu_tim2_p0clk       ),
  .pmu_tim2_p0rst_b      (pmu_tim2_p0rst_b     ),
  .pmu_tim3_p1clk        (pmu_tim3_p1clk       ),
  .pmu_tim3_p1rst_b      (pmu_tim3_p1rst_b     ),
  .pmu_tim4_p0clk        (pmu_tim4_p0clk       ),
  .pmu_tim4_p0rst_b      (pmu_tim4_p0rst_b     ),
  .pmu_tim5_p1clk        (pmu_tim5_p1clk       ),
  .pmu_tim5_p1rst_b      (pmu_tim5_p1rst_b     ),
  .pmu_tim6_p0clk        (pmu_tim6_p0clk       ),
  .pmu_tim6_p0rst_b      (pmu_tim6_p0rst_b     ),
  .pmu_tim7_p1clk        (pmu_tim7_p1clk       ),
  .pmu_tim7_p1rst_b      (pmu_tim7_p1rst_b     ),
  .pmu_usi0_p0clk        (pmu_usi0_p0clk       ),
  .pmu_usi0_p0rst_b      (pmu_usi0_p0rst_b     ),
  .pmu_usi1_p1clk        (pmu_usi1_p1clk       ),
  .pmu_usi1_p1rst_b      (pmu_usi1_p1rst_b     ),
  .pmu_usi2_p0clk        (pmu_usi2_p0clk       ),
  .pmu_usi2_p0rst_b      (pmu_usi2_p0rst_b     ),
  .pmu_wdt_p0clk         (pmu_wdt_p0clk        ),
  .pmu_wdt_p0rst_b       (pmu_wdt_p0rst_b      ),
  .pmu_wic_intr          (pmu_wic_intr         ),
  .pprot                 (apb1_xx_pprot        ),
  .prdata                (pmu_apb1_prdata      ),
  .psel                  (apb1_pmu_psel_s15    ),
  .pwdata                (apb1_pmu_pwdata      ),
  .pwrite                (apb1_pmu_pwrite      ),
  .wdt_pmu_rst_b         (wdt_pmu_rst_b        )
);
rd_wr_reg_top  x_rd_wr_reg_top (
  .gpio0_etb_trig       (gpio0_etb_trig      ),
  .gpio_ext_porta       (ioctl_gpio_ext_porta),
  .gpio_intr_flag       (gpio_wic_intr       ),
  .gpio_intrclk_en      (gpio_gpio_intrclk_en),
  .gpio_porta_ddr       (gpio_ioctl_porta_ddr),
  .gpio_porta_dr        (gpio_ioctl_porta_dr ),
  .paddr                (apb1_gpio_paddr     ),
  .pclk                 (pmu_gpio_p1clk      ),
  .pclk_intr            (pmu_gpio_p1clk      ),
  .penable              (apb1_gpio_penable   ),
  .pprot                (apb1_xx_pprot       ),
  .prdata               (gpio_apb1_prdata    ),
  .presetn              (pmu_gpio_p1rst_b    ),
  .psel                 (apb1_gpio_psel_s5   ),
  .pwdata               (apb1_gpio_pwdata    ),
  .pwrite               (apb1_gpio_pwrite    ),
  .tipc_gpio0_trust     (tipc_gpio0_trust    ),
  .rd_reg_01            (rd_reg_01           ),
  .rd_reg_02            (rd_reg_02           ),
  .rd_reg_03            (rd_reg_03           ),
  .rd_reg_04            (rd_reg_04           ),
  .rd_reg_05            (rd_reg_05           ),
  .rd_reg_06            (rd_reg_06           ),
  .rd_reg_07            (rd_reg_07           ),
  .rd_reg_08            (rd_reg_08           ),
  .rd_reg_09            (rd_reg_09           ),
  .rd_reg_10            (rd_reg_10           ),
  .wr_reg_01            (wr_reg_01           ),
  .wr_reg_02            (wr_reg_02           ),
  .wr_reg_03            (wr_reg_03           ),
  .wr_reg_04            (wr_reg_04           ),
  .wr_reg_05            (wr_reg_05           ),
  .wr_reg_06            (wr_reg_06           ),
  .wr_reg_07            (wr_reg_07           ),
  .wr_reg_08            (wr_reg_08           ),
  .wr_reg_09            (wr_reg_09           ),
  .wr_reg_10            (wr_reg_10           ),
  .wr_reg_11            (wr_reg_11           ),
  .wr_reg_12            (wr_reg_12           ),
  .wr_reg_13            (wr_reg_13           ),
  .wr_reg_14            (wr_reg_14           ),
  .wr_reg_15            (wr_reg_15           ),
  .wr_reg_16            (wr_reg_16           ),
  .wr_reg_17            (wr_reg_17           ),
  .wr_reg_18            (wr_reg_18           ),
  .wr_reg_19            (wr_reg_19           ),
  .wr_reg_20            (wr_reg_20           ),
  .wr_reg_21            (wr_reg_21           ),
  .wr_reg_22            (wr_reg_22           ),
  .wr_reg_23            (wr_reg_23           ),
  .wr_reg_24            (wr_reg_24           ),
  .wr_reg_25            (wr_reg_25           ),
  .wr_reg_26            (wr_reg_26           ),
  .wr_reg_27            (wr_reg_27           ),
  .wr_reg_28            (wr_reg_28           ),
  .wr_reg_29            (wr_reg_29           ),
  .wr_reg_30            (wr_reg_30           ),
  .wr_reg_31            (wr_reg_31           ),
  .wr_reg_32            (wr_reg_32           ),
  .wr_reg_33            (wr_reg_33           ),
  .wr_reg_34            (wr_reg_34           ),
  .wr_reg_35            (wr_reg_35           ),
  .wr_reg_36            (wr_reg_36           ),
  .wr_reg_37            (wr_reg_37           ),
  .wr_reg_38            (wr_reg_38           ),
  .wr_reg_39            (wr_reg_39           ),
  .wr_reg_40            (wr_reg_40           ),
  .wr_reg_41            (wr_reg_41           ),
  .wr_reg_42            (wr_reg_42           ),
  .wr_reg_43            (wr_reg_43           ),
  .wr_reg_44            (wr_reg_44           ),
  .wr_reg_45            (wr_reg_45           ),
  .wr_reg_46            (wr_reg_46           ),
  .wr_reg_47            (wr_reg_47           ),
  .wr_reg_48            (wr_reg_48           ),
  .wr_reg_49            (wr_reg_49           ),
  .wr_reg_50            (wr_reg_50           ),
  .wr_reg_51            (wr_reg_51           ),
  .wr_reg_52            (wr_reg_52           ),
  .wr_reg_53            (wr_reg_53           ),
  .wr_reg_54            (wr_reg_54           ),
  .wr_reg_55            (wr_reg_55           ),
  .wr_reg_56            (wr_reg_56           ),
  .wr_reg_57            (wr_reg_57           ),
  .wr_reg_58            (wr_reg_58           ),
  .wr_reg_59            (wr_reg_59           ),
  .wr_reg_60            (wr_reg_60           ),
      .wr_reg_61          (wr_reg_61),
    .wr_reg_62          (wr_reg_62),
    .wr_reg_63          (wr_reg_63),
    .wr_reg_64          (wr_reg_64),
    .wr_reg_65          (wr_reg_65),
    .wr_reg_66          (wr_reg_66),
    .wr_reg_67          (wr_reg_67),
    .wr_reg_68          (wr_reg_68),
    .wr_reg_69          (wr_reg_69),
    .wr_reg_70          (wr_reg_70),
    .wr_reg_71          (wr_reg_71),
    .wr_reg_72          (wr_reg_72),
    .wr_reg_73          (wr_reg_73),
    .wr_reg_74          (wr_reg_74),
    .wr_reg_75          (wr_reg_75),
    .wr_reg_76          (wr_reg_76),
    .wr_reg_77          (wr_reg_77),
    .wr_reg_78          (wr_reg_78),
    .wr_reg_79          (wr_reg_79),
    .wr_reg_80          (wr_reg_80),
    .wr_reg_81          (wr_reg_81),
    .wr_reg_82          (wr_reg_82),
    .wr_reg_83          (wr_reg_83),
    .wr_reg_84          (wr_reg_84),
    .wr_reg_85          (wr_reg_85),
    .wr_reg_86          (wr_reg_86),
    .wr_reg_87          (wr_reg_87),
    .wr_reg_88          (wr_reg_88),
    .wr_reg_89          (wr_reg_89),
    .wr_reg_90          (wr_reg_90),
    .wr_reg_91          (wr_reg_91),
    .wr_reg_92          (wr_reg_92),
        .rd_reg_11          (rd_reg_11),
    .rd_reg_12          (rd_reg_12),
    .rd_reg_13          (rd_reg_13),
    .rd_reg_14          (rd_reg_14),
    .rd_reg_15          (rd_reg_15),
    .rd_reg_16          (rd_reg_16),
    .rd_reg_17          (rd_reg_17),
    .rd_reg_18          (rd_reg_18),
    .rd_reg_19          (rd_reg_19),
    .rd_reg_20          (rd_reg_20),
    .rd_reg_21          (rd_reg_21),
    .rd_reg_22          (rd_reg_22),
    .rd_reg_23          (rd_reg_23),
    .rd_reg_24          (rd_reg_24),
    .rd_reg_25          (rd_reg_25),
    .rd_reg_26          (rd_reg_26),
    .rd_reg_27          (rd_reg_27),
    .rd_reg_28          (rd_reg_28),
    .rd_reg_29          (rd_reg_29),
    .rd_reg_30          (rd_reg_30),
    .rd_reg_31          (rd_reg_31),
    .rd_reg_32          (rd_reg_32),
    .rd_reg_33          (rd_reg_33),
    .rd_reg_34          (rd_reg_34),
    .rd_reg_35          (rd_reg_35)

);
assign pad_gpio_oen[31:0] = ~gpio_ioctl_porta_ddr[31:0];
assign pad_gpio_ien[31:0] = gpio_ioctl_porta_ddr[31:0];
rtc0_sec_top  x_rtc0_sec_top (
  .aortc_paddr        (apb1_rtc_paddr    ),
  .aortc_pclk         (pmu_rtc_p1clk     ),
  .aortc_penable      (apb1_rtc_penable  ),
  .aortc_pprot        (apb1_xx_pprot[2:0]),
  .aortc_prdata       (rtc_apb1_prdata   ),
  .aortc_psel         (apb1_rtc_psel_s6  ),
  .aortc_pwdata       (apb1_rtc_pwdata   ),
  .aortc_pwrite       (apb1_rtc_pwrite   ),
  .aortc_rst_n        (pmu_rtc_p1rst_b   ),
  .etb_rtc_trig       (1'b0              ),
  .i_rtc_ext_clk      (pmu_rtc_clk       ),
  .rtc0_vic_intr      (rtc_wic_intr      ),
  .rtc_etb_trig       (rtc_etb_trig      ),
  .test_mode          (test_mode         ),
  .tipc_rtc0_trust    (tipc_rtc0_trust   )
);
assign tipc_rtc0_trust = 1'b0;
assign tipc_gpio0_trust = 1'b0;
assign apb1_pmu_paddr[31:0]  = apb1_xx_paddr[31:0];
assign apb1_pmu_pwdata[31:0] = apb1_xx_pwdata[31:0];
assign apb1_pmu_penable      = apb1_xx_penable;
assign apb1_pmu_pwrite       = apb1_xx_pwrite;
assign apb1_gpio_paddr[31:0]  = apb1_xx_paddr[31:0];
assign apb1_gpio_pwdata[31:0] = apb1_xx_pwdata[31:0];
assign apb1_gpio_penable      = apb1_xx_penable;
assign apb1_gpio_pwrite       = apb1_xx_pwrite;
assign apb1_rtc_paddr[31:0]  = apb1_xx_paddr[31:0];
assign apb1_rtc_pwdata[31:0] = apb1_xx_pwdata[31:0];
assign apb1_rtc_penable      = apb1_xx_penable;
assign apb1_rtc_pwrite       = apb1_xx_pwrite;
endmodule
