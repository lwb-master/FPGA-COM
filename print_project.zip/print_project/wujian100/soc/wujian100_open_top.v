/*
Copyright (c) 2019 Alibaba Group Holding Limited

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/


























`define FPGA

module wujian100_open_fpga_top(
    PAD_USI0_SCLK,
    PAD_USI0_SD0,
    PIN_EHS,
    PAD_JTAG_TCLK,
    PAD_JTAG_TMS,
    PAD_MCURST,
    sys_clk_p,
    rd_reg_01,
    rd_reg_02,
    rd_reg_03,
    rd_reg_04,
    rd_reg_05,
    rd_reg_06,
    rd_reg_07,
    rd_reg_08,
    rd_reg_09,
    rd_reg_10,
        rd_reg_11,
    rd_reg_12,
    rd_reg_13,
    rd_reg_14,
    rd_reg_15,
    rd_reg_16,
    rd_reg_17,
    rd_reg_18,
    rd_reg_19,
    rd_reg_20,
    rd_reg_21,
    rd_reg_22,
    rd_reg_23,
    rd_reg_24,
    rd_reg_25,
    rd_reg_26,
    rd_reg_27,
    rd_reg_28,
    rd_reg_29,
    rd_reg_30,
    rd_reg_31,
    rd_reg_32,
    rd_reg_33,
    rd_reg_34,
    rd_reg_35,
    wr_reg_01,
    wr_reg_02,
    wr_reg_03,
    wr_reg_04,
    wr_reg_05,
    wr_reg_06,
    wr_reg_07,
    wr_reg_08,
    wr_reg_09,
    wr_reg_10,
    wr_reg_11,
    wr_reg_12,
    wr_reg_13,
    wr_reg_14,
    wr_reg_15,
    wr_reg_16,
    wr_reg_17,
    wr_reg_18,
    wr_reg_19,
    wr_reg_20,
    wr_reg_21,
    wr_reg_22,
    wr_reg_23,
    wr_reg_24,
    wr_reg_25,
    wr_reg_26,
    wr_reg_27,
    wr_reg_28,
    wr_reg_29,
    wr_reg_30,
    wr_reg_31,
    wr_reg_32,
    wr_reg_33,
    wr_reg_34,
    wr_reg_35,
    wr_reg_36,
    wr_reg_37,
    wr_reg_38,
    wr_reg_39,
    wr_reg_40,
    wr_reg_41,
    wr_reg_42,
    wr_reg_43,
    wr_reg_44,
    wr_reg_45,
    wr_reg_46,
    wr_reg_47,
    wr_reg_48,
    wr_reg_49,
    wr_reg_50,
    wr_reg_51,
    wr_reg_52,
    wr_reg_53,
    wr_reg_54,
    wr_reg_55,
    wr_reg_56,
    wr_reg_57,
    wr_reg_58,
    wr_reg_59,
    wr_reg_60,
            wr_reg_61,
    wr_reg_62,
    wr_reg_63,
    wr_reg_64,
    wr_reg_65,
    wr_reg_66,
    wr_reg_67,
    wr_reg_68,
    wr_reg_69,
    wr_reg_70,
    wr_reg_71,
    wr_reg_72,
    wr_reg_73,
    wr_reg_74,
    wr_reg_75,
    wr_reg_76,
    wr_reg_77,
    wr_reg_78,
    wr_reg_79,
    wr_reg_80,
    wr_reg_81,
    wr_reg_82,
    wr_reg_83,
    wr_reg_84,
    wr_reg_85,
    wr_reg_86,
    wr_reg_87,
    wr_reg_88,
    wr_reg_89,
    wr_reg_90,
    wr_reg_91,
    wr_reg_92

);

input [31:0] rd_reg_11;//synthesis keep
input [31:0] rd_reg_12;//synthesis keep
input [31:0] rd_reg_13;//synthesis keep
input [31:0] rd_reg_14;//synthesis keep
input [31:0] rd_reg_15;//synthesis keep
input [31:0] rd_reg_16;//synthesis keep
input [31:0] rd_reg_17;//synthesis keep
input [31:0] rd_reg_18;//synthesis keep
input [31:0] rd_reg_19;//synthesis keep
input [31:0] rd_reg_20;//synthesis keep
input [31:0] rd_reg_21;//synthesis keep
input [31:0] rd_reg_22;//synthesis keep
input [31:0] rd_reg_23;//synthesis keep
input [31:0] rd_reg_24;//synthesis keep
input [31:0] rd_reg_25;//synthesis keep
input [31:0] rd_reg_26;//synthesis keep
input [31:0] rd_reg_27;//synthesis keep
input [31:0] rd_reg_28;//synthesis keep
input [31:0] rd_reg_29;//synthesis keep
input [31:0] rd_reg_30;//synthesis keep
input [31:0] rd_reg_31;//synthesis keep
input [31:0] rd_reg_32;//synthesis keep
input [31:0] rd_reg_33;//synthesis keep
input [31:0] rd_reg_34;//synthesis keep
input [31:0] rd_reg_35;//synthesis keep
output [31:0] wr_reg_61;//synthesis keep
output [31:0] wr_reg_62;//synthesis keep
output [31:0] wr_reg_63;//synthesis keep
output [31:0] wr_reg_64;//synthesis keep
output [31:0] wr_reg_65;//synthesis keep
output [31:0] wr_reg_66;//synthesis keep
output [31:0] wr_reg_67;//synthesis keep
output [31:0] wr_reg_68;//synthesis keep
output [31:0] wr_reg_69;//synthesis keep
output [31:0] wr_reg_70;//synthesis keep
output [31:0] wr_reg_71;//synthesis keep
output [31:0] wr_reg_72;//synthesis keep
output [31:0] wr_reg_73;//synthesis keep
output [31:0] wr_reg_74;//synthesis keep
output [31:0] wr_reg_75;//synthesis keep
output [31:0] wr_reg_76;//synthesis keep
output [31:0] wr_reg_77;//synthesis keep
output [31:0] wr_reg_78;//synthesis keep
output [31:0] wr_reg_79;//synthesis keep
output [31:0] wr_reg_80;//synthesis keep
output [31:0] wr_reg_81;//synthesis keep
output [31:0] wr_reg_82;//synthesis keep
output [31:0] wr_reg_83;//synthesis keep
output [31:0] wr_reg_84;//synthesis keep
output [31:0] wr_reg_85;//synthesis keep
output [31:0] wr_reg_86;//synthesis keep
output [31:0] wr_reg_87;//synthesis keep
output [31:0] wr_reg_88;//synthesis keep
output [31:0] wr_reg_89;//synthesis keep
output [31:0] wr_reg_90;//synthesis keep
output [31:0] wr_reg_91;//synthesis keep
output [31:0] wr_reg_92;//synthesis keep

inout           PAD_USI0_SCLK;
inout           PAD_USI0_SD0;

input PIN_EHS;
input  [31:0]  rd_reg_01;
input  [31:0]  rd_reg_02;
input  [31:0]  rd_reg_03;
input  [31:0]  rd_reg_04;
input  [31:0]  rd_reg_05;
input  [31:0]  rd_reg_06;
input  [31:0]  rd_reg_07;
input  [31:0]  rd_reg_08;
input  [31:0]  rd_reg_09;
input  [31:0]  rd_reg_10;
output  [31:0]  wr_reg_01;
output  [31:0]  wr_reg_02;
output  [31:0]  wr_reg_03;
output  [31:0]  wr_reg_04;
output  [31:0]  wr_reg_05;
output  [31:0]  wr_reg_06;
output  [31:0]  wr_reg_07;
output  [31:0]  wr_reg_08;
output  [31:0]  wr_reg_09;
output  [31:0]  wr_reg_10;
output  [31:0]  wr_reg_11;
output  [31:0]  wr_reg_12;
output  [31:0]  wr_reg_13;
output  [31:0]  wr_reg_14;
output  [31:0]  wr_reg_15;
output  [31:0]  wr_reg_16;
output  [31:0]  wr_reg_17;
output  [31:0]  wr_reg_18;
output  [31:0]  wr_reg_19;
output  [31:0]  wr_reg_20;
output  [31:0]  wr_reg_21;
output  [31:0]  wr_reg_22;
output  [31:0]  wr_reg_23;
output  [31:0]  wr_reg_24;
output  [31:0]  wr_reg_25;
output  [31:0]  wr_reg_26;
output  [31:0]  wr_reg_27;
output  [31:0]  wr_reg_28;
output  [31:0]  wr_reg_29;
output  [31:0]  wr_reg_30;
output  [31:0]  wr_reg_31;
output  [31:0]  wr_reg_32;
output  [31:0]  wr_reg_33;
output  [31:0]  wr_reg_34;
output  [31:0]  wr_reg_35;
output  [31:0]  wr_reg_36;
output  [31:0]  wr_reg_37;
output  [31:0]  wr_reg_38;
output  [31:0]  wr_reg_39;
output  [31:0]  wr_reg_40;
output  [31:0]  wr_reg_41;
output  [31:0]  wr_reg_42;
output  [31:0]  wr_reg_43;
output  [31:0]  wr_reg_44;
output  [31:0]  wr_reg_45;
output  [31:0]  wr_reg_46;
output  [31:0]  wr_reg_47;
output  [31:0]  wr_reg_48;
output  [31:0]  wr_reg_49;
output  [31:0]  wr_reg_50;
output  [31:0]  wr_reg_51;
output  [31:0]  wr_reg_52;
output  [31:0]  wr_reg_53;
output  [31:0]  wr_reg_54;
output  [31:0]  wr_reg_55;
output  [31:0]  wr_reg_56;
output  [31:0]  wr_reg_57;
output  [31:0]  wr_reg_58;
output  [31:0]  wr_reg_59;
output  [31:0]  wr_reg_60;

input              sys_clk_p  ;     
  wire rest;

    
wire           PIN_EHS;           
wire           sys_clk_10M;    
         
inout           PAD_JTAG_TCLK;         
inout           PAD_JTAG_TMS;          
inout           PAD_MCURST;            
       
wire            PAD_JTAG_TCLK;         
wire            PAD_JTAG_TMS;          
wire            PAD_MCURST;            
  
wire            PIN_EHS;               

wire            POUT_EHS;              

wire            apb0_dummy1_intr;      
wire            apb0_dummy2_intr;      
wire            apb0_dummy3_intr;      
wire            apb0_dummy4_intr;      
wire            apb0_dummy5_intr;      
wire            apb0_dummy7_intr;      
wire            apb0_dummy8_intr;      
wire            apb0_dummy9_intr;      
wire            apb1_dummy1_intr;      
wire            apb1_dummy2_intr;      
wire            apb1_dummy3_intr;      
wire            apb1_dummy4_intr;      
wire            apb1_dummy5_intr;      
wire            apb1_dummy6_intr;      
wire            apb1_dummy7_intr;      
wire            apb1_dummy8_intr;      
wire            apb1_gpio_psel_s5;     
wire            apb1_pmu_psel_s15;     
wire            apb1_rtc_psel_s6;      
wire    [31:0]  apb1_xx_paddr;         
wire            apb1_xx_penable;       
wire    [2 :0]  apb1_xx_pprot;         
wire    [31:0]  apb1_xx_pwdata;        
wire            apb1_xx_pwrite;        
wire            bist0_mode;            
wire    [31:0]  cpu_hmain0_m0_haddr;   
wire    [2 :0]  cpu_hmain0_m0_hburst;  
wire    [3 :0]  cpu_hmain0_m0_hprot;   
wire    [2 :0]  cpu_hmain0_m0_hsize;   
wire    [1 :0]  cpu_hmain0_m0_htrans;  
wire    [31:0]  cpu_hmain0_m0_hwdata;  
wire            cpu_hmain0_m0_hwrite;  
wire    [31:0]  cpu_hmain0_m1_haddr;   
wire    [2 :0]  cpu_hmain0_m1_hburst;  
wire    [3 :0]  cpu_hmain0_m1_hprot;   
wire    [2 :0]  cpu_hmain0_m1_hsize;   
wire    [1 :0]  cpu_hmain0_m1_htrans;  
wire    [31:0]  cpu_hmain0_m1_hwdata;  
wire            cpu_hmain0_m1_hwrite;  
wire    [31:0]  cpu_hmain0_m2_haddr;   
wire    [2 :0]  cpu_hmain0_m2_hburst;  
wire    [3 :0]  cpu_hmain0_m2_hprot;   
wire    [2 :0]  cpu_hmain0_m2_hsize;   
wire    [1 :0]  cpu_hmain0_m2_htrans;  
wire    [31:0]  cpu_hmain0_m2_hwdata;  
wire            cpu_hmain0_m2_hwrite;  
wire            cpu_padmux_jtg_tms_ien; 
wire            cpu_padmux_jtg_tms_o;  
wire            cpu_padmux_jtg_tms_oe; 
wire            cpu_padmux_jtg_tms_oen; 
wire            cpu_pmu_dfs_ack;       
wire            cpu_pmu_sleep_b;       
wire            dft_clk;               
wire            dmac0_wic_intr;        
wire            ehs_pmu_clk;           
wire            els_pmu_clk;           
wire    [31:0]  gpio_apb1_prdata;      
wire    [31:0]  gpio_ioctl_porta_dr;   
wire            gpio_wic_intr;         
wire    [31:0]  hmain0_cpu_m0_hrdata;  
wire            hmain0_cpu_m0_hready;  
wire    [1 :0]  hmain0_cpu_m0_hresp;   
wire    [31:0]  hmain0_cpu_m1_hrdata;  
wire            hmain0_cpu_m1_hready;  
wire    [1 :0]  hmain0_cpu_m1_hresp;   
wire    [31:0]  hmain0_cpu_m2_hrdata;  
wire            hmain0_cpu_m2_hready;  
wire    [1 :0]  hmain0_cpu_m2_hresp;   
wire    [31:0]  hmain0_ismc_s0_haddr;  
wire    [3 :0]  hmain0_ismc_s0_hprot;  
wire            hmain0_ismc_s0_hsel;   
wire    [2 :0]  hmain0_ismc_s0_hsize;  
wire    [1 :0]  hmain0_ismc_s0_htrans; 
wire    [31:0]  hmain0_ismc_s0_hwdata; 
wire            hmain0_ismc_s0_hwrite; 
wire    [31:0]  hmain0_smc_s2_haddr;   
wire    [3 :0]  hmain0_smc_s2_hprot;   
wire            hmain0_smc_s2_hsel;    
wire    [2 :0]  hmain0_smc_s2_hsize;   
wire    [1 :0]  hmain0_smc_s2_htrans;  
wire    [31:0]  hmain0_smc_s2_hwdata;  
wire            hmain0_smc_s2_hwrite;  
wire    [31:0]  hmain0_smc_s3_haddr;   
wire    [3 :0]  hmain0_smc_s3_hprot;   
wire            hmain0_smc_s3_hsel;    
wire    [2 :0]  hmain0_smc_s3_hsize;   
wire    [1 :0]  hmain0_smc_s3_htrans;  
wire    [31:0]  hmain0_smc_s3_hwdata;  
wire            hmain0_smc_s3_hwrite;  
wire    [31:0]  hmain0_smc_s4_haddr;   
wire    [3 :0]  hmain0_smc_s4_hprot;   
wire            hmain0_smc_s4_hsel;    
wire    [2 :0]  hmain0_smc_s4_hsize;   
wire    [1 :0]  hmain0_smc_s4_htrans;  
wire    [31:0]  hmain0_smc_s4_hwdata;  
wire            hmain0_smc_s4_hwrite;  
wire    [31:0]  ioctl_gpio_ext_porta;  
wire            ioctl_pwm_cap0;        
wire            ioctl_pwm_cap10;       
wire            ioctl_pwm_cap2;        
wire            ioctl_pwm_cap4;        
wire            ioctl_pwm_cap6;        
wire            ioctl_pwm_cap8;        
wire            ioctl_pwm_fault;       
wire            ioctl_usi0_nss_in;     
wire            ioctl_usi0_sclk_in;    
wire            ioctl_usi0_sd0_in;     
wire            ioctl_usi0_sd1_in;     
wire            ioctl_usi1_nss_in;     
wire            ioctl_usi1_sclk_in;    
wire            ioctl_usi1_sd0_in;     
wire            ioctl_usi1_sd1_in;     
wire            ioctl_usi2_nss_in;     
wire            ioctl_usi2_sclk_in;    
wire            ioctl_usi2_sd0_in;     
wire            ioctl_usi2_sd1_in;     
wire    [31:0]  ismc_hmain0_s0_hrdata; 
wire            ismc_hmain0_s0_hready; 
wire    [1 :0]  ismc_hmain0_s0_hresp;  
wire            lsbus_dummy0_intr;     
wire            lsbus_dummy1_intr;     
wire            lsbus_dummy2_intr;     
wire            lsbus_dummy3_intr;     
wire            main_dmemdummy0_intr;  
wire            main_dummy0_intr;      
wire            main_dummy1_intr;      
wire            main_dummy2_intr;      
wire            main_dummy3_intr;      
wire            main_imemdummy0_intr;  
wire            pad_core_clk;          
wire            pad_core_ctim_refclk;  
wire            pad_core_rst_b;        
wire    [31:0]  pad_gpio_ien;          
wire    [31:0]  pad_gpio_oen;          
wire            pad_mcurst_b;          
wire            padmux_cpu_jtg_tclk;   
wire            padmux_cpu_jtg_tms_i;  
wire            pmu_apb0_pclk_en;      
wire            pmu_apb0_s3clk;        
wire            pmu_apb0_s3rst_b;      
wire            pmu_apb1_pclk_en;      
wire    [31:0]  pmu_apb1_prdata;       
wire            pmu_apb1_s3clk;        
wire            pmu_apb1_s3rst_b;      
wire            pmu_cpu_dfs_req;       
wire            pmu_dmac0_hclk;        
wire            pmu_dmac0_hrst_b;      
wire            pmu_dmemdummy0_hclk;   
wire            pmu_dmemdummy0_hrst_b; 
wire            pmu_dummy0_hclk;       
wire            pmu_dummy0_hrst_b;     
wire            pmu_dummy0_s3clk;      
wire            pmu_dummy0_s3rst_b;    
wire            pmu_dummy1_hclk;       
wire            pmu_dummy1_hrst_b;     
wire            pmu_dummy1_p0clk;      
wire            pmu_dummy1_p0rst_b;    
wire            pmu_dummy1_p1clk;      
wire            pmu_dummy1_p1rst_b;    
wire            pmu_dummy1_s3clk;      
wire            pmu_dummy1_s3rst_b;    
wire            pmu_dummy2_hclk;       
wire            pmu_dummy2_hrst_b;     
wire            pmu_dummy2_p0clk;      
wire            pmu_dummy2_p0rst_b;    
wire            pmu_dummy2_p1clk;      
wire            pmu_dummy2_p1rst_b;    
wire            pmu_dummy2_s3clk;      
wire            pmu_dummy2_s3rst_b;    
wire            pmu_dummy3_hclk;       
wire            pmu_dummy3_hrst_b;     
wire            pmu_dummy3_p0clk;      
wire            pmu_dummy3_p0rst_b;    
wire            pmu_dummy3_p1clk;      
wire            pmu_dummy3_p1rst_b;    
wire            pmu_dummy3_s3clk;      
wire            pmu_dummy3_s3rst_b;    
wire            pmu_dummy4_p0clk;      
wire            pmu_dummy4_p0rst_b;    
wire            pmu_dummy4_p1clk;      
wire            pmu_dummy4_p1rst_b;    
wire            pmu_dummy5_p0clk;      
wire            pmu_dummy5_p0rst_b;    
wire            pmu_dummy5_p1clk;      
wire            pmu_dummy5_p1rst_b;    
wire            pmu_dummy6_p1clk;      
wire            pmu_dummy6_p1rst_b;    
wire            pmu_dummy7_p0clk;      
wire            pmu_dummy7_p0rst_b;    
wire            pmu_dummy7_p1clk;      
wire            pmu_dummy7_p1rst_b;    
wire            pmu_dummy8_p0clk;      
wire            pmu_dummy8_p0rst_b;    
wire            pmu_dummy8_p1clk;      
wire            pmu_dummy8_p1rst_b;    
wire            pmu_dummy9_p0clk;      
wire            pmu_dummy9_p0rst_b;    
wire            pmu_hmain0_hclk;       
wire            pmu_hmain0_hrst_b;     
wire            pmu_imemdummy0_hclk;   
wire            pmu_imemdummy0_hrst_b; 
wire            pmu_lsbus_hclk;        
wire            pmu_lsbus_hrst_b;      
wire            pmu_mdummy0_hclk;      
wire            pmu_mdummy0_hrst_b;    
wire            pmu_mdummy1_hclk;      
wire            pmu_mdummy1_hrst_b;    
wire            pmu_mdummy2_hclk;      
wire            pmu_mdummy2_hrst_b;    
wire            pmu_pwm_p0clk;         
wire            pmu_pwm_p0rst_b;       
wire            pmu_smc_hclk;          
wire            pmu_smc_hrst_b;        
wire            pmu_sub3_s3clk;        
wire            pmu_sub3_s3rst_b;      
wire            pmu_tim0_p0clk;        
wire            pmu_tim0_p0rst_b;      
wire            pmu_tim1_p1clk;        
wire            pmu_tim1_p1rst_b;      
wire            pmu_tim2_p0clk;        
wire            pmu_tim2_p0rst_b;      
wire            pmu_tim3_p1clk;        
wire            pmu_tim3_p1rst_b;      
wire            pmu_tim4_p0clk;        
wire            pmu_tim4_p0rst_b;      
wire            pmu_tim5_p1clk;        
wire            pmu_tim5_p1rst_b;      
wire            pmu_tim6_p0clk;        
wire            pmu_tim6_p0rst_b;      
wire            pmu_tim7_p1clk;        
wire            pmu_tim7_p1rst_b;      
wire            pmu_usi0_p0clk;        
wire            pmu_usi0_p0rst_b;      
wire            pmu_usi1_p1clk;        
wire            pmu_usi1_p1rst_b;      
wire            pmu_usi2_p0clk;        
wire            pmu_usi2_p0rst_b;      
wire            pmu_wdt_p0clk;         
wire            pmu_wdt_p0rst_b;       
wire            pmu_wic_intr;          
wire            pwm_indata1;           
wire            pwm_indata11;          
wire            pwm_indata3;           
wire            pwm_indata5;           
wire            pwm_indata7;           
wire            pwm_indata9;           
wire            pwm_ioctl_ch0;         
wire            pwm_ioctl_ch0_ie_n;    
wire            pwm_ioctl_ch0_oe_n;    
wire            pwm_ioctl_ch1;         
wire            pwm_ioctl_ch10;        
wire            pwm_ioctl_ch10_ie_n;   
wire            pwm_ioctl_ch10_oe_n;   
wire            pwm_ioctl_ch11;        
wire            pwm_ioctl_ch11_ie_n;   
wire            pwm_ioctl_ch11_oe_n;   
wire            pwm_ioctl_ch1_ie_n;    
wire            pwm_ioctl_ch1_oe_n;    
wire            pwm_ioctl_ch2;         
wire            pwm_ioctl_ch2_ie_n;    
wire            pwm_ioctl_ch2_oe_n;    
wire            pwm_ioctl_ch3;         
wire            pwm_ioctl_ch3_ie_n;    
wire            pwm_ioctl_ch3_oe_n;    
wire            pwm_ioctl_ch4;         
wire            pwm_ioctl_ch4_ie_n;    
wire            pwm_ioctl_ch4_oe_n;    
wire            pwm_ioctl_ch5;         
wire            pwm_ioctl_ch5_ie_n;    
wire            pwm_ioctl_ch5_oe_n;    
wire            pwm_ioctl_ch6;         
wire            pwm_ioctl_ch6_ie_n;    
wire            pwm_ioctl_ch6_oe_n;    
wire            pwm_ioctl_ch7;         
wire            pwm_ioctl_ch7_ie_n;    
wire            pwm_ioctl_ch7_oe_n;    
wire            pwm_ioctl_ch8;         
wire            pwm_ioctl_ch8_ie_n;    
wire            pwm_ioctl_ch8_oe_n;    
wire            pwm_ioctl_ch9;         
wire            pwm_ioctl_ch9_ie_n;    
wire            pwm_ioctl_ch9_oe_n;    
wire            pwm_wic_intr;          
wire    [31:0]  rtc_apb1_prdata;       
wire            rtc_wic_intr;          
wire            scan_en;               
wire            scan_mode;             
wire    [31:0]  smc_hmain0_s2_hrdata;  
wire            smc_hmain0_s2_hready;  
wire    [1 :0]  smc_hmain0_s2_hresp;   
wire    [31:0]  smc_hmain0_s3_hrdata;  
wire            smc_hmain0_s3_hready;  
wire    [1 :0]  smc_hmain0_s3_hresp;   
wire    [31:0]  smc_hmain0_s4_hrdata;  
wire            smc_hmain0_s4_hready;  
wire    [1 :0]  smc_hmain0_s4_hresp;   
wire            test_mode;             
wire    [1 :0]  tim0_wic_intr;         
wire    [1 :0]  tim1_wic_intr;         
wire    [1 :0]  tim2_wic_intr;         
wire    [1 :0]  tim3_wic_intr;         
wire    [1 :0]  tim4_wic_intr;         
wire    [1 :0]  tim5_wic_intr;         
wire    [1 :0]  tim6_wic_intr;         
wire    [1 :0]  tim7_wic_intr;         
wire            usi0_ioctl_nss_ie_n;   
wire            usi0_ioctl_nss_oe_n;   
wire            usi0_ioctl_nss_out;    
wire            usi0_ioctl_sclk_ie_n;  
wire            usi0_ioctl_sclk_oe_n;  
wire            usi0_ioctl_sclk_out;   
wire            usi0_ioctl_sd0_ie_n;   
wire            usi0_ioctl_sd0_oe_n;   
wire            usi0_ioctl_sd0_out;    
wire            usi0_ioctl_sd1_ie_n;   
wire            usi0_ioctl_sd1_oe_n;   
wire            usi0_ioctl_sd1_out;    
wire            usi0_wic_intr;         
wire            usi1_ioctl_nss_ie_n;   
wire            usi1_ioctl_nss_oe_n;   
wire            usi1_ioctl_nss_out;    
wire            usi1_ioctl_sclk_ie_n;  
wire            usi1_ioctl_sclk_oe_n;  
wire            usi1_ioctl_sclk_out;   
wire            usi1_ioctl_sd0_ie_n;   
wire            usi1_ioctl_sd0_oe_n;   
wire            usi1_ioctl_sd0_out;    
wire            usi1_ioctl_sd1_ie_n;   
wire            usi1_ioctl_sd1_oe_n;   
wire            usi1_ioctl_sd1_out;    
wire            usi1_wic_intr;         
wire            usi2_ioctl_nss_ie_n;   
wire            usi2_ioctl_nss_oe_n;   
wire            usi2_ioctl_nss_out;    
wire            usi2_ioctl_sclk_ie_n;  
wire            usi2_ioctl_sclk_oe_n;  
wire            usi2_ioctl_sclk_out;   
wire            usi2_ioctl_sd0_ie_n;   
wire            usi2_ioctl_sd0_oe_n;   
wire            usi2_ioctl_sd0_out;    
wire            usi2_ioctl_sd1_ie_n;   
wire            usi2_ioctl_sd1_oe_n;   
wire            usi2_ioctl_sd1_out;    
wire            usi2_wic_intr;         
wire            wdt_pmu_rst_b;         
wire            wdt_wic_intr;          

aou_top  x_aou_top (
  .apb1_gpio_psel_s5     (apb1_gpio_psel_s5    ),
  .apb1_pmu_psel_s15     (apb1_pmu_psel_s15    ),
  .apb1_rtc_psel_s6      (apb1_rtc_psel_s6     ),
  .apb1_xx_paddr         (apb1_xx_paddr        ),
  .apb1_xx_penable       (apb1_xx_penable      ),
  .apb1_xx_pprot         (apb1_xx_pprot        ),
  .apb1_xx_pwdata        (apb1_xx_pwdata       ),
  .apb1_xx_pwrite        (apb1_xx_pwrite       ),
  .cpu_pmu_dfs_ack       (cpu_pmu_dfs_ack      ),
  .cpu_pmu_sleep_b       (cpu_pmu_sleep_b      ),
  .dft_clk               (dft_clk              ),
  .ehs_pmu_clk           (ehs_pmu_clk          ),
  .els_pmu_clk           (els_pmu_clk          ),
  .gpio_apb1_prdata      (gpio_apb1_prdata     ),
  .gpio_ioctl_porta_dr   (gpio_ioctl_porta_dr  ),
  .gpio_wic_intr         (gpio_wic_intr        ),
  .ioctl_gpio_ext_porta  (ioctl_gpio_ext_porta ),
  .pad_core_clk          (pad_core_clk         ),
  .pad_core_ctim_refclk  (pad_core_ctim_refclk ),
  .pad_core_rst_b        (pad_core_rst_b       ),
  .pad_gpio_ien          (pad_gpio_ien         ),
  .pad_gpio_oen          (pad_gpio_oen         ),
  .pad_mcurst_b          (pad_mcurst_b         ),
  .pmu_apb0_pclk_en      (pmu_apb0_pclk_en     ),
  .pmu_apb0_s3clk        (pmu_apb0_s3clk       ),
  .pmu_apb0_s3rst_b      (pmu_apb0_s3rst_b     ),
  .pmu_apb1_pclk_en      (pmu_apb1_pclk_en     ),
  .pmu_apb1_prdata       (pmu_apb1_prdata      ),
  .pmu_apb1_s3clk        (pmu_apb1_s3clk       ),
  .pmu_apb1_s3rst_b      (pmu_apb1_s3rst_b     ),
  .pmu_cpu_dfs_req       (pmu_cpu_dfs_req      ),
  .pmu_dmac0_hclk        (pmu_dmac0_hclk       ),
  .pmu_dmac0_hrst_b      (pmu_dmac0_hrst_b     ),
  .pmu_dmemdummy0_hclk   (pmu_dmemdummy0_hclk  ),
  .pmu_dmemdummy0_hrst_b (pmu_dmemdummy0_hrst_b),
  .pmu_dummy0_hclk       (pmu_dummy0_hclk      ),
  .pmu_dummy0_hrst_b     (pmu_dummy0_hrst_b    ),
  .pmu_dummy0_s3clk      (pmu_dummy0_s3clk     ),
  .pmu_dummy0_s3rst_b    (pmu_dummy0_s3rst_b   ),
  .pmu_dummy1_hclk       (pmu_dummy1_hclk      ),
  .pmu_dummy1_hrst_b     (pmu_dummy1_hrst_b    ),
  .pmu_dummy1_p0clk      (pmu_dummy1_p0clk     ),
  .pmu_dummy1_p0rst_b    (pmu_dummy1_p0rst_b   ),
  .pmu_dummy1_p1clk      (pmu_dummy1_p1clk     ),
  .pmu_dummy1_p1rst_b    (pmu_dummy1_p1rst_b   ),
  .pmu_dummy1_s3clk      (pmu_dummy1_s3clk     ),
  .pmu_dummy1_s3rst_b    (pmu_dummy1_s3rst_b   ),
  .pmu_dummy2_hclk       (pmu_dummy2_hclk      ),
  .pmu_dummy2_hrst_b     (pmu_dummy2_hrst_b    ),
  .pmu_dummy2_p0clk      (pmu_dummy2_p0clk     ),
  .pmu_dummy2_p0rst_b    (pmu_dummy2_p0rst_b   ),
  .pmu_dummy2_p1clk      (pmu_dummy2_p1clk     ),
  .pmu_dummy2_p1rst_b    (pmu_dummy2_p1rst_b   ),
  .pmu_dummy2_s3clk      (pmu_dummy2_s3clk     ),
  .pmu_dummy2_s3rst_b    (pmu_dummy2_s3rst_b   ),
  .pmu_dummy3_hclk       (pmu_dummy3_hclk      ),
  .pmu_dummy3_hrst_b     (pmu_dummy3_hrst_b    ),
  .pmu_dummy3_p0clk      (pmu_dummy3_p0clk     ),
  .pmu_dummy3_p0rst_b    (pmu_dummy3_p0rst_b   ),
  .pmu_dummy3_p1clk      (pmu_dummy3_p1clk     ),
  .pmu_dummy3_p1rst_b    (pmu_dummy3_p1rst_b   ),
  .pmu_dummy3_s3clk      (pmu_dummy3_s3clk     ),
  .pmu_dummy3_s3rst_b    (pmu_dummy3_s3rst_b   ),
  .pmu_dummy4_p0clk      (pmu_dummy4_p0clk     ),
  .pmu_dummy4_p0rst_b    (pmu_dummy4_p0rst_b   ),
  .pmu_dummy4_p1clk      (pmu_dummy4_p1clk     ),
  .pmu_dummy4_p1rst_b    (pmu_dummy4_p1rst_b   ),
  .pmu_dummy5_p0clk      (pmu_dummy5_p0clk     ),
  .pmu_dummy5_p0rst_b    (pmu_dummy5_p0rst_b   ),
  .pmu_dummy5_p1clk      (pmu_dummy5_p1clk     ),
  .pmu_dummy5_p1rst_b    (pmu_dummy5_p1rst_b   ),
  .pmu_dummy6_p1clk      (pmu_dummy6_p1clk     ),
  .pmu_dummy6_p1rst_b    (pmu_dummy6_p1rst_b   ),
  .pmu_dummy7_p0clk      (pmu_dummy7_p0clk     ),
  .pmu_dummy7_p0rst_b    (pmu_dummy7_p0rst_b   ),
  .pmu_dummy7_p1clk      (pmu_dummy7_p1clk     ),
  .pmu_dummy7_p1rst_b    (pmu_dummy7_p1rst_b   ),
  .pmu_dummy8_p0clk      (pmu_dummy8_p0clk     ),
  .pmu_dummy8_p0rst_b    (pmu_dummy8_p0rst_b   ),
  .pmu_dummy8_p1clk      (pmu_dummy8_p1clk     ),
  .pmu_dummy8_p1rst_b    (pmu_dummy8_p1rst_b   ),
  .pmu_dummy9_p0clk      (pmu_dummy9_p0clk     ),
  .pmu_dummy9_p0rst_b    (pmu_dummy9_p0rst_b   ),
  .pmu_hmain0_hclk       (pmu_hmain0_hclk      ),
  .pmu_hmain0_hrst_b     (pmu_hmain0_hrst_b    ),
  .pmu_imemdummy0_hclk   (pmu_imemdummy0_hclk  ),
  .pmu_imemdummy0_hrst_b (pmu_imemdummy0_hrst_b),
  .pmu_lsbus_hclk        (pmu_lsbus_hclk       ),
  .pmu_lsbus_hrst_b      (pmu_lsbus_hrst_b     ),
  .pmu_mdummy0_hclk      (pmu_mdummy0_hclk     ),
  .pmu_mdummy0_hrst_b    (pmu_mdummy0_hrst_b   ),
  .pmu_mdummy1_hclk      (pmu_mdummy1_hclk     ),
  .pmu_mdummy1_hrst_b    (pmu_mdummy1_hrst_b   ),
  .pmu_mdummy2_hclk      (pmu_mdummy2_hclk     ),
  .pmu_mdummy2_hrst_b    (pmu_mdummy2_hrst_b   ),
  .pmu_pwm_p0clk         (pmu_pwm_p0clk        ),
  .pmu_pwm_p0rst_b       (pmu_pwm_p0rst_b      ),
  .pmu_smc_hclk          (pmu_smc_hclk         ),
  .pmu_smc_hrst_b        (pmu_smc_hrst_b       ),
  .pmu_sub3_s3clk        (pmu_sub3_s3clk       ),
  .pmu_sub3_s3rst_b      (pmu_sub3_s3rst_b     ),
  .pmu_tim0_p0clk        (pmu_tim0_p0clk       ),
  .pmu_tim0_p0rst_b      (pmu_tim0_p0rst_b     ),
  .pmu_tim1_p1clk        (pmu_tim1_p1clk       ),
  .pmu_tim1_p1rst_b      (pmu_tim1_p1rst_b     ),
  .pmu_tim2_p0clk        (pmu_tim2_p0clk       ),
  .pmu_tim2_p0rst_b      (pmu_tim2_p0rst_b     ),
  .pmu_tim3_p1clk        (pmu_tim3_p1clk       ),
  .pmu_tim3_p1rst_b      (pmu_tim3_p1rst_b     ),
  .pmu_tim4_p0clk        (pmu_tim4_p0clk       ),
  .pmu_tim4_p0rst_b      (pmu_tim4_p0rst_b     ),
  .pmu_tim5_p1clk        (pmu_tim5_p1clk       ),
  .pmu_tim5_p1rst_b      (pmu_tim5_p1rst_b     ),
  .pmu_tim6_p0clk        (pmu_tim6_p0clk       ),
  .pmu_tim6_p0rst_b      (pmu_tim6_p0rst_b     ),
  .pmu_tim7_p1clk        (pmu_tim7_p1clk       ),
  .pmu_tim7_p1rst_b      (pmu_tim7_p1rst_b     ),
  .pmu_usi0_p0clk        (pmu_usi0_p0clk       ),
  .pmu_usi0_p0rst_b      (pmu_usi0_p0rst_b     ),
  .pmu_usi1_p1clk        (pmu_usi1_p1clk       ),
  .pmu_usi1_p1rst_b      (pmu_usi1_p1rst_b     ),
  .pmu_usi2_p0clk        (pmu_usi2_p0clk       ),
  .pmu_usi2_p0rst_b      (pmu_usi2_p0rst_b     ),
  .pmu_wdt_p0clk         (pmu_wdt_p0clk        ),
  .pmu_wdt_p0rst_b       (pmu_wdt_p0rst_b      ),
  .pmu_wic_intr          (pmu_wic_intr         ),
  .rtc_apb1_prdata       (rtc_apb1_prdata      ),
  .rtc_wic_intr          (rtc_wic_intr         ),
  .test_mode             (test_mode            ),
  .wdt_pmu_rst_b         (wdt_pmu_rst_b        ),
  .rd_reg_01            (rd_reg_01           ),
  .rd_reg_02            (rd_reg_02           ),
  .rd_reg_03            (rd_reg_03           ),
  .rd_reg_04            (rd_reg_04           ),
  .rd_reg_05            (rd_reg_05           ),
  .rd_reg_06            (rd_reg_06           ),
  .rd_reg_07            (rd_reg_07           ),
  .rd_reg_08            (rd_reg_08           ),
  .rd_reg_09            (rd_reg_09           ),
  .rd_reg_10            (rd_reg_10           ),
  .wr_reg_01            (wr_reg_01           ),
  .wr_reg_02            (wr_reg_02           ),
  .wr_reg_03            (wr_reg_03           ),
  .wr_reg_04            (wr_reg_04           ),
  .wr_reg_05            (wr_reg_05           ),
  .wr_reg_06            (wr_reg_06           ),
  .wr_reg_07            (wr_reg_07           ),
  .wr_reg_08            (wr_reg_08           ),
  .wr_reg_09            (wr_reg_09           ),
  .wr_reg_10            (wr_reg_10           ),
  .wr_reg_11            (wr_reg_11           ),
  .wr_reg_12            (wr_reg_12           ),
  .wr_reg_13            (wr_reg_13           ),
  .wr_reg_14            (wr_reg_14           ),
  .wr_reg_15            (wr_reg_15           ),
  .wr_reg_16            (wr_reg_16           ),
  .wr_reg_17            (wr_reg_17           ),
  .wr_reg_18            (wr_reg_18           ),
  .wr_reg_19            (wr_reg_19           ),
  .wr_reg_20            (wr_reg_20           ),
  .wr_reg_21            (wr_reg_21           ),
  .wr_reg_22            (wr_reg_22           ),
  .wr_reg_23            (wr_reg_23           ),
  .wr_reg_24            (wr_reg_24           ),
  .wr_reg_25            (wr_reg_25           ),
  .wr_reg_26            (wr_reg_26           ),
  .wr_reg_27            (wr_reg_27           ),
  .wr_reg_28            (wr_reg_28           ),
  .wr_reg_29            (wr_reg_29           ),
  .wr_reg_30            (wr_reg_30           ),
  .wr_reg_31            (wr_reg_31           ),
  .wr_reg_32            (wr_reg_32           ),
  .wr_reg_33            (wr_reg_33           ),
  .wr_reg_34            (wr_reg_34           ),
  .wr_reg_35            (wr_reg_35           ),
  .wr_reg_36            (wr_reg_36           ),
  .wr_reg_37            (wr_reg_37           ),
  .wr_reg_38            (wr_reg_38           ),
  .wr_reg_39            (wr_reg_39           ),
  .wr_reg_40            (wr_reg_40           ),
  .wr_reg_41            (wr_reg_41           ),
  .wr_reg_42            (wr_reg_42           ),
  .wr_reg_43            (wr_reg_43           ),
  .wr_reg_44            (wr_reg_44           ),
  .wr_reg_45            (wr_reg_45           ),
  .wr_reg_46            (wr_reg_46           ),
  .wr_reg_47            (wr_reg_47           ),
  .wr_reg_48            (wr_reg_48           ),
  .wr_reg_49            (wr_reg_49           ),
  .wr_reg_50            (wr_reg_50           ),
  .wr_reg_51            (wr_reg_51           ),
  .wr_reg_52            (wr_reg_52           ),
  .wr_reg_53            (wr_reg_53           ),
  .wr_reg_54            (wr_reg_54           ),
  .wr_reg_55            (wr_reg_55           ),
  .wr_reg_56            (wr_reg_56           ),
  .wr_reg_57            (wr_reg_57           ),
  .wr_reg_58            (wr_reg_58           ),
  .wr_reg_59            (wr_reg_59           ),
  .wr_reg_60            (wr_reg_60           ),
        .wr_reg_61          (wr_reg_61),
    .wr_reg_62          (wr_reg_62),
    .wr_reg_63          (wr_reg_63),
    .wr_reg_64          (wr_reg_64),
    .wr_reg_65          (wr_reg_65),
    .wr_reg_66          (wr_reg_66),
    .wr_reg_67          (wr_reg_67),
    .wr_reg_68          (wr_reg_68),
    .wr_reg_69          (wr_reg_69),
    .wr_reg_70          (wr_reg_70),
    .wr_reg_71          (wr_reg_71),
    .wr_reg_72          (wr_reg_72),
    .wr_reg_73          (wr_reg_73),
    .wr_reg_74          (wr_reg_74),
    .wr_reg_75          (wr_reg_75),
    .wr_reg_76          (wr_reg_76),
    .wr_reg_77          (wr_reg_77),
    .wr_reg_78          (wr_reg_78),
    .wr_reg_79          (wr_reg_79),
    .wr_reg_80          (wr_reg_80),
    .wr_reg_81          (wr_reg_81),
    .wr_reg_82          (wr_reg_82),
    .wr_reg_83          (wr_reg_83),
    .wr_reg_84          (wr_reg_84),
    .wr_reg_85          (wr_reg_85),
    .wr_reg_86          (wr_reg_86),
    .wr_reg_87          (wr_reg_87),
    .wr_reg_88          (wr_reg_88),
    .wr_reg_89          (wr_reg_89),
    .wr_reg_90          (wr_reg_90),
    .wr_reg_91          (wr_reg_91),
    .wr_reg_92          (wr_reg_92),
        .rd_reg_11          (rd_reg_11),
    .rd_reg_12          (rd_reg_12),
    .rd_reg_13          (rd_reg_13),
    .rd_reg_14          (rd_reg_14),
    .rd_reg_15          (rd_reg_15),
    .rd_reg_16          (rd_reg_16),
    .rd_reg_17          (rd_reg_17),
    .rd_reg_18          (rd_reg_18),
    .rd_reg_19          (rd_reg_19),
    .rd_reg_20          (rd_reg_20),
    .rd_reg_21          (rd_reg_21),
    .rd_reg_22          (rd_reg_22),
    .rd_reg_23          (rd_reg_23),
    .rd_reg_24          (rd_reg_24),
    .rd_reg_25          (rd_reg_25),
    .rd_reg_26          (rd_reg_26),
    .rd_reg_27          (rd_reg_27),
    .rd_reg_28          (rd_reg_28),
    .rd_reg_29          (rd_reg_29),
    .rd_reg_30          (rd_reg_30),
    .rd_reg_31          (rd_reg_31),
    .rd_reg_32          (rd_reg_32),
    .rd_reg_33          (rd_reg_33),
    .rd_reg_34          (rd_reg_34),
    .rd_reg_35          (rd_reg_35)
);




pdu_top  x_pdu_top (
  .apb0_dummy1_intr      (apb0_dummy1_intr     ),
  .apb0_dummy2_intr      (apb0_dummy2_intr     ),
  .apb0_dummy3_intr      (apb0_dummy3_intr     ),
  .apb0_dummy4_intr      (apb0_dummy4_intr     ),
  .apb0_dummy5_intr      (apb0_dummy5_intr     ),
  .apb0_dummy7_intr      (apb0_dummy7_intr     ),
  .apb0_dummy8_intr      (apb0_dummy8_intr     ),
  .apb0_dummy9_intr      (apb0_dummy9_intr     ),
  .apb1_dummy1_intr      (apb1_dummy1_intr     ),
  .apb1_dummy2_intr      (apb1_dummy2_intr     ),
  .apb1_dummy3_intr      (apb1_dummy3_intr     ),
  .apb1_dummy4_intr      (apb1_dummy4_intr     ),
  .apb1_dummy5_intr      (apb1_dummy5_intr     ),
  .apb1_dummy6_intr      (apb1_dummy6_intr     ),
  .apb1_dummy7_intr      (apb1_dummy7_intr     ),
  .apb1_dummy8_intr      (apb1_dummy8_intr     ),
  .apb1_gpio_psel_s5     (apb1_gpio_psel_s5    ),
  .apb1_pmu_psel_s15     (apb1_pmu_psel_s15    ),
  .apb1_rtc_psel_s6      (apb1_rtc_psel_s6     ),
  .apb1_xx_paddr         (apb1_xx_paddr        ),
  .apb1_xx_penable       (apb1_xx_penable      ),
  .apb1_xx_pprot         (apb1_xx_pprot        ),
  .apb1_xx_pwdata        (apb1_xx_pwdata       ),
  .apb1_xx_pwrite        (apb1_xx_pwrite       ),
  .cpu_hmain0_m0_haddr   (cpu_hmain0_m0_haddr  ),
  .cpu_hmain0_m0_hburst  (cpu_hmain0_m0_hburst ),
  .cpu_hmain0_m0_hprot   (cpu_hmain0_m0_hprot  ),
  .cpu_hmain0_m0_hsize   (cpu_hmain0_m0_hsize  ),
  .cpu_hmain0_m0_htrans  (cpu_hmain0_m0_htrans ),
  .cpu_hmain0_m0_hwdata  (cpu_hmain0_m0_hwdata ),
  .cpu_hmain0_m0_hwrite  (cpu_hmain0_m0_hwrite ),
  .cpu_hmain0_m1_haddr   (cpu_hmain0_m1_haddr  ),
  .cpu_hmain0_m1_hburst  (cpu_hmain0_m1_hburst ),
  .cpu_hmain0_m1_hprot   (cpu_hmain0_m1_hprot  ),
  .cpu_hmain0_m1_hsize   (cpu_hmain0_m1_hsize  ),
  .cpu_hmain0_m1_htrans  (cpu_hmain0_m1_htrans ),
  .cpu_hmain0_m1_hwdata  (cpu_hmain0_m1_hwdata ),
  .cpu_hmain0_m1_hwrite  (cpu_hmain0_m1_hwrite ),
  .cpu_hmain0_m2_haddr   (cpu_hmain0_m2_haddr  ),
  .cpu_hmain0_m2_hburst  (cpu_hmain0_m2_hburst ),
  .cpu_hmain0_m2_hprot   (cpu_hmain0_m2_hprot  ),
  .cpu_hmain0_m2_hsize   (cpu_hmain0_m2_hsize  ),
  .cpu_hmain0_m2_htrans  (cpu_hmain0_m2_htrans ),
  .cpu_hmain0_m2_hwdata  (cpu_hmain0_m2_hwdata ),
  .cpu_hmain0_m2_hwrite  (cpu_hmain0_m2_hwrite ),
  .dmac0_wic_intr        (dmac0_wic_intr       ),
  .gpio_apb1_prdata      (gpio_apb1_prdata     ),
  .hmain0_cpu_m0_hrdata  (hmain0_cpu_m0_hrdata ),
  .hmain0_cpu_m0_hready  (hmain0_cpu_m0_hready ),
  .hmain0_cpu_m0_hresp   (hmain0_cpu_m0_hresp  ),
  .hmain0_cpu_m1_hrdata  (hmain0_cpu_m1_hrdata ),
  .hmain0_cpu_m1_hready  (hmain0_cpu_m1_hready ),
  .hmain0_cpu_m1_hresp   (hmain0_cpu_m1_hresp  ),
  .hmain0_cpu_m2_hrdata  (hmain0_cpu_m2_hrdata ),
  .hmain0_cpu_m2_hready  (hmain0_cpu_m2_hready ),
  .hmain0_cpu_m2_hresp   (hmain0_cpu_m2_hresp  ),
  .hmain0_ismc_s0_haddr  (hmain0_ismc_s0_haddr ),
  .hmain0_ismc_s0_hprot  (hmain0_ismc_s0_hprot ),
  .hmain0_ismc_s0_hsel   (hmain0_ismc_s0_hsel  ),
  .hmain0_ismc_s0_hsize  (hmain0_ismc_s0_hsize ),
  .hmain0_ismc_s0_htrans (hmain0_ismc_s0_htrans),
  .hmain0_ismc_s0_hwdata (hmain0_ismc_s0_hwdata),
  .hmain0_ismc_s0_hwrite (hmain0_ismc_s0_hwrite),
  .hmain0_smc_s2_haddr   (hmain0_smc_s2_haddr  ),
  .hmain0_smc_s2_hprot   (hmain0_smc_s2_hprot  ),
  .hmain0_smc_s2_hsel    (hmain0_smc_s2_hsel   ),
  .hmain0_smc_s2_hsize   (hmain0_smc_s2_hsize  ),
  .hmain0_smc_s2_htrans  (hmain0_smc_s2_htrans ),
  .hmain0_smc_s2_hwdata  (hmain0_smc_s2_hwdata ),
  .hmain0_smc_s2_hwrite  (hmain0_smc_s2_hwrite ),
  .hmain0_smc_s3_haddr   (hmain0_smc_s3_haddr  ),
  .hmain0_smc_s3_hprot   (hmain0_smc_s3_hprot  ),
  .hmain0_smc_s3_hsel    (hmain0_smc_s3_hsel   ),
  .hmain0_smc_s3_hsize   (hmain0_smc_s3_hsize  ),
  .hmain0_smc_s3_htrans  (hmain0_smc_s3_htrans ),
  .hmain0_smc_s3_hwdata  (hmain0_smc_s3_hwdata ),
  .hmain0_smc_s3_hwrite  (hmain0_smc_s3_hwrite ),
  .hmain0_smc_s4_haddr   (hmain0_smc_s4_haddr  ),
  .hmain0_smc_s4_hprot   (hmain0_smc_s4_hprot  ),
  .hmain0_smc_s4_hsel    (hmain0_smc_s4_hsel   ),
  .hmain0_smc_s4_hsize   (hmain0_smc_s4_hsize  ),
  .hmain0_smc_s4_htrans  (hmain0_smc_s4_htrans ),
  .hmain0_smc_s4_hwdata  (hmain0_smc_s4_hwdata ),
  .hmain0_smc_s4_hwrite  (hmain0_smc_s4_hwrite ),
  .ioctl_pwm_cap0        (ioctl_pwm_cap0       ),
  .ioctl_pwm_cap10       (ioctl_pwm_cap10      ),
  .ioctl_pwm_cap2        (ioctl_pwm_cap2       ),
  .ioctl_pwm_cap4        (ioctl_pwm_cap4       ),
  .ioctl_pwm_cap6        (ioctl_pwm_cap6       ),
  .ioctl_pwm_cap8        (ioctl_pwm_cap8       ),
  .ioctl_pwm_fault       (ioctl_pwm_fault      ),
  .ioctl_usi0_nss_in     (ioctl_usi0_nss_in    ),
  .ioctl_usi0_sclk_in    (ioctl_usi0_sclk_in   ),
  .ioctl_usi0_sd0_in     (ioctl_usi0_sd0_in    ),
  .ioctl_usi0_sd1_in     (ioctl_usi0_sd1_in    ),
  .ioctl_usi1_nss_in     (ioctl_usi1_nss_in    ),
  .ioctl_usi1_sclk_in    (ioctl_usi1_sclk_in   ),
  .ioctl_usi1_sd0_in     (ioctl_usi1_sd0_in    ),
  .ioctl_usi1_sd1_in     (ioctl_usi1_sd1_in    ),
  .ioctl_usi2_nss_in     (ioctl_usi2_nss_in    ),
  .ioctl_usi2_sclk_in    (ioctl_usi2_sclk_in   ),
  .ioctl_usi2_sd0_in     (ioctl_usi2_sd0_in    ),
  .ioctl_usi2_sd1_in     (ioctl_usi2_sd1_in    ),
  .ismc_hmain0_s0_hrdata (ismc_hmain0_s0_hrdata),
  .ismc_hmain0_s0_hready (ismc_hmain0_s0_hready),
  .ismc_hmain0_s0_hresp  (ismc_hmain0_s0_hresp ),
  .lsbus_dummy0_intr     (lsbus_dummy0_intr    ),
  .lsbus_dummy1_intr     (lsbus_dummy1_intr    ),
  .lsbus_dummy2_intr     (lsbus_dummy2_intr    ),
  .lsbus_dummy3_intr     (lsbus_dummy3_intr    ),
  .main_dmemdummy0_intr  (main_dmemdummy0_intr ),
  .main_dummy0_intr      (main_dummy0_intr     ),
  .main_dummy1_intr      (main_dummy1_intr     ),
  .main_dummy2_intr      (main_dummy2_intr     ),
  .main_dummy3_intr      (main_dummy3_intr     ),
  .main_imemdummy0_intr  (main_imemdummy0_intr ),
  .pmu_apb0_pclk_en      (pmu_apb0_pclk_en     ),
  .pmu_apb0_s3clk        (pmu_apb0_s3clk       ),
  .pmu_apb0_s3rst_b      (pmu_apb0_s3rst_b     ),
  .pmu_apb1_pclk_en      (pmu_apb1_pclk_en     ),
  .pmu_apb1_prdata       (pmu_apb1_prdata      ),
  .pmu_apb1_s3clk        (pmu_apb1_s3clk       ),
  .pmu_apb1_s3rst_b      (pmu_apb1_s3rst_b     ),
  .pmu_dmac0_hclk        (pmu_dmac0_hclk       ),
  .pmu_dmac0_hrst_b      (pmu_dmac0_hrst_b     ),
  .pmu_dmemdummy0_hclk   (pmu_dmemdummy0_hclk  ),
  .pmu_dmemdummy0_hrst_b (pmu_dmemdummy0_hrst_b),
  .pmu_dummy0_hclk       (pmu_dummy0_hclk      ),
  .pmu_dummy0_hrst_b     (pmu_dummy0_hrst_b    ),
  .pmu_dummy0_s3clk      (pmu_dummy0_s3clk     ),
  .pmu_dummy0_s3rst_b    (pmu_dummy0_s3rst_b   ),
  .pmu_dummy1_hclk       (pmu_dummy1_hclk      ),
  .pmu_dummy1_hrst_b     (pmu_dummy1_hrst_b    ),
  .pmu_dummy1_p0clk      (pmu_dummy1_p0clk     ),
  .pmu_dummy1_p0rst_b    (pmu_dummy1_p0rst_b   ),
  .pmu_dummy1_p1clk      (pmu_dummy1_p1clk     ),
  .pmu_dummy1_p1rst_b    (pmu_dummy1_p1rst_b   ),
  .pmu_dummy1_s3clk      (pmu_dummy1_s3clk     ),
  .pmu_dummy1_s3rst_b    (pmu_dummy1_s3rst_b   ),
  .pmu_dummy2_hclk       (pmu_dummy2_hclk      ),
  .pmu_dummy2_hrst_b     (pmu_dummy2_hrst_b    ),
  .pmu_dummy2_p0clk      (pmu_dummy2_p0clk     ),
  .pmu_dummy2_p0rst_b    (pmu_dummy2_p0rst_b   ),
  .pmu_dummy2_p1clk      (pmu_dummy2_p1clk     ),
  .pmu_dummy2_p1rst_b    (pmu_dummy2_p1rst_b   ),
  .pmu_dummy2_s3clk      (pmu_dummy2_s3clk     ),
  .pmu_dummy2_s3rst_b    (pmu_dummy2_s3rst_b   ),
  .pmu_dummy3_hclk       (pmu_dummy3_hclk      ),
  .pmu_dummy3_hrst_b     (pmu_dummy3_hrst_b    ),
  .pmu_dummy3_p0clk      (pmu_dummy3_p0clk     ),
  .pmu_dummy3_p0rst_b    (pmu_dummy3_p0rst_b   ),
  .pmu_dummy3_p1clk      (pmu_dummy3_p1clk     ),
  .pmu_dummy3_p1rst_b    (pmu_dummy3_p1rst_b   ),
  .pmu_dummy3_s3clk      (pmu_dummy3_s3clk     ),
  .pmu_dummy3_s3rst_b    (pmu_dummy3_s3rst_b   ),
  .pmu_dummy4_p0clk      (pmu_dummy4_p0clk     ),
  .pmu_dummy4_p0rst_b    (pmu_dummy4_p0rst_b   ),
  .pmu_dummy4_p1clk      (pmu_dummy4_p1clk     ),
  .pmu_dummy4_p1rst_b    (pmu_dummy4_p1rst_b   ),
  .pmu_dummy5_p0clk      (pmu_dummy5_p0clk     ),
  .pmu_dummy5_p0rst_b    (pmu_dummy5_p0rst_b   ),
  .pmu_dummy5_p1clk      (pmu_dummy5_p1clk     ),
  .pmu_dummy5_p1rst_b    (pmu_dummy5_p1rst_b   ),
  .pmu_dummy6_p1clk      (pmu_dummy6_p1clk     ),
  .pmu_dummy6_p1rst_b    (pmu_dummy6_p1rst_b   ),
  .pmu_dummy7_p0clk      (pmu_dummy7_p0clk     ),
  .pmu_dummy7_p0rst_b    (pmu_dummy7_p0rst_b   ),
  .pmu_dummy7_p1clk      (pmu_dummy7_p1clk     ),
  .pmu_dummy7_p1rst_b    (pmu_dummy7_p1rst_b   ),
  .pmu_dummy8_p0clk      (pmu_dummy8_p0clk     ),
  .pmu_dummy8_p0rst_b    (pmu_dummy8_p0rst_b   ),
  .pmu_dummy8_p1clk      (pmu_dummy8_p1clk     ),
  .pmu_dummy8_p1rst_b    (pmu_dummy8_p1rst_b   ),
  .pmu_dummy9_p0clk      (pmu_dummy9_p0clk     ),
  .pmu_dummy9_p0rst_b    (pmu_dummy9_p0rst_b   ),
  .pmu_hmain0_hclk       (pmu_hmain0_hclk      ),
  .pmu_hmain0_hrst_b     (pmu_hmain0_hrst_b    ),
  .pmu_imemdummy0_hclk   (pmu_imemdummy0_hclk  ),
  .pmu_imemdummy0_hrst_b (pmu_imemdummy0_hrst_b),
  .pmu_lsbus_hclk        (pmu_lsbus_hclk       ),
  .pmu_lsbus_hrst_b      (pmu_lsbus_hrst_b     ),
  .pmu_mdummy0_hclk      (pmu_mdummy0_hclk     ),
  .pmu_mdummy0_hrst_b    (pmu_mdummy0_hrst_b   ),
  .pmu_mdummy1_hclk      (pmu_mdummy1_hclk     ),
  .pmu_mdummy1_hrst_b    (pmu_mdummy1_hrst_b   ),
  .pmu_mdummy2_hclk      (pmu_mdummy2_hclk     ),
  .pmu_mdummy2_hrst_b    (pmu_mdummy2_hrst_b   ),
  .pmu_pwm_p0clk         (pmu_pwm_p0clk        ),
  .pmu_pwm_p0rst_b       (pmu_pwm_p0rst_b      ),
  .pmu_sub3_s3clk        (pmu_sub3_s3clk       ),
  .pmu_sub3_s3rst_b      (pmu_sub3_s3rst_b     ),
  .pmu_tim0_p0clk        (pmu_tim0_p0clk       ),
  .pmu_tim0_p0rst_b      (pmu_tim0_p0rst_b     ),
  .pmu_tim1_p1clk        (pmu_tim1_p1clk       ),
  .pmu_tim1_p1rst_b      (pmu_tim1_p1rst_b     ),
  .pmu_tim2_p0clk        (pmu_tim2_p0clk       ),
  .pmu_tim2_p0rst_b      (pmu_tim2_p0rst_b     ),
  .pmu_tim3_p1clk        (pmu_tim3_p1clk       ),
  .pmu_tim3_p1rst_b      (pmu_tim3_p1rst_b     ),
  .pmu_tim4_p0clk        (pmu_tim4_p0clk       ),
  .pmu_tim4_p0rst_b      (pmu_tim4_p0rst_b     ),
  .pmu_tim5_p1clk        (pmu_tim5_p1clk       ),
  .pmu_tim5_p1rst_b      (pmu_tim5_p1rst_b     ),
  .pmu_tim6_p0clk        (pmu_tim6_p0clk       ),
  .pmu_tim6_p0rst_b      (pmu_tim6_p0rst_b     ),
  .pmu_tim7_p1clk        (pmu_tim7_p1clk       ),
  .pmu_tim7_p1rst_b      (pmu_tim7_p1rst_b     ),
  .pmu_usi0_p0clk        (pmu_usi0_p0clk       ),
  .pmu_usi0_p0rst_b      (pmu_usi0_p0rst_b     ),
  .pmu_usi1_p1clk        (pmu_usi1_p1clk       ),
  .pmu_usi1_p1rst_b      (pmu_usi1_p1rst_b     ),
  .pmu_usi2_p0clk        (pmu_usi2_p0clk       ),
  .pmu_usi2_p0rst_b      (pmu_usi2_p0rst_b     ),
  .pmu_wdt_p0clk         (pmu_wdt_p0clk        ),
  .pmu_wdt_p0rst_b       (pmu_wdt_p0rst_b      ),
  .pwm_ioctl_ch0         (pwm_ioctl_ch0        ),
  .pwm_ioctl_ch0_oe_n    (pwm_ioctl_ch0_oe_n   ),
  .pwm_ioctl_ch1         (pwm_ioctl_ch1        ),
  .pwm_ioctl_ch10        (pwm_ioctl_ch10       ),
  .pwm_ioctl_ch10_oe_n   (pwm_ioctl_ch10_oe_n  ),
  .pwm_ioctl_ch11        (pwm_ioctl_ch11       ),
  .pwm_ioctl_ch11_oe_n   (pwm_ioctl_ch11_oe_n  ),
  .pwm_ioctl_ch1_oe_n    (pwm_ioctl_ch1_oe_n   ),
  .pwm_ioctl_ch2         (pwm_ioctl_ch2        ),
  .pwm_ioctl_ch2_oe_n    (pwm_ioctl_ch2_oe_n   ),
  .pwm_ioctl_ch3         (pwm_ioctl_ch3        ),
  .pwm_ioctl_ch3_oe_n    (pwm_ioctl_ch3_oe_n   ),
  .pwm_ioctl_ch4         (pwm_ioctl_ch4        ),
  .pwm_ioctl_ch4_oe_n    (pwm_ioctl_ch4_oe_n   ),
  .pwm_ioctl_ch5         (pwm_ioctl_ch5        ),
  .pwm_ioctl_ch5_oe_n    (pwm_ioctl_ch5_oe_n   ),
  .pwm_ioctl_ch6         (pwm_ioctl_ch6        ),
  .pwm_ioctl_ch6_oe_n    (pwm_ioctl_ch6_oe_n   ),
  .pwm_ioctl_ch7         (pwm_ioctl_ch7        ),
  .pwm_ioctl_ch7_oe_n    (pwm_ioctl_ch7_oe_n   ),
  .pwm_ioctl_ch8         (pwm_ioctl_ch8        ),
  .pwm_ioctl_ch8_oe_n    (pwm_ioctl_ch8_oe_n   ),
  .pwm_ioctl_ch9         (pwm_ioctl_ch9        ),
  .pwm_ioctl_ch9_oe_n    (pwm_ioctl_ch9_oe_n   ),
  .pwm_wic_intr          (pwm_wic_intr         ),
  .rtc_apb1_prdata       (rtc_apb1_prdata      ),
  .scan_mode             (scan_mode            ),
  .smc_hmain0_s2_hrdata  (smc_hmain0_s2_hrdata ),
  .smc_hmain0_s2_hready  (smc_hmain0_s2_hready ),
  .smc_hmain0_s2_hresp   (smc_hmain0_s2_hresp  ),
  .smc_hmain0_s3_hrdata  (smc_hmain0_s3_hrdata ),
  .smc_hmain0_s3_hready  (smc_hmain0_s3_hready ),
  .smc_hmain0_s3_hresp   (smc_hmain0_s3_hresp  ),
  .smc_hmain0_s4_hrdata  (smc_hmain0_s4_hrdata ),
  .smc_hmain0_s4_hready  (smc_hmain0_s4_hready ),
  .smc_hmain0_s4_hresp   (smc_hmain0_s4_hresp  ),
  .test_mode             (test_mode            ),
  .tim0_wic_intr         (tim0_wic_intr        ),
  .tim1_wic_intr         (tim1_wic_intr        ),
  .tim2_wic_intr         (tim2_wic_intr        ),
  .tim3_wic_intr         (tim3_wic_intr        ),
  .tim4_wic_intr         (tim4_wic_intr        ),
  .tim5_wic_intr         (tim5_wic_intr        ),
  .tim6_wic_intr         (tim6_wic_intr        ),
  .tim7_wic_intr         (tim7_wic_intr        ),
  .usi0_ioctl_nss_ie_n   (usi0_ioctl_nss_ie_n  ),
  .usi0_ioctl_nss_oe_n   (usi0_ioctl_nss_oe_n  ),
  .usi0_ioctl_nss_out    (usi0_ioctl_nss_out   ),
  .usi0_ioctl_sclk_ie_n  (usi0_ioctl_sclk_ie_n ),
  .usi0_ioctl_sclk_oe_n  (usi0_ioctl_sclk_oe_n ),
  .usi0_ioctl_sclk_out   (usi0_ioctl_sclk_out  ),
  .usi0_ioctl_sd0_ie_n   (usi0_ioctl_sd0_ie_n  ),
  .usi0_ioctl_sd0_oe_n   (usi0_ioctl_sd0_oe_n  ),
  .usi0_ioctl_sd0_out    (usi0_ioctl_sd0_out   ),
  .usi0_ioctl_sd1_ie_n   (usi0_ioctl_sd1_ie_n  ),
  .usi0_ioctl_sd1_oe_n   (usi0_ioctl_sd1_oe_n  ),
  .usi0_ioctl_sd1_out    (usi0_ioctl_sd1_out   ),
  .usi0_wic_intr         (usi0_wic_intr        ),
  .usi1_ioctl_nss_ie_n   (usi1_ioctl_nss_ie_n  ),
  .usi1_ioctl_nss_oe_n   (usi1_ioctl_nss_oe_n  ),
  .usi1_ioctl_nss_out    (usi1_ioctl_nss_out   ),
  .usi1_ioctl_sclk_ie_n  (usi1_ioctl_sclk_ie_n ),
  .usi1_ioctl_sclk_oe_n  (usi1_ioctl_sclk_oe_n ),
  .usi1_ioctl_sclk_out   (usi1_ioctl_sclk_out  ),
  .usi1_ioctl_sd0_ie_n   (usi1_ioctl_sd0_ie_n  ),
  .usi1_ioctl_sd0_oe_n   (usi1_ioctl_sd0_oe_n  ),
  .usi1_ioctl_sd0_out    (usi1_ioctl_sd0_out   ),
  .usi1_ioctl_sd1_ie_n   (usi1_ioctl_sd1_ie_n  ),
  .usi1_ioctl_sd1_oe_n   (usi1_ioctl_sd1_oe_n  ),
  .usi1_ioctl_sd1_out    (usi1_ioctl_sd1_out   ),
  .usi1_wic_intr         (usi1_wic_intr        ),
  .usi2_ioctl_nss_ie_n   (usi2_ioctl_nss_ie_n  ),
  .usi2_ioctl_nss_oe_n   (usi2_ioctl_nss_oe_n  ),
  .usi2_ioctl_nss_out    (usi2_ioctl_nss_out   ),
  .usi2_ioctl_sclk_ie_n  (usi2_ioctl_sclk_ie_n ),
  .usi2_ioctl_sclk_oe_n  (usi2_ioctl_sclk_oe_n ),
  .usi2_ioctl_sclk_out   (usi2_ioctl_sclk_out  ),
  .usi2_ioctl_sd0_ie_n   (usi2_ioctl_sd0_ie_n  ),
  .usi2_ioctl_sd0_oe_n   (usi2_ioctl_sd0_oe_n  ),
  .usi2_ioctl_sd0_out    (usi2_ioctl_sd0_out   ),
  .usi2_ioctl_sd1_ie_n   (usi2_ioctl_sd1_ie_n  ),
  .usi2_ioctl_sd1_oe_n   (usi2_ioctl_sd1_oe_n  ),
  .usi2_ioctl_sd1_out    (usi2_ioctl_sd1_out   ),
  .usi2_wic_intr         (usi2_wic_intr        ),
  .wdt_pmu_rst_b         (wdt_pmu_rst_b        ),
  .wdt_wic_intr          (wdt_wic_intr         )
);



core_top  x_cpu_top (
  .apb0_dummy1_intr      (apb0_dummy1_intr     ),
  .apb0_dummy2_intr      (apb0_dummy2_intr     ),
  .apb0_dummy3_intr      (apb0_dummy3_intr     ),
  .apb0_dummy4_intr      (apb0_dummy4_intr     ),
  .apb0_dummy5_intr      (apb0_dummy5_intr     ),
  .apb0_dummy7_intr      (apb0_dummy7_intr     ),
  .apb0_dummy8_intr      (apb0_dummy8_intr     ),
  .apb0_dummy9_intr      (apb0_dummy9_intr     ),
  .apb1_dummy1_intr      (apb1_dummy1_intr     ),
  .apb1_dummy2_intr      (apb1_dummy2_intr     ),
  .apb1_dummy3_intr      (apb1_dummy3_intr     ),
  .apb1_dummy4_intr      (apb1_dummy4_intr     ),
  .apb1_dummy5_intr      (apb1_dummy5_intr     ),
  .apb1_dummy6_intr      (apb1_dummy6_intr     ),
  .apb1_dummy7_intr      (apb1_dummy7_intr     ),
  .apb1_dummy8_intr      (apb1_dummy8_intr     ),
  .bist0_mode            (bist0_mode           ),
  .cpu_hmain0_m0_haddr   (cpu_hmain0_m0_haddr  ),
  .cpu_hmain0_m0_hburst  (cpu_hmain0_m0_hburst ),
  .cpu_hmain0_m0_hprot   (cpu_hmain0_m0_hprot  ),
  .cpu_hmain0_m0_hsize   (cpu_hmain0_m0_hsize  ),
  .cpu_hmain0_m0_htrans  (cpu_hmain0_m0_htrans ),
  .cpu_hmain0_m0_hwdata  (cpu_hmain0_m0_hwdata ),
  .cpu_hmain0_m0_hwrite  (cpu_hmain0_m0_hwrite ),
  .cpu_hmain0_m1_haddr   (cpu_hmain0_m1_haddr  ),
  .cpu_hmain0_m1_hburst  (cpu_hmain0_m1_hburst ),
  .cpu_hmain0_m1_hprot   (cpu_hmain0_m1_hprot  ),
  .cpu_hmain0_m1_hsize   (cpu_hmain0_m1_hsize  ),
  .cpu_hmain0_m1_htrans  (cpu_hmain0_m1_htrans ),
  .cpu_hmain0_m1_hwdata  (cpu_hmain0_m1_hwdata ),
  .cpu_hmain0_m1_hwrite  (cpu_hmain0_m1_hwrite ),
  .cpu_hmain0_m2_haddr   (cpu_hmain0_m2_haddr  ),
  .cpu_hmain0_m2_hburst  (cpu_hmain0_m2_hburst ),
  .cpu_hmain0_m2_hprot   (cpu_hmain0_m2_hprot  ),
  .cpu_hmain0_m2_hsize   (cpu_hmain0_m2_hsize  ),
  .cpu_hmain0_m2_htrans  (cpu_hmain0_m2_htrans ),
  .cpu_hmain0_m2_hwdata  (cpu_hmain0_m2_hwdata ),
  .cpu_hmain0_m2_hwrite  (cpu_hmain0_m2_hwrite ),
  .cpu_padmux_jtg_tms_o  (cpu_padmux_jtg_tms_o ),
  .cpu_padmux_jtg_tms_oe (cpu_padmux_jtg_tms_oe),
  .cpu_pmu_dfs_ack       (cpu_pmu_dfs_ack      ),
  .cpu_pmu_sleep_b       (cpu_pmu_sleep_b      ),
  .dft_clk               (dft_clk              ),
  .dmac0_wic_intr        (dmac0_wic_intr       ),
  .gpio_wic_intr         (gpio_wic_intr        ),
  .hmain0_cpu_m0_hrdata  (hmain0_cpu_m0_hrdata ),
  .hmain0_cpu_m0_hready  (hmain0_cpu_m0_hready ),
  .hmain0_cpu_m0_hresp   (hmain0_cpu_m0_hresp  ),
  .hmain0_cpu_m1_hrdata  (hmain0_cpu_m1_hrdata ),
  .hmain0_cpu_m1_hready  (hmain0_cpu_m1_hready ),
  .hmain0_cpu_m1_hresp   (hmain0_cpu_m1_hresp  ),
  .hmain0_cpu_m2_hrdata  (hmain0_cpu_m2_hrdata ),
  .hmain0_cpu_m2_hready  (hmain0_cpu_m2_hready ),
  .hmain0_cpu_m2_hresp   (hmain0_cpu_m2_hresp  ),
  .lsbus_dummy0_intr     (lsbus_dummy0_intr    ),
  .lsbus_dummy1_intr     (lsbus_dummy1_intr    ),
  .lsbus_dummy2_intr     (lsbus_dummy2_intr    ),
  .lsbus_dummy3_intr     (lsbus_dummy3_intr    ),
  .main_dmemdummy0_intr  (main_dmemdummy0_intr ),
  .main_dummy0_intr      (main_dummy0_intr     ),
  .main_dummy1_intr      (main_dummy1_intr     ),
  .main_dummy2_intr      (main_dummy2_intr     ),
  .main_dummy3_intr      (main_dummy3_intr     ),
  .main_imemdummy0_intr  (main_imemdummy0_intr ),
  .pad_core_clk          (pad_core_clk         ),
  .pad_core_ctim_refclk  (pad_core_ctim_refclk ),
  .pad_core_rst_b        (pad_core_rst_b       ),
  .padmux_cpu_jtg_tclk   (padmux_cpu_jtg_tclk  ),
  .padmux_cpu_jtg_tms_i  (padmux_cpu_jtg_tms_i ),
  .pmu_cpu_dfs_req       (pmu_cpu_dfs_req      ),
  .pmu_wic_intr          (pmu_wic_intr         ),
  .pwm_wic_intr          (pwm_wic_intr         ),
  .rtc_wic_intr          (rtc_wic_intr         ),
  .scan_en               (scan_en              ),
  .scan_mode             (scan_mode            ),
  .test_mode             (test_mode            ),
  .tim0_wic_intr         (tim0_wic_intr        ),
  .tim1_wic_intr         (tim1_wic_intr        ),
  .tim2_wic_intr         (tim2_wic_intr        ),
  .tim3_wic_intr         (tim3_wic_intr        ),
  .tim4_wic_intr         (tim4_wic_intr        ),
  .tim5_wic_intr         (tim5_wic_intr        ),
  .tim6_wic_intr         (tim6_wic_intr        ),
  .tim7_wic_intr         (tim7_wic_intr        ),
  .usi0_wic_intr         (usi0_wic_intr        ),
  .usi1_wic_intr         (usi1_wic_intr        ),
  .usi2_wic_intr         (usi2_wic_intr        ),
  .wdt_wic_intr          (wdt_wic_intr         )
);



retu_top  x_retu_top (
  .hmain0_ismc_s0_haddr  (hmain0_ismc_s0_haddr ),
  .hmain0_ismc_s0_hprot  (hmain0_ismc_s0_hprot ),
  .hmain0_ismc_s0_hsel   (hmain0_ismc_s0_hsel  ),
  .hmain0_ismc_s0_hsize  (hmain0_ismc_s0_hsize ),
  .hmain0_ismc_s0_htrans (hmain0_ismc_s0_htrans),
  .hmain0_ismc_s0_hwdata (hmain0_ismc_s0_hwdata),
  .hmain0_ismc_s0_hwrite (hmain0_ismc_s0_hwrite),
  .hmain0_smc_s2_haddr   (hmain0_smc_s2_haddr  ),
  .hmain0_smc_s2_hprot   (hmain0_smc_s2_hprot  ),
  .hmain0_smc_s2_hsel    (hmain0_smc_s2_hsel   ),
  .hmain0_smc_s2_hsize   (hmain0_smc_s2_hsize  ),
  .hmain0_smc_s2_htrans  (hmain0_smc_s2_htrans ),
  .hmain0_smc_s2_hwdata  (hmain0_smc_s2_hwdata ),
  .hmain0_smc_s2_hwrite  (hmain0_smc_s2_hwrite ),
  .hmain0_smc_s3_haddr   (hmain0_smc_s3_haddr  ),
  .hmain0_smc_s3_hprot   (hmain0_smc_s3_hprot  ),
  .hmain0_smc_s3_hsel    (hmain0_smc_s3_hsel   ),
  .hmain0_smc_s3_hsize   (hmain0_smc_s3_hsize  ),
  .hmain0_smc_s3_htrans  (hmain0_smc_s3_htrans ),
  .hmain0_smc_s3_hwdata  (hmain0_smc_s3_hwdata ),
  .hmain0_smc_s3_hwrite  (hmain0_smc_s3_hwrite ),
  .hmain0_smc_s4_haddr   (hmain0_smc_s4_haddr  ),
  .hmain0_smc_s4_hprot   (hmain0_smc_s4_hprot  ),
  .hmain0_smc_s4_hsel    (hmain0_smc_s4_hsel   ),
  .hmain0_smc_s4_hsize   (hmain0_smc_s4_hsize  ),
  .hmain0_smc_s4_htrans  (hmain0_smc_s4_htrans ),
  .hmain0_smc_s4_hwdata  (hmain0_smc_s4_hwdata ),
  .hmain0_smc_s4_hwrite  (hmain0_smc_s4_hwrite ),
  .ismc_hmain0_s0_hrdata (ismc_hmain0_s0_hrdata),
  .ismc_hmain0_s0_hready (ismc_hmain0_s0_hready),
  .ismc_hmain0_s0_hresp  (ismc_hmain0_s0_hresp ),
  .pmu_smc_hclk          (pmu_smc_hclk         ),
  .pmu_smc_hrst_b        (pmu_smc_hrst_b       ),
  .smc_hmain0_s2_hrdata  (smc_hmain0_s2_hrdata ),
  .smc_hmain0_s2_hready  (smc_hmain0_s2_hready ),
  .smc_hmain0_s2_hresp   (smc_hmain0_s2_hresp  ),
  .smc_hmain0_s3_hrdata  (smc_hmain0_s3_hrdata ),
  .smc_hmain0_s3_hready  (smc_hmain0_s3_hready ),
  .smc_hmain0_s3_hresp   (smc_hmain0_s3_hresp  ),
  .smc_hmain0_s4_hrdata  (smc_hmain0_s4_hrdata ),
  .smc_hmain0_s4_hready  (smc_hmain0_s4_hready ),
  .smc_hmain0_s4_hresp   (smc_hmain0_s4_hresp  )
);
PAD_OSC_IO  x_PAD_EHS (
  .CLK         (ehs_pmu_clk),
  .EN          (1'b1       ),
  .XOSC_IN     (PIN_EHS    ),
  .XOSC_OUT    (POUT_EHS   )
);



assign els_pmu_clk = ehs_pmu_clk;


wire PAD_rest;
// synthesis keep
PAD_DIG_IO  x_PAD_MCURST (
  .ID           (pad_mcurst_b),
  .IEN          (1'b0        ),
  .OD           (1'b1        ),
  .OEN          (1'b0        ),
  .PAD          (PAD_rest   )
);








assign cpu_padmux_jtg_tms_oen = ~cpu_padmux_jtg_tms_oe;
assign cpu_padmux_jtg_tms_ien = cpu_padmux_jtg_tms_oe;


PAD_DIG_IO  x_PAD_JTAG_TMS (
  .ID                     (padmux_cpu_jtg_tms_i  ),
  .IEN                    (cpu_padmux_jtg_tms_ien),
  .OD                     (cpu_padmux_jtg_tms_o  ),
  .OEN                    (cpu_padmux_jtg_tms_oen),
  .PAD                    (PAD_JTAG_TMS          )
);











PAD_DIG_IO  x_PAD_JTAG_TCLK (
  .ID                  (padmux_cpu_jtg_tclk),
  .IEN                 (1'b0               ),
  .OD                  (1'b0               ),
  .OEN                 (1'b1               ),
  .PAD                 (PAD_JTAG_TCLK      )
);



assign pwm_ioctl_ch0_ie_n = ~pwm_ioctl_ch0_oe_n;
assign pwm_ioctl_ch1_ie_n = ~pwm_ioctl_ch1_oe_n;
assign pwm_ioctl_ch2_ie_n = ~pwm_ioctl_ch2_oe_n;
assign pwm_ioctl_ch3_ie_n = ~pwm_ioctl_ch3_oe_n;
assign pwm_ioctl_ch4_ie_n = ~pwm_ioctl_ch4_oe_n;
assign pwm_ioctl_ch5_ie_n = ~pwm_ioctl_ch5_oe_n;
assign pwm_ioctl_ch6_ie_n = ~pwm_ioctl_ch6_oe_n;
assign pwm_ioctl_ch7_ie_n = ~pwm_ioctl_ch7_oe_n;
assign pwm_ioctl_ch8_ie_n = ~pwm_ioctl_ch8_oe_n;
assign pwm_ioctl_ch9_ie_n = ~pwm_ioctl_ch9_oe_n;
assign pwm_ioctl_ch10_ie_n = ~pwm_ioctl_ch10_oe_n;
assign pwm_ioctl_ch11_ie_n = ~pwm_ioctl_ch11_oe_n;


PAD_DIG_IO  x_PAD_USI0_SCLK (
  .ID                   (ioctl_usi0_sclk_in  ),
  .IEN                  (usi0_ioctl_sclk_ie_n),
  .OD                   (usi0_ioctl_sclk_out ),
  .OEN                  (usi0_ioctl_sclk_oe_n),
  .PAD                  (PAD_USI0_SCLK       )
);











PAD_DIG_IO  x_PAD_USI0_SD0 (
  .ID                  (ioctl_usi0_sd0_in  ),
  .IEN                 (usi0_ioctl_sd0_ie_n),
  .OD                  (usi0_ioctl_sd0_out ),
  .OEN                 (usi0_ioctl_sd0_oe_n),
  .PAD                 (PAD_USI0_SD0       )
);











PAD_DIG_IO  x_PAD_USI0_SD1 (
  .ID                  (ioctl_usi0_sd1_in  ),
  .IEN                 (usi0_ioctl_sd1_ie_n),
  .OD                  (usi0_ioctl_sd1_out ),
  .OEN                 (usi0_ioctl_sd1_oe_n),
  .PAD                 (PAD_USI0_SD1       )
);











PAD_DIG_IO  x_PAD_USI0_NSS (
  .ID                  (ioctl_usi0_nss_in  ),
  .IEN                 (usi0_ioctl_nss_ie_n),
  .OD                  (usi0_ioctl_nss_out ),
  .OEN                 (usi0_ioctl_nss_oe_n),
  .PAD                 (PAD_USI0_NSS       )
);


assign bist0_mode = 1'b0;




assign scan_en = 1'b0;
assign scan_mode = 1'b0;
assign test_mode = 1'b0;



endmodule


